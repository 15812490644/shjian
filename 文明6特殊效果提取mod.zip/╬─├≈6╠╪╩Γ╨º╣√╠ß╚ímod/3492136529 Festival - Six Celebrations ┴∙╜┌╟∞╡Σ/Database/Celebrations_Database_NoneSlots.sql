-------------------------------------
--*     Celebrations Database     *--
--*        Author:Nwflower        *--
--*         Thanks:HD2.0          *--
-------------------------------------

-- 永久政策卡
UPDATE Modifiers
SET OwnerRequirementSetId = 'NW_CELEBRATION_ERA_IS_ERA_ANCIENT'
WHERE ModifierId IN (SELECT 'MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT_' || EraType
                     FROM Eras);


UPDATE Modifiers
SET OwnerRequirementSetId = 'NW_CELEBRATION_ERA_IS_ERA_ANCIENT'
WHERE ModifierId = 'MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT';

DELETE FROM Policies WHERE PolicyType IN ('POLICY_NW_CELEBRATION_VIOD1', 'POLICY_NW_CELEBRATION_VIOD2');