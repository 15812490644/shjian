INSERT INTO CivilopediaPageLayouts(PageLayoutId, ScriptTemplate) VALUES
('CelebrationMode','Simple');

-- CivilopediaPageLayoutChapters 表插入
INSERT INTO CivilopediaPageLayoutChapters(PageLayoutId, ChapterId, SortIndex) VALUES
('CelebrationMode', 'WELCOME', 10),
('CelebrationMode', 'HAPPINESS', 20),
('CelebrationMode', 'CELEBRATIONS_EFFECT', 30),
('CelebrationMode', 'CELEBRATIONS_BACKGROUND', 40);

-- CivilopediaPages 表插入
INSERT INTO CivilopediaPages(SectionId, PageId, PageGroupId, PageLayoutId, Name, Tooltip, SortIndex) VALUES
('CONCEPTS', 'GAMEMODE_CELEBRATION', 'GAME_MODES', 'CelebrationMode', 'LOC_PEDIA_CONCEPTS_PAGE_GAMEMODE_CELEBRATION_CHAPTER_CONTENT_TITLE', '', 3);

-- CivilopediaPageSearchTerms 表插入
INSERT INTO CivilopediaPageSearchTerms(SectionId, PageId, Term) VALUES
('CONCEPTS', 'GAMEMODE_CELEBRATION', 'LOC_PEDIA_CONCEPTS_PAGE_GAMEMODE_CELEBRATION_CHAPTER_CONTENT_TITLE');