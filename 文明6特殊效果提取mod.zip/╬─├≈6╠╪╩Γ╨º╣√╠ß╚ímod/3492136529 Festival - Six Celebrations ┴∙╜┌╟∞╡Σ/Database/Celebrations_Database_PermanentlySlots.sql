-------------------------------------
--*     Celebrations Database     *--
--*        Author:Nwflower        *--
--*         Thanks:HD2.0          *--
-------------------------------------

-- 永久政策卡
UPDATE Modifiers
SET OwnerRequirementSetId = NULL
WHERE ModifierId IN (SELECT 'MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT_' || EraType
                     FROM Eras);
