-------------------------------------
--*     Celebrations Database     *--
--*        Author:Nwflower        *--
--*         Thanks:HD2.0          *--
-------------------------------------

-- 庆典表
-- 庆典类型
-- 庆典名
-- 庆典效果
-- 最早出现的时代
-- 强制过时时代
-- 是否需要效果来解锁：如果是，则会检查玩家的'Property_'||CelebrationsTypes属性，该值不为nil才会出现
-- 该词条我在千帆竞渡中使用到
-- 权重：该选项出现的权重
-- 如果玩家触发庆典时选项少于4个或者本表被删除，则会在日志中抛出错误且不会触发庆典。
CREATE TABLE IF NOT EXISTS NWflower_Celebrations
(
    CelebrationsTypes TEXT NOT NULL,
    Name              TEXT,
    Description       TEXT,
    PreEra            TEXT NOT NULL DEFAULT 'ERA_ANCIENT'
        REFERENCES Eras (EraType)
            ON UPDATE CASCADE ON DELETE SET DEFAULT,
    ObsoleteEra       TEXT          DEFAULT NULL
        REFERENCES Eras (EraType)
            ON UPDATE CASCADE ON DELETE SET DEFAULT,
    UnlocksFromEffect Integer       Default 0,
    Weight            Integer       Default 100,
    PRIMARY KEY ('CelebrationsTypes'),
    CHECK (UnlocksFromEffect IN (0, 1)),
    CHECK (Weight >= 0)
);

-- 庆典修改器
-- 庆典的效果是通过虚拟建筑间接实现的
-- 比较复杂的代码建议还是用LUA监听BuildingAddToMap事件
CREATE TABLE IF NOT EXISTS NWflower_CelebrationModifiers
(
    CelebrationsTypes TEXT NOT NULL
        REFERENCES NWflower_Celebrations (CelebrationsTypes)
            ON UPDATE CASCADE ON DELETE CASCADE,
    BuildingType      TEXT DEFAULT NULL
                           REFERENCES Buildings (BuildingType)
                               ON UPDATE CASCADE ON DELETE SET NULL,
    PRIMARY KEY ('CelebrationsTypes')
);

-- 默认庆典效果
INSERT OR
REPLACE
INTO NWflower_Celebrations (CelebrationsTypes, PreEra, ObsoleteEra)
VALUES ('NW_CELEBRATIONS_FOOD_BOOST', 'ERA_ANCIENT', 'ERA_RENAISSANCE'),
       ('NW_CELEBRATIONS_FAITH_BOOST', 'ERA_ANCIENT', 'ERA_RENAISSANCE'),
       ('NW_CELEBRATIONS_INTI', 'ERA_ANCIENT', 'ERA_RENAISSANCE'),
       ('NW_CELEBRATIONS_AMEN_BOOST', 'ERA_ANCIENT', 'ERA_INDUSTRIAL'),
       ('NW_CELEBRATIONS_ENGINEER_BOOST', 'ERA_ANCIENT', 'ERA_INDUSTRIAL'),
       ('NW_CELEBRATIONS_MELEE_BOOST', 'ERA_CLASSICAL', 'ERA_INDUSTRIAL'),
       ('NW_CELEBRATIONS_GOLD_BOOST', 'ERA_CLASSICAL', NULL),
       ('NW_CELEBRATIONS_SCIENCE_BOOST', 'ERA_CLASSICAL', NULL),
       ('NW_CELEBRATIONS_CULTURE_BOOST', 'ERA_MEDIEVAL', NULL),
       ('NW_CELEBRATIONS_MOBILIZATION', 'ERA_MEDIEVAL', NULL),
       ('NW_CELEBRATIONS_THOUGHT', 'ERA_MEDIEVAL', NULL);

INSERT INTO NWflower_Celebrations (CelebrationsTypes, PreEra, ObsoleteEra, UnlocksFromEffect)
VALUES ('NW_CELEBRATIONS_BOAT_BOOST', 'ERA_CLASSICAL', 'ERA_INDUSTRIAL', 1);

UPDATE NWflower_Celebrations
SET Name        = 'LOC_' || CelebrationsTypes || '_NAME',
    Description = 'LOC_' || CelebrationsTypes || '_DESCRIPTION'
WHERE CelebrationsTypes IS NOT NULL;

INSERT OR
REPLACE
INTO NWflower_CelebrationModifiers (CelebrationsTypes, BuildingType)
SELECT CelebrationsTypes, 'BUILDING_' || CelebrationsTypes
FROM NWflower_Celebrations;

-- 庆典提供一个通配符槽位
INSERT INTO Modifiers (ModifierId, ModifierType, OwnerRequirementSetId)
SELECT 'MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT_' || EraType,
       'MODIFIER_PLAYER_CULTURE_ADJUST_GOVERNMENT_SLOTS_MODIFIER',
       'NW_CELEBRATION_ERA_IS_' || EraType
FROM Eras;
INSERT INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT_' || EraType, 'GovernmentSlotType', 'SLOT_WILDCARD'
FROM Eras;

INSERT INTO Modifiers (ModifierId, ModifierType)
VALUES ('MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT', 'MODIFIER_PLAYER_CULTURE_ADJUST_GOVERNMENT_SLOTS_MODIFIER');
INSERT INTO ModifierArguments (ModifierId, Name, Value)
VALUES ('MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT', 'GovernmentSlotType', 'SLOT_WILDCARD');

-- RequirementSets
INSERT INTO RequirementSets (RequirementSetId, RequirementSetType)
SELECT 'NW_CELEBRATION_ERA_IS_' || EraType,
       'REQUIREMENTSET_TEST_ALL'
FROM Eras;
INSERT INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'NW_CELEBRATION_ERA_IS_' || EraType,
       'REQ_NW_CELEBRATION_ERA_IS_' || EraType
FROM Eras;

-- Requirements
INSERT INTO Requirements (RequirementId, RequirementType, Inverse)
SELECT 'REQ_NW_CELEBRATION_ERA_IS_' || EraType,
       'REQUIREMENT_GAME_ERA_ATLEAST_EXPANSION',
       1
FROM Eras;

INSERT INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_NW_CELEBRATION_ERA_IS_' || EraType,
       'EraType',
       EraType
FROM Eras;


-- Pop通知
INSERT INTO Types (Type, Kind)
VALUES ('NOTIFICATION_CELEBRATIONS_AVAILABLE', 'KIND_NOTIFICATION');
INSERT INTO Notifications(NotificationType, SeverityType, ExpiresEndOfTurn, AutoNotify, AutoActivate)
VALUES ('NOTIFICATION_CELEBRATIONS_AVAILABLE', 'MID', 1, 0, 0);


-- 添加两张空白通配政策卡，政治哲学过期
INSERT INTO Types(Type, Kind) VALUES
('POLICY_NW_CELEBRATION_VIOD1','KIND_POLICY'),
('POLICY_NW_CELEBRATION_VIOD2','KIND_POLICY');

INSERT INTO Policies(PolicyType, Name, Description, PrereqCivic, GovernmentSlotType) VALUES
('POLICY_NW_CELEBRATION_VIOD1','LOC_POLICY_NW_CELEBRATION_VIOD1','LOC_POLICY_NW_CELEBRATION_VIOD1_DES','CIVIC_CODE_OF_LAWS','SLOT_MILITARY'),
('POLICY_NW_CELEBRATION_VIOD2','LOC_POLICY_NW_CELEBRATION_VIOD1','LOC_POLICY_NW_CELEBRATION_VIOD1_DES','CIVIC_CODE_OF_LAWS','SLOT_ECONOMIC');

INSERT INTO ObsoletePolicies(PolicyType, ObsoletePolicy) VALUES
('POLICY_NW_CELEBRATION_VIOD1','POLICY_DIPLOMATIC_LEAGUE'),
('POLICY_NW_CELEBRATION_VIOD2','POLICY_CHARISMATIC_LEADER');