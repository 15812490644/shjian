-- CelebrationsPoints
-- Author: Nwflower
-- DateCreated: 2025-5-13 18:55:08
-- Inspired by: HSbF6HSO3F
--------------------------------------------------------------
--||=======================include========================||--

include('CelebrationsCore')

--||======================MetaTable=======================||--

CelebrationsPointsManager = {}

--||=======================Constants======================||--

local CelebrationsPointsKey = 'CelebrationsPoints'
local CelebrationsTimesKey = 'CelebrationsTimes'
local CITY_AMENITIES_FOR_FREE = GameInfo.GlobalParameters['CITY_AMENITIES_FOR_FREE'].Value or 0;


local CELEBRATION_FREQUENCY = GameConfiguration.GetValue('NW_CELEBRATION_FREQUENCY') or 2;
local CELEBRATION_FREQUENCY_MULTI = 0.8 + CELEBRATION_FREQUENCY * 0.1;


local AmenitiesToHappinessPercent = 1;
local LoyaltyToHappinessPercent = 0.05;

--||=========================Base========================||--
function Player_HasBuilding(iPlayer,iBuilding,bOnlyCapital)
	local pPlayer = Players[iPlayer];
	if bOnlyCapital then
    	local pCapital = pPlayer:GetCities():GetCapitalCity();
		if pCapital and (pCapital:GetBuildings():HasBuilding(iBuilding)) then
			return true;
		end
	else
        local pCities = pPlayer:GetCities();
        for _, pCity in pCities:Members() do
			if pCity and (pCity:GetBuildings():HasBuilding(iBuilding)) then
				return true;
			end
        end
	end
	return false
end
--||====================GamePlay, UI======================||--

--检查是否能举办庆典
function CelebrationsPointsManager:CanCelebrations(playerID)
    local bCan = self:GetPointsPoint(playerID) >= self:GetPointsTrigger(playerID)
    print('playerID',playerID,'是否能举办庆典',bCan)
    return bCan
end

--获取幸福值
function CelebrationsPointsManager:GetPointsPoint(playerID)
    local pPlayer = Players[playerID]
    if not pPlayer then return 0 end
    return pPlayer:GetProperty(CelebrationsPointsKey) or 0
end

--获取已举办的庆典次数
function CelebrationsPointsManager:GetTimes(playerID)
    local pPlayer = Players[playerID]
    if not pPlayer then return 0 end
    return pPlayer:GetProperty(CelebrationsTimesKey) or 0
end

--获取下次庆典所需的幸福值
function CelebrationsPointsManager:GetPointsTrigger(playerID)
    local pPlayer = Players[playerID]
    if not pPlayer then return 0 end
    local G_CelebrationTimes = self:GetTimes(playerID)
    local Trigger = (10 * CELEBRATION_FREQUENCY + G_CelebrationTimes * 35 * CELEBRATION_FREQUENCY_MULTI) * math.exp (0.06 * CELEBRATION_FREQUENCY * G_CelebrationTimes * CELEBRATION_FREQUENCY_MULTI)
    return Celebration:ModifyBySpeed(Trigger);
end

-- 获取某一城市每回合产出的正宜居度
-- 这里认为传递进来的cityID是可信的
function CelebrationsPointsManager:GetCityAmenities(playerID, cityID)
    local pCity = CityManager.GetCity(playerID,cityID)
    local totalAmen = pCity:GetGrowth():GetAmenities();
    local needAmen = math.floor((pCity:GetPopulation() + 1)/2) ;
    return ((needAmen < totalAmen + CITY_AMENITIES_FOR_FREE) and {totalAmen - needAmen + CITY_AMENITIES_FOR_FREE} or {0})[1]
end

-- 获取某一城市每回合产出的溢出忠诚度（UI）
-- 这里认为传递进来的cityID是可信的
function CelebrationsPointsManager:GetCityLoyalty(playerID, cityID)
    local pCity = CityManager.GetCity(playerID,cityID)
    local pCityCulturalIdentity = pCity:GetCulturalIdentity();
    local pCityLoyalty = pCityCulturalIdentity:GetLoyalty();
    local pCityMaxLoyalty = pCityCulturalIdentity:GetMaxLoyalty();
    local pCityLoyaltyPerTurn = pCityCulturalIdentity:GetLoyaltyPerTurn();
    return ((pCityLoyalty == pCityMaxLoyalty) and {pCityLoyaltyPerTurn} or {0})[1]
end

-- 获取某一城市每回合产出的幸福值（UI）
-- 返回幸福值、宜居度、忠诚度
function CelebrationsPointsManager:GetCityPointsPoint(playerID, cityID)
    if not CityManager.GetCity(playerID,cityID) then return 0 end
    local Amen = self:GetCityAmenities(playerID, cityID);
    local Loyalty = self:GetCityLoyalty(playerID, cityID);
    local HappinessPoint = Amen * AmenitiesToHappinessPercent + Loyalty * LoyaltyToHappinessPercent;
    return HappinessPoint, Amen, Loyalty;
end

--获取某玩家每回合产出的幸福值（UI）
function CelebrationsPointsManager:GetPerTurnPoints(playerID)
    --获取玩家
    local pPlayer = Players[playerID];
    if not pPlayer then return 0; end
    local TotalHappinessPoint,TotalAmen,TotalLoyalty = 0,0,0;
    --遍历城市
    for _, city in pPlayer:GetCities():Members() do
        local cityID = city:GetID();
        local cityHappinessPoint,cityAmen,cityLoyalty = self:GetCityPointsPoint(playerID,cityID);
        if cityHappinessPoint > 0 then
            TotalHappinessPoint = TotalHappinessPoint + cityHappinessPoint;
        end
    end
    return TotalHappinessPoint;
end

--获取玩家当前庆典效果
function CelebrationsPointsManager:GetCelebrationTypeNow(playerID)
    --获取玩家
    local pPlayer = Players[playerID];
    local CelebrationsTypeKey = 'CelebrationsType'
	local CelebrationsType = pPlayer:GetProperty(CelebrationsTypeKey)
    return CelebrationsType or -1;
end

--获取每回合产出的幸福值的tooltip（UI）
function CelebrationsPointsManager:GetPerTurnPointTooltip(playerID)
    local citiesTooltip = ''
    --获取玩家
    local pPlayer = Players[playerID]
    if not pPlayer then return '' end
    --获取每个城市的tooltip和城市产出的幸福值
    local cityTooltip, yieldPoint = '', 0
    local cities = pPlayer:GetCities()
    for _, city in cities:Members() do
        local cityID = city:GetID()
        --获取城市产出的幸福值
        local cityPoint,cityAmen,cityLoyalty = self:GetCityPointsPoint(playerID, cityID)
        yieldPoint = yieldPoint + cityPoint
        if cityPoint ~= 0 then
            --获取城市名称
            local cityName = city:GetName()
            --设置tooltip
            cityTooltip = cityTooltip .. Locale.Lookup('LOC_Celebrations_HAPPY_POINT_FROM_CITY', cityPoint, cityName)
        end
    end
    --来自城市的tooltip
    citiesTooltip = Locale.Lookup('LOC_Celebrations_HAPPY_POINT_TITLE') .. Locale.Lookup('LOC_Celebrations_HAPPY_POINT_FROM_CITIES', yieldPoint) .. cityTooltip
    --如果玩家正处于庆典中，也加入庆典效果
    local CelebrationsType = self:GetCelebrationTypeNow(playerID)
    if CelebrationsType ~= -1 then
        citiesTooltip = Locale.Lookup('LOC_Celebrations_NOW_TITLE',GameInfo.NWflower_Celebrations[CelebrationsType].Name) .. Locale.Lookup('LOC_Celebrations_NOW_SUBS',GameInfo.NWflower_Celebrations[CelebrationsType].Description) .. citiesTooltip
    end

    return citiesTooltip
end

--||======================GamePlay========================||--

--设置幸福值 (GamePlay)
function CelebrationsPointsManager:SetPointsPoint(playerID, point)
    local pPlayer = Players[playerID]
    if not pPlayer then return end
    pPlayer:SetProperty(CelebrationsPointsKey, point)
    return point;
end

--改变幸福值，返回新的幸福值 (GamePlay)
function CelebrationsPointsManager:ChangePointsPoint(playerID, num)
    print('PlayerID',playerID,'Get',num,'CelebrationsPoint');
    return self:SetPointsPoint(playerID, self:GetPointsPoint(playerID) + num);
end

--||==========================UI==========================||--

--||=======================include========================||--
include('CelebrationsPoints_', true)
