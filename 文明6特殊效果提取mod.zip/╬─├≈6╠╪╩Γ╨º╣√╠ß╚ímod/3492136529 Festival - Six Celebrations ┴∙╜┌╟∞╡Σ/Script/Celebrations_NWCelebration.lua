-- Celebrations_NWCelebration
-- Author: Nwflower
-- DateCreated: 2025-6-5 21:40:07
--------------------------------------------------------------

-- 千帆竞渡效果激活：港口建造完毕
-- 该事件是因为解释UnlocksFromEffect有什么用而做的
function CELEBRATIONS_BOAT_BOOST_ACTIVE(playerID , districtID , cityID , iX , iY , districtType , era , civilization , percentComplete , iAppeal , isPillaged)
	local DISTRICT_HARBOR_INDEX=GameInfo.Districts['DISTRICT_HARBOR'].Index;
    local pPlayer = Players[playerID]
	if districtType == DISTRICT_HARBOR_INDEX and percentComplete==100 then
	    local isActivated = pPlayer:GetProperty('Property_NW_CELEBRATIONS_BOAT_BOOST');
        if not isActivated then
            pPlayer:SetProperty('Property_NW_CELEBRATIONS_BOAT_BOOST', 1);
        end
	end
end

-- =====================================================================
-- INIT
-- =====================================================================
function initialize()
    Events.DistrictBuildProgressChanged.Add(CELEBRATIONS_BOAT_BOOST_ACTIVE);
end

Events.LoadScreenClose.Add(initialize)