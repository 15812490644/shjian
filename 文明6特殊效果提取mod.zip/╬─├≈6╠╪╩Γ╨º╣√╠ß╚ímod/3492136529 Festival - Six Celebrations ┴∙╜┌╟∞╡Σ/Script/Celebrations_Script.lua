-- Penacony_Script
-- Author: Nwflower
-- DateCreated: 2025-5-12 21:51:26
--------------------------------------------------------------
--||=======================include========================||--
include('CelebrationsCore')
include('CelebrationsPoints')

local CelebrationsTimesKey = 'CelebrationsTimes'
local CelebrationsBeginKey = 'CelebrationsBegin'
local CelebrationsTypeKey = 'CelebrationsType'

-- UI request：玩家增加幸福值
function CelebrationsPointAdd(playerID, param)
	local perTurnPoint = param.perTurnPoint
	CelebrationsPointsManager:ChangePointsPoint(playerID, perTurnPoint)
end

-- 选择庆典
function SelectNWCelebration(iPlayer,param)
	local pPlayer = Players[iPlayer];
	local CelebrationType = param.CelebrationId;
	local point = CelebrationsPointsManager:GetPointsPoint(iPlayer)
	local pointMax = CelebrationsPointsManager:GetPointsTrigger(iPlayer)

	-- 删点数
	if point >= pointMax then CelebrationsPointsManager:ChangePointsPoint(iPlayer, -pointMax)
	else CelebrationsPointsManager:SetPointsPoint(iPlayer, 0) end

	-- 记录庆典次数
	local CelebrationsTimes = pPlayer:GetProperty(CelebrationsTimesKey) or 0
	pPlayer:SetProperty(CelebrationsTimesKey, CelebrationsTimes + 1)

	-- 记录当前回合
	local CelebrationsBegin = Game.GetCurrentGameTurn()
	pPlayer:SetProperty(CelebrationsBeginKey, CelebrationsBegin)

	-- 记录庆典类型
	pPlayer:SetProperty(CelebrationsTypeKey, CelebrationType)

	-- GP端广播
	LuaEvents.NWCelebration( iPlayer )
	LuaEvents.NWCelebrationType( iPlayer, CelebrationType )
	print('玩家',iPlayer,'举办了庆典',CelebrationType)
end

-- 庆典结束
function NWCelebrationEnd(iPlayer,param)
	local pPlayer = Players[iPlayer];
	local CelebrationType = param.CelebrationId;

	-- 记录非庆典状态
	pPlayer:SetProperty(CelebrationsTypeKey, -1)

	-- GP端广播
	LuaEvents.NWCelebrationEnd( iPlayer )
	LuaEvents.NWCelebrationTypeEnd( iPlayer, CelebrationType )
end

-- =====================================================================
-- INIT
-- =====================================================================
function initialize()
	GameEvents.CelebrationsPointAdd.Add( CelebrationsPointAdd );
	GameEvents.SelectNWCelebration.Add( SelectNWCelebration );
	GameEvents.NWCelebrationEnd.Add( NWCelebrationEnd );
end

Events.LoadScreenClose.Add( initialize)