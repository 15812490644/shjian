-- Penacony_Script
-- Author: Nwflower
-- DateCreated: 2025-5-12 21:51:26
--------------------------------------------------------------
--||=======================include========================||--

include('CelebrationsCore')
include('CelebrationsPoints')

local CelebrationsTimesKey = 'CelebrationsTimes'
local CelebrationsBeginKey = 'CelebrationsBegin'
local CelebrationsTypeKey = 'CelebrationsType'

-- 庆典通用效果效果
function NWCelebration(iPlayer)
    local pPlayer = Players[iPlayer];
    local EraIndex = Game.GetEras():GetCurrentEra() + 1
    if GameInfo.Eras[EraIndex] then
        local EraType = GameInfo.Eras[EraIndex].EraType
        pPlayer:AttachModifierByID('MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT_'..EraType)
    else
        -- 获取不到当前时代信息，可能是最后一个时代，直接加槽
        pPlayer:AttachModifierByID('MODFEAT_CELEBRATIONS_ADD_POLICY_SLOT')
    end
end

-- 庆典个性化效果
-- 这里进行虚拟建筑的处理
-- 传入CelebrationType:string
function NWCelebrationType(iPlayer, CelebrationType)
    if (GameInfo.NWflower_CelebrationModifiers[CelebrationType] and GameInfo.NWflower_CelebrationModifiers[CelebrationType].BuildingType) then

	    print('接受到玩家',iPlayer,'举办了庆典',CelebrationType)
        local pPlayer = Players[iPlayer];
        local pCity = pPlayer:GetCities():GetCapitalCity()

        -- 先清空其他庆典虚拟建筑
        for row in GameInfo.NWflower_CelebrationModifiers() do
            if CelebrationType ~= row.CelebrationType and pCity:GetBuildings():HasBuilding(GameInfo.Buildings[row.BuildingType].Index) then
                pCity:GetBuildings():RemoveBuilding(GameInfo.Buildings[row.BuildingType].Index);
            end
        end

        -- 给玩家提供一个虚拟建筑
        local BuildingType = GameInfo.NWflower_CelebrationModifiers[CelebrationType].BuildingType;
        local iBuilding = GameInfo.Buildings[BuildingType].Index;
        if not (pCity:GetBuildings():HasBuilding(iBuilding)) then
            pCity:GetBuildQueue():CreateBuilding(iBuilding);
        end
    end
end

-- 庆典个性化效果结束
-- 这里需要删除虚拟建筑
function NWCelebrationTypeEnd(iPlayer, CelebrationType)
    local pPlayer = Players[iPlayer];
    if pPlayer and CelebrationType ~= -1 then
        local pCity = pPlayer:GetCities():GetCapitalCity()
        -- 清空所有庆典虚拟建筑
        for row in GameInfo.NWflower_CelebrationModifiers() do
            if CelebrationType ~= row.CelebrationType and pCity:GetBuildings():HasBuilding(GameInfo.Buildings[row.BuildingType].Index) then
                pCity:GetBuildings():RemoveBuilding(GameInfo.Buildings[row.BuildingType].Index);
            end
        end
    end
end

-- =====================================================================
-- INIT
-- =====================================================================
function initialize()
    LuaEvents.NWCelebration.Add(NWCelebration);
    LuaEvents.NWCelebrationType.Add(NWCelebrationType);
    LuaEvents.NWCelebrationTypeEnd.Add(NWCelebrationTypeEnd);
end

Events.LoadScreenClose.Add(initialize)