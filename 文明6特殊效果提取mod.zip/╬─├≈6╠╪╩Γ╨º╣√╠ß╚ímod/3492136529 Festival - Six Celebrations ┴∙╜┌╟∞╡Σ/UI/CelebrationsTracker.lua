-- CelebrationsTracker
-- Author: Nwflower
-- DateCreated: 2025-5-13 19:25:13
--------------------------------------------------------------
--||=======================include========================||--

include('CelebrationsCore')
include('CelebrationsPoints')

NW_CELEBRATION_NOTIFICATION_HASH = GameInfo.Types["NOTIFICATION_CELEBRATIONS_AVAILABLE"].Hash;

--||====================c=================================||--
local loaclPlayerID = Game.GetLocalPlayer()
local loaclPlayer = Players[loaclPlayerID];

--||====================base functions====================||--

function CelebrationsTrackerReset()
    loaclPlayerID = Game.GetLocalPlayer()
    Controls.CelebrationsTrackerGrid:SetHide(false)
    --获取点数
    local point = CelebrationsPointsManager:GetPointsPoint(loaclPlayerID) or 0
    local pointMax = CelebrationsPointsManager:GetPointsTrigger(loaclPlayerID) or 0
    --更新点数显示
    Controls.HappinessBalance:SetText(Locale.ToNumber(point, "#,###.#")..'/'..Locale.ToNumber(pointMax, "#,###.#"))
    local perTurnPoint = CelebrationsPointsManager:GetPerTurnPoints(loaclPlayerID)
    Controls.HappinessPerTurn:SetText(Celebration:FormatValue(perTurnPoint))
    local perTurnPointTooltip = CelebrationsPointsManager:GetPerTurnPointTooltip(loaclPlayerID)
    Controls.CelebrationsTrackerHappiness:SetToolTipString(perTurnPointTooltip)
    -- 如果可以触发庆典，发送通知
    if point >= pointMax then
		LuaEvents.Celebration_SendNotification();
    end
end

function CelebrationsTrackerInit()
    local parent = ContextPtr:LookUpControl("/InGame/TopPanel/InfoStack")
    if parent ~= nil then
        Controls.CelebrationsTrackerGrid:ChangeParent(parent)
        parent:AddChildAtIndex(Controls.CelebrationsTrackerGrid, 1)
        parent:CalculateSize()
        parent:ReprocessAnchoring()
    	Controls.CelebrationsTrackerHappiness:RegisterCallback(Mouse.eLClick, CelebrationsTrackerReset)
        CelebrationsTrackerReset()
    end
end

-- 回合开始时加点数、顺便更新显示
function onPlayerTurnActivated(playerID, isFirst)
    if playerID == loaclPlayerID and isFirst then
        local perTurnPoint = CelebrationsPointsManager:GetPerTurnPoints(loaclPlayerID)
        local point = CelebrationsPointsManager:GetPointsPoint(loaclPlayerID)
		local pointMax = CelebrationsPointsManager:GetPointsTrigger(loaclPlayerID)

        local kParameters = {};
        kParameters.OnStart = "CelebrationsPointAdd";
        kParameters.playerID = loaclPlayerID;
        kParameters.perTurnPoint = perTurnPoint;
        kParameters.point = point;
        kParameters.pointMax = pointMax;
        UI.RequestPlayerOperation(loaclPlayerID, PlayerOperations.EXECUTE_SCRIPT, kParameters);

        local perTurnPointTooltip = CelebrationsPointsManager:GetPerTurnPointTooltip(loaclPlayerID)
        Controls.HappinessBalance:SetText(Locale.ToNumber(point + perTurnPoint, "#,###.#")..'/'..Locale.ToNumber(pointMax, "#,###.#"))
        Controls.HappinessPerTurn:SetText(Celebration:FormatValue(perTurnPoint))
        Controls.CelebrationsTrackerHappiness:SetToolTipString(perTurnPointTooltip)
    end
end

--||======================initialize======================||--

--initialization function
function Initialize()
    -----------------------Events-----------------------
    Events.LoadGameViewStateDone.Add(CelebrationsTrackerInit)
    Events.PlayerTurnActivated.Add(onPlayerTurnActivated)
    -------------------Resets---------------------------
    Events.CityAddedToMap.Add(CelebrationsTrackerReset)
    Events.CityPopulationChanged.Add(CelebrationsTrackerReset)
    Events.CityProductionChanged.Add(CelebrationsTrackerReset)
    Events.CityProductionCompleted.Add(CelebrationsTrackerReset)
    Events.CityRemovedFromMap.Add(CelebrationsTrackerReset)
    Events.PlayerResourceChanged.Add(CelebrationsTrackerReset)
    Events.LocalPlayerChanged.Add(CelebrationsTrackerReset)
    ---------------------GameEvents---------------------
    ----------------------LuaEvents---------------------
    ----------------------------------------------------
    print('Celebrations Tracker Initial success')
end

include('CelebrationsTracker_', true)

Initialize()
