-- =================================================================================
-- Import base file
-- =================================================================================
include("InstanceManager");
include('CelebrationsCore');
include('CelebrationsPoints')

-- ===========================================================================
-- CONSTANTS
-- ===========================================================================
local IN_CELEBRATION = 'NW_PLAYER_IS_IN_CELEBRATION';
local CelebrationsTimesKey = 'CelebrationsTimes'
local CelebrationsBeginKey = 'CelebrationsBegin'
local CelebrationsTypeKey = 'CelebrationsType'
-- ===========================================================================
-- VARIABLES
-- ===========================================================================
local m_SelectedCelebrationType = -1;
local m_CommemorationInstanceManager = InstanceManager:new("Commemoration", "SelectCheck", Controls.CommemorationsStack);

local m_refresh = true;-- 是否需要刷新
local CelebrationsContinue = Celebration:ModifyBySpeed(10)

-- ===========================================================================
-- 回合开始时：检查庆典是否结束
function OnPlayerTurnActivated(playerID, isFirst)
    local localPlayerID = Game.GetLocalPlayer();
    local localPlayer = Players[localPlayerID]
    if isFirst and playerID == localPlayerID then
	    local Turn = Game.GetCurrentGameTurn()
        local LastCelebrationTurn = localPlayer:GetProperty(CelebrationsBeginKey) or 0
        local LastCelebrationType = localPlayer:GetProperty(CelebrationsTypeKey) or -1
        if LastCelebrationType ~= -1 and Turn > LastCelebrationTurn + CelebrationsContinue then
            local param = {};
            param['OnStart'] = 'NWCelebrationEnd'
            param['CelebrationId'] = LastCelebrationType;
            UI.RequestPlayerOperation(Game.GetLocalPlayer(), PlayerOperations.EXECUTE_SCRIPT, param);
        end

        -- 检查是否能举办庆典
        if CelebrationsPointsManager:CanCelebrations(localPlayerID) then
            OnTogglePanel()
        end
    end
end

function OnTogglePanel()
    if ContextPtr:IsHidden() and m_refresh then
        Open()
    elseif ContextPtr:IsHidden() and not m_refresh then
        ContextPtr:SetHide(false);
    else
        Close()
    end
end

function Open()
    local localPlayerID = Game.GetLocalPlayer();
    local localPlayer = Players[localPlayerID]
    local gameEras = Game.GetEras():GetCurrentEra();

    -- 忽略观察者
    if localPlayerID == PlayerTypes.NONE then return ; end

    -- 显示界面
    ContextPtr:SetHide(false);
    LuaEvents.CelebrationPanel_Opened();
    UI.PlaySound("Tech_Tray_Slide_Open");

    -- 设置标题
    Controls.Title:SetText(Locale.ToUpper(Locale.Lookup('LOC_NW_CHOOSE_CELEBRATIONS_COMMEMORATION_TITLE')));

    -- 初始化庆典选项
    m_CommemorationInstanceManager:ResetInstances();

    local selection = {}
    local selection_tmp = {}

    -- 查找庆典
    for row in GameInfo.NWflower_Celebrations() do
        local Celebration = {
            Index = row.Index,
            CelebrationsTypes = row.CelebrationsTypes,
            CelebrationsTypesName = row.Name,
            CelebrationsTypesDescription = row.Description,
            PreEra = row.PreEra,
            ObsoleteEra = row.ObsoleteEra,
            UnlocksFromEffect = row.UnlocksFromEffect,
            Weight = row.Weight,
        }
        local PreEraRule,ObsoleteEraRule,UnlocksFromEffectRule = true,true,true;
        if GameInfo.Eras[row.PreEra] then
            PreEraRule = GameInfo.Eras[row.PreEra].Index <= gameEras;
        end
        if GameInfo.Eras[row.ObsoleteEra] then
            ObsoleteEraRule = GameInfo.Eras[row.ObsoleteEra].Index > gameEras;
        end
        if row.UnlocksFromEffect == 1 then
            UnlocksFromEffectRule = localPlayer:GetProperty('Property_'..row.CelebrationsTypes) ~= nil;
        end
        -- 检查庆典条件
        if PreEraRule and ObsoleteEraRule and UnlocksFromEffectRule then
            table.insert(selection_tmp,Celebration)
        end
        print("庆典:", Celebration.Index, Locale.Lookup(Celebration.CelebrationsTypesName))
        print("庆典满足触发条件:", PreEraRule and ObsoleteEraRule and UnlocksFromEffectRule)
    end

    selection = Celebration:WeightedRandomSelection(selection_tmp,4)

    -- 快排
    table.sort(selection, function(a, b)
        local aIndex = a.Index or math.huge
        local bIndex = b.Index or math.huge
        return tonumber(aIndex) < tonumber(bIndex)
    end)

    for _, Celebration in ipairs(selection) do
        CreateCommemoration(Celebration);
    end

    m_SelectedCelebrationType = -1;
    Controls.Confirm:SetDisabled(true);
    Controls.CommemorationsStack:CalculateSize();
    Controls.CommemorationsScroller:CalculateSize();
    Controls.CommemorationsScroller:SetScrollValue(0);

    -- 更新控件样式
    Controls.AgeAchieved:SetText(Locale.ToUpper(Locale.Lookup("LOC_NW_CHOOSE_CELEBRATIONS_COMMEMORATION_DESCRIPTION")));
    Controls.PopupBackground:SetTexture("Ages_ParchmentHeroic");
    Controls.PopupFrame:SetTexture("Ages_FrameHeroic");
    Controls.HeroicFrameGlow:SetHide(false);
    UpdateConfirmButton();
end

-- ===========================================================================
function CreateCommemoration(CelebrationInfo)
    local localPlayerID = Game.GetLocalPlayer();
    local localPlayer = Players[localPlayerID]

    local instance = m_CommemorationInstanceManager:GetInstance();
    -- Commemoration Icon
    local iconName = "ICON_" .. CelebrationInfo.CelebrationsTypes;
    instance.CommemorationIcon:SetIcon(iconName);

    -- 庆典名
    local categoryText = "";
    if (CelebrationInfo ~= nil and CelebrationInfo.CelebrationsTypesName ~= nil) then
        categoryText = Locale.ToUpper(Locale.Lookup(CelebrationInfo.CelebrationsTypesName));
    end
    instance.MomentCategory:SetText(categoryText);

    -- 庆典效果文本
    local bonusText = ""
    if (CelebrationInfo ~= nil and CelebrationInfo.CelebrationsTypesDescription ~= nil) then
        bonusText = Locale.Lookup(CelebrationInfo.CelebrationsTypesDescription);
    end

    instance.SelectCheck:SetTexture("Ages_ButtonComHeroic");
    instance.MomentBonuses:SetText(bonusText);
    instance.SelectCheck:SetSelected(false);
    instance.SelectCheck:RegisterCallback(Mouse.eLClick, function()
        OnCommemorationSelected(instance, CelebrationInfo.CelebrationsTypes)
    end);
end

-- ===========================================================================
function OnCommemorationSelected(selectedInstance, commemorationType)
    local localPlayerID = Game.GetLocalPlayer();
    local localPlayer = Players[localPlayerID]

    -- 是否已经选中
    if m_SelectedCelebrationType == commemorationType then
        selectedInstance.SelectCheck:SetSelected(false);
        m_SelectedCelebrationType = -1;
    else
        for _, instance in ipairs(m_CommemorationInstanceManager.m_AllocatedInstances) do
            instance.SelectCheck:SetSelected(false);
        end
        m_SelectedCelebrationType = commemorationType
        selectedInstance.SelectCheck:SetSelected(true);
    end

    UpdateConfirmButton();
end

-- ===========================================================================
function UpdateConfirmButton()
    Controls.Confirm:SetDisabled(m_SelectedCelebrationType == -1);
end

-- ===========================================================================
function OnConfirm()
    local param = {};
    param['OnStart'] = 'SelectNWCelebration'
    param['CelebrationId'] = m_SelectedCelebrationType;
    UI.RequestPlayerOperation(Game.GetLocalPlayer(), PlayerOperations.EXECUTE_SCRIPT, param);

    UI.PlaySound("Confirm_Dedication");
    m_refresh = true;
    Close();
end

-- ===========================================================================
function CloseButtonCallback()
    Skip()
    LuaEvents.Celebration_SendNotification();
end

function Close()
    m_SelectedCelebrationType = -1
    for _, instance in ipairs(m_CommemorationInstanceManager.m_AllocatedInstances) do
        instance.SelectCheck:SetSelected(false);
    end
    UI.PlaySound("Tech_Tray_Slide_Closed");
    LuaEvents.CelebrationPanel_Closed()
    ContextPtr:SetHide(true);
end

function Skip()
    print("暂时跳过不选")
    m_SelectedCelebrationType = -1
    for _, instance in ipairs(m_CommemorationInstanceManager.m_AllocatedInstances) do
        instance.SelectCheck:SetSelected(false);
    end
    LuaEvents.CelebrationPanel_Closed()
    ContextPtr:SetHide(true);
    m_refresh = false;
end

-- ===========================================================================
function OnInit(isReload)
end

-- ===========================================================================
--	Input
--	UI Event Handler
-- ===========================================================================
function OnInputHandler(pInputStruct)
    if (pInputStruct:GetMessageType() == KeyEvents.KeyUp) then
        local key = pInputStruct:GetKey();
        if (key == Keys.VK_ESCAPE) then
            Close();
        end
    end
    -- Intercept all input while on this screen (is modal)
    return true;
end

-- ===========================================================================
function Initialize()
    ContextPtr:SetHide(true);
    ContextPtr:SetInitHandler(OnInit);
    ContextPtr:SetInputHandler(OnInputHandler, true);

    Controls.CloseButton:RegisterCallback(Mouse.eLClick, CloseButtonCallback);
    Controls.Confirm:RegisterCallback(Mouse.eLClick, OnConfirm);

    Events.PlayerTurnActivated.Add(OnPlayerTurnActivated);
    LuaEvents.Celebration_TogglePopup.Add(OnTogglePanel);
end
Initialize();