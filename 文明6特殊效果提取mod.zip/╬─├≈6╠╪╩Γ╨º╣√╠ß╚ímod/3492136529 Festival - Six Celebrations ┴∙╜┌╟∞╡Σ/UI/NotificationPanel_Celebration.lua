-- ===========================================================================
-- CACHE BASE FUNCTIONS
-- ===========================================================================
local BASE_RegisterHandlers = RegisterHandlers;

-- ===========================================================================
--	CONSTANTS
-- ===========================================================================
local HASH_Celebration_NOTIFICATION = DB.MakeHash('NOTIFICATION_CELEBRATIONS_AVAILABLE');
local IsNotificationExist = false;
local IsCelebrationPanelOpen = false;

-- ===========================================================================
--	All we need is to call the panel to show up
-- ===========================================================================
function OnCelebrationActivate(notificationEntry)
    if (notificationEntry ~= nil and notificationEntry.m_PlayerID == Game.GetLocalPlayer()) then
        local pNotification = GetActiveNotificationFromEntry(notificationEntry);
        if pNotification ~= nil then
            LuaEvents.Celebration_TogglePopup()
            notificationEntry.m_kHandlers.TryDismiss(notificationEntry);
            IsNotificationExist = false
        end
    end
end

function OnCelebrationDismiss(notificationEntry)
    if (notificationEntry ~= nil and notificationEntry.m_PlayerID == Game.GetLocalPlayer()) then
        IsNotificationExist = false
        OnDefaultTryDismissNotification(notificationEntry)
    end
end

function Celebration_NotificationDismissed(iPlayer, iNotification)
    if iPlayer == Game.GetLocalPlayer() then
        local pNotification = NotificationManager.Find(iPlayer, iNotification);
        if pNotification and pNotification:GetType() == GameInfo.Notifications['NOTIFICATION_CELEBRATIONS_AVAILABLE'].Index then
            IsNotificationExist = false
        end
    end
end

function Celebration_LocalPlayerTurnEnd()
    IsNotificationExist = false
end

function CelebrationPanel_Opened()
    IsCelebrationPanelOpen = true
end

function CelebrationPanel_Closed()
    IsCelebrationPanelOpen = false
end
-- ========================================================================================================================
function Celebration_SendNotification()
    if not IsNotificationExist and not IsCelebrationPanelOpen then
        local tNotificationData = {}
        tNotificationData[ParameterTypes.MESSAGE] = Locale.Lookup('LOC_NW_CELEBRATIONS_COMMEMORATION_NOTIFICATION')
        tNotificationData[ParameterTypes.SUMMARY] = Locale.Lookup('LOC_NW_CHOOSE_CELEBRATIONS_COMMEMORATION_TITLE')
        NotificationManager.SendNotification(Game.GetLocalPlayer(), HASH_Celebration_NOTIFICATION, tNotificationData)
        IsNotificationExist = true
    end
end

function Celebration_CancelNotification( iPlayer )
    if IsNotificationExist and IsCelebrationPanelOpen then
        local lastCelebration = nil;
        local notificationIds = NotificationManager.GetList( iPlayer );
        for _, notificationId in ipairs(notificationIds) do
            local notification = NotificationManager.Find(iPlayer, notificationId);
            if notification ~= nil and notification:GetType() == NotificationTypes.NOTIFICATION_CELEBRATIONS_AVAILABLE then
                lastCelebration = notification;
            end
        end
        if lastCelebration ~= nil and not lastCelebration:IsDismissed() then
            NotificationManager.Dismiss(iPlayer, lastCelebration:GetID());
            IsNotificationExist = false
        end
    end
end

-- ========================================================================================================================


function RegisterHandlers()
    BASE_RegisterHandlers();

    g_notificationHandlers[HASH_Celebration_NOTIFICATION] = MakeDefaultHandlers();
    g_notificationHandlers[HASH_Celebration_NOTIFICATION].AddSound = 'NOTIFICATION_MISC_POSITIVE';
    g_notificationHandlers[HASH_Celebration_NOTIFICATION].Activate = OnCelebrationActivate;
    g_notificationHandlers[HASH_Celebration_NOTIFICATION].TryDismiss = OnCelebrationDismiss;

    Events.NotificationDismissed.Add(Celebration_NotificationDismissed);
    Events.LocalPlayerTurnEnd.Add(Celebration_LocalPlayerTurnEnd);

    LuaEvents.CelebrationPanel_Opened.Add(CelebrationPanel_Opened);
    LuaEvents.CelebrationPanel_Closed.Add(CelebrationPanel_Closed);
    LuaEvents.Celebration_SendNotification.Add(Celebration_SendNotification);
    LuaEvents.Celebration_CancelNotification.Add(Celebration_CancelNotification);
end