To Modder:
添加新庆典的方法：

添加新庆典格式参照Celebrations_Database.sql

INSERT INTO NWflower_Celebrations (CelebrationsTypes, Name, Description, PreEra, ObsoleteEra, UnlocksFromEffect, Weight)
-- 庆典类型CelebrationsTypes
-- 庆典名Name
-- 庆典效果Description
-- 最早出现的时代PreEra
-- 强制过时时代ObsoleteEra
-- 是否需要效果来解锁UnlocksFromEffect：如果是，则会检查玩家的'Property_'||CelebrationsTypes属性，该值不为nil才会出现
-- 权重Weight：该选项出现的权重，默认100，值越大出现概率越高
触发庆典时，将随机抽选4个满足条件的庆典选项呈现给玩家。

庆典的效果是通过虚拟建筑间接实现的，写法可以参照Celebrations_Buildings.sql

触发庆典时，在gameplay端会广播以下事件
LuaEvents.NWCelebration( iPlayer )
LuaEvents.NWCelebrationType( iPlayer, CelebrationType )
CelebrationType 是字符串，是你在NWflower_Celebrations表填的CelebrationsTypes字段。

庆典结束时，同样会在GP端广播以下事件
LuaEvents.NWCelebrationEnd( iPlayer )
LuaEvents.NWCelebrationTypeEnd( iPlayer, CelebrationType )

Player Property相关：
CelebrationsTimes：庆典次数
CelebrationsBegin：上次庆典的回合数
CelebrationsType：上次庆典（是Index还是Type String忘了）

理论上做了联机性适配，一般不会有大问题