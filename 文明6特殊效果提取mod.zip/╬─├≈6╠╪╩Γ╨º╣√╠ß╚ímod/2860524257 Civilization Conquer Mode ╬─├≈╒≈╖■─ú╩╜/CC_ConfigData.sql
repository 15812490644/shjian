-- CC_ConfigData
-- Author: muyyi

--------------------------------------------------------------

INSERT INTO GameModeItems
		(GameModeType,			Name,							Description,							Icon,						Portrait,							Background,								SortIndex)
VALUES	('GAMEMODE_MUYYI_CC',	'LOC_GAMEMODE_MUYYI_CC_NAME',	'LOC_GAMEMODE_MUYYI_CC_DESCRIPTION',	'ICON_GAMEMODE_MUYYI_CC',	'IMAGE_GAMEMODE_CC_PORTRAIT.dds',	'GAMEMODE_BARBARIAN_CLANS_BACKGROUND',	10);


INSERT INTO Parameters
		(ParameterId,			Name,							Description,							Domain,		DefaultValue,	ConfigurationGroup,		ConfigurationId,			NameArrayConfigurationId,	GroupId, 			SortIndex)
VALUES	('GameMode_Muyyi_CC',	'LOC_GAMEMODE_MUYYI_CC_NAME',	'LOC_GAMEMODE_MUYYI_CC_DESCRIPTION',	'bool',		1,				'Game',					'GAMEMODE_MUYYI_CC',		'GAMEMODES_ENABLED_NAMES',	'GameModes',		20),
		('CanCaptureUA',		'LOC_CanCaptureUA_NAME',		'LOC_CanCaptureUA_DESCRIPTION',			'bool',		0,				'Game',					'CanCaptureUA_OPTION',		'GAMEMODES_ENABLED_NAMES',	'AdvancedOptions',	10),
		('CanCaptureLA',		'LOC_CanCaptureLA_NAME',		'LOC_CanCaptureLA_DESCRIPTION',			'bool',		0,				'Game',					'CanCaptureLA_OPTION',		'GAMEMODES_ENABLED_NAMES',	'AdvancedOptions',	11);
		
--=====
--ConfigurationUpdates
--=====
INSERT INTO ConfigurationUpdates	
(SourceGroup,	SourceId,					SourceValue,	TargetGroup,		TargetId,					TargetValue,	'Static')
VALUES
('Game',		'GAMEMODE_MUYYI_CC',		0,				'Game',				'CanCaptureUA_OPTION',		0,				1),
('Game',		'GAMEMODE_MUYYI_CC',		0,				'Game',				'CanCaptureLA_OPTION',		0,				1);
--=====
--ParameterCriteria
--=====
INSERT INTO ParameterCriteria	
(ParameterId,		ConfigurationGroup,		ConfigurationId,				'Operator',		ConfigurationValue)
VALUES
('CanCaptureUA',	'Game',					'GAMEMODE_MUYYI_CC',			'NotEquals',	0),
('CanCaptureLA',	'Game',					'GAMEMODE_MUYYI_CC',			'NotEquals',	0);




