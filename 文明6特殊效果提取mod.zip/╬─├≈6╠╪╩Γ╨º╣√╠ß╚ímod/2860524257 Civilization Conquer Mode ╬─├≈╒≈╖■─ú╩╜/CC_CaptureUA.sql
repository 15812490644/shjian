UPDATE CC_CONFIG SET Value = 1
WHERE Option = 'CanCaptureUA'