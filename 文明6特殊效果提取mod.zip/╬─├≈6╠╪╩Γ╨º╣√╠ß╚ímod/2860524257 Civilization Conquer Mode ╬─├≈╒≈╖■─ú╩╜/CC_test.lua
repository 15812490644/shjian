-- cc_test
-- Author: Muyyi
-- DateCreated: 2022/8/18
-- Update: 2021/1/22

local sDefaultThings = "Nothing";
local sUniqueThings = {sDefaultThings, sDefaultThings, sDefaultThings, sDefaultThings, sDefaultThings};
local iUniqueThingCount = {0,0,0,0,0};
local CanCaptureUA = GameConfiguration.GetValue("CanCaptureUA_OPTION");
local CanCaptureLA = GameConfiguration.GetValue("CanCaptureLA_OPTION");
local sPrevName = sDefaultThings;
print("CanCaptureUA: ", CanCaptureUA);
print("CanCaptureLA: ", CanCaptureLA);

function CollectUniqueThings(sTypeName, iTypeIndex)
	if (sTypeName == nil or iTypeIndex == nil) then
		return sUniqueThings;
	end
	local sRealName = Locale.Lookup(sTypeName);
	--避免重复
	if sPrevName == sRealName then
		return sUniqueThings;
	end

	if (sUniqueThings[iTypeIndex] == sDefaultThings) then
		sUniqueThings[iTypeIndex] = Locale.Lookup(sRealName);
	else
		sUniqueThings[iTypeIndex] = sUniqueThings[iTypeIndex]..", "..sRealName;
	end
	print("加入了新东西，编号为：", iTypeIndex);
	print("内容为：", sRealName);
	iUniqueThingCount[iTypeIndex] = iUniqueThingCount[iTypeIndex] + 1;
	sPrevName = sRealName;
	return sUniqueThings;
end

function CapitalBandCivUa(playerID:number, cityID:number, cityX:number, cityY:number)
    print("CapitalBandCivUa - " .. tostring(playerID) .. ":" .. tostring(cityID) .. " " .. tostring(cityX) .. "x" .. tostring(cityY));
    local pPlayer = Players[playerID];
    local pCity = CityManager.GetCity(playerID,cityID)
    local originalOwnerID = pCity:GetOriginalOwner()
    if originalOwnerID ~= playerID and originalOwnerID ~= nil then
        local oPlayer = Players[originalOwnerID]
        local oPlayerConfig = PlayerConfigurations[originalOwnerID]
        local oCiv = oPlayerConfig:GetCivilizationTypeName()
        local oLD = oPlayerConfig:GetLeaderTypeName()
        local have_captured = pPlayer:GetProperty('CC_CAPITAL_HAVE_CAPTURED_'..originalOwnerID)
        print('has capture:', have_captured)
        print('Civilization: ',oCiv)
        print('Leader: ',oLD)
		if not (oPlayer:IsMajor()) then
			return;
		end
        if have_captured == nil then -- avoid repeating
            print("capture skill")
            pPlayer:SetProperty('CC_CAPITAL_HAVE_CAPTURED_'..originalOwnerID, true)
            -- 要执行的捕获代码
            -- 城市捕获有个致命的问题，就是原来的文明会获得2倍加成。建筑也一样。
            -- print("CanCaptureUA: ",Game:GetProperty('CanCaptureUA'));
			-- 判断玩家是否想获得文明及领袖的能力
            local oCivName = "LOC_"..oCiv.."_NAME";
			local oLDName = "LOC_"..oLD.."_NAME"
			--初始化
			sUniqueThings = {sDefaultThings, sDefaultThings, sDefaultThings, sDefaultThings, sDefaultThings};
			iUniqueThingCount = {0,0,0,0,0};
			-- 获得Trait部分
			sPrevName = sDefaultThings; --初始化
			if (CanCaptureUA and CanCaptureUA ~= nil) then
				for cc_row in GameInfo.CC_CIV_UA() do
					if cc_row.CivilizationType == oCiv then
						pPlayer:AttachModifierByID(cc_row.ModifierId);
						print("you get "..cc_row.CivilizationType.." ability modifier "..cc_row.ModifierId) 
						local sTypeName = cc_row.TraitName;
						CollectUniqueThings(sTypeName, 1);
					end
				end
			end
			if (CanCaptureLA and CanCaptureLA ~= nil) then
				for cc_row in GameInfo.CC_LD_UA() do
					if cc_row.LeaderType == oLD then
						pPlayer:AttachModifierByID(cc_row.ModifierId);
						print("you get "..cc_row.LeaderType.." ability modifier "..cc_row.ModifierId);
						local sTypeName = cc_row.TraitName;
						CollectUniqueThings(sTypeName, 2);
					end
				end
			end
			-- 获得除Trait以外的部分
            for cc_row in GameInfo.CC_CIV_UU() do
                if cc_row.CivilizationType == oCiv then
                   pPlayer:AttachModifierByID('CC_PLAYER_UNLOCK_'..cc_row.UnitType);
                   -- print("you get new unit: ",cc_row.UnitType) "LOC_"..oCiv.."_NAME"
				   local sTypeName = "LOC_"..cc_row.UnitType.."_NAME";
				   print("you get new unit: ",Locale.Lookup(sTypeName));
				   CollectUniqueThings(sTypeName, 3);
                end
            end
            for cc_row in GameInfo.CC_LD_UU() do
                if cc_row.LeaderType == oLD then
                   pPlayer:AttachModifierByID('CC_PLAYER_UNLOCK_'..cc_row.UnitType); 
				   local sTypeName = "LOC_"..cc_row.UnitType.."_NAME";
                   print("you get new unit: ",Locale.Lookup(sTypeName)) 
				   CollectUniqueThings(sTypeName, 3);
                end
            end
			for cc_row in GameInfo.CC_CIV_UB() do
                if cc_row.CivilizationType == oCiv then
                   pPlayer:AttachModifierByID('CC_PLAYER_UNLOCK_'..cc_row.BuildingType);
				   local sTypeName = "LOC_"..cc_row.BuildingType.."_NAME";
                   print("you get new building: ",Locale.Lookup(sTypeName))  
				   CollectUniqueThings(sTypeName, 4);
                end
            end
            for cc_row in GameInfo.CC_LD_UB() do
                if cc_row.LeaderType == oLD then
                   pPlayer:AttachModifierByID('CC_PLAYER_UNLOCK_'..cc_row.BuildingType);
				   local sTypeName = "LOC_"..cc_row.BuildingType.."_NAME";
                   print("you get new building: ",Locale.Lookup(sTypeName)) 
				   CollectUniqueThings(sTypeName, 4);
                end
            end
            for cc_row in GameInfo.CC_CIV_UI() do
                if cc_row.CivilizationType == oCiv then
                   pPlayer:AttachModifierByID('CC_PLAYER_UNLOCK_'..cc_row.ImprovementType);
				   local sTypeName = "LOC_"..cc_row.ImprovementType.."_NAME";
                   print("you get new imp: ",Locale.Lookup(sTypeName))  
				   CollectUniqueThings(sTypeName, 5);
                end
            end
            for cc_row in GameInfo.CC_LD_UI() do
                if cc_row.LeaderType == oLD then
                   pPlayer:AttachModifierByID('CC_PLAYER_UNLOCK_'..cc_row.ImprovementType);
				   local sTypeName = "LOC_"..cc_row.ImprovementType.."_NAME";
                   print("you get new imp: ",Locale.Lookup(sTypeName)) 
				   CollectUniqueThings(sTypeName, 5);
                end
            end
            local cc_capture_msg = Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_MSG")
            local cc_capture_sum = Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_SUM")
            print(cc_capture_msg)
            print(cc_capture_sum)
            -- local cc_capture_msg = "[ICON_Capital]占领"..Locale.Lookup(oCivName).."的首都"
            -- local cc_capture_sum = "你现在可以获得该文明的UU,UI和UB!"
            NotificationManager.SendNotification(playerID, "NOTIFICATION_CAPITAL_RECLAIMED", cc_capture_msg, cc_capture_sum)
			if (pPlayer == Players[Game.GetLocalPlayer()]) then
				ExposedMembers.MuyyiCC.CCSendPopup(CanCaptureUA, CanCaptureLA, oCivName, oLDName, sUniqueThings, iUniqueThingCount);
			end
		end
    else
        return
        -- pPlayer:AttachModifierByID("CC_TEST_CITY_10_PRO");
        -- pPlayer:AttachModifierByID("CC_TEST_TECH_ANIMAL_HUSBANDRY");
    end
end

-- config
function InitializeUmaNewGame()
    print("cc_test ver220818");
    -- Game:SetProperty('CanCaptureUA', false);
    -- Game:SetProperty('CanCaptureLA', false);
    -- Game:SetProperty('CanCaptureUU', false);
    -- Game:SetProperty('CanCaptureUI', true);
    -- Game:SetProperty('CanCaptureUB', true);
    -- print("now config is:\n".."CanCaptureUA: "..Game:GetProperty('CanCaptureUA').."\n".."CanCaptureLA: "..Game:GetProperty('CanCaptureLA').."\n".."CanCaptureUU: "..Game:GetProperty('CanCaptureUU'));
end


GameEvents.CapitalBandCiv.Add(CapitalBandCivUa);
LuaEvents.NewGameInitialized.Add(InitializeUmaNewGame);

ExposedMembers.MuyyiCC = ExposedMembers.MuyyiCC or {}
--if ( not ExposedMembers.MuyyiCC) then ExposedMembers.MuyyiCC = {}; end
ExposedMembers.MuyyiCC.CapitalBandCivUa = CapitalBandCivUa;









