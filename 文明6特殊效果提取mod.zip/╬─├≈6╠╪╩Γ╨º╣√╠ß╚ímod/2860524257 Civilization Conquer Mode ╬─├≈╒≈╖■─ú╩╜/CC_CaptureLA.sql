CREATE TABLE IF NOT EXISTS CC_CONFIG(
	Option varchar(255) NOT NULL,
	Value bool,
	PRIMARY KEY (Option)
);

UPDATE CC_CONFIG SET Value = 1
WHERE Option = 'CanCaptureLA'