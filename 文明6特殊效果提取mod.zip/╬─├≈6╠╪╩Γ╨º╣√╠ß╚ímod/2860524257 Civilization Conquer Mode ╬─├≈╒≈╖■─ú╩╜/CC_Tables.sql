
-- config
CREATE TABLE IF NOT EXISTS CC_CONFIG(
	Option varchar(255) NOT NULL,
	Value bool,
	PRIMARY KEY (Option)
);

INSERT OR REPLACE INTO CC_CONFIG (Option,Value) 
VALUES 
	('CanCaptureUA', 0),
    ('CanCaptureLA', 0),
    ('CanCaptureUU', 1),
    ('CanCaptureUI', 1),
    ('CanCaptureUB', 1);
