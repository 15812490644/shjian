include( "PopupDialog" );

function CapitalBandCivUa(cc_capture_msg, cc_capture_sum)
	print("cc_capture_msg is: ", cc_capture_msg);
	print("cc_capture_sum is: ", cc_capture_sum);
	local pPopupDialog	:table = PopupDialogInGame:new("GetAbility"); 
	--pPopupDialog:Reset();
	pPopupDialog:AddTitle(cc_capture_msg);
	pPopupDialog:AddText(cc_capture_sum);
	pPopupDialog:AddButton(Locale.Lookup("LOC_YES"), nil);
	pPopupDialog:Open();
	return;
end

ExposedMembers.MuyyiCC = ExposedMembers.MuyyiCC or {}
ExposedMembers.MuyyiCC.CCSendPopup = CCSendPopup;