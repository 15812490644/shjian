-- cc_test_ui
-- Author: Muyyi
-- DateCreated: 2022/8/18
-- Update: 2021/1/22
include( "PopupDialog" );

function PlayGainMusic(iAllThingsCount)
	if iAllThingsCount > 2 then
		--UI.PlaySound("CC_GainAbility_Many");
	else
		--UI.PlaySound("CC_GainAbility_Few");
	end
	return;
end

function CCSendPopup(bCanCaptureUA, bCanCaptureLA, sCivName, sLeaderName, sUniqueThings, iUniqueThingCount)
	print("sCivName is: ", sCivName);
	print("sLeaderName is: ", sLeaderName);
	local pPopupDialog	:table = PopupDialogInGame:new("GetAbility"); 
	pPopupDialog:AddTitle(Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_POPUP_TITLE"));

	local sPopupTextGain = Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_POPUP_GAINS_1", sCivName);
	
	print("bCanCaptureUA is: ", bCanCaptureUA);
	print("bCanCaptureLA is: ", bCanCaptureLA);
	
	if bCanCaptureUA then
		if (iUniqueThingCount[1] ~= 0) then
			sPopupTextGain = sPopupTextGain..Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_POPUP_GAINS_2", sCivName, sUniqueThings[1]);
		end
	end
	
	if bCanCaptureLA then
		if (iUniqueThingCount[2] ~= 0) then
			sPopupTextGain = sPopupTextGain..Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_POPUP_GAINS_3", sLeaderName, sUniqueThings[2]);
		end
	end
	
	if (iUniqueThingCount[3] ~= 0) then
		sPopupTextGain = sPopupTextGain..Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_POPUP_GAINS_4", sUniqueThings[3]);
	end
	
	if (iUniqueThingCount[4] ~= 0) then
		sPopupTextGain = sPopupTextGain..Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_POPUP_GAINS_5", sUniqueThings[4]);
	end
	
	if (iUniqueThingCount[5] ~= 0) then
		sPopupTextGain = sPopupTextGain..Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_POPUP_GAINS_6", sUniqueThings[5]);
	end
	
	local iAllThingsCount = iUniqueThingCount[3] + iUniqueThingCount[4] + iUniqueThingCount[5];
	
	pPopupDialog:AddText(sPopupTextGain);
	--AddButton
	pPopupDialog:AddConfirmButton(Locale.Lookup("LOC_CC_CAPTURE_CAPITAL_POPUP_OK"), PlayGainMusic(iAllThingsCount));
	pPopupDialog:Open();
	return;
end

function OnCapitalBuilding(playerID:number, cityID:number, cityX:number, cityY:number)
    print("OnCapitalBuilding - " .. tostring(playerID) .. ":" .. tostring(cityID) .. " " .. tostring(cityX) .. "x" .. tostring(cityY));
    local pPlayer = Players[playerID];
    if pPlayer == nil or pPlayer:IsBarbarian() or not (pPlayer:IsMajor()) then
        return;
    end
    local pCity = CityManager.GetCity(playerID,cityID);
    -- 不需要判断是否原始首都，因为无法建造非原始首都
    if not pCity:IsOriginalCapital() then
        return;
    end
    print("capital has building");
    ExposedMembers.MuyyiCC.CapitalBandCivUa(playerID, cityID, cityX, cityY);
end

-- GameEvents.CityBuilt.Add(OnCapitalBuilding);
Events.CityAddedToMap.Add(OnCapitalBuilding);

--if ( not ExposedMembers.MuyyiCC) then ExposedMembers.MuyyiCC = {}; end
ExposedMembers.MuyyiCC = ExposedMembers.MuyyiCC or {}
ExposedMembers.MuyyiCC.CCSendPopup = CCSendPopup;