-- Umamusume
-- Author: Muyyi
-- DateCreated: 2022/9/10
-- 修复了文明特性和领袖特性多次触发的问题

INSERT INTO Modifiers 
		(ModifierId, ModifierType, SubjectRequirementSetId)
VALUES	
		-- 注意这个效果是加产能百分比而非产能（所以你马娘那边也写错了）	
		('CC_TEST_CITY_10_PRO', 'MODIFIER_PLAYER_CITIES_ADJUST_CITY_YIELD_MODIFIER', NULL) ,
		('CC_TEST_TECH_ANIMAL_HUSBANDRY', 'MODIFIER_PLAYER_GRANT_SPECIFIC_TECHNOLOGY', NULL) ;


		
INSERT INTO ModifierArguments
		(ModifierId, Name, Value)
VALUES	
		('CC_TEST_CITY_10_PRO', 'Amount', 100),
		('CC_TEST_CITY_10_PRO', 'YieldType',  'YIELD_PRODUCTION') ,
		('CC_TEST_TECH_ANIMAL_HUSBANDRY', 'TechType',  'TECH_ANIMAL_HUSBANDRY') ;


-- ua
-- CREATE TABLE IF NOT EXISTS CC_CIV_UA AS 
-- SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,TraitModifiers.ModifierId FROM Civilizations
-- INNER JOIN CivilizationTraits ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
-- INNER JOIN Traits ON Traits.TraitType = CivilizationTraits.TraitType
-- INNER JOIN TraitModifiers ON TraitModifiers.TraitType = Traits.TraitType
-- INNER JOIN Modifiers ON Modifiers.ModifierId = TraitModifiers.ModifierId
-- WHERE Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';


CREATE TABLE IF NOT EXISTS CC_CIV_UA (
	CivilizationType    TEXT   NOT NULL,
    TraitType    		TEXT   NOT NULL,
	TraitName			TEXT,
    ModifierId   		TEXT   NOT NULL,
    PRIMARY KEY (CivilizationType, ModifierId)
);

-- CREATE TABLE mytable (
-- field1 text,
-- field2 text,
-- field3 integer,
-- PRIMARY KEY (field1, field2)
-- );


INSERT OR REPLACE INTO CC_CIV_UA (CivilizationType, TraitType, TraitName, ModifierId)
SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,Traits.Name,TraitModifiers.ModifierId FROM Civilizations
INNER JOIN CivilizationTraits ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
INNER JOIN Traits ON Traits.TraitType = CivilizationTraits.TraitType
INNER JOIN TraitModifiers ON TraitModifiers.TraitType = Traits.TraitType
INNER JOIN Modifiers ON Modifiers.ModifierId = TraitModifiers.ModifierId
WHERE Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';

-- ALTER TABLE CC_CIV_UA ADD CONSTRAINT PK_CIV_UA PRIMARY KEY (CivilizationType, ModifierId);

-- la
-- CREATE TABLE IF NOT EXISTS CC_LD_UA AS 
-- SELECT Leaders.LeaderType,LeaderTraits.TraitType,TraitModifiers.ModifierId FROM Leaders
-- INNER JOIN LeaderTraits ON LeaderTraits.LeaderType = Leaders.LeaderType
-- INNER JOIN Traits ON Traits.TraitType = LeaderTraits.TraitType
-- INNER JOIN TraitModifiers ON TraitModifiers.TraitType = Traits.TraitType
-- INNER JOIN Modifiers ON Modifiers.ModifierId = TraitModifiers.ModifierId
-- WHERE Leaders.InheritFrom IS 'LEADER_DEFAULT';

-- ALTER TABLE CC_LD_UA ADD CONSTRAINT PK_LD_UA PRIMARY KEY (LeaderType, ModifierId);

CREATE TABLE IF NOT EXISTS CC_LD_UA (
	LeaderType		TEXT   NOT NULL,
    TraitType		TEXT   NOT NULL,
	TraitName		TEXT,
    ModifierId		TEXT   NOT NULL,
    PRIMARY KEY (LeaderType, ModifierId)
);

INSERT OR REPLACE INTO CC_LD_UA (LeaderType, TraitType, TraitName, ModifierId)
SELECT Leaders.LeaderType,LeaderTraits.TraitType,Traits.Name,TraitModifiers.ModifierId FROM Leaders
INNER JOIN LeaderTraits ON LeaderTraits.LeaderType = Leaders.LeaderType
INNER JOIN Traits ON Traits.TraitType = LeaderTraits.TraitType
INNER JOIN TraitModifiers ON TraitModifiers.TraitType = Traits.TraitType
INNER JOIN Modifiers ON Modifiers.ModifierId = TraitModifiers.ModifierId
WHERE Leaders.InheritFrom IS 'LEADER_DEFAULT';


-- ld_uu
CREATE TABLE IF NOT EXISTS CC_LD_UU AS 
SELECT Leaders.LeaderType,LeaderTraits.TraitType,Units.UnitType FROM Leaders
INNER JOIN LeaderTraits ON LeaderTraits.LeaderType = Leaders.LeaderType
INNER JOIN Traits ON Traits.TraitType = LeaderTraits.TraitType
INNER JOIN Units ON Units.TraitType = Traits.TraitType
WHERE Leaders.InheritFrom IS 'LEADER_DEFAULT';

-- civ_uu
CREATE TABLE IF NOT EXISTS CC_CIV_UU AS 
SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,Units.UnitType FROM Civilizations
INNER JOIN CivilizationTraits ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
INNER JOIN Traits ON Traits.TraitType = CivilizationTraits.TraitType
INNER JOIN Units ON Units.TraitType = Traits.TraitType
WHERE Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';



INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
SELECT 'CC_PLAYER_UNLOCK_'||UnitType, 'MODIFIER_PLAYER_ADJUST_VALID_UNIT_BUILD' FROM CC_LD_UU;

INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
SELECT 'CC_PLAYER_UNLOCK_'||UnitType, 'MODIFIER_PLAYER_ADJUST_VALID_UNIT_BUILD' FROM CC_CIV_UU;

INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
SELECT 'CC_PLAYER_UNLOCK_'||UnitType, 'UnitType', UnitType FROM CC_LD_UU;

INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
SELECT 'CC_PLAYER_UNLOCK_'||UnitType, 'UnitType', UnitType FROM CC_CIV_UU;

-- ld_ui
CREATE TABLE IF NOT EXISTS CC_LD_UI AS 
SELECT Leaders.LeaderType,LeaderTraits.TraitType,Improvements.ImprovementType FROM Leaders
INNER JOIN LeaderTraits ON LeaderTraits.LeaderType = Leaders.LeaderType
INNER JOIN Traits ON Traits.TraitType = LeaderTraits.TraitType
INNER JOIN Improvements ON Improvements.TraitType = Traits.TraitType
WHERE Leaders.InheritFrom IS 'LEADER_DEFAULT';

-- cc_ui
CREATE TABLE IF NOT EXISTS CC_CIV_UI AS 
SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,Improvements.ImprovementType FROM Civilizations
INNER JOIN CivilizationTraits ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
INNER JOIN Traits ON Traits.TraitType = CivilizationTraits.TraitType
INNER JOIN Improvements ON Improvements.TraitType = Traits.TraitType
WHERE Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';

INSERT OR REPLACE INTO  Modifiers 
		(ModifierId, ModifierType, RunOnce, Permanent, OwnerRequirementSetId, SubjectRequirementSetId)
SELECT 'CC_PLAYER_UNLOCK_' || ImprovementType, 'MODIFIER_PLAYER_ADJUST_VALID_IMPROVEMENT', 0, 0, NULL, NULL
FROM CC_LD_UI;

INSERT OR REPLACE INTO  Modifiers 
		(ModifierId, ModifierType, RunOnce, Permanent, OwnerRequirementSetId, SubjectRequirementSetId)
SELECT 'CC_PLAYER_UNLOCK_' || ImprovementType, 'MODIFIER_PLAYER_ADJUST_VALID_IMPROVEMENT', 0, 0, NULL, NULL
FROM CC_CIV_UI;

INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
SELECT 'CC_PLAYER_UNLOCK_'||ImprovementType, 'ImprovementType', ImprovementType FROM CC_LD_UI;

INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
SELECT 'CC_PLAYER_UNLOCK_'||ImprovementType, 'ImprovementType', ImprovementType FROM CC_CIV_UI;


-- ld_ub
CREATE TABLE IF NOT EXISTS CC_LD_UB AS 
SELECT Leaders.LeaderType,LeaderTraits.TraitType,Buildings.BuildingType,BuildingReplaces.ReplacesBuildingType FROM Leaders
INNER JOIN LeaderTraits ON LeaderTraits.LeaderType = Leaders.LeaderType
INNER JOIN Traits ON Traits.TraitType = LeaderTraits.TraitType
INNER JOIN Buildings ON Buildings.TraitType = Traits.TraitType
INNER JOIN BuildingReplaces ON BuildingReplaces.CivUniqueBuildingType = Buildings.BuildingType
WHERE Leaders.InheritFrom IS 'LEADER_DEFAULT';


-- civ_ub
CREATE TABLE IF NOT EXISTS CC_CIV_UB AS 
SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,Buildings.BuildingType,BuildingReplaces.ReplacesBuildingType FROM Civilizations
INNER JOIN CivilizationTraits ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
INNER JOIN Traits ON Traits.TraitType = CivilizationTraits.TraitType
INNER JOIN Buildings ON Buildings.TraitType = Traits.TraitType
INNER JOIN BuildingReplaces ON BuildingReplaces.CivUniqueBuildingType = Buildings.BuildingType
WHERE Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';



INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'MODIFIER_PLAYER_ADJUST_VALID_BUILDING' FROM CC_LD_UB;

INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'MODIFIER_PLAYER_ADJUST_VALID_BUILDING' FROM CC_CIV_UB;

INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'BuildingType', BuildingType FROM CC_LD_UB;

INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'BuildingType', BuildingType FROM CC_CIV_UB;

INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'BuildingTypeToReplace', ReplacesBuildingType FROM CC_LD_UB;

INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'BuildingTypeToReplace', ReplacesBuildingType FROM CC_CIV_UB;


-- config
CREATE TABLE IF NOT EXISTS CC_CONFIG(
	Option varchar(255) NOT NULL,
	Value BOOLEAN,
	PRIMARY KEY (Option)
);

INSERT OR REPLACE INTO CC_CONFIG (Option, Value) 
VALUES 
	('CanCaptureUA', 0),
    ('CanCaptureLA', 0),
    ('CanCaptureUU', 1),
    ('CanCaptureUI', 1),
    ('CanCaptureUB', 1);



-- UPDATE Building_YieldChanges 
-- SET YieldChange = 10
-- WHERE BuildingType = 'BUILDING_PALACE';



-- extra mod and dlc
CREATE TRIGGER CCNewUA
AFTER INSERT ON TraitModifiers
WHEN NEW.TraitType NOT NULL
BEGIN
	INSERT OR REPLACE INTO CC_CIV_UA 
	(CivilizationType, TraitType, ModifierId)
	SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,TraitModifiers.ModifierId FROM TraitModifiers
	INNER JOIN Traits ON Traits.TraitType = TraitModifiers.TraitType
	INNER JOIN CivilizationTraits ON Traits.TraitType = CivilizationTraits.TraitType
	INNER JOIN Civilizations ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
	WHERE TraitModifiers.TraitType = NEW.TraitType AND Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';


	INSERT OR REPLACE INTO CC_LD_UA 
	(LeaderType, TraitType, ModifierId)
	SELECT Leaders.LeaderType,LeaderTraits.TraitType,TraitModifiers.ModifierId FROM TraitModifiers
	INNER JOIN Traits ON Traits.TraitType = TraitModifiers.TraitType
	INNER JOIN LeaderTraits ON Traits.TraitType = LeaderTraits.TraitType
	INNER JOIN Leaders ON Leaders.LeaderType = LeaderTraits.LeaderType
	WHERE TraitModifiers.TraitType = NEW.TraitType AND Leaders.InheritFrom IS 'LEADER_DEFAULT';
END;


CREATE TRIGGER CCNewUU
AFTER INSERT ON Units
WHEN NEW.TraitType NOT NULL
BEGIN
	INSERT OR REPLACE INTO CC_CIV_UU 
	(CivilizationType, TraitType, UnitType)
	SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,Units.UnitType FROM Units
	INNER JOIN Traits ON Traits.TraitType = Units.TraitType
	INNER JOIN CivilizationTraits ON Traits.TraitType = CivilizationTraits.TraitType
	INNER JOIN Civilizations ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
	WHERE Units.UnitType = NEW.UnitType AND Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';

	INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
	SELECT 'CC_PLAYER_UNLOCK_'||UnitType, 'MODIFIER_PLAYER_ADJUST_VALID_UNIT_BUILD' FROM CC_CIV_UU;

	INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
	SELECT 'CC_PLAYER_UNLOCK_'||UnitType, 'UnitType', UnitType FROM CC_CIV_UU;

	INSERT OR REPLACE INTO CC_LD_UU 
	(LeaderType, TraitType, UnitType)
	SELECT Leaders.LeaderType,LeaderTraits.TraitType,Units.UnitType FROM Units
	INNER JOIN Traits ON Traits.TraitType = Units.TraitType
	INNER JOIN LeaderTraits ON LeaderTraits.TraitType = Traits.TraitType
	INNER JOIN Leaders ON Leaders.LeaderType = LeaderTraits.LeaderType
	WHERE Units.UnitType = NEW.UnitType AND Leaders.InheritFrom IS 'LEADER_DEFAULT';

	INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
	SELECT 'CC_PLAYER_UNLOCK_'||UnitType, 'MODIFIER_PLAYER_ADJUST_VALID_UNIT_BUILD' FROM CC_LD_UU;

	INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
	SELECT 'CC_PLAYER_UNLOCK_'||UnitType, 'UnitType', UnitType FROM CC_LD_UU;
END;

CREATE TRIGGER CCNewUB
AFTER INSERT ON Buildings
WHEN NEW.TraitType NOT NULL
BEGIN
	INSERT OR REPLACE INTO CC_CIV_UB 
	(CivilizationType, TraitType, BuildingType)
	SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,Buildings.BuildingType FROM Buildings
	INNER JOIN Traits ON Traits.TraitType = Buildings.TraitType
	INNER JOIN CivilizationTraits ON Traits.TraitType = CivilizationTraits.TraitType
	INNER JOIN Civilizations ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
	WHERE Buildings.BuildingType = NEW.BuildingType AND Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';

	INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
	SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'MODIFIER_PLAYER_ADJUST_VALID_BUILDING' FROM CC_CIV_UB;

	INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
	SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'BuildingType', BuildingType FROM CC_CIV_UB;

	INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
	SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'BuildingTypeToReplace', ReplacesBuildingType FROM CC_CIV_UB;

	INSERT OR REPLACE INTO CC_LD_UB 
	(LeaderType, TraitType, BuildingType)
	SELECT Leaders.LeaderType,LeaderTraits.TraitType,Buildings.BuildingType FROM Buildings
	INNER JOIN Traits ON Traits.TraitType = Buildings.TraitType
	INNER JOIN LeaderTraits ON LeaderTraits.TraitType = Traits.TraitType
	INNER JOIN Leaders ON Leaders.LeaderType = LeaderTraits.LeaderType
	WHERE Buildings.BuildingType = NEW.BuildingType AND Leaders.InheritFrom IS 'LEADER_DEFAULT';

	INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
	SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'MODIFIER_PLAYER_ADJUST_VALID_BUILDING' FROM CC_LD_UB;

	INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
	SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'BuildingType', BuildingType FROM CC_LD_UB;

	INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
	SELECT 'CC_PLAYER_UNLOCK_'||BuildingType, 'BuildingTypeToReplace', ReplacesBuildingType FROM CC_LD_UB;
END;

CREATE TRIGGER CCNewUI
AFTER INSERT ON Improvements
WHEN NEW.TraitType NOT NULL
BEGIN
	INSERT OR REPLACE INTO CC_CIV_UI 
	(CivilizationType, TraitType, ImprovementType)
	SELECT Civilizations.CivilizationType,CivilizationTraits.TraitType,Improvements.ImprovementType FROM Improvements
	INNER JOIN Traits ON Traits.TraitType = Improvements.TraitType
	INNER JOIN CivilizationTraits ON Traits.TraitType = CivilizationTraits.TraitType
	INNER JOIN Civilizations ON Civilizations.CivilizationType = CivilizationTraits.CivilizationType
	WHERE Improvements.ImprovementType = NEW.ImprovementType AND Civilizations.StartingCivilizationLevelType IS 'CIVILIZATION_LEVEL_FULL_CIV';

	INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
	SELECT 'CC_PLAYER_UNLOCK_'||ImprovementType, 'MODIFIER_PLAYER_ADJUST_VALID_IMPROVEMENT' FROM CC_CIV_UI;

	INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
	SELECT 'CC_PLAYER_UNLOCK_'||ImprovementType, 'ImprovementType', ImprovementType FROM CC_CIV_UI;

	INSERT OR REPLACE INTO CC_LD_UI 
	(LeaderType, TraitType, ImprovementType)
	SELECT Leaders.LeaderType,LeaderTraits.TraitType,Improvements.ImprovementType FROM Improvements
	INNER JOIN Traits ON Traits.TraitType = Improvements.TraitType
	INNER JOIN LeaderTraits ON LeaderTraits.TraitType = Traits.TraitType
	INNER JOIN Leaders ON Leaders.LeaderType = LeaderTraits.LeaderType
	WHERE Improvements.ImprovementType = NEW.ImprovementType AND Leaders.InheritFrom IS 'LEADER_DEFAULT';

	INSERT OR REPLACE INTO Modifiers (ModifierId,ModifierType) 
	SELECT 'CC_PLAYER_UNLOCK_'||ImprovementType, 'MODIFIER_PLAYER_ADJUST_VALID_IMPROVEMENT' FROM CC_LD_UI;

	INSERT OR REPLACE INTO ModifierArguments (ModifierId,Name,Value) 
	SELECT 'CC_PLAYER_UNLOCK_'||ImprovementType, 'ImprovementType', ImprovementType FROM CC_LD_UI;
END;


