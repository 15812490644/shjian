-- MLME_Mementos_GameEffects_Mode
-- Author: Maple_Leaves
-- DateCreated: 5/28/2025 12:40:38 AM
--------------------------------------------------------------


--=======================================================================
--���ްͶ�ʫ��
--��Ժ�㳡+1 [ICON_GreatWriter] �����ҵ����� [ICON_GreatMusician] �����ּҵ�����
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS',		'GAME_EFFECT_MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS_GREAT_WRITER_POINT'),
	('MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS',		'GAME_EFFECT_MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS_GREAT_MUSICIAN_POINT');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,												OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS_GREAT_WRITER_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_DISTRICT_IS_THEATER_LIKE_MLME'),
	('GAME_EFFECT_MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS_GREAT_MUSICIAN_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_DISTRICT_IS_THEATER_LIKE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,																Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS_GREAT_WRITER_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS_GREAT_WRITER_POINT',	'Amount',						1),
	('GAME_EFFECT_MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS_GREAT_MUSICIAN_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_MUSICIAN'),
	('GAME_EFFECT_MEMENTO_TROUBADOUR_POETRY_MANUSCRIPTS_GREAT_MUSICIAN_POINT',	'Amount',						1);

--=======================================================================
--���ɹ�Ϯ����ʡ�
--�غ������������µ�λ+20% [ICON_Production] ��������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_MOKO_SHURAI_EKOTOBA',					'GAME_EFFECT_MEMENTO_MOKO_SHURAI_EKOTOBA_MILITARY_UNITS_PRODUCTION');


INSERT INTO Modifiers
	(ModifierId,															ModifierType,												OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_MOKO_SHURAI_EKOTOBA_MILITARY_UNITS_PRODUCTION',	'MODIFIER_PLAYER_CITIES_ADJUST_MILITARY_UNITS_PRODUCTION',	NULL,					'REQSET_PLOT_IS_COASTAL_LAND_MLME');

INSERT INTO ModifierArguments
	(ModifierId,															Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_MOKO_SHURAI_EKOTOBA_MILITARY_UNITS_PRODUCTION',	'Amount',						20);

	

INSERT INTO Requirements 
	(RequirementId,									RequirementType,						Inverse	)
VALUES
	('REQUIRES_PLOT_IS_COASTAL_LAND_MLME',			'REQUIREMENT_PLOT_IS_COASTAL_LAND',		0);


INSERT INTO RequirementSets
	(RequirementSetId,								RequirementSetType			)
VALUES
	('REQSET_PLOT_IS_COASTAL_LAND_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
VALUES
	('REQSET_PLOT_IS_COASTAL_LAND_MLME',			'REQUIRES_PLOT_IS_COASTAL_LAND_MLME');

--=======================================================================
--ʥ�˵ñ�������
--�½����ĳ��ж���+1 [ICON_Citizen] �˿ڡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_FOUNDING_DECREE_OF_SAINT_PETERSBURG',		'GAME_EFFECT_MEMENTO_FOUNDING_DECREE_OF_SAINT_PETERSBURG_FREE_POPULATION');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_FOUNDING_DECREE_OF_SAINT_PETERSBURG_FREE_POPULATION',	'MODIFIER_PLAYER_BUILT_CITIES_GRANT_FREE_POPULATION',	1,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,																	Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_FOUNDING_DECREE_OF_SAINT_PETERSBURG_FREE_POPULATION',		'Amount',						1);

--=======================================================================
--������˵
--��Ժ�㳡������+2 [ICON_Culture] �Ļ�ֵ���ڼӳɡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_PERICLES_FUNERAL_ORATION',				'GAME_EFFECT_MEMENTO_PERICLES_FUNERAL_ORATION_THEATER_CULTURE_ADJACENCY');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_PERICLES_FUNERAL_ORATION_THEATER_CULTURE_ADJACENCY',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_BASE_YIELD_CHANGE_MLME',	0,			NULL,					'REQSET_DISTRICT_IS_THEATER_LIKE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,																	Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_PERICLES_FUNERAL_ORATION_THEATER_CULTURE_ADJACENCY',		'YieldType',					'YIELD_CULTURE'),
	('GAME_EFFECT_MEMENTO_PERICLES_FUNERAL_ORATION_THEATER_CULTURE_ADJACENCY',		'Amount',						2);


INSERT INTO Vocabularies
	(Vocabulary)
VALUES
	('DISTRICT_CLASS_MLME');

INSERT INTO Tags
	(Tag,									Vocabulary)
VALUES
	('CLASS_DISTRICT_THEATER_LIKE_MLME',	'DISTRICT_CLASS_MLME');

INSERT INTO TypeTags
	(Type,					Tag)
VALUES	
	('DISTRICT_THEATER',	'CLASS_DISTRICT_THEATER_LIKE_MLME');


INSERT INTO Requirements 
	(RequirementId,									RequirementType,							Inverse	)
VALUES
	('REQUIRES_DISTRICT_IS_THEATER_LIKE_MLME',		'REQUIREMENT_PLOT_DISTRICT_TAG_MATCHES',	0);

INSERT INTO RequirementArguments
	(RequirementId,									Name,			Value	)
VALUES
	('REQUIRES_DISTRICT_IS_THEATER_LIKE_MLME',		'Tag',			'CLASS_DISTRICT_THEATER_LIKE_MLME');

INSERT INTO RequirementSets
	(RequirementSetId,									RequirementSetType			)
VALUES
	('REQSET_DISTRICT_IS_THEATER_LIKE_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,									RequirementId					)
VALUES
	('REQSET_DISTRICT_IS_THEATER_LIKE_MLME',			'REQUIRES_DISTRICT_IS_THEATER_LIKE_MLME');


--=======================================================================
--�Ŕ����
--���������λ�ṩ+2 [ICON_Faith] ����ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_TSAGAAN_SULDE',							'GAME_EFFECT_MEMENTO_TSAGAAN_SULDE_CAVALRY_FAITH');


INSERT INTO Modifiers
	(ModifierId,											ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TSAGAAN_SULDE_CAVALRY_FAITH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,											Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_TSAGAAN_SULDE_CAVALRY_FAITH',		'AbilityType',					'ABILITY_CAVALRY_FAITH_MLME');


--=======================================================================
--ţƤ
--�½����ĳ��ж�����2����Ԫ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_OXHIDE',									'GAME_EFFECT_MEMENTO_OXHIDE_EXTRA_CITY_TILES');


INSERT INTO Modifiers
	(ModifierId,										ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_OXHIDE_EXTRA_CITY_TILES',		'MODIFIER_PLAYER_ADJUST_CITY_TILES',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,											Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_OXHIDE_EXTRA_CITY_TILES',			'Amount',					2);


--=======================================================================
--��˹�����Ƕ�ʥ����
--ʥ��+2 [ICON_Amenities] �˾Ӷȡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_EL_ESCORIAL_RELIQUARIES',					'GAME_EFFECT_MEMENTO_EL_ESCORIAL_RELIQUARIES_HOLYSITE_AMENITY');


INSERT INTO Modifiers
	(ModifierId,															ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_EL_ESCORIAL_RELIQUARIES_HOLYSITE_AMENITY',		'MODIFIER_PLAYER_DISTRICTS_ADJUST_DISTRICT_AMENITY_MLME',	0,			NULL,					'REQSET_DISTRICT_IS_HOLY_SITE_LIKE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,															Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_EL_ESCORIAL_RELIQUARIES_HOLYSITE_AMENITY',		'Amount',					2);


--=======================================================================
--����˹̹�ĺ�Լ��
--ͨ���ǰ��ó��·��+2 [ICON_Gold] ��ң���Ϸ���������ͺ����+2��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_TREATY_OF_CONSTANCE',					'GAME_EFFECT_MEMENTO_TREATY_OF_CONSTANCE_CITYSTATE_TRADE_GOLD'),
	('MEMENTO_TREATY_OF_CONSTANCE',					'GAME_EFFECT_MEMENTO_TREATY_OF_CONSTANCE_CITYSTATE_TRADE_GOLD_MEDIEVAL');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,												Permanent,	OwnerRequirementSetId,									SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TREATY_OF_CONSTANCE_CITYSTATE_TRADE_GOLD',			'MODIFIER_PLAYER_ADJUST_TRADE_ROUTES_CITY_STATE_YIELD',		0,			NULL,													NULL),
	('GAME_EFFECT_MEMENTO_TREATY_OF_CONSTANCE_CITYSTATE_TRADE_GOLD_MEDIEVAL',	'MODIFIER_PLAYER_ADJUST_TRADE_ROUTES_CITY_STATE_YIELD',		0,			'REQSET_GAME_ERA_ATLEAST_EXPANSION_ERA_MEDIEVAL_MLME',	NULL);

INSERT INTO ModifierArguments
	(ModifierId,																	Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_TREATY_OF_CONSTANCE_CITYSTATE_TRADE_GOLD',				'YieldType',				'YIELD_GOLD'),
	('GAME_EFFECT_MEMENTO_TREATY_OF_CONSTANCE_CITYSTATE_TRADE_GOLD',				'Amount',					2),
	('GAME_EFFECT_MEMENTO_TREATY_OF_CONSTANCE_CITYSTATE_TRADE_GOLD_MEDIEVAL',		'YieldType',				'YIELD_GOLD'),
	('GAME_EFFECT_MEMENTO_TREATY_OF_CONSTANCE_CITYSTATE_TRADE_GOLD_MEDIEVAL',		'Amount',					2);

--=======================================================================
--Ϳ��ľ��
--½�ص�λ��ɱ��Ҫ��С�������ĵ�λʱ�������ս����25%�� [ICON_GreatWriter] �����ҵ�������׼�ٶ��£���
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_WAX_COATED_WOODEN_TABLET',			'GAME_EFFECT_MEMENTO_WAX_COATED_WOODEN_TABLET_COMBAT_GREAT_WRITER_POINT');


INSERT INTO Modifiers
	(ModifierId,																	ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_WAX_COATED_WOODEN_TABLET_COMBAT_GREAT_WRITER_POINT',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,																	Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_WAX_COATED_WOODEN_TABLET_COMBAT_GREAT_WRITER_POINT',		'AbilityType',					'ABILITY_COMBAT_GREAT_WRITER_POINT_MLME');

--=======================================================================
--���������¡������������ȡ�
--�ڵз�������սʱ+3 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_SAGA_OF_HARALD_HARDRADA',				'GAME_EFFECT_MEMENTO_SAGA_OF_HARALD_HARDRADA_STRENGTH_ENEMY_TERRITORY');


INSERT INTO Modifiers
	(ModifierId,																	ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_SAGA_OF_HARALD_HARDRADA_STRENGTH_ENEMY_TERRITORY',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,																	Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_SAGA_OF_HARALD_HARDRADA_STRENGTH_ENEMY_TERRITORY',		'AbilityType',					'ABILITY_STRENGTH_ENEMY_TERRITORY_MLME');

--=======================================================================
--������٤��ʲʷʫ�����
--����;��񷽼Ɱ+1 [ICON_GreatWriter] �����ҵ���������Ӣ�۴�˵��Ŀʱ+100% [ICON_Production] ��������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_EPIC_OF_GILGAMESH',				'GAME_EFFECT_MEMENTO_EPIC_OF_GILGAMESH_MONUMENT_GREAT_WRITER_POINT');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,										Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_EPIC_OF_GILGAMESH_MONUMENT_GREAT_WRITER_POINT',		'MODIFIER_PLAYER_CITIES_ADJUST_GREAT_PERSON_POINT',	0,			NULL,					'REQSET_CITY_HAS_MONUMENT_LIKE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,																Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_EPIC_OF_GILGAMESH_MONUMENT_GREAT_WRITER_POINT',		'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_EPIC_OF_GILGAMESH_MONUMENT_GREAT_WRITER_POINT',		'Amount',						1);


INSERT INTO Requirements 
	(RequirementId,									RequirementType,						Inverse	)
VALUES
	('REQUIRES_CITY_HAS_MONUMENT_MLME',				'REQUIREMENT_CITY_HAS_BUILDING',		0);

INSERT INTO RequirementArguments
	(RequirementId,									Name,					Value	)
VALUES
	('REQUIRES_CITY_HAS_MONUMENT_MLME',				'BuildingType',			'BUILDING_MONUMENT');

INSERT INTO RequirementSets
	(RequirementSetId,								RequirementSetType			)
VALUES
	('REQSET_CITY_HAS_MONUMENT_LIKE_MLME',			'REQUIREMENTSET_TEST_ANY');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
VALUES
	('REQSET_CITY_HAS_MONUMENT_LIKE_MLME',			'REQUIRES_CITY_HAS_MONUMENT_MLME');

--=======================================================================
--����
--ѵ�����ʱ+50% [ICON_Production] ��������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_BLACK_CLOTH',						'GAME_EFFECT_MEMENTO_BLACK_CLOTH_SPY_PRODUCTION');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,										Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_BLACK_CLOTH_SPY_PRODUCTION',				'MODIFIER_PLAYER_UNITS_ADJUST_UNIT_PRODUCTION',		0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_BLACK_CLOTH_SPY_PRODUCTION',				'UnitType',					'UNIT_SPY'),
	('GAME_EFFECT_MEMENTO_BLACK_CLOTH_SPY_PRODUCTION',				'Amount',					50);


--=======================================================================
--�°�����ŵ����
--�����㳡�����е�1��3���������ṩ+2 [ICON_GreatWriter]�����ң� [ICON_GreatArtist] �������Һ� [ICON_GreatMusician] �����ּҵ�����

--�����㳡
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_WRITER_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_ARTIST_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_MUSICIAN_POINT');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,												OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_WRITER_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_DISTRICT_IS_GOVERNMENT_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_ARTIST_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_DISTRICT_IS_GOVERNMENT_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_MUSICIAN_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_DISTRICT_IS_GOVERNMENT_MLME');

INSERT INTO ModifierArguments
	(ModifierId,																Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_WRITER_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_WRITER_POINT',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_ARTIST_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_ARTIST'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_ARTIST_POINT',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_MUSICIAN_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_MUSICIAN'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOVERNMENT_GREAT_MUSICIAN_POINT',	'Amount',						2);


INSERT INTO Requirements 
	(RequirementId,									RequirementType,						Inverse	)
VALUES
	('REQUIRES_DISTRICT_IS_GOVERNMENT_MLME',		'REQUIREMENT_DISTRICT_TYPE_MATCHES',	0);

INSERT INTO RequirementArguments
	(RequirementId,									Name,					Value	)
VALUES
	('REQUIRES_DISTRICT_IS_GOVERNMENT_MLME',		'DistrictType',			'DISTRICT_GOVERNMENT');

INSERT INTO RequirementSets
	(RequirementSetId,								RequirementSetType			)
VALUES
	('REQSET_DISTRICT_IS_GOVERNMENT_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
VALUES
	('REQSET_DISTRICT_IS_GOVERNMENT_MLME',			'REQUIRES_DISTRICT_IS_GOVERNMENT_MLME');

--�����㳡����
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_WRITER_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_ARTIST_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_MUSICIAN_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_WRITER_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_ARTIST_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_MUSICIAN_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_WRITER_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_ARTIST_POINT'),
	('MEMENTO_LETTERS_TO_AZZOLINO',						'GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_MUSICIAN_POINT');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,												OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_WRITER_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_1_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_ARTIST_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_1_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_MUSICIAN_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_1_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_WRITER_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_2_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_ARTIST_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_2_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_MUSICIAN_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_2_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_WRITER_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_3_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_ARTIST_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_3_MLME'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_MUSICIAN_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_3_MLME');

INSERT INTO ModifierArguments
	(ModifierId,																Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_WRITER_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_WRITER_POINT',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_ARTIST_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_ARTIST'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_ARTIST_POINT',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_MUSICIAN_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_MUSICIAN'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_1_GREAT_MUSICIAN_POINT',	'Amount',						2),

	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_WRITER_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_WRITER_POINT',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_ARTIST_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_ARTIST'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_ARTIST_POINT',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_MUSICIAN_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_MUSICIAN'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_2_GREAT_MUSICIAN_POINT',	'Amount',						2),

	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_WRITER_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_WRITER_POINT',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_ARTIST_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_ARTIST'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_ARTIST_POINT',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_MUSICIAN_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_MUSICIAN'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_AZZOLINO_GOV_TIER_3_GREAT_MUSICIAN_POINT',	'Amount',						2);

INSERT INTO RequirementSets
	(RequirementSetId,											RequirementSetType			)
VALUES
	('REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_1_MLME',			'REQUIREMENTSET_TEST_ANY'),
	('REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_2_MLME',			'REQUIREMENTSET_TEST_ANY'),
	('REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_3_MLME',			'REQUIREMENTSET_TEST_ANY');

--=======================================================================
--Ů����̺
--���Գǰ���������ͬ�˵ȼ��� [ICON_FAVOR] �⽻֧��+50%��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_QUEEN_S_CARPET',					'GAME_EFFECT_MEMENTO_QUEEN_S_CARPET_ALLIANCE_FAVOR'),
	('MEMENTO_QUEEN_S_CARPET',					'GAME_EFFECT_MEMENTO_QUEEN_S_CARPET_SUZERAIN_FAVOR');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_QUEEN_S_CARPET_ALLIANCE_FAVOR',			'MODIFIER_PLAYER_ADJUST_ALLIANCE_FAVOR_MULTIPLIER',		0,			NULL,					NULL),
	('GAME_EFFECT_MEMENTO_QUEEN_S_CARPET_SUZERAIN_FAVOR',			'MODIFIER_PLAYER_ADJUST_SUZERAIN_FAVOR_MULTIPLIER',		0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_QUEEN_S_CARPET_ALLIANCE_FAVOR',			'Amount',					50),
	('GAME_EFFECT_MEMENTO_QUEEN_S_CARPET_SUZERAIN_FAVOR',			'Amount',					50);

--=======================================================================
--�����ʥʯ
--�������ӵ���Ѹ����� [ICON_RESOURCE_STONE] ʯͷ��Դ����+15% [ICON_Culture] �Ļ�ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_NINEPIN_ROCK',					'GAME_EFFECT_MEMENTO_NINEPIN_ROCK_CITY_IMPROVED_STONE_CULTURE');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_NINEPIN_ROCK_CITY_IMPROVED_STONE_CULTURE',	'MODIFIER_PLAYER_CITIES_ADJUST_CITY_YIELD_MODIFIER',	0,			NULL,					'REQSET_CITY_HAS_IMPROVED_STONE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,														Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_NINEPIN_ROCK_CITY_IMPROVED_STONE_CULTURE',	'YieldType',				'YIELD_CULTURE'),
	('GAME_EFFECT_MEMENTO_NINEPIN_ROCK_CITY_IMPROVED_STONE_CULTURE',	'Amount',					15);


INSERT INTO Requirements 
	(RequirementId,									RequirementType,									Inverse	)
VALUES
	('REQUIRES_CITY_HAS_IMPROVED_STONE_MLME',		'REQUIREMENT_CITY_HAS_RESOURCE_TYPE_IMPROVED',		0);

INSERT INTO RequirementArguments
	(RequirementId,									Name,					Value	)
VALUES
	('REQUIRES_CITY_HAS_IMPROVED_STONE_MLME',		'ResourceType',			'RESOURCE_STONE');

INSERT INTO RequirementSets
	(RequirementSetId,								RequirementSetType			)
VALUES
	('REQSET_CITY_HAS_IMPROVED_STONE_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
VALUES
	('REQSET_CITY_HAS_IMPROVED_STONE_MLME',			'REQUIRES_CITY_HAS_IMPROVED_STONE_MLME');

--=======================================================================
--�����ͼ��ɡ�
--���׶����ڴ�½��ʱ��λ+3 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_LA_ARAUCANA',							'GAME_EFFECT_MEMENTO_LA_ARAUCANA_HOME_CONTINENT_STRENGTH');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_LA_ARAUCANA_HOME_CONTINENT_STRENGTH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_LA_ARAUCANA_HOME_CONTINENT_STRENGTH',		'AbilityType',					'ABILITY_HOME_CONTINENT_STRENGTH_MLME');

--=======================================================================
--�¸ҵ���
--���ڽ̵�λ���ŷ������ڽ̵���������ս��ʱ��+3 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_BRAVE_HEART',							'GAME_EFFECT_MEMENTO_BRAVE_HEART_OTHER_RELIGION_STRENGTH_ATTACH');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,								Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_BRAVE_HEART_OTHER_RELIGION_STRENGTH_ATTACH',	'MODIFIER_PLAYER_UNITS_ATTACH_MODIFIER',	0,			NULL,					'WARS_OF_RELIGION_REQUIREMENTS'),
	('GAME_EFFECT_MEMENTO_BRAVE_HEART_OTHER_RELIGION_STRENGTH',			'MODIFIER_UNIT_ADJUST_COMBAT_STRENGTH',		0,			NULL,					'REQUIREMENTS_OPPONENT_IS_OTHER_RELIGION');

INSERT INTO ModifierArguments
	(ModifierId,															Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_BRAVE_HEART_OTHER_RELIGION_STRENGTH_ATTACH',		'ModifierId',	'GAME_EFFECT_MEMENTO_BRAVE_HEART_OTHER_RELIGION_STRENGTH'),
	('GAME_EFFECT_MEMENTO_BRAVE_HEART_OTHER_RELIGION_STRENGTH',				'Amount',		3);

INSERT INTO ModifierStrings
	(ModifierId,													Context,			Text)
VALUES
	('GAME_EFFECT_MEMENTO_BRAVE_HEART_OTHER_RELIGION_STRENGTH',		'Preview',			'LOC_BRAVE_HEART_OTHER_RELIGION_STRENGTH_PREVIEW');


--=======================================================================
--�ƽ�
--ʥ�ػ��+4 [ICON_Gold] ������ڼӳɡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_GOLD_OF_MANSA_MUSA',				'GAME_EFFECT_MEMENTO_GOLD_OF_MANSA_MUSA_HOLY_SITE_GOLD_ADJACENCY');


INSERT INTO Modifiers
	(ModifierId,															ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_GOLD_OF_MANSA_MUSA_HOLY_SITE_GOLD_ADJACENCY',		'MODIFIER_PLAYER_DISTRICTS_ADJUST_BASE_YIELD_CHANGE_MLME',	0,			NULL,					'REQSET_DISTRICT_IS_HOLY_SITE_LIKE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,															Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_GOLD_OF_MANSA_MUSA_HOLY_SITE_GOLD_ADJACENCY',		'YieldType',					'YIELD_GOLD'),
	('GAME_EFFECT_MEMENTO_GOLD_OF_MANSA_MUSA_HOLY_SITE_GOLD_ADJACENCY',		'Amount',						4);


INSERT INTO Tags
	(Tag,									Vocabulary)
VALUES
	('CLASS_DISTRICT_HOLY_SITE_LIKE_MLME',	'DISTRICT_CLASS_MLME');

INSERT INTO TypeTags
	(Type,					Tag)
VALUES	
	('DISTRICT_HOLY_SITE',	'CLASS_DISTRICT_HOLY_SITE_LIKE_MLME');


INSERT INTO Requirements 
	(RequirementId,										RequirementType,							Inverse	)
VALUES
	('REQUIRES_DISTRICT_IS_HOLY_SITE_LIKE_MLME',		'REQUIREMENT_PLOT_DISTRICT_TAG_MATCHES',	0);

INSERT INTO RequirementArguments
	(RequirementId,										Name,			Value	)
VALUES
	('REQUIRES_DISTRICT_IS_HOLY_SITE_LIKE_MLME',		'Tag',			'CLASS_DISTRICT_HOLY_SITE_LIKE_MLME');

INSERT INTO RequirementSets
	(RequirementSetId,									RequirementSetType			)
VALUES
	('REQSET_DISTRICT_IS_HOLY_SITE_LIKE_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,									RequirementId					)
VALUES
	('REQSET_DISTRICT_IS_HOLY_SITE_LIKE_MLME',			'REQUIRES_DISTRICT_IS_HOLY_SITE_LIKE_MLME');

--=======================================================================
--����
--�غ���½�ص�Ԫ�������Դ+1 [ICON_Faith] ����ֵ���غ����ݾ�+1 [ICON_Faith] ����ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_SEA_SALT',				'GAME_EFFECT_MEMENTO_SEA_SALT_COASTAL_LAND_FAITH'),
	('MEMENTO_SEA_SALT',				'GAME_EFFECT_MEMENTO_SEA_SALT_COASTAL_LAND_STEPWELL_FAITH'),
	('MEMENTO_SEA_SALT',				'GAME_EFFECT_MEMENTO_SEA_SALT_SALT_FAITH');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_SEA_SALT_COASTAL_LAND_FAITH',					'MODIFIER_PLAYER_ADJUST_PLOT_YIELD',	0,			NULL,					'REQSET_PLOT_IS_COASTAL_LAND_MLME'),
	('GAME_EFFECT_MEMENTO_SEA_SALT_COASTAL_LAND_STEPWELL_FAITH',		'MODIFIER_PLAYER_ADJUST_PLOT_YIELD',	0,			NULL,					'REQSET_PLOT_HAS_STEPWELL_IS_COASTAL_LAND_MLME'),
	('GAME_EFFECT_MEMENTO_SEA_SALT_SALT_FAITH',							'MODIFIER_PLAYER_ADJUST_PLOT_YIELD',	0,			NULL,					'REQSET_PLOT_HAS_SALT_MLME');

INSERT INTO ModifierArguments
	(ModifierId,													Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_SEA_SALT_COASTAL_LAND_FAITH',				'YieldType',					'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_SEA_SALT_COASTAL_LAND_FAITH',				'Amount',						1),
	('GAME_EFFECT_MEMENTO_SEA_SALT_COASTAL_LAND_STEPWELL_FAITH',	'YieldType',					'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_SEA_SALT_COASTAL_LAND_STEPWELL_FAITH',	'Amount',						1),
	('GAME_EFFECT_MEMENTO_SEA_SALT_SALT_FAITH',						'YieldType',					'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_SEA_SALT_SALT_FAITH',						'Amount',						1);


INSERT INTO Requirements 
	(RequirementId,								RequirementType,									Inverse	)
VALUES
	('REQUIRES_PLOT_HAS_SALT_MLME',				'REQUIREMENT_PLOT_RESOURCE_TYPE_MATCHES',			0),
	('REQUIRES_PLOT_HAS_STEPWELL_MLME',			'REQUIREMENT_PLOT_IMPROVEMENT_TYPE_MATCHES',		0);

INSERT INTO RequirementArguments
	(RequirementId,								Name,					Value	)
VALUES
	('REQUIRES_PLOT_HAS_SALT_MLME',				'ResourceType',			'RESOURCE_SALT'),
	('REQUIRES_PLOT_HAS_STEPWELL_MLME',			'ImprovementType',		'IMPROVEMENT_STEPWELL');

INSERT INTO RequirementSets
	(RequirementSetId,										RequirementSetType			)
VALUES
	('REQSET_PLOT_HAS_SALT_MLME',							'REQUIREMENTSET_TEST_ALL'),
	('REQSET_PLOT_HAS_STEPWELL_IS_COASTAL_LAND_MLME',		'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,										RequirementId					)
VALUES
	('REQSET_PLOT_HAS_SALT_MLME',							'REQUIRES_PLOT_HAS_SALT_MLME'),
	('REQSET_PLOT_HAS_STEPWELL_IS_COASTAL_LAND_MLME',		'REQUIRES_PLOT_HAS_STEPWELL_MLME'),
	('REQSET_PLOT_HAS_STEPWELL_IS_COASTAL_LAND_MLME',		'REQUIRES_PLOT_IS_COASTAL_LAND_MLME');


--=======================================================================
--����Ŭ����һ������
--����ķ���޻��Ժ�㳡ʱ+30% [ICON_Production] ��������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_LETTERS_TO_MANUEL_I',		'GAME_EFFECT_MEMENTO_LETTERS_TO_MANUEL_I_THEATER_PRODUCTION'),
	('MEMENTO_LETTERS_TO_MANUEL_I',		'GAME_EFFECT_MEMENTO_LETTERS_TO_MANUEL_I_MBANZA_PRODUCTION');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_LETTERS_TO_MANUEL_I_THEATER_PRODUCTION',		'MODIFIER_PLAYER_CITIES_ADJUST_DISTRICT_PRODUCTION',	0,			NULL,					NULL),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_MANUEL_I_MBANZA_PRODUCTION',		'MODIFIER_PLAYER_CITIES_ADJUST_DISTRICT_PRODUCTION',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,					Value)
VALUES
	('GAME_EFFECT_MEMENTO_LETTERS_TO_MANUEL_I_THEATER_PRODUCTION',		'DistrictType',			'DISTRICT_THEATER'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_MANUEL_I_THEATER_PRODUCTION',		'Amount',				30),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_MANUEL_I_MBANZA_PRODUCTION',		'DistrictType',			'DISTRICT_MBANZA'),
	('GAME_EFFECT_MEMENTO_LETTERS_TO_MANUEL_I_MBANZA_PRODUCTION',		'Amount',				30);

--=======================================================================
--��˹�����
--��ɽ�����ڵ�����+2 [ICON_Gold] ��Һ�+1 [ICON_Food] ʳ�����ڼӳɡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_MASCAPAYCHA',		'GAME_EFFECT_MEMENTO_MASCAPAYCHA_MOUNTAIN_FOOD_ADJACENCY'),
	('MEMENTO_MASCAPAYCHA',		'GAME_EFFECT_MEMENTO_MASCAPAYCHA_MOUNTAIN_GOLD_ADJACENCY');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_MASCAPAYCHA_MOUNTAIN_FOOD_ADJACENCY',		'MODIFIER_PLAYER_DISTRICTS_ADJUST_BASE_YIELD_CHANGE_MLME',	0,			NULL,					'REQSET_PLOT_ADJACENT_TO_MOUNTAIN_MLME'),
	('GAME_EFFECT_MEMENTO_MASCAPAYCHA_MOUNTAIN_GOLD_ADJACENCY',		'MODIFIER_PLAYER_DISTRICTS_ADJUST_BASE_YIELD_CHANGE_MLME',	0,			NULL,					'REQSET_PLOT_ADJACENT_TO_MOUNTAIN_MLME');

INSERT INTO ModifierArguments
	(ModifierId,													Name,					Value)
VALUES
	('GAME_EFFECT_MEMENTO_MASCAPAYCHA_MOUNTAIN_FOOD_ADJACENCY',		'YieldType',			'YIELD_FOOD'),
	('GAME_EFFECT_MEMENTO_MASCAPAYCHA_MOUNTAIN_FOOD_ADJACENCY',		'Amount',				1),
	('GAME_EFFECT_MEMENTO_MASCAPAYCHA_MOUNTAIN_GOLD_ADJACENCY',		'YieldType',			'YIELD_GOLD'),
	('GAME_EFFECT_MEMENTO_MASCAPAYCHA_MOUNTAIN_GOLD_ADJACENCY',		'Amount',				2);


INSERT INTO RequirementSets
	(RequirementSetId,										RequirementSetType			)
VALUES
	('REQSET_PLOT_ADJACENT_TO_MOUNTAIN_MLME',				'REQUIREMENTSET_TEST_ALL'	);

INSERT INTO RequirementSetRequirements
	(RequirementSetId,										RequirementId							)
VALUES
	('REQSET_PLOT_ADJACENT_TO_MOUNTAIN_MLME',				'REQUIRES_PLOT_ADJACENT_TO_MOUNTAIN'	);

--=======================================================================
--��6����Լ��
--�����ѽ���ó��ÿ�غϿɶ�����+1ͬ�˵�����
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,				ModifierId) 
VALUES 
	('MEMENTO_TREATY_6',		'GAME_EFFECT_MEMENTO_TREATY_6_ALLIANCE_POINTS_FROM_TRADE');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TREATY_6_ALLIANCE_POINTS_FROM_TRADE',		'MODIFIER_PLAYER_ADJUST_ALLIANCE_POINTS_FOR_TRADE',			0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,					Value)
VALUES
	('GAME_EFFECT_MEMENTO_TREATY_6_ALLIANCE_POINTS_FROM_TRADE',		'Amount',				1);

--=======================================================================
--�����ɳ�������
--ÿλ�����ṩ+0.5 [ICON_Culture] �Ļ�ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,				ModifierId) 
VALUES 
	('MEMENTO_RIO_BRANCO_LAW',		'GAME_EFFECT_MEMENTO_RIO_BRANCO_LAW_CULTURE_PER_POPULATION');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,													Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_RIO_BRANCO_LAW_CULTURE_PER_POPULATION',		'MODIFIER_PLAYER_CITIES_ADJUST_CITY_YIELD_PER_POPULATION',		0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,					Value)
VALUES
	('GAME_EFFECT_MEMENTO_RIO_BRANCO_LAW_CULTURE_PER_POPULATION',		'YieldType',			'YIELD_CULTURE'),
	('GAME_EFFECT_MEMENTO_RIO_BRANCO_LAW_CULTURE_PER_POPULATION',		'Amount',				0.5);

--=======================================================================
--�����߶�ì
--�������λ+5 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,				ModifierId) 
VALUES 
	('MEMENTO_IKLWA',			'GAME_EFFECT_MEMENTO_IKLWA_ANTI_CAVALRY_STRENGTH');


INSERT INTO Modifiers
	(ModifierId,											ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_IKLWA_ANTI_CAVALRY_STRENGTH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,											Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_IKLWA_ANTI_CAVALRY_STRENGTH',		'AbilityType',					'ABILITY_ANTI_CAVALRY_STRENGTH_MLME');

--=======================================================================
--��������
--�׶�ѵ�������ߵ�λʱ+50% [ICON_Production] ��������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_HEIRLOOM_SEAL_OF_THE_REALM',		'GAME_EFFECT_MEMENTO_HEIRLOOM_SEAL_OF_THE_REALM_CAPITAL_BUILDER_PRODUCTION');


INSERT INTO Modifiers
	(ModifierId,																		ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_HEIRLOOM_SEAL_OF_THE_REALM_CAPITAL_BUILDER_PRODUCTION',		'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_UNIT_PRODUCTION_MLME',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,																		Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_HEIRLOOM_SEAL_OF_THE_REALM_CAPITAL_BUILDER_PRODUCTION',		'UnitType',		'UNIT_BUILDER'),
	('GAME_EFFECT_MEMENTO_HEIRLOOM_SEAL_OF_THE_REALM_CAPITAL_BUILDER_PRODUCTION',		'Amount',		50);

--=======================================================================
--���ŷ���Լ��
--���µ�λλ��ʥ��6����Ԫ������ʱ��+5 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_TREATY_OF_JAFFA_1192',		'GAME_EFFECT_MEMENTO_TREATY_OF_JAFFA_1192_HOLY_SITE_STRENGTH');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TREATY_OF_JAFFA_1192_HOLY_SITE_STRENGTH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_TREATY_OF_JAFFA_1192_HOLY_SITE_STRENGTH',		'AbilityType',	'ABILITY_HOLY_SITE_STRENGTH_MLME');

--=======================================================================
--ĵ��
--����3�������ĵ���ݳ�Ʒ��Դ��+6 [ICON_Amenities] �˾Ӷȡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_PEONY_SEONDEOK',			'GAME_EFFECT_MEMENTO_PEONY_SEONDEOK_LUXURY_RESOURCE_PEONY_MLME');


INSERT INTO Modifiers
	(ModifierId,															ModifierType,									Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_PEONY_SEONDEOK_LUXURY_RESOURCE_PEONY_MLME',		'MODIFIER_SINGLE_CITY_GRANT_RESOURCE_IN_CITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,															Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_PEONY_SEONDEOK_LUXURY_RESOURCE_PEONY_MLME',		'ResourceType',	'RESOURCE_PEONY_MLME'),
	('GAME_EFFECT_MEMENTO_PEONY_SEONDEOK_LUXURY_RESOURCE_PEONY_MLME',		'Amount',		3);

--=======================================================================
--��˹������
--���г���+5�ҳ϶ȡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_OTTOMAN_LAWS',			'GAME_EFFECT_MEMENTO_OTTOMAN_LAWS_CITY_IDENTITY');


INSERT INTO Modifiers
	(ModifierId,												ModifierType,										Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_OTTOMAN_LAWS_CITY_IDENTITY',			'MODIFIER_PLAYER_CITIES_ADJUST_IDENTITY_PER_TURN',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,												Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_OTTOMAN_LAWS_CITY_IDENTITY',			'Amount',		5);

--=======================================================================
--����³���Ǳ���ʷ��
--�����������ϵĳ���+15% [ICON_Faith] ����ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_THE_GEORGIAN_CHRONICLES',		'GAME_EFFECT_MEMENTO_THE_GEORGIAN_CHRONICLESS_HILLS_CITY_FAITH');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_THE_GEORGIAN_CHRONICLESS_HILLS_CITY_FAITH',	'MODIFIER_PLAYER_CITIES_ADJUST_CITY_YIELD_MODIFIER',	0,			NULL,					'REQSET_PLOT_IS_HILLS_MLME');

INSERT INTO ModifierArguments
	(ModifierId,														Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_THE_GEORGIAN_CHRONICLESS_HILLS_CITY_FAITH',	'YieldType',				'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_THE_GEORGIAN_CHRONICLESS_HILLS_CITY_FAITH',	'Amount',					15);


INSERT INTO RequirementSets
	(RequirementSetId,							RequirementSetType			)
VALUES
	('REQSET_PLOT_IS_HILLS_MLME',				'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,							RequirementId					)
VALUES
	('REQSET_PLOT_IS_HILLS_MLME',				'PLOT_IS_HILLS_REQUIREMENT');


--=======================================================================
--ͼ����͹���
--����;��񷽼Ɱ+2 [ICON_Culture] �Ļ�ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_TRAJAN_S_COLUMN',				'GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_MONUMENT_CULTURE');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_MONUMENT_CULTURE',		'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_MONUMENT_CULTURE',		'BuildingType',				'BUILDING_MONUMENT'),
	('GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_MONUMENT_CULTURE',		'YieldType',				'YIELD_CULTURE'),
	('GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_MONUMENT_CULTURE',		'Amount',					2);


--=======================================================================
--��Ѫ����
--½�ص�λ��ɱ��Ҫ��С�������ĵ�λʱ������� [ICON_Strength] ս����25%�� [ICON_GREATGENERAL] �󽫾���������׼�ٶ��£���
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_BLOOD_BAG',				'GAME_EFFECT_MEMENTO_BLOOD_BAG_COMBAT_GREAT_GENERAL_POINT');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_BLOOD_BAG_COMBAT_GREAT_GENERAL_POINT',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_BLOOD_BAG_COMBAT_GREAT_GENERAL_POINT',		'AbilityType',					'ABILITY_COMBAT_GREAT_GENERAL_POINT_MLME');


--=======================================================================
--����֮·
--���д�ÿ���ڽ̣���������1����ͽ�����1�� [ICON_Amenities] �˾Ӷȡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_SUNNY_WAYS',				'GAME_EFFECT_MEMENTO_SUNNY_WAYS_AMENITIES_FOR_MIN_FOLLOWERS');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,																Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_SUNNY_WAYS_AMENITIES_FOR_MIN_FOLLOWERS',		'MODIFIER_PLAYER_CITIES_ADJUST_RELIGION_AMENITIES_FOR_MINIMUM_FOLLOWERS',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,					Value)
VALUES
	('GAME_EFFECT_MEMENTO_SUNNY_WAYS_AMENITIES_FOR_MIN_FOLLOWERS',		'Amenities',			1),
	('GAME_EFFECT_MEMENTO_SUNNY_WAYS_AMENITIES_FOR_MIN_FOLLOWERS',		'Followers',			1);


--=======================================================================
--��į�����µ�
--�㲥����+2 [ICON_Production] ����������Ϊ12����Ԫ�����ڵľ��µ�λ+5 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_EENZAAM_MAAR_NIET_ALLEEN',		'GAME_EFFECT_MEMENTO_EENZAAM_MAAR_NIET_ALLEEN_BROADCAST_CENTER_PRODUCTION'),
	('MEMENTO_EENZAAM_MAAR_NIET_ALLEEN',		'GAME_EFFECT_MEMENTO_EENZAAM_MAAR_NIET_ALLEEN_BROADCAST_CENTER_STRENGTH');


INSERT INTO Modifiers
	(ModifierId,																	ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_EENZAAM_MAAR_NIET_ALLEEN_BROADCAST_CENTER_PRODUCTION',	'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',	0,			NULL,					NULL),
	('GAME_EFFECT_MEMENTO_EENZAAM_MAAR_NIET_ALLEEN_BROADCAST_CENTER_STRENGTH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',					0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,																	Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_EENZAAM_MAAR_NIET_ALLEEN_BROADCAST_CENTER_PRODUCTION',	'BuildingType',				'BUILDING_BROADCAST_CENTER'),
	('GAME_EFFECT_MEMENTO_EENZAAM_MAAR_NIET_ALLEEN_BROADCAST_CENTER_PRODUCTION',	'YieldType',				'YIELD_PRODUCTION'),
	('GAME_EFFECT_MEMENTO_EENZAAM_MAAR_NIET_ALLEEN_BROADCAST_CENTER_PRODUCTION',	'Amount',					2),
	('GAME_EFFECT_MEMENTO_EENZAAM_MAAR_NIET_ALLEEN_BROADCAST_CENTER_STRENGTH',		'AbilityType',				'ABILITY_BROADCAST_CENTER_STRENGTH_MLME');


--=======================================================================
--��ά������Ů���ռǡ�
--��ҵ���͸ۿ�+1 [ICON_GreatWriter] �����ҵ�����
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_QUEEN_VICTORIA_S_JOURNALS',		'GAME_EFFECT_MEMENTO_QUEEN_VICTORIA_S_JOURNALS_INDUSTRIAL_ZONE_GREAT_WRITER_POINT'),
	('MEMENTO_QUEEN_VICTORIA_S_JOURNALS',		'GAME_EFFECT_MEMENTO_QUEEN_VICTORIA_S_JOURNALS_HARBOR_GREAT_WRITER_POINT');


INSERT INTO Modifiers
	(ModifierId,																			ModifierType,												OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_QUEEN_VICTORIA_S_JOURNALS_INDUSTRIAL_ZONE_GREAT_WRITER_POINT',	'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_DISTRICT_IS_INDUSTRIAL_ZONE_LIKE_MLME'),
	('GAME_EFFECT_MEMENTO_QUEEN_VICTORIA_S_JOURNALS_HARBOR_GREAT_WRITER_POINT',				'MODIFIER_PLAYER_DISTRICTS_ADJUST_GREAT_PERSON_POINTS',		NULL,					'REQSET_DISTRICT_IS_HARBOR_LIKE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,																			Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_QUEEN_VICTORIA_S_JOURNALS_INDUSTRIAL_ZONE_GREAT_WRITER_POINT',	'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_QUEEN_VICTORIA_S_JOURNALS_INDUSTRIAL_ZONE_GREAT_WRITER_POINT',	'Amount',						1),
	('GAME_EFFECT_MEMENTO_QUEEN_VICTORIA_S_JOURNALS_HARBOR_GREAT_WRITER_POINT',				'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_QUEEN_VICTORIA_S_JOURNALS_HARBOR_GREAT_WRITER_POINT',				'Amount',						1);

INSERT INTO Tags
	(Tag,											Vocabulary)
VALUES
	('CLASS_DISTRICT_INDUSTRIAL_ZONE_LIKE_MLME',	'DISTRICT_CLASS_MLME'),
	('CLASS_DISTRICT_HARBOR_LIKE_MLME',				'DISTRICT_CLASS_MLME');

INSERT INTO TypeTags
	(Type,							Tag)
VALUES	
	('DISTRICT_INDUSTRIAL_ZONE',	'CLASS_DISTRICT_INDUSTRIAL_ZONE_LIKE_MLME'),
	('DISTRICT_HARBOR',				'CLASS_DISTRICT_HARBOR_LIKE_MLME');


INSERT INTO Requirements 
	(RequirementId,											RequirementType,							Inverse	)
VALUES
	('REQUIRES_DISTRICT_IS_INDUSTRIAL_ZONE_LIKE_MLME',		'REQUIREMENT_PLOT_DISTRICT_TAG_MATCHES',	0),
	('REQUIRES_DISTRICT_IS_HARBOR_LIKE_MLME',				'REQUIREMENT_PLOT_DISTRICT_TAG_MATCHES',	0);

INSERT INTO RequirementArguments
	(RequirementId,											Name,			Value	)
VALUES
	('REQUIRES_DISTRICT_IS_INDUSTRIAL_ZONE_LIKE_MLME',		'Tag',			'CLASS_DISTRICT_INDUSTRIAL_ZONE_LIKE_MLME'),
	('REQUIRES_DISTRICT_IS_HARBOR_LIKE_MLME',				'Tag',			'CLASS_DISTRICT_HARBOR_LIKE_MLME');

INSERT INTO RequirementSets
	(RequirementSetId,										RequirementSetType			)
VALUES
	('REQSET_DISTRICT_IS_INDUSTRIAL_ZONE_LIKE_MLME',		'REQUIREMENTSET_TEST_ALL'),
	('REQSET_DISTRICT_IS_HARBOR_LIKE_MLME',					'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,										RequirementId					)
VALUES
	('REQSET_DISTRICT_IS_INDUSTRIAL_ZONE_LIKE_MLME',		'REQUIRES_DISTRICT_IS_INDUSTRIAL_ZONE_LIKE_MLME'),
	('REQSET_DISTRICT_IS_HARBOR_LIKE_MLME',					'REQUIRES_DISTRICT_IS_HARBOR_LIKE_MLME');

--=======================================================================
--����Ұ���ˡ�
--½�ص�λ��ɭ�֡����ֻ�ϡ����ԭ����սʱ+5 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_THE_WILDERNESS_HUNTER',			'GAME_EFFECT_MEMENTO_THE_WILDERNESS_HUNTER_TREE_STRENGTH');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_THE_WILDERNESS_HUNTER_TREE_STRENGTH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_THE_WILDERNESS_HUNTER_TREE_STRENGTH',		'AbilityType',	'ABILITY_TREE_STRENGTH_MLME');


--=======================================================================
--�ƶ�����ͼ���
--ͼ���+1 [ICON_Culture] �Ļ�ֵ+1 [ICON_FAVOR] �⽻֧�֡�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_BIBLIOTHECA_CORVINIANA',			'GAME_EFFECT_MEMENTO_BIBLIOTHECA_CORVINIANA_LIBRARY_CULTURE'),
	('MEMENTO_BIBLIOTHECA_CORVINIANA',			'GAME_EFFECT_MEMENTO_BIBLIOTHECA_CORVINIANA_LIBRARY_EXTRA_FAVOR');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_BIBLIOTHECA_CORVINIANA_LIBRARY_CULTURE',		'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',	0,			NULL,					NULL),
	('GAME_EFFECT_MEMENTO_BIBLIOTHECA_CORVINIANA_LIBRARY_EXTRA_FAVOR',	'MODIFIER_PLAYER_CITIES_ADJUST_EXTRA_FAVOR_PER_TURN',	0,			NULL,					'BUILDING_IS_LIBRARY');

INSERT INTO ModifierArguments
	(ModifierId,														Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_BIBLIOTHECA_CORVINIANA_LIBRARY_CULTURE',		'BuildingType',				'BUILDING_LIBRARY'),
	('GAME_EFFECT_MEMENTO_BIBLIOTHECA_CORVINIANA_LIBRARY_CULTURE',		'YieldType',				'YIELD_CULTURE'),
	('GAME_EFFECT_MEMENTO_BIBLIOTHECA_CORVINIANA_LIBRARY_CULTURE',		'Amount',					1),
	('GAME_EFFECT_MEMENTO_BIBLIOTHECA_CORVINIANA_LIBRARY_EXTRA_FAVOR',	'Amount',					1);

--=======================================================================
--�������ۡ�
--����������ѵ����������+1�������߲�λ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_ARTHASHASTRA',					'GAME_EFFECT_MEMENTO_ARTHASHASTRA_SLOT_MILITARY');


INSERT INTO Modifiers
	(ModifierId,											ModifierType,												Permanent,	OwnerRequirementSetId,							SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_ARTHASHASTRA_SLOT_MILITARY',		'MODIFIER_PLAYER_CULTURE_ADJUST_GOVERNMENT_SLOTS_MODIFIER',	0,			'REQSET_PLAYER_HAS_MILITARY_TRAINING_MLME',		NULL);

INSERT INTO ModifierArguments
	(ModifierId,											Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_ARTHASHASTRA_SLOT_MILITARY',		'GovernmentSlotType',		'SLOT_MILITARY');


INSERT INTO Requirements 
	(RequirementId,										RequirementType,					Inverse	)
VALUES
	('REQUIRES_PLAYER_HAS_MILITARY_TRAINING_MLME',		'REQUIREMENT_PLAYER_HAS_CIVIC',		0);

INSERT INTO RequirementArguments
	(RequirementId,										Name,				Value	)
VALUES
	('REQUIRES_PLAYER_HAS_MILITARY_TRAINING_MLME',		'CivicType',		'CIVIC_MILITARY_TRAINING');

INSERT INTO RequirementSets
	(RequirementSetId,									RequirementSetType			)
VALUES
	('REQSET_PLAYER_HAS_MILITARY_TRAINING_MLME',		'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,									RequirementId					)
VALUES
	('REQSET_PLAYER_HAS_MILITARY_TRAINING_MLME',		'REQUIRES_PLAYER_HAS_MILITARY_TRAINING_MLME');




