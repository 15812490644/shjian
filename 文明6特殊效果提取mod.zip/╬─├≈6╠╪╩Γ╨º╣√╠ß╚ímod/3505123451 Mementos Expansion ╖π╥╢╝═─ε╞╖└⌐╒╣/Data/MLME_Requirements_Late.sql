-- MLME_Requirements_Late
-- Author: Maple_Leaves
-- DateCreated: 6/8/2025 11:51:08 AM
--------------------------------------------------------------

--����ˮ��UD
INSERT INTO Requirements 
	(RequirementId,														RequirementType,									Inverse	)
SELECT
	'REQUIRES_PLOT_ADJACENT_TO_'||CivUniqueDistrictType||'_MLME',		'REQUIREMENT_PLOT_ADJACENT_DISTRICT_TYPE_MATCHES',	0
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_AQUEDUCT';

INSERT INTO RequirementArguments
	(RequirementId,														Name,					Value	)
SELECT
	'REQUIRES_PLOT_ADJACENT_TO_'||CivUniqueDistrictType||'_MLME',		'DistrictType',			CivUniqueDistrictType
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_AQUEDUCT';

INSERT INTO RequirementSetRequirements
	(RequirementSetId,									RequirementId					)
SELECT
	'REQSET_PLOT_IS_AQUEDUCT_LIKE_ADJACENT_MLME',		'REQUIRES_PLOT_ADJACENT_TO_'||CivUniqueDistrictType||'_MLME'
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_AQUEDUCT';


--��Ժ�㳡UD
INSERT INTO TypeTags
	(Type,					Tag)
SELECT
	CivUniqueDistrictType,	'CLASS_DISTRICT_THEATER_LIKE_MLME'
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_THEATER';


--���UB
INSERT INTO Requirements 
	(RequirementId,												RequirementType,						Inverse	)
SELECT
	'REQUIRES_CITY_HAS_'||CivUniqueBuildingType||'_MLME',		'REQUIREMENT_CITY_HAS_BUILDING',		0
FROM BuildingReplaces WHERE ReplacesBuildingType = 'BUILDING_MONUMENT';

INSERT INTO RequirementArguments
	(RequirementId,												Name,				Value	)
SELECT
	'REQUIRES_CITY_HAS_'||CivUniqueBuildingType||'_MLME',		'BuildingType',		CivUniqueBuildingType
FROM BuildingReplaces WHERE ReplacesBuildingType = 'BUILDING_MONUMENT';

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
SELECT
	'REQSET_CITY_HAS_MONUMENT_LIKE_MLME',			'REQUIRES_CITY_HAS_'||CivUniqueBuildingType||'_MLME'
FROM BuildingReplaces WHERE ReplacesBuildingType = 'BUILDING_MONUMENT';



--�����㳡����
--Tier1
INSERT INTO Requirements 
	(RequirementId,												RequirementType,						Inverse	)
SELECT
	'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_1_MLME',		'REQUIREMENT_CITY_HAS_BUILDING',		0
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier1';

INSERT INTO RequirementArguments
	(RequirementId,												Name,				Value	)
SELECT
	'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_1_MLME',		'BuildingType',		BuildingType
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier1';

INSERT INTO RequirementSetRequirements
	(RequirementSetId,											RequirementId					)
SELECT
	'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_1_MLME',			'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_1_MLME'
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier1';

--Tier2
INSERT INTO Requirements 
	(RequirementId,												RequirementType,						Inverse	)
SELECT
	'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_2_MLME',		'REQUIREMENT_CITY_HAS_BUILDING',		0
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier2';

INSERT INTO RequirementArguments
	(RequirementId,												Name,				Value	)
SELECT
	'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_2_MLME',		'BuildingType',		BuildingType
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier2';

INSERT INTO RequirementSetRequirements
	(RequirementSetId,											RequirementId					)
SELECT
	'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_2_MLME',			'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_2_MLME'
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier2';

--Tier3
INSERT INTO Requirements 
	(RequirementId,												RequirementType,						Inverse	)
SELECT
	'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_3_MLME',		'REQUIREMENT_CITY_HAS_BUILDING',		0
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier3';

INSERT INTO RequirementArguments
	(RequirementId,												Name,				Value	)
SELECT
	'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_3_MLME',		'BuildingType',		BuildingType
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier3';

INSERT INTO RequirementSetRequirements
	(RequirementSetId,											RequirementId					)
SELECT
	'REQSET_CITY_HAS_GOVERNMENT_BUILDING_TIER_3_MLME',			'REQUIRES_CITY_HAS_'||BuildingType||'_GOV_TIER_3_MLME'
FROM Buildings WHERE PrereqDistrict='DISTRICT_GOVERNMENT' AND GovernmentTierRequirement='Tier3';



--ʥ��UD
INSERT INTO TypeTags
	(Type,					Tag)
SELECT
	CivUniqueDistrictType,	'CLASS_DISTRICT_HOLY_SITE_LIKE_MLME'
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_HOLY_SITE';


--��ҵ��UD
INSERT INTO TypeTags
	(Type,					Tag)
SELECT
	CivUniqueDistrictType,	'CLASS_DISTRICT_INDUSTRIAL_ZONE_LIKE_MLME'
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_INDUSTRIAL_ZONE';


--�ۿ�UD
INSERT INTO TypeTags
	(Type,					Tag)
SELECT
	CivUniqueDistrictType,	'CLASS_DISTRICT_HARBOR_LIKE_MLME'
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_HARBOR';



--JNR��ϡ����ԭ
INSERT INTO Requirements 
	(RequirementId,									RequirementType,							Inverse	)
SELECT
	'REQUIRES_PLOT_IS_'||FeatureType||'_MLME',		'REQUIREMENT_PLOT_FEATURE_TYPE_MATCHES',	0
FROM Features WHERE FeatureType = 'FEATURE_JNR_SAVANNAH';

INSERT INTO RequirementArguments
	(RequirementId,									Name,				Value	)
SELECT
	'REQUIRES_PLOT_IS_'||FeatureType||'_MLME',		'FeatureType',		FeatureType
FROM Features WHERE FeatureType = 'FEATURE_JNR_SAVANNAH';

INSERT INTO RequirementSetRequirements
	(RequirementSetId,											RequirementId					)
SELECT
	'REQSET_UNIT_ON_TREES_MLME',								'REQUIRES_PLOT_IS_'||FeatureType||'_MLME'
FROM Features WHERE FeatureType = 'FEATURE_JNR_SAVANNAH';


--����UB
INSERT INTO Requirements 
	(RequirementId,												RequirementType,						Inverse	)
SELECT
	'REQUIRES_CITY_HAS_'||CivUniqueBuildingType||'_MLME',		'REQUIREMENT_CITY_HAS_BUILDING',		0
FROM BuildingReplaces WHERE ReplacesBuildingType = 'BUILDING_SHRINE';

INSERT INTO RequirementArguments
	(RequirementId,												Name,				Value	)
SELECT
	'REQUIRES_CITY_HAS_'||CivUniqueBuildingType||'_MLME',		'BuildingType',		CivUniqueBuildingType
FROM BuildingReplaces WHERE ReplacesBuildingType = 'BUILDING_SHRINE';

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
SELECT
	'REQSET_CITY_HAS_SHRINE_LIKE_MLME',			'REQUIRES_CITY_HAS_'||CivUniqueBuildingType||'_MLME'
FROM BuildingReplaces WHERE ReplacesBuildingType = 'BUILDING_SHRINE';



--����UU
INSERT INTO TypeTags
	(Type,					Tag)
SELECT
	CivUniqueUnitType,		'CLASS_CELTIC_LONGSWORD_MLME'
FROM UnitReplaces WHERE ReplacesUnitType = 'UNIT_SWORDSMAN';

--����սʿUU
INSERT INTO TypeTags
	(Type,					Tag)
SELECT
	CivUniqueUnitType,		'CLASS_CELTIC_LONGSWORD_MLME'
FROM UnitReplaces WHERE ReplacesUnitType = 'UNIT_MAN_AT_ARMS';


--ѧԺUD
INSERT INTO TypeTags
	(Type,					Tag)
SELECT
	CivUniqueDistrictType,	'CLASS_DISTRICT_CAMPUS_LIKE_MLME'
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_CAMPUS';


--��Ϸ���빤ҵʱ��
INSERT INTO Requirements 
	(RequirementId,													RequirementType,							Inverse	)
SELECT
	'REQUIRES_GAME_ERA_ATLEAST_EXPANSION_'||EraType||'_MLME',		'REQUIREMENT_GAME_ERA_ATLEAST_EXPANSION',	0
FROM Eras;

INSERT INTO RequirementArguments
	(RequirementId,													Name,				Value	)
SELECT
	'REQUIRES_GAME_ERA_ATLEAST_EXPANSION_'||EraType||'_MLME',		'EraType',			EraType
FROM Eras;

INSERT OR REPLACE INTO RequirementSets
	(RequirementSetId,												RequirementSetType			)
SELECT
	'REQSET_GAME_ERA_ATLEAST_EXPANSION_'||EraType||'_MLME',			'REQUIREMENTSET_TEST_ALL'
FROM Eras;

INSERT OR REPLACE INTO RequirementSetRequirements
	(RequirementSetId,												RequirementId					)
SELECT
	'REQSET_GAME_ERA_ATLEAST_EXPANSION_'||EraType||'_MLME',			'REQUIRES_GAME_ERA_ATLEAST_EXPANSION_'||EraType||'_MLME'
FROM Eras;






