-- MLME_Resources_Mode
-- Author: Maple_Leaves
-- DateCreated: 6/10/2025 11:10:07 PM
--------------------------------------------------------------



INSERT INTO Types 
	(Type,							Kind) 
VALUES 
	('RESOURCE_PEONY_MLME',			'KIND_RESOURCE');

INSERT INTO Resources
	(ResourceType,					Name,								ResourceClassType,			Happiness,	Frequency) 
VALUES 
	('RESOURCE_PEONY_MLME',			'LOC_RESOURCE_PEONY_MLME_NAME',		'RESOURCECLASS_LUXURY',		6,			0);



