-- MLME_PostProcess_Mode
-- Author: Maple_Leaves
-- DateCreated: 5/11/2025 9:43:28 PM
--------------------------------------------------------------


INSERT INTO Types
	(Type,									Kind)
SELECT
	'BUILDING_'||MementoType||'_MLME',		'KIND_BUILDING'
FROM ML_Mementos_Mode WHERE Disabled = 0 ;

INSERT INTO Buildings 
	(BuildingType,						Name,	Description,		Mustpurchase,		ObsoleteEra,	Cost,	MaxPlayerInstances) 
SELECT 
	'BUILDING_'||MementoType||'_MLME',	Name,	Description,		1,					'ERA_ANCIENT',	1,		1
FROM ML_Mementos_Mode WHERE Disabled = 0 ;

INSERT INTO BuildingModifiers 
	(BuildingType,						ModifierId) 
SELECT 
	'BUILDING_'||MementoType||'_MLME',	ModifierId 
FROM ML_MementoModifiers_Mode WHERE MementoType IN  (SELECT MementoType FROM ML_Mementos_Mode WHERE Disabled = 0);



INSERT INTO CivilopediaPageExcludes
	(SectionId,							PageId) 
SELECT
	'BUILDINGS',						'BUILDING_'||MementoType||'_MLME'
FROM ML_Mementos_Mode WHERE Disabled = 0 ;