-- MLME_Heroes_Mode
-- Author: Maple_Leaves
-- DateCreated: 6/8/2025 11:33:43 PM
--------------------------------------------------------------


--=======================================================================
--������٤��ʲʷʫ�����
--����;��񷽼Ɱ+1 [ICON_GreatWriter] �����ҵ���������Ӣ�۴�˵��Ŀʱ+100% [ICON_Production] ��������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_EPIC_OF_GILGAMESH',				'GAME_EFFECT_MEMENTO_EPIC_OF_GILGAMESH_PROJECT_PRODUCTION');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,										Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_EPIC_OF_GILGAMESH_PROJECT_PRODUCTION',		'MODIFIER_PLAYER_CITIES_ADJUST_PROJECT_PRODUCTION',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,					Value)
VALUES
	('GAME_EFFECT_MEMENTO_EPIC_OF_GILGAMESH_PROJECT_PRODUCTION',		'ProjectType',			'PROJECT_DISCOVER_NEXT_HERO'),
	('GAME_EFFECT_MEMENTO_EPIC_OF_GILGAMESH_PROJECT_PRODUCTION',		'Amount',				100);

