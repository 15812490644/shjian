-- MLME_Requirements_Mode
-- Author: Maple_Leaves
-- DateCreated: 6/11/2025 3:09:50 PM
--------------------------------------------------------------

--��Ԫ������ˮ��
INSERT INTO Requirements 
	(RequirementId,												RequirementType,									Inverse	)
VALUES
	('REQUIRES_PLOT_ADJACENT_TO_DISTRICT_AQUEDUCT_MLME',		'REQUIREMENT_PLOT_ADJACENT_DISTRICT_TYPE_MATCHES',	0),
	('REQUIRES_PLOT_IS_AQUEDUCT_LIKE_ADJACENT_MLME',			'REQUIREMENT_REQUIREMENTSET_IS_MET',				0);

INSERT INTO RequirementArguments
	(RequirementId,												Name,					Value	)
VALUES
	('REQUIRES_PLOT_ADJACENT_TO_DISTRICT_AQUEDUCT_MLME',		'DistrictType',			'DISTRICT_AQUEDUCT'),
	('REQUIRES_PLOT_IS_AQUEDUCT_LIKE_ADJACENT_MLME',			'RequirementSetId',		'REQSET_PLOT_IS_AQUEDUCT_LIKE_ADJACENT_MLME');

INSERT INTO RequirementSets
	(RequirementSetId,									RequirementSetType			)
VALUES
	('REQSET_PLOT_IS_FARM_AQUEDUCT_ADJACENT_MLME',		'REQUIREMENTSET_TEST_ALL'),
	('REQSET_PLOT_IS_AQUEDUCT_LIKE_ADJACENT_MLME',		'REQUIREMENTSET_TEST_ANY');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,									RequirementId					)
VALUES
	('REQSET_PLOT_IS_FARM_AQUEDUCT_ADJACENT_MLME',		'REQUIRES_PLOT_IS_AQUEDUCT_LIKE_ADJACENT_MLME'),
	('REQSET_PLOT_IS_FARM_AQUEDUCT_ADJACENT_MLME',		'REQUIRES_PLOT_HAS_FARM'),
	('REQSET_PLOT_IS_AQUEDUCT_LIKE_ADJACENT_MLME',		'REQUIRES_PLOT_ADJACENT_TO_DISTRICT_AQUEDUCT_MLME');


--�����������ѧ����
INSERT INTO Requirements 
	(RequirementId,										RequirementType,					Inverse	)
VALUES
	('REQUIRES_PLAYER_HAS_POLITICAL_PHILOSOPHY_MLME',	'REQUIREMENT_PLAYER_HAS_CIVIC',		0);

INSERT INTO RequirementArguments
	(RequirementId,										Name,				Value	)
VALUES
	('REQUIRES_PLAYER_HAS_POLITICAL_PHILOSOPHY_MLME',	'CivicType',		'CIVIC_POLITICAL_PHILOSOPHY');

INSERT INTO RequirementSets
	(RequirementSetId,									RequirementSetType			)
VALUES
	('REQSET_PLAYER_HAS_POLITICAL_PHILOSOPHY_MLME',		'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,									RequirementId					)
VALUES
	('REQSET_PLAYER_HAS_POLITICAL_PHILOSOPHY_MLME',		'REQUIRES_PLAYER_HAS_POLITICAL_PHILOSOPHY_MLME');


--����з�������
INSERT INTO Requirements 
	(RequirementId,								RequirementType,					Inverse	)
VALUES
	('REQUIRES_PLAYER_HAS_CODE_OF_LAWS_MLME',	'REQUIREMENT_PLAYER_HAS_CIVIC',		0);

INSERT INTO RequirementArguments
	(RequirementId,								Name,				Value	)
VALUES
	('REQUIRES_PLAYER_HAS_CODE_OF_LAWS_MLME',	'CivicType',		'CIVIC_CODE_OF_LAWS');

INSERT INTO RequirementSets
	(RequirementSetId,							RequirementSetType			)
VALUES
	('REQSET_PLAYER_HAS_CODE_OF_LAWS_MLME',		'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,							RequirementId					)
VALUES
	('REQSET_PLAYER_HAS_CODE_OF_LAWS_MLME',		'REQUIRES_PLAYER_HAS_CODE_OF_LAWS_MLME');


--����������
INSERT INTO Requirements 
	(RequirementId,						RequirementType,					Inverse	)
VALUES
	('REQUIRES_CITY_HAS_SHRINE_MLME',	'REQUIREMENT_CITY_HAS_BUILDING',	0);

INSERT INTO RequirementArguments
	(RequirementId,						Name,				Value	)
VALUES
	('REQUIRES_CITY_HAS_SHRINE_MLME',	'BuildingType',		'BUILDING_SHRINE');

INSERT INTO RequirementSets
	(RequirementSetId,							RequirementSetType			)
VALUES
	('REQSET_CITY_HAS_SHRINE_LIKE_MLME',		'REQUIREMENTSET_TEST_ANY');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,							RequirementId					)
VALUES
	('REQSET_CITY_HAS_SHRINE_LIKE_MLME',		'REQUIRES_CITY_HAS_SHRINE_MLME');


--ѧԺ
INSERT INTO Tags
	(Tag,									Vocabulary)
VALUES
	('CLASS_DISTRICT_CAMPUS_LIKE_MLME',		'DISTRICT_CLASS_MLME');

INSERT INTO TypeTags
	(Type,					Tag)
VALUES	
	('DISTRICT_CAMPUS',		'CLASS_DISTRICT_CAMPUS_LIKE_MLME');


INSERT INTO Requirements 
	(RequirementId,									RequirementType,							Inverse	)
VALUES
	('REQUIRES_DISTRICT_IS_CAMPUS_LIKE_MLME',		'REQUIREMENT_PLOT_DISTRICT_TAG_MATCHES',	0);

INSERT INTO RequirementArguments
	(RequirementId,									Name,			Value	)
VALUES
	('REQUIRES_DISTRICT_IS_CAMPUS_LIKE_MLME',		'Tag',			'CLASS_DISTRICT_CAMPUS_LIKE_MLME');

INSERT INTO RequirementSets
	(RequirementSetId,								RequirementSetType			)
VALUES
	('REQSET_DISTRICT_IS_CAMPUS_LIKE_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
VALUES
	('REQSET_DISTRICT_IS_CAMPUS_LIKE_MLME',			'REQUIRES_DISTRICT_IS_CAMPUS_LIKE_MLME');



