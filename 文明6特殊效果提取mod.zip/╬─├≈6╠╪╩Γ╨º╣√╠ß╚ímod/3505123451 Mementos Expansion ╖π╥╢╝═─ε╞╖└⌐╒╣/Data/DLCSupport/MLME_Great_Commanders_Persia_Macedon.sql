-- MLME_Great_Commanders_Persia_Macedon
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 11:30:08 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_PEACOCK_THRONE',					'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode	
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_PEACOCK_THRONE',					'LOC_MEMENTO_PEACOCK_THRONE_NAME',					'LOC_MEMENTO_PEACOCK_THRONE_EFFECT',					'LOC_MEMENTO_PEACOCK_THRONE_DESCRIPTION',					'LOC_MEMENTO_PEACOCK_THRONE_TOOLTIP');

INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_NADER_SHAH',						'MEMENTO_PEACOCK_THRONE');


--=======================================================================
--��ȸ����
--ռ��һ���з����к����г��н����20%�� [ICON_Production] �������ӳɣ�Ч������5�غϡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_PEACOCK_THRONE',				'GAME_EFFECT_MEMENTO_PEACOCK_THRONE_PRODUCTION_BOOST_FROM_CAPTURE');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,										Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_PEACOCK_THRONE_PRODUCTION_BOOST_FROM_CAPTURE',		'MODIFIER_PLAYER_ADD_DIPLOMATIC_YIELD_MODIFIER',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,																Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_PEACOCK_THRONE_PRODUCTION_BOOST_FROM_CAPTURE',		'DiplomaticYieldSource',				'CITY_CAPTURED'),
	('GAME_EFFECT_MEMENTO_PEACOCK_THRONE_PRODUCTION_BOOST_FROM_CAPTURE',		'TurnsActive',							5),
	('GAME_EFFECT_MEMENTO_PEACOCK_THRONE_PRODUCTION_BOOST_FROM_CAPTURE',		'YieldType',							'YIELD_PRODUCTION'),
	('GAME_EFFECT_MEMENTO_PEACOCK_THRONE_PRODUCTION_BOOST_FROM_CAPTURE',		'Amount',								20),
	('GAME_EFFECT_MEMENTO_PEACOCK_THRONE_PRODUCTION_BOOST_FROM_CAPTURE',		'StackWithOtherDiploYieldModifiers',	1);