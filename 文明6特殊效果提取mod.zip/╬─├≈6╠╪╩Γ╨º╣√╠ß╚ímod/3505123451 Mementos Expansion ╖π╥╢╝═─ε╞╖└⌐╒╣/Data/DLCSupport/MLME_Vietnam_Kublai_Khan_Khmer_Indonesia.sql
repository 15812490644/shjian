-- MLME_Vietnam_Kublai_Khan_Khmer_Indonesia
-- Author: Maple_Leaves
-- DateCreated: 6/8/2025 1:05:17 AM
--------------------------------------------------------------


--=======================================================================
--����
--���ӵ��������Դ��������ѵ������͸���ս��λ��������Դ+2 [ICON_Culture] �Ļ�ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_ELEPHANT_BORNE_THRONE',				'GAME_EFFECT_MEMENTO_ELEPHANT_BORNE_THRONE_KHMER_DOMREY_VALID_BUILD');


INSERT INTO Modifiers
	(ModifierId,															ModifierType,								Permanent,	OwnerRequirementSetId,			SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_ELEPHANT_BORNE_THRONE_KHMER_DOMREY_VALID_BUILD',	'MODIFIER_PLAYER_ADJUST_VALID_UNIT_BUILD',	0,			'REQSET_PLAYER_HAS_IVORY_MLME',	NULL);

INSERT INTO ModifierArguments
	(ModifierId,															Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_ELEPHANT_BORNE_THRONE_KHMER_DOMREY_VALID_BUILD',	'UnitType',		'UNIT_KHMER_DOMREY');