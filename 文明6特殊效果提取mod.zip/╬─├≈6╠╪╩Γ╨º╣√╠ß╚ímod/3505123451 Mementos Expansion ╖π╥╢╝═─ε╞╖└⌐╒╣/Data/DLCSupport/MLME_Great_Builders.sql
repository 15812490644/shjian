-- MLME_Great_Builders
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:15:18 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_HUNMINJEONGEUM',					'KIND_MAPLE_LEAVES_MEMENTO'),
	('MEMENTO_ROYAL_SLEIGH',					'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_HUNMINJEONGEUM',					'LOC_MEMENTO_HUNMINJEONGEUM_NAME',					'LOC_MEMENTO_HUNMINJEONGEUM_EFFECT',					'LOC_MEMENTO_HUNMINJEONGEUM_DESCRIPTION',					'LOC_MEMENTO_HUNMINJEONGEUM_TOOLTIP'),
	('MEMENTO_ROYAL_SLEIGH',					'LOC_MEMENTO_ROYAL_SLEIGH_NAME',					'LOC_MEMENTO_ROYAL_SLEIGH_EFFECT',						'LOC_MEMENTO_ROYAL_SLEIGH_DESCRIPTION',						'LOC_MEMENTO_ROYAL_SLEIGH_TOOLTIP');

INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_SEJONG',							'MEMENTO_HUNMINJEONGEUM'),
	('LEADER_LUDWIG',							'MEMENTO_ROYAL_SLEIGH');

--=======================================================================
--��ѵ��������
--ѧԺ����Ժ+2 [ICON_Science] �Ƽ�ֵ���ڼӳɡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_HUNMINJEONGEUM',				'GAME_EFFECT_MEMENTO_HUNMINJEONGEUM_CAMPUS_SCIENCE_ADJACENCY');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_HUNMINJEONGEUM_CAMPUS_SCIENCE_ADJACENCY',		'MODIFIER_PLAYER_DISTRICTS_ADJUST_BASE_YIELD_CHANGE_MLME',	0,			NULL,					'REQSET_DISTRICT_IS_CAMPUS_LIKE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,														Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_HUNMINJEONGEUM_CAMPUS_SCIENCE_ADJACENCY',		'YieldType',					'YIELD_SCIENCE'),
	('GAME_EFFECT_MEMENTO_HUNMINJEONGEUM_CAMPUS_SCIENCE_ADJACENCY',		'Amount',						2);


--=======================================================================
--�ʼ�����ѩ��
--����Ϊ����ṩ+2 [ICON_Culture] �Ļ�ֵ���ڼӳɡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_ROYAL_SLEIGH',				'GAME_EFFECT_MEMENTO_ROYAL_SLEIGH_PASTURE_WONDER_CULTURE_ADJACENCY');


INSERT INTO Modifiers
	(ModifierId,															ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_ROYAL_SLEIGH_PASTURE_WONDER_CULTURE_ADJACENCY',	'MODIFIER_PLAYER_CITIES_IMPROVEMENT_ADJACENCY_MLME',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,															Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_ROYAL_SLEIGH_PASTURE_WONDER_CULTURE_ADJACENCY',	'DistrictType',					'DISTRICT_WONDER'),
	('GAME_EFFECT_MEMENTO_ROYAL_SLEIGH_PASTURE_WONDER_CULTURE_ADJACENCY',	'YieldType',					'YIELD_CULTURE'),
	('GAME_EFFECT_MEMENTO_ROYAL_SLEIGH_PASTURE_WONDER_CULTURE_ADJACENCY',	'ImprovementType',				'IMPROVEMENT_PASTURE'),
	('GAME_EFFECT_MEMENTO_ROYAL_SLEIGH_PASTURE_WONDER_CULTURE_ADJACENCY',	'Amount',						2),
	('GAME_EFFECT_MEMENTO_ROYAL_SLEIGH_PASTURE_WONDER_CULTURE_ADJACENCY',	'TilesRequired',				1),
	('GAME_EFFECT_MEMENTO_ROYAL_SLEIGH_PASTURE_WONDER_CULTURE_ADJACENCY',	'Description',					'LOC_DISTRICT_PASTURE_1_CULTURE_MLME');