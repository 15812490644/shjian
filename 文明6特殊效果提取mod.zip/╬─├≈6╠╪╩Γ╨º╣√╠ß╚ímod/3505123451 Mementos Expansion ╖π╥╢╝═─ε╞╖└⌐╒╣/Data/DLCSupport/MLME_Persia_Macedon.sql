-- MLME_Persia_Macedon
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:06:57 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_CYRUS_CYLINDER',					'KIND_MAPLE_LEAVES_MEMENTO'),
	('MEMENTO_LION_HELMET',						'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_CYRUS_CYLINDER',					'LOC_MEMENTO_CYRUS_CYLINDER_NAME',					'LOC_MEMENTO_CYRUS_CYLINDER_EFFECT',					'LOC_MEMENTO_CYRUS_CYLINDER_DESCRIPTION',					'LOC_MEMENTO_CYRUS_CYLINDER_TOOLTIP'),
	('MEMENTO_LION_HELMET',						'LOC_MEMENTO_LION_HELMET_NAME',						'LOC_MEMENTO_LION_HELMET_EFFECT',						'LOC_MEMENTO_LION_HELMET_DESCRIPTION',						'LOC_MEMENTO_LION_HELMET_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_CYRUS',							'MEMENTO_CYRUS_CYLINDER'),
	('LEADER_ALEXANDER',						'MEMENTO_LION_HELMET');


--=======================================================================
--��³ʿԲ��
--ÿλ�����ṩ+1 [ICON_Faith] ����ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,					ModifierId) 
VALUES 
	('MEMENTO_CYRUS_CYLINDER',		'GAME_EFFECT_MEMENTO_CYRUS_CYLINDER_FAITH_PER_POPULATION');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,													Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_CYRUS_CYLINDER_FAITH_PER_POPULATION',		'MODIFIER_PLAYER_CITIES_ADJUST_CITY_YIELD_PER_POPULATION',		0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,					Value)
VALUES
	('GAME_EFFECT_MEMENTO_CYRUS_CYLINDER_FAITH_PER_POPULATION',		'YieldType',			'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_CYRUS_CYLINDER_FAITH_PER_POPULATION',		'Amount',				1);


--=======================================================================
--ʨ��ͷ��
--�󽫾�����Ϊ2����Ԫ���ڵ�½�ؾ��µ�λ+5 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,					ModifierId) 
VALUES 
	('MEMENTO_LION_HELMET',			'GAME_EFFECT_MEMENTO_LION_HELMET_GREAT_GENERAL_STRENGTH');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_LION_HELMET_GREAT_GENERAL_STRENGTH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_LION_HELMET_GREAT_GENERAL_STRENGTH',		'AbilityType',					'ABILITY_GREAT_GENERAL_STRENGTH_AOE_MLME');