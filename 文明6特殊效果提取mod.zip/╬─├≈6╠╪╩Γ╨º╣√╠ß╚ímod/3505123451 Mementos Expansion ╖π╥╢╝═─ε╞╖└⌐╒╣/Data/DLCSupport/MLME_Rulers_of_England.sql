-- MLME_Rulers_of_England
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:16:52 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_TILBURY_SPEECH',					'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_TILBURY_SPEECH',					'LOC_MEMENTO_TILBURY_SPEECH_NAME',				'LOC_MEMENTO_TILBURY_SPEECH_EFFECT',						'LOC_MEMENTO_TILBURY_SPEECH_DESCRIPTION',					'LOC_MEMENTO_TILBURY_SPEECH_TOOLTIP');

INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_ELIZABETH',						'MEMENTO_TILBURY_SPEECH'),
	('LEADER_VICTORIA_ALT',						'MEMENTO_QUEEN_VICTORIA_S_JOURNALS'),
	('LEADER_HARALD_ALT',						'MEMENTO_SAGA_OF_HARALD_HARDRADA');


--=======================================================================
--�ٶ�������˵
--������λ+3 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_TILBURY_SPEECH',			'GAME_EFFECT_MEMENTO_TILBURY_SPEECH_NAVAL_STRENGTH');


INSERT INTO Modifiers
	(ModifierId,												ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TILBURY_SPEECH_NAVAL_STRENGTH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,												Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_TILBURY_SPEECH_NAVAL_STRENGTH',		'AbilityType',					'ABILITY_NAVAL_STRENGTH_MLME');