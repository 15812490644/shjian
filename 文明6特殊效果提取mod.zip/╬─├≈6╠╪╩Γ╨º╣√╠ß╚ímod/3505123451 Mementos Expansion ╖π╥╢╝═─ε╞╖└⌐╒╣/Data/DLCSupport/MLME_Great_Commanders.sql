-- MLME_Great_Commanders
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:15:42 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_GO',								'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode	
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_GO',								'LOC_MEMENTO_GO_NAME',								'LOC_MEMENTO_GO_EFFECT',								'LOC_MEMENTO_GO_DESCRIPTION',								'LOC_MEMENTO_GO_TOOLTIP');

INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_SULEIMAN_ALT',						'MEMENTO_OTTOMAN_LAWS'),
	('LEADER_TOKUGAWA',							'MEMENTO_GO');


--=======================================================================
--Χ��
--ͼ���+2 [ICON_GreatWriter] �����ҵ�����
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_GO',							'GAME_EFFECT_MEMENTO_GO_LIBRARY_GREAT_WRITER_POINT');


INSERT INTO Modifiers
	(ModifierId,												ModifierType,										Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_GO_LIBRARY_GREAT_WRITER_POINT',		'MODIFIER_PLAYER_CITIES_ADJUST_GREAT_PERSON_POINT',	0,			NULL,					'BUILDING_IS_LIBRARY');

INSERT INTO ModifierArguments
	(ModifierId,												Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_GO_LIBRARY_GREAT_WRITER_POINT',		'GreatPersonClassType',			'GREAT_PERSON_CLASS_WRITER'),
	('GAME_EFFECT_MEMENTO_GO_LIBRARY_GREAT_WRITER_POINT',		'Amount',						2);