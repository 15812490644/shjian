-- MLME_Portugal
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:09:04 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,									Kind) 
VALUES 
	('MEMENTO_TREATY_OF_ZARAGOZA',			'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,							Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_TREATY_OF_ZARAGOZA',			'LOC_MEMENTO_TREATY_OF_ZARAGOZA_NAME',				'LOC_MEMENTO_TREATY_OF_ZARAGOZA_EFFECT',				'LOC_MEMENTO_TREATY_OF_ZARAGOZA_DESCRIPTION',				'LOC_MEMENTO_TREATY_OF_ZARAGOZA_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,							MementoType)
VALUES
	('LEADER_JOAO_III',						'MEMENTO_TREATY_OF_ZARAGOZA');


--=======================================================================
--������������Լ��
--������λ���׶���ͬ��½ʱ+2 [ICON_Movement] �ƶ�����������+2 [ICON_Movement] ˮ���ƶ�����
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_TREATY_OF_ZARAGOZA',		'GAME_EFFECT_MEMENTO_TREATY_OF_ZARAGOZA_SETTLER_MOVEMENT');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TREATY_OF_ZARAGOZA_SETTLER_MOVEMENT',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_TREATY_OF_ZARAGOZA_SETTLER_MOVEMENT',		'AbilityType',	'ABILITY_SETTLER_MOVEMENT_MLME');