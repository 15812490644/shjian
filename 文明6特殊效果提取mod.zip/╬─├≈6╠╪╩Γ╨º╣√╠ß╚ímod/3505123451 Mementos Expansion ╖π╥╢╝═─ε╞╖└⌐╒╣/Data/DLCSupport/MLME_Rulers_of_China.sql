-- MLME_Rulers_of_China
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:16:17 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_YONGLE_ENCYCLOPEDIA',				'KIND_MAPLE_LEAVES_MEMENTO'),
	('MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE',		'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_YONGLE_ENCYCLOPEDIA',				'LOC_MEMENTO_YONGLE_ENCYCLOPEDIA_NAME',				'LOC_MEMENTO_YONGLE_ENCYCLOPEDIA_EFFECT',				'LOC_MEMENTO_YONGLE_ENCYCLOPEDIA_DESCRIPTION',				'LOC_MEMENTO_YONGLE_ENCYCLOPEDIA_TOOLTIP'),
	('MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE',		'LOC_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_NAME',		'LOC_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_EFFECT',		'LOC_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DESCRIPTION',		'LOC_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_TOOLTIP');

INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_YONGLE',							'MEMENTO_YONGLE_ENCYCLOPEDIA'),
	('LEADER_WU_ZETIAN',						'MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE'),
	('LEADER_QIN_ALT',							'MEMENTO_HEIRLOOM_SEAL_OF_THE_REALM');



--=======================================================================
--�����ִ�䡷
--ӵ��ͼ��ݵĳ���+3 [ICON_Food] ʳ�+15%�˿������ٶȡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_YONGLE_ENCYCLOPEDIA',						'GAME_EFFECT_MEMENTO_YONGLE_ENCYCLOPEDIA_LIBRARY_CITY_GROWTH'),
	('MEMENTO_YONGLE_ENCYCLOPEDIA',						'GAME_EFFECT_MEMENTO_YONGLE_ENCYCLOPEDIA_LIBRARY_FOOD');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_YONGLE_ENCYCLOPEDIA_LIBRARY_CITY_GROWTH',		'MODIFIER_PLAYER_CITIES_ADJUST_CITY_GROWTH',			0,			NULL,					'BUILDING_IS_LIBRARY'),
	('GAME_EFFECT_MEMENTO_YONGLE_ENCYCLOPEDIA_LIBRARY_FOOD',			'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_YONGLE_ENCYCLOPEDIA_LIBRARY_CITY_GROWTH',		'Amount',					15),
	('GAME_EFFECT_MEMENTO_YONGLE_ENCYCLOPEDIA_LIBRARY_FOOD',			'BuildingType',				'BUILDING_LIBRARY'),
	('GAME_EFFECT_MEMENTO_YONGLE_ENCYCLOPEDIA_LIBRARY_FOOD',			'YieldType',				'YIELD_FOOD'),
	('GAME_EFFECT_MEMENTO_YONGLE_ENCYCLOPEDIA_LIBRARY_FOOD',			'Amount',					3);


--=======================================================================
--���ֱ�
--�����ڵ�ѧԺ����Ժ�㳡����ҵ���ģ���ҵ����ʥ��Ϊ����;��񷽼Ɱ+1��Ӧ�Ĳ�����


CREATE TEMPORARY TABLE 'MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP'
(
District TEXT NOT NULL,
Yield TEXT NOT NULL,
Num INT NOT NULL DEFAULT 1,
PRIMARY KEY (District)
);

INSERT INTO MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
	(District,						Yield,				Num)
VALUES
	('DISTRICT_CAMPUS',				'YIELD_SCIENCE',	1),
	('DISTRICT_HOLY_SITE',			'YIELD_FAITH',		1),
	('DISTRICT_THEATER',			'YIELD_CULTURE',	1),
	('DISTRICT_INDUSTRIAL_ZONE',	'YIELD_PRODUCTION',	1),
	('DISTRICT_COMMERCIAL_HUB',		'YIELD_GOLD',		1);

INSERT INTO MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
	(District,						Yield,				Num)
SELECT 
	CivUniqueDistrictType,			'YIELD_SCIENCE',	1
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_CAMPUS';

INSERT INTO MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
	(District,						Yield,				Num)
SELECT 
	CivUniqueDistrictType,			'YIELD_FAITH',		1
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_HOLY_SITE';

INSERT INTO MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
	(District,						Yield,				Num)
SELECT 
	CivUniqueDistrictType,			'YIELD_CULTURE',	1
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_THEATER';

INSERT INTO MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
	(District,						Yield,				Num)
SELECT 
	CivUniqueDistrictType,			'YIELD_PRODUCTION',	1
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_INDUSTRIAL_ZONE';

INSERT INTO MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
	(District,						Yield,				Num)
SELECT 
	CivUniqueDistrictType,			'YIELD_GOLD',		1
FROM DistrictReplaces WHERE ReplacesDistrictType = 'DISTRICT_COMMERCIAL_HUB';


--��ͨ���
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
SELECT
	'MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE',				'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_MONUMENT_YIELD'
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;


INSERT INTO Modifiers
	(ModifierId,																		ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
SELECT
	'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_MONUMENT_YIELD',	'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',	0,			NULL,					'REQSET_STELE_CITY_HAS_'||District||'_MLME'
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;

INSERT INTO ModifierArguments
	(ModifierId,																		Name,				Value)
SELECT
	'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_MONUMENT_YIELD',	'BuildingType',		'BUILDING_MONUMENT'
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;

INSERT INTO ModifierArguments
	(ModifierId,																		Name,				Value)
SELECT
	'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_MONUMENT_YIELD',	'YieldType',		Yield
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;

INSERT INTO ModifierArguments
	(ModifierId,																		Name,				Value)
SELECT
	'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_MONUMENT_YIELD',	'Amount',			Num
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;


--���񷽼Ɱ
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
SELECT
	'MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE',				'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_OLD_GOD_OBELISK_YIELD'
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
WHERE EXISTS (SELECT * FROM Buildings WHERE BuildingType = 'BUILDING_OLD_GOD_OBELISK');


INSERT INTO Modifiers
	(ModifierId,																			ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
SELECT
	'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_OLD_GOD_OBELISK_YIELD',	'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',	0,			NULL,					'REQSET_STELE_CITY_HAS_'||District||'_MLME'
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
WHERE EXISTS (SELECT * FROM Buildings WHERE BuildingType = 'BUILDING_OLD_GOD_OBELISK');

INSERT INTO ModifierArguments
	(ModifierId,																			Name,				Value)
SELECT
	'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_OLD_GOD_OBELISK_YIELD',	'BuildingType',		'BUILDING_OLD_GOD_OBELISK'
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
WHERE EXISTS (SELECT * FROM Buildings WHERE BuildingType = 'BUILDING_OLD_GOD_OBELISK');

INSERT INTO ModifierArguments
	(ModifierId,																			Name,				Value)
SELECT
	'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_OLD_GOD_OBELISK_YIELD',	'YieldType',		Yield
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
WHERE EXISTS (SELECT * FROM Buildings WHERE BuildingType = 'BUILDING_OLD_GOD_OBELISK');

INSERT INTO ModifierArguments
	(ModifierId,																			Name,				Value)
SELECT
	'GAME_EFFECT_MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_'||District||'_OLD_GOD_OBELISK_YIELD',	'Amount',			Num
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP
WHERE EXISTS (SELECT * FROM Buildings WHERE BuildingType = 'BUILDING_OLD_GOD_OBELISK');


--����������
INSERT INTO Requirements 
	(RequirementId,										RequirementType,						Inverse	)
SELECT
	'REQUIRES_STELE_CITY_HAS_'||District||'_MLME',		'REQUIREMENT_CITY_HAS_DISTRICT',		0
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;

INSERT INTO RequirementArguments
	(RequirementId,										Name,				Value	)
SELECT
	'REQUIRES_STELE_CITY_HAS_'||District||'_MLME',		'DistrictType',		District
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;

INSERT INTO RequirementSets
	(RequirementSetId,										RequirementSetType		)
SELECT
	'REQSET_STELE_CITY_HAS_'||District||'_MLME',			'REQUIREMENTSET_TEST_ALL'
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;

INSERT INTO RequirementSetRequirements
	(RequirementSetId,										RequirementId					)
SELECT
	'REQSET_STELE_CITY_HAS_'||District||'_MLME',			'REQUIRES_STELE_CITY_HAS_'||District||'_MLME'
FROM MEMENTO_WU_ZETIAN_UNINSCRIBED_STELE_DistrictYields_TEMP;


