-- MLME_Byzantium_Gaul
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:11:37 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_MENOLOGION_OF_BASIL_II',			'KIND_MAPLE_LEAVES_MEMENTO'),
	('MEMENTO_CELTIC_LONGSWORD',				'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_MENOLOGION_OF_BASIL_II',			'LOC_MEMENTO_MENOLOGION_OF_BASIL_II_NAME',			'LOC_MEMENTO_MENOLOGION_OF_BASIL_II_EFFECT',			'LOC_MEMENTO_MENOLOGION_OF_BASIL_II_DESCRIPTION',			'LOC_MEMENTO_MENOLOGION_OF_BASIL_II_TOOLTIP'),
	('MEMENTO_CELTIC_LONGSWORD',				'LOC_MEMENTO_CELTIC_LONGSWORD_NAME',				'LOC_MEMENTO_CELTIC_LONGSWORD_EFFECT',					'LOC_MEMENTO_CELTIC_LONGSWORD_DESCRIPTION',					'LOC_MEMENTO_CELTIC_LONGSWORD_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_BASIL',							'MEMENTO_MENOLOGION_OF_BASIL_II'),
	('LEADER_AMBIORIX',							'MEMENTO_CELTIC_LONGSWORD');


--=======================================================================
--����������ʥͽ����
--ӵ������ĳ���ѵ�����������λʱ+30% [ICON_Production] ��������

--�����
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
SELECT
	'MEMENTO_MENOLOGION_OF_BASIL_II',				'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_HEAVY_CAVALRY_PRODUCTION'
FROM Eras;


INSERT INTO Modifiers
	(ModifierId,																			ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
SELECT
	'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_HEAVY_CAVALRY_PRODUCTION',	'MODIFIER_PLAYER_CITIES_ADJUST_UNIT_TAG_ERA_PRODUCTION',	0,			NULL,					'REQSET_CITY_HAS_SHRINE_LIKE_MLME'
FROM Eras;

INSERT INTO ModifierArguments
	(ModifierId,																			Name,					Value,								Extra)
SELECT
	'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_HEAVY_CAVALRY_PRODUCTION',	'UnitPromotionClass',	'PROMOTION_CLASS_HEAVY_CAVALRY',	-1
FROM Eras;

INSERT INTO ModifierArguments
	(ModifierId,																			Name,					Value,								Extra)
SELECT
	'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_HEAVY_CAVALRY_PRODUCTION',	'EraType',				EraType,							-1
FROM Eras;

INSERT INTO ModifierArguments
	(ModifierId,																			Name,					Value,								Extra)
SELECT
	'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_HEAVY_CAVALRY_PRODUCTION',	'Amount',				30,									-1
FROM Eras;

--�����
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
SELECT
	'MEMENTO_MENOLOGION_OF_BASIL_II',				'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_LIGHT_CAVALRY_PRODUCTION'
FROM Eras;


INSERT INTO Modifiers
	(ModifierId,																			ModifierType,												Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
SELECT
	'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_LIGHT_CAVALRY_PRODUCTION',	'MODIFIER_PLAYER_CITIES_ADJUST_UNIT_TAG_ERA_PRODUCTION',	0,			NULL,					'REQSET_CITY_HAS_SHRINE_LIKE_MLME'
FROM Eras;

INSERT INTO ModifierArguments
	(ModifierId,																			Name,					Value,								Extra)
SELECT
	'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_LIGHT_CAVALRY_PRODUCTION',	'UnitPromotionClass',	'PROMOTION_CLASS_LIGHT_CAVALRY',	-1
FROM Eras;

INSERT INTO ModifierArguments
	(ModifierId,																			Name,					Value,								Extra)
SELECT
	'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_LIGHT_CAVALRY_PRODUCTION',	'EraType',				EraType,							-1
FROM Eras;

INSERT INTO ModifierArguments
	(ModifierId,																			Name,					Value,								Extra)
SELECT
	'GAME_EFFECT_MEMENTO_MENOLOGION_OF_BASIL_II_'||EraType||'_LIGHT_CAVALRY_PRODUCTION',	'Amount',				30,									-1
FROM Eras;


--=======================================================================
--�����س���
--���ͺ�����սʿ+5 [ICON_Strength] ս������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_CELTIC_LONGSWORD',			'GAME_EFFECT_MEMENTO_CELTIC_LONGSWORD_SWORDSMAN_STRENGTH');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_CELTIC_LONGSWORD_SWORDSMAN_STRENGTH',		'MODIFIER_PLAYER_UNITS_GRANT_ABILITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_CELTIC_LONGSWORD_SWORDSMAN_STRENGTH',		'AbilityType',					'ABILITY_SWORDSMAN_STRENGTH_MLME');