-- MLME_Babylon
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:11:06 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_CODE_OF_HAMMURABI',				'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_CODE_OF_HAMMURABI',				'LOC_MEMENTO_CODE_OF_HAMMURABI_NAME',				'LOC_MEMENTO_CODE_OF_HAMMURABI_EFFECT',					'LOC_MEMENTO_CODE_OF_HAMMURABI_DESCRIPTION',				'LOC_MEMENTO_CODE_OF_HAMMURABI_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_HAMMURABI',						'MEMENTO_CODE_OF_HAMMURABI');


--=======================================================================
--�������ȷ���ʯ��
--���������䡱������+1�������߲�λ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_CODE_OF_HAMMURABI',					'GAME_EFFECT_MEMENTO_CODE_OF_HAMMURABI_SLOT_ECONOMIC');


INSERT INTO Modifiers
	(ModifierId,												ModifierType,												Permanent,	OwnerRequirementSetId,						SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_CODE_OF_HAMMURABI_SLOT_ECONOMIC',		'MODIFIER_PLAYER_CULTURE_ADJUST_GOVERNMENT_SLOTS_MODIFIER',	0,			'REQSET_PLAYER_HAS_CODE_OF_LAWS_MLME',		NULL);

INSERT INTO ModifierArguments
	(ModifierId,												Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_CODE_OF_HAMMURABI_SLOT_ECONOMIC',		'GovernmentSlotType',		'SLOT_ECONOMIC');