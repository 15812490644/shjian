-- MLME_Khmer_Indonesia
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:08:02 PM
--------------------------------------------------------------

INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_SMILING_BUDDHA_STATUE',			'KIND_MAPLE_LEAVES_MEMENTO'),
	('MEMENTO_NAGARAKRETAGAMA',					'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_SMILING_BUDDHA_STATUE',			'LOC_MEMENTO_SMILING_BUDDHA_STATUE_NAME',			'LOC_MEMENTO_SMILING_BUDDHA_STATUE_EFFECT',				'LOC_MEMENTO_SMILING_BUDDHA_STATUE_DESCRIPTION',			'LOC_MEMENTO_SMILING_BUDDHA_STATUE_TOOLTIP'),
	('MEMENTO_NAGARAKRETAGAMA',					'LOC_MEMENTO_NAGARAKRETAGAMA_NAME',					'LOC_MEMENTO_NAGARAKRETAGAMA_EFFECT',					'LOC_MEMENTO_NAGARAKRETAGAMA_DESCRIPTION',					'LOC_MEMENTO_NAGARAKRETAGAMA_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_JAYAVARMAN',						'MEMENTO_SMILING_BUDDHA_STATUE'),
	('LEADER_GITARJA',							'MEMENTO_NAGARAKRETAGAMA');


--=======================================================================
--΢Ц����
--����+3 [ICON_Faith] ����ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,										ModifierId) 
VALUES 
	('MEMENTO_SMILING_BUDDHA_STATUE',					'GAME_EFFECT_MEMENTO_SMILING_BUDDHA_STATUE_TEMPLE_FAITH');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_SMILING_BUDDHA_STATUE_TEMPLE_FAITH',		'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_SMILING_BUDDHA_STATUE_TEMPLE_FAITH',		'BuildingType',				'BUILDING_TEMPLE'),
	('GAME_EFFECT_MEMENTO_SMILING_BUDDHA_STATUE_TEMPLE_FAITH',		'YieldType',				'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_SMILING_BUDDHA_STATUE_TEMPLE_FAITH',		'Amount',					3);


--=======================================================================
--��צ��ʷ�̡�
--�Ѹ����ĺ����������Ԫ��+2 [ICON_Faith] ����ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_NAGARAKRETAGAMA',					'GAME_EFFECT_MEMENTO_NAGARAKRETAGAMAE_IMPROVED_COAST_FAITH');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_NAGARAKRETAGAMAE_IMPROVED_COAST_FAITH',		'MODIFIER_PLAYER_ADJUST_PLOT_YIELD',	0,			NULL,					'REQSET_PLOT_IS_IMPROVED_COAST_MLME');

INSERT INTO ModifierArguments
	(ModifierId,														Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_NAGARAKRETAGAMAE_IMPROVED_COAST_FAITH',		'YieldType',				'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_NAGARAKRETAGAMAE_IMPROVED_COAST_FAITH',		'Amount',					2);


INSERT INTO Requirements 
	(RequirementId,									RequirementType,						Inverse	)
VALUES
	('REQUIRES_PLOT_IS_IMPROVED_MLME',				'REQUIREMENT_PLOT_HAS_ANY_IMPROVEMENT',	0);

INSERT INTO RequirementSets
	(RequirementSetId,								RequirementSetType			)
VALUES
	('REQSET_PLOT_IS_IMPROVED_COAST_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
VALUES
	('REQSET_PLOT_IS_IMPROVED_COAST_MLME',			'REQUIRES_PLOT_IS_IMPROVED_MLME'),
	('REQSET_PLOT_IS_IMPROVED_COAST_MLME',			'REQUIRES_PLOT_HAS_COAST');