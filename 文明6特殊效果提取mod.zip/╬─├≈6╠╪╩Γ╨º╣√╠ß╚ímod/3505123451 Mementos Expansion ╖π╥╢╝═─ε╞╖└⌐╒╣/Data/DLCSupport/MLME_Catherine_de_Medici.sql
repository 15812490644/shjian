-- MLME_Catherine_de_Medici
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:13:54 PM
--------------------------------------------------------------


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_CATHERINE_DE_MEDICI_ALT',			'MEMENTO_BLACK_CLOTH');