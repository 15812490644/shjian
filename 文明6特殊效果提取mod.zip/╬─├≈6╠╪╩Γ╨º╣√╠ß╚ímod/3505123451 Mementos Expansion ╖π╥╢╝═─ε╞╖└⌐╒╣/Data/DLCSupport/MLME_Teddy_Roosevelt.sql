-- MLME_Teddy_Roosevelt
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:14:24 PM
--------------------------------------------------------------


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_T_ROOSEVELT_ROUGHRIDER',			'MEMENTO_THE_WILDERNESS_HUNTER');