-- MLME_Aztec
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:05:42 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_DOUBLE_HEADED_SERPENT',			'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,													Effect,														Description,													Tooltip)
VALUES
	('MEMENTO_DOUBLE_HEADED_SERPENT',			'LOC_MEMENTO_DOUBLE_HEADED_SERPENT_NAME',				'LOC_MEMENTO_DOUBLE_HEADED_SERPENT_EFFECT',					'LOC_MEMENTO_DOUBLE_HEADED_SERPENT_DESCRIPTION',				'LOC_MEMENTO_DOUBLE_HEADED_SERPENT_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_MONTEZUMA',						'MEMENTO_DOUBLE_HEADED_SERPENT');


--=======================================================================
--����ʯ˫ͷ��
--����3������� [ICON_RESOURCE_TURQUOISE_MLME] ����ʯ�ݳ�Ʒ��Դ��+6 [ICON_Amenities] �˾Ӷȡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_DOUBLE_HEADED_SERPENT',				'GAME_EFFECT_MEMENTO_DOUBLE_HEADED_SERPENT_LUXURY_RESOURCE_TURQUOISE_MLME');


INSERT INTO Modifiers
	(ModifierId,																	ModifierType,									Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_DOUBLE_HEADED_SERPENT_LUXURY_RESOURCE_TURQUOISE_MLME',	'MODIFIER_SINGLE_CITY_GRANT_RESOURCE_IN_CITY',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,																	Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_DOUBLE_HEADED_SERPENT_LUXURY_RESOURCE_TURQUOISE_MLME',	'ResourceType',	'RESOURCE_TURQUOISE_MLME'),
	('GAME_EFFECT_MEMENTO_DOUBLE_HEADED_SERPENT_LUXURY_RESOURCE_TURQUOISE_MLME',	'Amount',		3);

--����ʯ
INSERT INTO Types 
	(Type,							Kind) 
VALUES 
	('RESOURCE_TURQUOISE_MLME',		'KIND_RESOURCE');

INSERT INTO Resources
	(ResourceType,					Name,								ResourceClassType,			Happiness,	Frequency) 
VALUES 
	('RESOURCE_TURQUOISE_MLME',		'LOC_RESOURCE_TURQUOISE_MLME_NAME',	'RESOURCECLASS_LUXURY',		6,			0);