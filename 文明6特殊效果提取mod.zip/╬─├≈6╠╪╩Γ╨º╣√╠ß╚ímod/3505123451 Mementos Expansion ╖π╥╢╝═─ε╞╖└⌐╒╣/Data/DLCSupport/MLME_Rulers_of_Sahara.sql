-- MLME_Rulers_of_Sahara
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:16:36 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_BAOBAB_CRUTCHES',					'KIND_MAPLE_LEAVES_MEMENTO'),
	('MEMENTO_KADESH_INSCRIPTIONS',				'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_BAOBAB_CRUTCHES',					'LOC_MEMENTO_BAOBAB_CRUTCHES_NAME',					'LOC_MEMENTO_BAOBAB_CRUTCHES_EFFECT',					'LOC_MEMENTO_BAOBAB_CRUTCHES_DESCRIPTION',					'LOC_MEMENTO_BAOBAB_CRUTCHES_TOOLTIP'),
	('MEMENTO_KADESH_INSCRIPTIONS',				'LOC_MEMENTO_KADESH_INSCRIPTIONS_NAME',				'LOC_MEMENTO_KADESH_INSCRIPTIONS_EFFECT',				'LOC_MEMENTO_KADESH_INSCRIPTIONS_DESCRIPTION',				'LOC_MEMENTO_KADESH_INSCRIPTIONS_TOOLTIP');

INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_SUNDIATA_KEITA',					'MEMENTO_BAOBAB_CRUTCHES'),
	('LEADER_RAMSES',							'MEMENTO_KADESH_INSCRIPTIONS'),
	('LEADER_CLEOPATRA_ALT',					'MEMENTO_QUEEN_S_CARPET');


--=======================================================================
--�����������
--���֡�ɭ�ֺ�ϡ����ԭ+1 [ICON_Food] ʳ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,						ModifierId) 
VALUES 
	('MEMENTO_BAOBAB_CRUTCHES',			'GAME_EFFECT_MEMENTO_BAOBAB_CRUTCHES_TREE_FOOD');


INSERT INTO Modifiers
	(ModifierId,											ModifierType,							Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_BAOBAB_CRUTCHES_TREE_FOOD',		'MODIFIER_PLAYER_ADJUST_PLOT_YIELD',	0,			NULL,					'REQSET_UNIT_ON_TREES_MLME');

INSERT INTO ModifierArguments
	(ModifierId,												Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_BAOBAB_CRUTCHES_TREE_FOOD',			'YieldType',					'YIELD_FOOD'),
	('GAME_EFFECT_MEMENTO_BAOBAB_CRUTCHES_TREE_FOOD',			'Amount',						1);


--=======================================================================
--����ʯ����
--��������������ս��ʱ���������+30% [ICON_Production] ��������
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_KADESH_INSCRIPTIONS',			'GAME_EFFECT_MEMENTO_KADESH_INSCRIPTIONS_WAR_WONDER_PRODUCTION');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,										Permanent,	OwnerRequirementSetId,									SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_KADESH_INSCRIPTIONS_WAR_WONDER_PRODUCTION',	'MODIFIER_PLAYER_CITIES_ADJUST_WONDER_PRODUCTION',	0,			'REQSET_PLAYER_IS_NOT_AT_PEACE_WITH_ALL_MAJORS_MLME',	NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,					Value)
VALUES
	('GAME_EFFECT_MEMENTO_KADESH_INSCRIPTIONS_WAR_WONDER_PRODUCTION',	'Amount',				30);


INSERT INTO Requirements 
	(RequirementId,													RequirementType,									Inverse	)
VALUES
	('REQUIRES_PLAYER_IS_NOT_AT_PEACE_WITH_ALL_MAJORS_MLME',		'REQUIREMENT_PLAYER_IS_AT_PEACE_WITH_ALL_MAJORS',	1);

INSERT INTO RequirementSets
	(RequirementSetId,												RequirementSetType			)
VALUES
	('REQSET_PLAYER_IS_NOT_AT_PEACE_WITH_ALL_MAJORS_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,												RequirementId					)
VALUES
	('REQSET_PLAYER_IS_NOT_AT_PEACE_WITH_ALL_MAJORS_MLME',			'REQUIRES_PLAYER_IS_NOT_AT_PEACE_WITH_ALL_MAJORS_MLME');