-- MLME_Poland
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:06:12 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_FOOTPRINT_STONE',					'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,													Effect,														Description,													Tooltip)
VALUES
	('MEMENTO_FOOTPRINT_STONE',					'LOC_MEMENTO_FOOTPRINT_STONE_NAME',						'LOC_MEMENTO_FOOTPRINT_STONE_EFFECT',						'LOC_MEMENTO_FOOTPRINT_STONE_DESCRIPTION',						'LOC_MEMENTO_FOOTPRINT_STONE_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_JADWIGA',							'MEMENTO_FOOTPRINT_STONE');


--=======================================================================
--��ӡʯ
--���ĳ�����ÿ���������ڽ̵ľ���ʹ [ICON_Faith] ����ֵ+3%��
--Your cities receive +2% [ICON_Faith] Faith for every [ICON_Citizen] Population in the city.
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_FOOTPRINT_STONE',				'GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_FOLLOWER_FAITH');

INSERT INTO Modifiers
	(ModifierId,											ModifierType,													RunOnce,	Permanent,	OwnerRequirementSetId,		SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_FOLLOWER_FAITH',	'MODIFIER_PLAYER_CITIES_ADJUST_FOLLOWER_YIELD_MODIFIER_MLME',	0,			0,			NULL,						NULL);

INSERT INTO ModifierArguments
	(ModifierId,											Name,				Value)
VALUES
	('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_FOLLOWER_FAITH',	'YieldType',		'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_FOLLOWER_FAITH',	'Amount',			2);



