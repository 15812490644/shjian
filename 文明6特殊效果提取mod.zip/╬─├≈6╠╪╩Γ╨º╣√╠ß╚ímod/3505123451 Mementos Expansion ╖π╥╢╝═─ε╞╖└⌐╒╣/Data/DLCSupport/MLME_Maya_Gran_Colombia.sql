-- MLME_Maya_Gran_Colombia
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:10:06 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_STELA_OF_NARANJO',				'KIND_MAPLE_LEAVES_MEMENTO'),
	('MEMENTO_JAMAICA_LETTER',					'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_STELA_OF_NARANJO',				'LOC_MEMENTO_STELA_OF_NARANJO_NAME',				'LOC_MEMENTO_STELA_OF_NARANJO_EFFECT',					'LOC_MEMENTO_STELA_OF_NARANJO_DESCRIPTION',					'LOC_MEMENTO_STELA_OF_NARANJO_TOOLTIP'),
	('MEMENTO_JAMAICA_LETTER',					'LOC_MEMENTO_JAMAICA_LETTER_NAME',					'LOC_MEMENTO_JAMAICA_LETTER_EFFECT',					'LOC_MEMENTO_JAMAICA_LETTER_DESCRIPTION',					'LOC_MEMENTO_JAMAICA_LETTER_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_LADY_SIX_SKY',						'MEMENTO_STELA_OF_NARANJO'),
	('LEADER_SIMON_BOLIVAR',					'MEMENTO_JAMAICA_LETTER');


--=======================================================================
--��������24��ʯ��
--������Դ+3 [ICON_Production] ��������+1 [ICON_Science] �Ƽ�ֵ��ӵ���Ѹ���������Դ�ĳ���+1 [ICON_Amenities] �˾Ӷȡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_STELA_OF_NARANJO',					'GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_PRODUCTION'),
	('MEMENTO_STELA_OF_NARANJO',					'GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_SCIENCE'),
	('MEMENTO_STELA_OF_NARANJO',					'GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_AMENITY');


INSERT INTO Modifiers
	(ModifierId,												ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_PRODUCTION',	'MODIFIER_PLAYER_ADJUST_PLOT_YIELD',					0,			NULL,					'RESOURCE_IS_MAIZE'),
	('GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_SCIENCE',		'MODIFIER_PLAYER_ADJUST_PLOT_YIELD',					0,			NULL,					'RESOURCE_IS_MAIZE'),
	('GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_AMENITY',		'MODIFIER_PLAYER_CITIES_ADJUST_IMPROVEMENT_AMENITY',	0,			NULL,					'REQSET_CITY_HAS_IMPROVED_MAIZE_MLME');

INSERT INTO ModifierArguments
	(ModifierId,													Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_PRODUCTION',		'YieldType',				'YIELD_PRODUCTION'),
	('GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_PRODUCTION',		'Amount',					1),
	('GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_SCIENCE',			'YieldType',				'YIELD_SCIENCE'),
	('GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_SCIENCE',			'Amount',					1),
	('GAME_EFFECT_MEMENTO_STELA_OF_NARANJO_MAIZE_AMENITY',			'Amount',					1);


INSERT INTO Requirements 
	(RequirementId,									RequirementType,									Inverse	)
VALUES
	('REQUIRES_CITY_HAS_IMPROVED_MAIZE_MLME',		'REQUIREMENT_CITY_HAS_RESOURCE_TYPE_IMPROVED',		0);

INSERT INTO RequirementArguments
	(RequirementId,									Name,					Value	)
VALUES
	('REQUIRES_CITY_HAS_IMPROVED_MAIZE_MLME',		'ResourceType',			'RESOURCE_MAIZE');

INSERT INTO RequirementSets
	(RequirementSetId,								RequirementSetType			)
VALUES
	('REQSET_CITY_HAS_IMPROVED_MAIZE_MLME',			'REQUIREMENTSET_TEST_ALL');

INSERT INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
VALUES
	('REQSET_CITY_HAS_IMPROVED_MAIZE_MLME',			'REQUIRES_CITY_HAS_IMPROVED_MAIZE_MLME');


--=======================================================================
--���������
--ÿ�غ�+3 [ICON_FAVOR] �⽻֧�֣���Ϸ���빤ҵʱ�������+3��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,								ModifierId) 
VALUES 
	('MEMENTO_JAMAICA_LETTER',			'GAME_EFFECT_MEMENTO_JAMAICA_LETTER_EXTRA_FAVOR'),
	('MEMENTO_JAMAICA_LETTER',			'GAME_EFFECT_MEMENTO_JAMAICA_LETTER_EXTRA_FAVOR_INDUSTRIAL');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,									Permanent,	OwnerRequirementSetId,										SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_JAMAICA_LETTER_EXTRA_FAVOR',				'MODIFIER_PLAYER_ADJUST_EXTRA_FAVOR_PER_TURN',	0,			NULL,														NULL),
	('GAME_EFFECT_MEMENTO_JAMAICA_LETTER_EXTRA_FAVOR_INDUSTRIAL',	'MODIFIER_PLAYER_ADJUST_EXTRA_FAVOR_PER_TURN',	0,			'REQSET_GAME_ERA_ATLEAST_EXPANSION_ERA_INDUSTRIAL_MLME',	NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_JAMAICA_LETTER_EXTRA_FAVOR',				'Amount',					3),
	('GAME_EFFECT_MEMENTO_JAMAICA_LETTER_EXTRA_FAVOR_INDUSTRIAL',	'Amount',					3);