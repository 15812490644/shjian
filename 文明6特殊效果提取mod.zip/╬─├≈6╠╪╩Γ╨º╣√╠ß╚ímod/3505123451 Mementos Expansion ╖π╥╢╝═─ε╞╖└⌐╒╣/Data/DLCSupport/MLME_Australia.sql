-- MLME_Australia
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:08:33 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_AUSTRALIA_LOOKS_TO_US',			'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,													Effect,														Description,													Tooltip)
VALUES
	('MEMENTO_AUSTRALIA_LOOKS_TO_US',			'LOC_MEMENTO_AUSTRALIA_LOOKS_TO_US_NAME',				'LOC_MEMENTO_AUSTRALIA_LOOKS_TO_US_EFFECT',					'LOC_MEMENTO_AUSTRALIA_LOOKS_TO_US_DESCRIPTION',				'LOC_MEMENTO_AUSTRALIA_LOOKS_TO_US_TOOLTIP');


INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_JOHN_CURTIN',						'MEMENTO_AUSTRALIA_LOOKS_TO_US');


--=======================================================================
--���Ĵ��������������롷
--������������ѧ��������+1�⽻���߲�λ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_AUSTRALIA_LOOKS_TO_US',				'GAME_EFFECT_MEMENTO_AUSTRALIA_LOOKS_TO_US_SLOT_DIPLOMATIC');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,												Permanent,	OwnerRequirementSetId,							SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_AUSTRALIA_LOOKS_TO_US_SLOT_DIPLOMATIC',	'MODIFIER_PLAYER_CULTURE_ADJUST_GOVERNMENT_SLOTS_MODIFIER',	0,			'REQSET_PLAYER_HAS_POLITICAL_PHILOSOPHY_MLME',		NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_AUSTRALIA_LOOKS_TO_US_SLOT_DIPLOMATIC',	'GovernmentSlotType',		'SLOT_DIPLOMATIC');




