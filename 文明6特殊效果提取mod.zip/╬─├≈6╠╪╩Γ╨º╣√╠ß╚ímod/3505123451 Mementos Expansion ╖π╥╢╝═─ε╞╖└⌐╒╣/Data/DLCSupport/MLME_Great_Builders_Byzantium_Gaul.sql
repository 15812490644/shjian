-- MLME_Great_Builders_Byzantium_Gaul
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 11:28:36 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_MOSAIC_OF_THEODORA',				'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_MOSAIC_OF_THEODORA',				'LOC_MEMENTO_MOSAIC_OF_THEODORA_NAME',				'LOC_MEMENTO_MOSAIC_OF_THEODORA_EFFECT',				'LOC_MEMENTO_MOSAIC_OF_THEODORA_DESCRIPTION',				'LOC_MEMENTO_MOSAIC_OF_THEODORA_TOOLTIP');

INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_THEODORA',							'MEMENTO_MOSAIC_OF_THEODORA');


--=======================================================================
--ʥά����������Ƕ��
--ũ��Ϊʥ���ṩ��׼�� [ICON_Faith] ����ֵ���ڼӳɡ�
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_MOSAIC_OF_THEODORA',				'GAME_EFFECT_MEMENTO_MOSAIC_OF_THEODORA_FARM_HOLY_SITE_FAITH_ADJACENCY');


INSERT INTO Modifiers
	(ModifierId,																ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_MOSAIC_OF_THEODORA_FARM_HOLY_SITE_FAITH_ADJACENCY',	'MODIFIER_PLAYER_CITIES_IMPROVEMENT_ADJACENCY_MLME',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,																Name,							Value)
VALUES
	('GAME_EFFECT_MEMENTO_MOSAIC_OF_THEODORA_FARM_HOLY_SITE_FAITH_ADJACENCY',	'DistrictType',					'DISTRICT_HOLY_SITE'),
	('GAME_EFFECT_MEMENTO_MOSAIC_OF_THEODORA_FARM_HOLY_SITE_FAITH_ADJACENCY',	'YieldType',					'YIELD_FAITH'),
	('GAME_EFFECT_MEMENTO_MOSAIC_OF_THEODORA_FARM_HOLY_SITE_FAITH_ADJACENCY',	'ImprovementType',				'IMPROVEMENT_FARM'),
	('GAME_EFFECT_MEMENTO_MOSAIC_OF_THEODORA_FARM_HOLY_SITE_FAITH_ADJACENCY',	'Amount',						1),
	('GAME_EFFECT_MEMENTO_MOSAIC_OF_THEODORA_FARM_HOLY_SITE_FAITH_ADJACENCY',	'TilesRequired',				1),
	('GAME_EFFECT_MEMENTO_MOSAIC_OF_THEODORA_FARM_HOLY_SITE_FAITH_ADJACENCY',	'Description',					'LOC_DISTRICT_FARM_1_FAITH_MLME');