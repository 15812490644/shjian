-- MLME_Great_Negotiators
-- Author: Maple_Leaves
-- DateCreated: 6/7/2025 6:17:35 PM
--------------------------------------------------------------


INSERT INTO Types 
	(Type,										Kind) 
VALUES 
	('MEMENTO_GETTYSBURG_ADDRESS',				'KIND_MAPLE_LEAVES_MEMENTO'),
	('MEMENTO_NEGOTIATION_STOOL',				'KIND_MAPLE_LEAVES_MEMENTO');


INSERT INTO ML_Mementos_Mode	
	(MementoType,								Name,												Effect,													Description,												Tooltip)
VALUES
	('MEMENTO_GETTYSBURG_ADDRESS',				'LOC_MEMENTO_GETTYSBURG_ADDRESS_NAME',				'LOC_MEMENTO_GETTYSBURG_ADDRESS_EFFECT',				'LOC_MEMENTO_GETTYSBURG_ADDRESS_DESCRIPTION',				'LOC_MEMENTO_GETTYSBURG_ADDRESS_TOOLTIP'),
	('MEMENTO_NEGOTIATION_STOOL',				'LOC_MEMENTO_NEGOTIATION_STOOL_NAME',				'LOC_MEMENTO_NEGOTIATION_STOOL_EFFECT',					'LOC_MEMENTO_NEGOTIATION_STOOL_DESCRIPTION',				'LOC_MEMENTO_NEGOTIATION_STOOL_TOOLTIP');

INSERT INTO ML_LeaderMementos_Mode
	(LeaderType,								MementoType)
VALUES
	('LEADER_SALADIN_ALT',						'MEMENTO_TREATY_OF_JAFFA_1192'),
	('LEADER_ABRAHAM_LINCOLN',					'MEMENTO_GETTYSBURG_ADDRESS'),
	('LEADER_NZINGA_MBANDE',					'MEMENTO_NEGOTIATION_STOOL');


--=======================================================================
--���˹����˵
--������������ѧ��������+1ͨ������߲�λ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_GETTYSBURG_ADDRESS',					'GAME_EFFECT_MEMENTO_GETTYSBURG_ADDRESS_SLOT_WILDCARD');


INSERT INTO Modifiers
	(ModifierId,													ModifierType,												Permanent,	OwnerRequirementSetId,							SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_GETTYSBURG_ADDRESS_SLOT_WILDCARD',		'MODIFIER_PLAYER_CULTURE_ADJUST_GOVERNMENT_SLOTS_MODIFIER',	0,			'REQSET_PLAYER_HAS_POLITICAL_PHILOSOPHY_MLME',		NULL);

INSERT INTO ModifierArguments
	(ModifierId,													Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_GETTYSBURG_ADDRESS_SLOT_WILDCARD',		'GovernmentSlotType',		'SLOT_WILDCARD');


--=======================================================================
--̸����
--ÿ�غ�+4Ӱ������������Ϸ���빤ҵʱ�������+4��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,									ModifierId) 
VALUES 
	('MEMENTO_NEGOTIATION_STOOL',					'GAME_EFFECT_MEMENTO_NEGOTIATION_STOOL_INFLUENCE_POINTS'),
	('MEMENTO_NEGOTIATION_STOOL',					'GAME_EFFECT_MEMENTO_NEGOTIATION_STOOL_INFLUENCE_POINTS_INDUSTRIAL');


INSERT INTO Modifiers
	(ModifierId,															ModifierType,										Permanent,	OwnerRequirementSetId,										SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_NEGOTIATION_STOOL_INFLUENCE_POINTS',				'MODIFIER_PLAYER_ADJUST_INFLUENCE_POINTS_PER_TURN',	0,			NULL,														NULL),
	('GAME_EFFECT_MEMENTO_NEGOTIATION_STOOL_INFLUENCE_POINTS_INDUSTRIAL',	'MODIFIER_PLAYER_ADJUST_INFLUENCE_POINTS_PER_TURN',	0,			'REQSET_GAME_ERA_ATLEAST_EXPANSION_ERA_INDUSTRIAL_MLME',	NULL);

INSERT INTO ModifierArguments
	(ModifierId,															Name,			Value)
VALUES
	('GAME_EFFECT_MEMENTO_NEGOTIATION_STOOL_INFLUENCE_POINTS',				'Amount',		4),
	('GAME_EFFECT_MEMENTO_NEGOTIATION_STOOL_INFLUENCE_POINTS_INDUSTRIAL',	'Amount',		4);