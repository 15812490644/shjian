-- MLME_Poland_Heroes_Mode
-- Author: Maple_Leaves
-- DateCreated: 6/11/2025 9:19:45 PM
--------------------------------------------------------------


--=======================================================================
--��ӡʯ
--���� [ICON_Relic] ��Ӣ���������3�� [ICON_Faith] ����ֵ�� [ICON_Tourism] ����ҵ����
--�Ѿ�ɾ��

--INSERT INTO ML_MementoModifiers_Mode
	--(MementoType,							ModifierId) 
--VALUES 
	--('MEMENTO_FOOTPRINT_STONE',				'GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_FAITH'),
	--('MEMENTO_FOOTPRINT_STONE',				'GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_TOURISM');


--INSERT INTO Modifiers
	--(ModifierId,													ModifierType,											Permanent,	OwnerRequirementSetId,		SubjectRequirementSetId)
--VALUES
	--('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_FAITH',		'MODIFIER_PLAYER_CITIES_ADJUST_GREATWORK_YIELD',		0,			NULL,						NULL),
	--('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_TOURISM',	'MODIFIER_PLAYER_CITIES_ADJUST_TOURISM_MLME',			0,			NULL,						NULL);
--
--INSERT INTO ModifierArguments
	--(ModifierId,														Name,						Value)
--VALUES
	--('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_FAITH',			'GreatWorkObjectType',		'GREATWORKOBJECT_HERO'),
	--('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_FAITH',			'YieldType',				'YIELD_FAITH'),
	--('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_FAITH',			'ScalingFactor',			300),
--
	--('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_TOURISM',		'GreatWorkObjectType',		'GREATWORKOBJECT_HERO'),
	--('GAME_EFFECT_MEMENTO_FOOTPRINT_STONE_HEROIC_RELIC_TOURISM',		'ScalingFactor',			300);