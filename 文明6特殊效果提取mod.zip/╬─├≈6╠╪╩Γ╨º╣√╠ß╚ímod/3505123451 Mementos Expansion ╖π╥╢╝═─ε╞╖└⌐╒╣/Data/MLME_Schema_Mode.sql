-- MLME_Schema_Mode
-- Author: Maple_Leaves
-- DateCreated: 5/11/2025 9:39:09 PM
--------------------------------------------------------------


CREATE TABLE IF NOT EXISTS 'ML_Mementos_Mode'
(
MementoType TEXT NOT NULL,
Name TEXT NOT NULL,
Description TEXT NOT NULL,
Effect TEXT NOT NULL,
Tooltip TEXT NOT NULL,
Disabled BOOLEAN NOT NULL CHECK (Disabled IN (0,1)) DEFAULT 0,
PRIMARY KEY (MementoType),
FOREIGN KEY (MementoType) REFERENCES Types(Type) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS 'ML_LeaderMementos_Mode'
(
LeaderType TEXT NOT NULL,
MementoType TEXT NOT NULL,
PRIMARY KEY (LeaderType, MementoType),
FOREIGN KEY (LeaderType) REFERENCES Leaders(LeaderType) ON DELETE CASCADE ON UPDATE CASCADE,
FOREIGN KEY (MementoType) REFERENCES ML_Mementos_Mode(MementoType) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE 'ML_MementoModifiers_Mode'
(
MementoType TEXT NOT NULL,
ModifierId TEXT NOT NULL,
PRIMARY KEY (MementoType, ModifierId),
FOREIGN KEY (MementoType) REFERENCES ML_Mementos_Mode(MementoType) ON DELETE CASCADE ON UPDATE CASCADE
);