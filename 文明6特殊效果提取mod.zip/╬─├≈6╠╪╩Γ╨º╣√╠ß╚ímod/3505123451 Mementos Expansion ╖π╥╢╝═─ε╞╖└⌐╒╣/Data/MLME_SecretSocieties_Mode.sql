-- MLME_SecretSocieties_Mode
-- Author: Maple_Leaves
-- DateCreated: 6/8/2025 11:34:52 PM
--------------------------------------------------------------


--=======================================================================
--������٤��ʲʷʫ�����
--����;��񷽼Ɱ+1 [ICON_GreatWriter] �����ҵ���������Ӣ�۴�˵��Ŀʱ+100% [ICON_Production] ��������

INSERT  INTO Requirements 
	(RequirementId,										RequirementType,						Inverse	)
VALUES
	('REQUIRES_CITY_HAS_OLD_GOD_OBELISK_MLME',			'REQUIREMENT_CITY_HAS_BUILDING',		0);

INSERT  INTO RequirementArguments
	(RequirementId,										Name,					Value	)
VALUES
	('REQUIRES_CITY_HAS_OLD_GOD_OBELISK_MLME',			'BuildingType',			'BUILDING_OLD_GOD_OBELISK');

INSERT  INTO RequirementSetRequirements
	(RequirementSetId,								RequirementId					)
VALUES
	('REQSET_CITY_HAS_MONUMENT_LIKE_MLME',			'REQUIRES_CITY_HAS_OLD_GOD_OBELISK_MLME');


--=======================================================================
--ͼ����͹���
--����;��񷽼Ɱ+2 [ICON_Culture] �Ļ�ֵ��
INSERT INTO ML_MementoModifiers_Mode
	(MementoType,							ModifierId) 
VALUES 
	('MEMENTO_TRAJAN_S_COLUMN',				'GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_OLD_GOD_OBELISK_CULTURE');


INSERT INTO Modifiers
	(ModifierId,														ModifierType,											Permanent,	OwnerRequirementSetId,	SubjectRequirementSetId)
VALUES
	('GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_OLD_GOD_OBELISK_CULTURE',		'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',	0,			NULL,					NULL);

INSERT INTO ModifierArguments
	(ModifierId,														Name,						Value)
VALUES
	('GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_OLD_GOD_OBELISK_CULTURE',		'BuildingType',				'BUILDING_OLD_GOD_OBELISK'),
	('GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_OLD_GOD_OBELISK_CULTURE',		'YieldType',				'YIELD_CULTURE'),
	('GAME_EFFECT_MEMENTO_TRAJAN_S_COLUMN_OLD_GOD_OBELISK_CULTURE',		'Amount',					2);