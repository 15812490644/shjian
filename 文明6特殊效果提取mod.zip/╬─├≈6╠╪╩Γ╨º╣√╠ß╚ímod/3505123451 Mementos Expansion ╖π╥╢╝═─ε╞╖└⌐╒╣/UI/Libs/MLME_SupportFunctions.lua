-- MLME_SupportFunctions
-- Author: Maple_Leaves
-- DateCreated: 5/14/2025 12:27:13 AM
--------------------------------------------------------------

-- ===========================================================================
--FUNCTIONS
-- ===========================================================================

function TableIncludeValue_MLME(ttable, vvalue)
	for k, v in pairs(ttable) do
		if v == vvalue then 
			return true;
		end
	end
	return false;
end

-- ===========================================================================
function FindKeyForCertainValue_MLME(ttable, vvalue)
	for k, v in pairs(ttable) do
		if v == vvalue then 
			return k
		end
	end
end

-- ===========================================================================
function TableIsSame_MLME(ttable, ttable2)
	for k, v in pairs(ttable) do
		if not TableIncludeValue_MLME(ttable2, v) then 
			return false
		end
	end

	for k, v in pairs(ttable2) do
		if not TableIncludeValue_MLME(ttable, v) then 
			return false
		end
	end

	return true
end

