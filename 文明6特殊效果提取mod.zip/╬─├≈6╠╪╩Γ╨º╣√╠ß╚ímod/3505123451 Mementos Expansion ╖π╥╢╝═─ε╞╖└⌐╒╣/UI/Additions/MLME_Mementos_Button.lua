-- MLME_Mementos_Button
-- Author: Maple_Leaves
-- DateCreated: 5/12/2025 10:40:44 PM
--------------------------------------------------------------

local m_LaunchButtonInstance_MLME = {};
local m_buttonActivated = false

-- ===========================================================================
function TogglePopup_MLME()
	print("toggle 1")
	LuaEvents.MLMementosViewer_Button_TogglePopup()
	print("toggle 2")
end
-- ===========================================================================
function AttachLaunchButton_MLMementosViewer()
    local buttonStack = ContextPtr:LookUpControl("/InGame/LaunchBar/ButtonStack");

    ContextPtr:BuildInstanceForControl("MLMementosViewer_Item", m_LaunchButtonInstance_MLME, buttonStack);
    m_LaunchButtonInstance_MLME.MLMementosViewer_Button:RegisterCallback(Mouse.eLClick, TogglePopup_MLME);
    ContextPtr:BuildInstanceForControl("MLMementosViewer_PinInstance", {}, buttonStack);

    -- Resize.
    buttonStack:CalculateSize();

    local backing = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBacking");
    backing:SetSizeX(buttonStack:GetSizeX() + 116);

    local backingTile = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBackingTile");
    backingTile:SetSizeX(buttonStack:GetSizeX() - 20);

    LuaEvents.LaunchBar_Resize(buttonStack:GetSizeX());
end
-- ===========================================================================
function Refresh()
	if m_LaunchButtonInstance_MLME == nil then
		return
	end

	if Players[Game.GetLocalPlayer()]:IsHuman() then
		--���ǲ���ʾ��̾��
		m_LaunchButtonInstance_MLME.MLMementosViewer_AlertIndicator:SetHide(true);
		return;
	end
	m_LaunchButtonInstance_MLME.MLMementosViewer_AlertIndicator:SetHide(true);
end
-- ===========================================================================
function OnLoadGameViewStateDone_MLMementosViewer()
	AttachLaunchButton_MLMementosViewer();
	Refresh()

end
-- ===========================================================================
function Initialize_MLMementosViewer()
	if not m_buttonActivated then
		if Players[Game.GetLocalPlayer()]:IsHuman() then
			Events.LoadGameViewStateDone.Add(OnLoadGameViewStateDone_MLMementosViewer);


			--Events.PlayerTurnActivated.Add(Refresh);
			--Events.ResearchCompleted.Add(Refresh)
			--Events.CivicCompleted.Add(Refresh)
			--Events.InfluenceGiven.Add(Refresh)

			LuaEvents.MLMementosViewer_Panel_Closed.Add(Refresh)

			m_buttonActivated = true
		end
	end
    
end

Initialize_MLMementosViewer();
-- ===========================================================================


-- ===========================================================================
function initialize()	
	print("ML Mementos Viewer Button Initialized!")

end
Events.LoadGameViewStateDone.Add( initialize );