-- MLME_Mementos_Panel
-- Author: Maple_Leaves
-- DateCreated: 5/12/2025 10:41:04 PM
--------------------------------------------------------------


include("InstanceManager");
include("SupportFunctions");	--Round
include("TabSupport");
--include("PopupDialog");
include("ModalScreen_PlayerYieldsHelper");	-- Resizing and top panel vis.
include("CivilizationIcon");
include( "DiplomacyRibbonSupport" ); -- Relationship.IsValidWithHuman

include("MLME_SupportFunctions");

-- ===========================================================================
--CONSTS
-- ===========================================================================
local COLOR_ML_MUSIC_UNREVEAL_BLACK						= UI.GetColorValueFromHexLiteral(0xFF000000);
local COLOR_ML_MUSIC_UNREVEAL_WHITE						= UI.GetColorValueFromHexLiteral(0xFFFFFFFF);

local debug_mode				=	false;

local m_TopPanelHeight		:number			= 0;		-- Used to push vignette below top panel

local m_LocalPlayer							= 	Game.GetLocalPlayer();

--local wtime						=	os.time()

local DATA_FIELD_BELIEF_INDEX	:string		= "DataField_BeliefIndex";
local SIZE_MEMENTO_ICON_64		:number		= 64;
local SIZE_CIV_ICON_64			:number		= 64;
local SIZE_LEADER_ICON_64		:number		= 64;

local m_SpeedMul 				= 	GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;
local m_IsXP1Active:boolean 	=	Modding.IsModActive("1B28771A-C749-434B-9053-D1380C553DE9");
local m_IsXP2Active:boolean 	= 	Modding.IsModActive("4873eb62-8ccc-4574-b784-dda455e74e68");


local player_mementos_change_num_trait_key = "MAPLE_LEAVES_MEMENTOS_CHANGE_NUM_TRAIT_KEY"
local player_mementos_change_num_used_key = "MAPLE_LEAVES_MEMENTOS_CHANGE_NUM_USED_KEY"

local player_mementos_key = "MAPLE_LEAVES_MEMENTOS_KEY"

local player_memento_slot_num_trait_key = "MAPLE_LEAVES_MEMENTO_SLOT_NUM_TRAIT_KEY"

-- ===========================================================================
--VARIABLES
-- ===========================================================================
local panelIsOpen = false
local beforeTab = 0
local currentTab = 0


--����ɸ������������
local change_num_from_debug = 0
--����������λ
local slot_from_debug = 0

--GameEvents = ExposedMembers.GameEvents;



local tab1_button_disabled = false;
local tab1_selected_mementos = {};
local tab1_selected_mementos_temp = {};
local player_memento_slot_num = 1;

local tab_3_selected_inst = nil;
-- ===========================================================================
--INSTANCES
-- ===========================================================================
local m_Tab1MementoIM:table = InstanceManager:new("MementoSlot", "MementoButton", Controls.ML_Mementos_Tab_1_MyMementosStack);
local m_Tab1SelectedMementoIM:table = InstanceManager:new("SelectedMementoSlot", "SelectedMementoButton", Controls.ML_Mementos_Tab_1_SelectedMementosStack);

local m_Tab2PlayerIM:table = InstanceManager:new("PlayerSlot", "PlayerButton", Controls.ML_Mementos_Tab_2_PlayersStack);

local m_Tab3MementoIM:table = InstanceManager:new("Tab3MementoSlot", "Tab3MementoButton", Controls.ML_Mementos_Tab_3_MementoListStack);

local m_tabs				:table;				-- Main tabs

-- ===========================================================================
--TAB 1
-- ===========================================================================

function Refresh_MyMementos()
	--print("001")

	tab1_selected_mementos_temp = {}

	--print("002")

	local localPlayer = Players[Game.GetLocalPlayer()]
	tab1_selected_mementos = localPlayer:GetProperty(player_mementos_key) or {}
	for k, v in pairs(tab1_selected_mementos) do
		if v ~= nil and GameInfo.ML_Mementos_Mode[v] ~= nil then
			table.insert(tab1_selected_mementos_temp, v)
		end
	end

	Populate_MementoList()

	Populate_SelectedMementoList()

	player_memento_slot_num = GetPlayerMementoSlotNum(Game.GetLocalPlayer())
	
	Populate_Tab_1_Labels()

	Initialize_Tab_1_Buttons()

	print("end Refresh_MyMementos")

end

-- ===========================================================================

function GetPlayerMementoSlotNum(playerID)
	local pPlayer = Players[playerID]

	local medieval_num = GameInfo.Eras["ERA_MEDIEVAL"].ChronologyIndex
	local industrial_num = GameInfo.Eras["ERA_INDUSTRIAL"].ChronologyIndex

	local era_index = Game.GetEras():GetCurrentEra()
	local era_num = GameInfo.Eras[era_index].ChronologyIndex

	local slot_from_era = 1
	if era_num >= medieval_num then
		slot_from_era = slot_from_era + 1
	end
	if era_num >= industrial_num then
		slot_from_era = slot_from_era + 1
	end

	local slot_from_trait = pPlayer:GetProperty(player_memento_slot_num_trait_key) or 0

	local slot_total = slot_from_debug + slot_from_era + slot_from_trait

	return slot_total 

end


function Populate_MementoList()
	m_Tab1MementoIM:ResetInstances();

	for row in GameInfo.ML_Mementos_Mode() do 
		if not row.Disabled then
			--print("003")
			local memento_Inst:table = m_Tab1MementoIM:GetInstance();
			Populate_MementoInst_FromDatabase(memento_Inst, row, 1)
		end
	end

	--print("end Populate_MementoList")
end

function Populate_SelectedMementoList()
	m_Tab1SelectedMementoIM:ResetInstances();

	for k, v in ipairs(tab1_selected_mementos_temp) do
		local mementoItem = GameInfo.ML_Mementos_Mode[v]
		if mementoItem ~= nil then
			local memento_Inst:table = m_Tab1SelectedMementoIM:GetInstance();
			Populate_MementoInst_FromDatabase(memento_Inst, mementoItem, 2)
		end
	end

	--print("end Populate_SelectedMementoList")
end

function Populate_MementoInst_FromDatabase(memento_Inst, mementoData, mode)

	--print("004")

	memento_Inst[DATA_FIELD_BELIEF_INDEX] = 0;
	memento_Inst.MementoLabel:LocalizeAndSetText(Locale.ToUpper(mementoData.Name));

	--print("005")

	memento_Inst.MementoDescription:SetText(Locale.Lookup(mementoData.Effect));

	--print("006")

	local primaryColor = UI.GetColorValue("COLOR_WHITE")
	SetMementoIcon(memento_Inst.MementoIconButton, memento_Inst.MementoIcon, 
		primaryColor, 
		mementoData.MementoType, SIZE_MEMENTO_ICON_64
	);

	local tooltip = Locale.Lookup(mementoData.Description)

	if mode == 1 then
		--print("0071")
		memento_Inst.MementoButton:SetToolTipString(tooltip);

		if TableIncludeValue_MLME(tab1_selected_mementos_temp, mementoData.MementoType) then
			memento_Inst.MementoButton:SetSelected(true);
		else
			memento_Inst.MementoButton:SetSelected(false);
		end

		--���
		memento_Inst.MementoButton:RegisterCallback( Mouse.eLClick, 
											function() 
												OnLeftMementoSelected(memento_Inst, mementoData); 
											end 
		);
		--print("0081")
		--�Ҽ��򿪰ٿ�
		memento_Inst.MementoButton:RegisterCallback( Mouse.eRClick, 
											function() 
													LuaEvents.OpenCivilopedia(mementoData.MementoType); 
													UI.PlaySound("Civilopedia_Open");
											end 
		);

		memento_Inst.MementoButton:RegisterCallback( Mouse.eMouseEnter, function() UI.PlaySound("Main_Menu_Mouse_Over"); end );

	else
		--print("0072")
		memento_Inst.SelectedMementoButton:SetToolTipString(tooltip);

		memento_Inst.SelectedMementoButton:SetSelected(false);

		--���
		memento_Inst.SelectedMementoButton:RegisterCallback( Mouse.eLClick, 
											function() 
												OnRightMementoSelected(memento_Inst, mementoData); 
											end 
		);
		--print("0082")
		--�Ҽ��򿪰ٿ�
		memento_Inst.SelectedMementoButton:RegisterCallback( Mouse.eRClick, 
											function() 
													LuaEvents.OpenCivilopedia(mementoData.MementoType); 
													UI.PlaySound("Civilopedia_Open");
											end 
		);

		memento_Inst.SelectedMementoButton:RegisterCallback( Mouse.eMouseEnter, function() UI.PlaySound("Main_Menu_Mouse_Over"); end );

	end

	--print("009")

end

function SetMementoIcon(primaryControl:table, secondaryControl:table, primaryColor, MementoType:string, iconSize:number)
	--local textureOffsetX=0
	--local textureOffsetY=0
	--local textureSheet=""
	local textureOffsetX:number, textureOffsetY:number, textureSheet:string = IconManager:FindIconAtlas("ICON_" .. MementoType, iconSize);

	if(textureSheet == nil or textureSheet == "") then
		print("set icon error for\t", MementoType)
		--print("textureSheet=\t", textureSheet)
	else    
		secondaryControl:SetTexture(textureOffsetX, textureOffsetY, textureSheet);
		secondaryControl:SetSizeVal(iconSize, iconSize); 

	end
	
	--��ɫ
	primaryControl:SetColor( primaryColor );
end


function OnLeftMementoSelected(inst, mementoData)
	
	--���ԭ����δѡ��,��ѱ�ѡ�е����ӵ�list��
	if not TableIncludeValue_MLME(tab1_selected_mementos_temp, mementoData.MementoType) then
		--�ж�һ�¼������λ����
		if #tab1_selected_mementos_temp < player_memento_slot_num then
			table.insert(tab1_selected_mementos_temp, mementoData.MementoType)
			inst.MementoButton:SetSelected(true);
		else
			--�����������ֱ�ӷ���
			return
		end
	else
		--�����ѡ�о�ɾ��
		local remove_key = FindKeyForCertainValue_MLME(tab1_selected_mementos_temp, mementoData.MementoType)
		table.remove(tab1_selected_mementos_temp, remove_key)
		inst.MementoButton:SetSelected(false);
	end

	Populate_SelectedMementoList()
	OnUpdateTab1Buttons()

end

function OnRightMementoSelected(inst, mementoData)
	--��list��ɾ�����Ҹ���
	local remove_key = FindKeyForCertainValue_MLME(tab1_selected_mementos_temp, mementoData.MementoType)
	table.remove(tab1_selected_mementos_temp, remove_key)

	Populate_MementoList()
	Populate_SelectedMementoList()
	OnUpdateTab1Buttons()
end

function OnUpdateTab1Buttons()
	Populate_Tab_1_Labels()

	if tab1_button_disabled then
		Controls.ML_Mementos_Tab_1_Confirm_Button:SetDisabled(true)	
		Controls.ML_Mementos_Tab_1_Cancel_Button:SetDisabled(true)	
		return
	end

	if TableIsSame_MLME(tab1_selected_mementos_temp, tab1_selected_mementos) then
		--����Ϊ����
		Controls.ML_Mementos_Tab_1_Confirm_Button:SetDisabled(true)	
		Controls.ML_Mementos_Tab_1_Cancel_Button:SetDisabled(true)	
		return
	else
		--������ѡ
		Controls.ML_Mementos_Tab_1_Confirm_Button:SetDisabled(false)	
		Controls.ML_Mementos_Tab_1_Cancel_Button:SetDisabled(false)

		Controls.ML_Mementos_Tab_1_Confirm_Button:RegisterCallback( Mouse.eLClick, 
										function() 
												local tParameters:table = {}
												tParameters['OnStart'] 				= 'MLME_ChangeMementos';
												tParameters['Mementos'] 			= tab1_selected_mementos_temp
												UI.RequestPlayerOperation( Game.GetLocalPlayer(), PlayerOperations.EXECUTE_SCRIPT, tParameters)
												Close();
										end 
		);

		Controls.ML_Mementos_Tab_1_Cancel_Button:RegisterCallback( Mouse.eLClick, function() Refresh_MyMementos() end );
		
	end

end

function GetPlayerChangeMementoNum(playerID)
	
	local pPlayer = Players[playerID]

	local era_index = Game.GetEras():GetCurrentEra()
	local era_num = GameInfo.Eras[era_index].ChronologyIndex
	local num_from_era = era_num

	local num_from_trait = pPlayer:GetProperty(player_mementos_change_num_trait_key) or 0

	local num_total = change_num_from_debug + num_from_era + num_from_trait 

	local num_used = pPlayer:GetProperty(player_mementos_change_num_used_key) or 0

	return num_total, num_used
end

function Populate_Tab_1_Labels()
	
	local playerChangeMementoCounts, playerChangeMementoCounts_Used = GetPlayerChangeMementoNum(Game.GetLocalPlayer())

	local left_num = playerChangeMementoCounts - playerChangeMementoCounts_Used
	local tip_text = Locale.Lookup("LOC_UI_ML_MEMENTOS_VIEWER_TAB_1_TIPS_SLOT_NUM_MEMENTO", player_memento_slot_num, #tab1_selected_mementos_temp)
	if left_num <= 0 then
		tip_text = tip_text .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_ML_MEMENTOS_VIEWER_TAB_1_TIPS_CANNOT_CHANGE_MEMENTO")
		tab1_button_disabled = true
	else
		tip_text = tip_text .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_ML_MEMENTOS_VIEWER_TAB_1_TIPS_CAN_CHANGE_MEMENTO", left_num)
		tab1_button_disabled = false
	end

	Controls.ML_Mementos_Tab_1_Tips:SetText( tip_text );

	--print("tab1_button_disabled=\t", tab1_button_disabled)
end

function Initialize_Tab_1_Buttons()
	Controls.ML_Mementos_Tab_1_Confirm_Button:SetDisabled(true)	
	Controls.ML_Mementos_Tab_1_Cancel_Button:SetDisabled(true)	
end

-- ===========================================================================
--TAB 2
-- ===========================================================================

function Refresh_WorldTracker()	 

	Populate_PlayerList()

	print("end Refresh_WorldTracker")
end

function Populate_PlayerList()
	m_Tab2PlayerIM:ResetInstances();
	local localPlayer = Players[Game.GetLocalPlayer()]


	local player_Inst:table = m_Tab2PlayerIM:GetInstance();
	local playerData = {};
	playerData.self = true
	playerData.civType = PlayerConfigurations[Game.GetLocalPlayer()]:GetCivilizationTypeName();
	playerData.leaderType = PlayerConfigurations[Game.GetLocalPlayer()]:GetLeaderTypeName();
	playerData.relationName = ""
	playerData.diploState = ""
	playerData.showRelation = false

	local localplayer_mementos = localPlayer:GetProperty(player_mementos_key) or {}
	playerData.playerMementos = localplayer_mementos

	local m_primaryColor, m_secondaryColor  = UI.GetPlayerColors( Game.GetLocalPlayer() );
	playerData.primaryColor = m_primaryColor
	playerData.secondaryColor = m_secondaryColor
	Populate_PlayerInst(player_Inst, playerData);

	--print("Populate_PlayerList 001")

	for j, iPlayer in ipairs(PlayerManager.GetAliveMajorIDs()) do
		if Game.GetLocalPlayer() ~= iPlayer and localPlayer:GetDiplomacy():HasMet(iPlayer) then

			local player_Inst:table = m_Tab2PlayerIM:GetInstance();
			local playerData = {};
			playerData.self = false

			local kPlayer = Players[iPlayer]
			local civType:string = PlayerConfigurations[iPlayer]:GetCivilizationTypeName();
			local leaderType:string = PlayerConfigurations[iPlayer]:GetLeaderTypeName();

			playerData.civType = civType
			playerData.leaderType = leaderType

			--print("Populate_PlayerList 002")
			--print(Locale.Lookup(leaderType))

			playerData.relationName = ""
			playerData.diploState = 1

			local iPlayerDiploState	:number= kPlayer:GetDiplomaticAI():GetDiplomaticStateIndex(Game.GetLocalPlayer());
			
			--print("iPlayerDiploState=\t", iPlayerDiploState)
							
			local kRelationship		:table = GameInfo.DiplomaticStates[iPlayerDiploState];
			local isRelationHidden	:boolean = true;
			-- If a state other than neutral exsits, then look up the corresponding 
			-- relationship rules for AI or human, based on the players.
			if (kRelationship.Hash ~= DiplomaticStates.NEUTRAL) then
				local isHuman		:boolean= not (kPlayer:IsAI() or localPlayer:IsAI());
				local relationType	:string = kRelationship.StateType;
				local isValid		:boolean= (isHuman and Relationship.IsValidWithHuman( relationType )) or (not isHuman and Relationship.IsValidWithAI( relationType ));
				if isValid then
					playerData.relationName = kRelationship.Name
					playerData.diploState = iPlayerDiploState
					isRelationHidden = false;
				end
			end

			playerData.showRelation = not isRelationHidden

			--print("Populate_PlayerList 003")

			local player_mementos = kPlayer:GetProperty(player_mementos_key) or {}
			playerData.playerMementos = player_mementos

			local m_primaryColor, m_secondaryColor  = UI.GetPlayerColors( iPlayer );
			playerData.primaryColor = m_primaryColor
			playerData.secondaryColor = m_secondaryColor

			--print("Populate_PlayerList 004")
			Populate_PlayerInst(player_Inst, playerData);
		end
	end

	--print("end Populate_PlayerList")
end

function Populate_PlayerInst(player_Inst, playerData)

	player_Inst[DATA_FIELD_BELIEF_INDEX] = 0;
	--player_Inst.MementoLabel:LocalizeAndSetText(Locale.ToUpper(mementoData.Name));

	--print("005")

	--memento_Inst.MementoDescription:SetText(Locale.Lookup(mementoData.Effect));

	--print("006")

	--��������ͼ��
	SetCivIcon(	player_Inst.CivIconButton, player_Inst.CivIcon, 
		playerData.primaryColor, playerData.secondaryColor, 
		playerData.civType, SIZE_CIV_ICON_64
	)
	SetLeaderIcon(	player_Inst.LeaderIconButton, player_Inst.LeaderIcon, 
		playerData.leaderType, SIZE_CIV_ICON_64
	)

	--print("Populate_PlayerList 005")

	--������ͼ��
	if #playerData.playerMementos > 0 then
		player_Inst.MementoIconButton:SetHide(false)
		local memento_1 = playerData.playerMementos[1]
		local memento_1_Item = GameInfo.ML_Mementos_Mode[memento_1]

		local m_primaryColor = UI.GetColorValue("COLOR_WHITE")
		SetMementoIcon(player_Inst.MementoIconButton, player_Inst.MementoIcon, 
			m_primaryColor, memento_1_Item.MementoType, SIZE_MEMENTO_ICON_64
		);
		local mementoName = Locale.Lookup(Locale.ToUpper(memento_1_Item.Name));
		local mementoEffect = "[ICON_Bullet]"..Locale.Lookup(memento_1_Item.Effect);
		local tooltip = Locale.Lookup(memento_1_Item.Description)
		player_Inst.MementoIconButton:SetToolTipString(tooltip);

		if #playerData.playerMementos > 1 then
			player_Inst.MementoIconButton2:SetHide(false)
			local memento_2 = playerData.playerMementos[2]
			local memento_2_Item = GameInfo.ML_Mementos_Mode[memento_2]
			SetMementoIcon(player_Inst.MementoIconButton2, player_Inst.MementoIcon2, 
				m_primaryColor, memento_2_Item.MementoType, SIZE_MEMENTO_ICON_64
			);

			mementoName = mementoName .. "//" .. Locale.Lookup(Locale.ToUpper(memento_2_Item.Name))
			mementoEffect = mementoEffect .. "[NEWLINE][ICON_Bullet]".. Locale.Lookup(memento_2_Item.Effect);
			local tooltip_2 = Locale.Lookup(memento_2_Item.Description)
			player_Inst.MementoIconButton2:SetToolTipString(tooltip_2);

			if #playerData.playerMementos > 2 then
				player_Inst.MementoIconButton3:SetHide(false)
				local memento_3 = playerData.playerMementos[3]
				local memento_3_Item = GameInfo.ML_Mementos_Mode[memento_3]
				SetMementoIcon(player_Inst.MementoIconButton3, player_Inst.MementoIcon3, 
					m_primaryColor, memento_3_Item.MementoType, SIZE_MEMENTO_ICON_64
				);

				mementoName = mementoName .. "//" .. Locale.Lookup(Locale.ToUpper(memento_3_Item.Name))
				mementoEffect = mementoEffect .. "[NEWLINE][ICON_Bullet]".. Locale.Lookup(memento_3_Item.Effect);
				local tooltip_3 = Locale.Lookup(memento_3_Item.Description)
				player_Inst.MementoIconButton3:SetToolTipString(tooltip_3);

			else
				player_Inst.MementoIconButton3:SetHide(true)
			end

		else
			player_Inst.MementoIconButton2:SetHide(true)
			player_Inst.MementoIconButton3:SetHide(true)
		end

		player_Inst.MementoDescription:SetText(mementoEffect)
		player_Inst.MementoLabel:SetText(mementoName)

	else
		player_Inst.MementoIconButton:SetHide(true)
		player_Inst.MementoIconButton2:SetHide(true)
		player_Inst.MementoIconButton3:SetHide(true)

		player_Inst.MementoDescription:SetHide(true)
		player_Inst.MementoLabel:SetText(Locale.Lookup("LOC_UI_ML_MEMENTOS_VIEWER_TAB_2_NO_MEMENTOS"))
	end

	--print("Populate_PlayerList 006")

	--�⽻״̬
	if playerData.self then
		player_Inst.Status:SetHide(true)
	else
		if playerData.showRelation then
			player_Inst.Status:SetHide(false)

			player_Inst.Status:SetToolTipString( Locale.Lookup(playerData.relationName) );
			player_Inst.Status:SetVisState( playerData.diploState );

		else
			player_Inst.Status:SetHide(true)
		end
	end
	
	--print("Populate_PlayerList 007")

end

function SetCivIcon(primaryControl:table, secondaryControl:table, primaryColor, secondaryColor, CivType:string, iconSize:number)

	local textureOffsetX:number, textureOffsetY:number, textureSheet:string = IconManager:FindIconAtlas("ICON_" .. CivType, iconSize);

	if(textureSheet == nil or textureSheet == "") then
		print("set icon error for\t", CivType)
	else    
		secondaryControl:SetTexture(textureOffsetX, textureOffsetY, textureSheet);
		secondaryControl:SetSizeVal(iconSize, iconSize); 
		secondaryControl:SetColor( secondaryColor );
	end

	primaryControl:SetColor( primaryColor );
end

function SetLeaderIcon(primaryControl:table, secondaryControl:table, LeaderType:string, iconSize:number)
	local textureOffsetX:number, textureOffsetY:number, textureSheet:string = IconManager:FindIconAtlas("ICON_" .. LeaderType, iconSize);

	if(textureSheet == nil or textureSheet == "") then
		print("set icon error for\t", LeaderType)
	else    
		secondaryControl:SetTexture(textureOffsetX, textureOffsetY, textureSheet);
		secondaryControl:SetSizeVal(iconSize, iconSize); 
	end

end

-- ===========================================================================
--TAB 3
-- ===========================================================================

function Refresh_MementoLists()	
	
	Populate_Tab3_MementoList()

	InitializeTab3Labels()

	print("end Refresh_MementoLists")


end

function Populate_Tab3_MementoList()
	m_Tab3MementoIM:ResetInstances();

	for row in GameInfo.ML_Mementos_Mode() do 
		if not row.Disabled then
			--print("003")
			local memento_Inst:table = m_Tab3MementoIM:GetInstance();
			Populate_Tab3_MementoInst_FromDatabase(memento_Inst, row)
		end
	end

	--print("end Populate_Tab3_MementoList")
end

function Populate_Tab3_MementoInst_FromDatabase(memento_Inst, mementoData)

	--print("004")

	memento_Inst[DATA_FIELD_BELIEF_INDEX] = 0;
	memento_Inst.MementoLabel:LocalizeAndSetText(Locale.ToUpper(mementoData.Name));

	memento_Inst.MementoDescription:SetText(Locale.Lookup(mementoData.Effect));

	local associated_leaders = {}

	for row in GameInfo.ML_LeaderMementos_Mode() do	
		if row.MementoType == mementoData.MementoType then
			table.insert(associated_leaders, row.LeaderType)
		end
	end

	--print("006")

	--������ͼ��
	local primaryColor = UI.GetColorValue("COLOR_WHITE")
	SetMementoIcon(memento_Inst.MementoIconButton, memento_Inst.MementoIcon, 
		primaryColor, 
		mementoData.MementoType, SIZE_MEMENTO_ICON_64
	);

	--����ͼ��
	if #associated_leaders > 0 then
		memento_Inst.LeaderIconButton:SetHide(false)
		SetLeaderIcon(	memento_Inst.LeaderIconButton, memento_Inst.LeaderIcon, 
			associated_leaders[1], SIZE_CIV_ICON_64
		)
	else
		memento_Inst.LeaderIconButton:SetHide(true)
	end

	local tooltip = Locale.Lookup(mementoData.Description)

	--print("0071")
	memento_Inst.Tab3MementoButton:SetToolTipString(tooltip);

	--���
	memento_Inst.Tab3MementoButton:RegisterCallback( Mouse.eLClick, 
										function() 
											OnTab3MementoSelected(memento_Inst, mementoData, associated_leaders); 
										end 
	);
	--print("0081")
	--�Ҽ��򿪰ٿ�
	memento_Inst.Tab3MementoButton:RegisterCallback( Mouse.eRClick, 
										function() 
												LuaEvents.OpenCivilopedia(mementoData.MementoType); 
												UI.PlaySound("Civilopedia_Open");
										end 
	);

	memento_Inst.Tab3MementoButton:RegisterCallback( Mouse.eMouseEnter, function() UI.PlaySound("Main_Menu_Mouse_Over"); end );

	--print("009")

end

function OnTab3MementoSelected(inst, mementoData, leaders)
	
	-- Ignore select if this belief is already selected
	if tab_3_selected_inst == inst then
		return;
	end

	-- Unselect the previous selection
	if tab_3_selected_inst ~= nil then
		tab_3_selected_inst.Tab3MementoButton:SetSelected(false);
	end

	-- Select new instance
	tab_3_selected_inst = inst
	tab_3_selected_inst.Tab3MementoButton:SetSelected(true);	

	OnUpdateTab3Labels(mementoData, leaders)

end


function InitializeTab3Labels()
	Controls.ML_Mementos_Tab_3_MementoName_Label:LocalizeAndSetText("LOC_UI_ML_MEMENTOS_VIEWER_TAB_3_MEMENTO_NAME")

	Controls.ML_Mementos_Tab_3_MementoLeader_Label:LocalizeAndSetText("LOC_UI_ML_MEMENTOS_VIEWER_TAB_3_MEMENTO_LEADER")
	Controls.ML_Mementos_Tab_3_MementoLeader_Label:SetHide(true)

	Controls.ML_Mementos_Tab_3_MementoEffect_Label:LocalizeAndSetText("LOC_UI_ML_MEMENTOS_VIEWER_TAB_3_MEMENTO_EFFECT")

	Controls.ML_Mementos_Tab_3_MementoHistoricalBG_Label:LocalizeAndSetText("LOC_UI_ML_MEMENTOS_VIEWER_TAB_3_MEMENTO_HISTORICAL_BACKGROUND")
	Controls.ML_Mementos_Tab_3_MementoHistoricalBG_Label:SetHide(true)
end

function OnUpdateTab3Labels(mementoData, leaders)
	
	--����������
	Controls.ML_Mementos_Tab_3_MementoName_Label:LocalizeAndSetText(Locale.ToUpper(mementoData.Name))

	--��������
	local leader_text = Locale.Lookup("LOC_UI_ML_MEMENTOS_VIEWER_TAB_3_MEMENTO_ASSOCIATED_LEADER")

	for k, v in ipairs(leaders) do
		local leader_name = Locale.Lookup(GameInfo.Leaders[v].Name)
		leader_text = leader_text.."[NEWLINE][ICON_Bullet]"..leader_name
	end

	if #leaders > 0 then
		Controls.ML_Mementos_Tab_3_MementoLeader_Label:SetText(leader_text)
	else
		leader_text = leader_text .. Locale.Lookup("LOC_UI_ML_MEMENTOS_VIEWER_TAB_3_MEMENTO_ASSOCIATED_LEADER_NONE")
		Controls.ML_Mementos_Tab_3_MementoLeader_Label:LocalizeAndSetText(Locale.ToUpper(mementoData.Name))
	end
	Controls.ML_Mementos_Tab_3_MementoLeader_Label:SetHide(false)

	--������Ч��
	Controls.ML_Mementos_Tab_3_MementoEffect_Label:SetText(Locale.Lookup(mementoData.Effect))

	--��������ʷ����
	local memento_desc = Locale.Lookup(mementoData.Description)
	local desc_and_history = Locale.Lookup("LOC_UI_ML_MEMENTOS_VIEWER_TAB_3_MEMENTO_BRIEF_INTRO").."[NEWLINE]"..memento_desc

	for i = 1, 5 ,1 do
		local para_i_str = "LOC_PEDIA_CIVILIZATIONS_PAGE_" .. mementoData.MementoType .. "_CHAPTER_HISTORY_PARA_"..tostring(i)

		local loc_para_i_str = Locale.Lookup(para_i_str)
		if loc_para_i_str ~= nil and loc_para_i_str ~= para_i_str then
			if i == 1 then
				desc_and_history = desc_and_history .. "[NEWLINE]---------------------[NEWLINE]"..Locale.Lookup("LOC_UI_ML_MEMENTOS_VIEWER_TAB_3_MEMENTO_HISTORICAL_BACKGROUND")
			end
			desc_and_history = desc_and_history .."[NEWLINE][ICON_Bullet]" .. loc_para_i_str
		end
	end

	Controls.ML_Mementos_Tab_3_MementoHistoricalBG_Label:SetHide(false)
	Controls.ML_Mementos_Tab_3_MementoHistoricalBG_Label:SetText(desc_and_history)
end

-- ===========================================================================

-- ===========================================================================
function RealizeTabs( selectedTabName:string )
	
	m_currentTabName = selectedTabName;

	local kTabNames:table = {"MyMementos","CO2Levels","EventHistory" }

	Controls.Selected_MyMementos:SetHide( selectedTabName ~= "MyMementos" );
	Controls.Button_MyMementos:SetSelected( selectedTabName == "MyMementos" );
	Controls.MyMementos_Panel:SetHide( selectedTabName ~= "MyMementos" );

	Controls.Selected_WorldTracker:SetHide( selectedTabName ~= "WorldTracker"  );
	Controls.Button_WorldTracker:SetSelected( selectedTabName == "WorldTracker"   );
	Controls.WorldTracker_Panel:SetHide( selectedTabName ~= "WorldTracker" );

	Controls.Selected_MementoList:SetHide( selectedTabName ~= "MementoList"  );
	Controls.Button_MementoList:SetSelected( selectedTabName == "MementoList"   );	
	Controls.MementoList_Panel:SetHide( selectedTabName ~= "MementoList" );

end
-- ===========================================================================
function SetShow_TopPanel()
	if not RefreshYields() then
		Controls.Vignette:SetSizeY(m_TopPanelHeight);
	end
end

-- ===========================================================================
function TabSelect_MyMementos()
	RealizeTabs("MyMementos");
	--print("000")

	beforeTab = currentTab
	currentTab = 1

	Refresh_MyMementos();

	SetShow_TopPanel()
end

-- ===========================================================================
function TabSelect_WorldTracker()
	RealizeTabs("WorldTracker");

	beforeTab = currentTab
	currentTab = 2

	Refresh_WorldTracker();

	SetShow_TopPanel()

end

-- ===========================================================================
function TabSelect_MementoList()
	RealizeTabs("MementoList");

	beforeTab = currentTab
	currentTab = 3

	Refresh_MementoLists()	

	SetShow_TopPanel()
end

-- ===========================================================================
function RefreshTime()
	if currentTab ~= 1 then
		return
	end

	local format = UserConfiguration.GetClockFormat();
	
	local strTime;
	
	if(format == 1) then
		strTime = os.date("%H:%M");
	else
		strTime = os.date("%I:%M %p");

		-- Remove the leading zero (if any) from 12-hour clock format
		if(string.sub(strTime, 1, 1) == "0") then
			strTime = string.sub(strTime, 2);
		end
	end

	Controls.ML_Mementos_Time:SetText( strTime );
	local d = Locale.Lookup("{1_Time : datetime full}", os.time());
	Controls.ML_Mementos_Time:SetToolTipString(d);
end

function On_RefreshTimeTick_Timer()
	RefreshTime();
	Controls.ML_Mementos_TimeCallback:SetToBeginning();
	Controls.ML_Mementos_TimeCallback:Play();

end

-- ===========================================================================

-- ===========================================================================
function LateInitialize()
	Controls.ML_Mementos_TimeCallback:RegisterEndCallback( On_RefreshTimeTick_Timer );

	m_tabs = CreateTabs( Controls.ML_Mementos_TabContainer, 42, 34, UI.GetColorValueFromHexLiteral(0xFF331D05) );
	m_tabs.AddTab( Controls.Button_MyMementos,				TabSelect_MyMementos );
	m_tabs.AddTab( Controls.Button_WorldTracker,			TabSelect_WorldTracker );
	m_tabs.AddTab( Controls.Button_MementoList,				TabSelect_MementoList );
	m_tabs.CenterAlignTabs(-10);	

end

-- ===========================================================================
function OnInit( isReload:boolean )
	if isReload then
        local takeplace = 0
    end
	LateInitialize();
end

function OnShutdown()
	local takeplace = 0
end

function OnInputHandler(pInputStruct:table)
	local uiMsg = pInputStruct:GetMessageType();
	if uiMsg == KeyEvents.KeyUp and pInputStruct:GetKey() == Keys.VK_ESCAPE then
		if not ContextPtr:IsHidden() then
			Close();
		end
		return true;
	end
	return false;
end

-- ===========================================================================
function OnTogglePanel()
	if ContextPtr:IsHidden() then
		--���Ǵ򿪵�һҳ
		Open("MyMementos")
		panelIsOpen = true
	else
		Close()
		panelIsOpen = false
	end
end

function Open(selectedTabName:string)
	local localplayer = Game.GetLocalPlayer()
	local pPlayer = Players[localplayer]
	if pPlayer == nil then
		return
	end
	CloseOtherPanels()


	if selectedTabName=="MyMementos" or selectedTabName == nil then 
		m_tabs.SelectTab( Controls.Button_MyMementos ); 
	end
	if selectedTabName=="WorldTracker" then 
		m_tabs.SelectTab( Controls.Button_WorldTracker ); 
	end
	if selectedTabName=="MementoList" then
		m_tabs.SelectTab( Controls.Button_MementoList ); 
	end

	--ContextPtr:SetHide(false);
	
	if not UIManager:IsInPopupQueue(ContextPtr) then
		-- Queue the screen as a popup, but we want it to render at a desired location in the hierarchy, not on top of everything.
        local kParameters = {};
        kParameters.RenderAtCurrentParent = true;
        kParameters.InputAtCurrentParent = true;
        kParameters.AlwaysVisibleInQueue = true;
        UIManager:QueuePopup(ContextPtr, PopupPriority.Low, kParameters);
        UI.PlaySound("UI_Screen_Open");
    end

	Controls.ScreenAnimIn:SetToBeginning();
	Controls.ScreenAnimIn:Play();

	LuaEvents.MLMusicPlayer_OpenPanel();	

	--LuaEvents.TradeRouteChooser_CloseIfPopups();
	--LuaEvents.LaunchBar_CloseChoosers();
end

function Close()
	--Refresh_WorldTracker();

	if not ContextPtr:IsHidden() then
		UI.PlaySound("UI_Screen_Close");

		--m_Music_IM:DestroyInstances()
		--m_Tab1_MyMementosMusic_IM:DestroyInstances()
		--m_PlayList_IM:DestroyInstances()
		--m_PlayListMusic_IM:DestroyInstances()
	end
		
	UIManager:DequeuePopup(ContextPtr);

	currentTab = 0

	LuaEvents.MLMusicPlayer_ClosePanel(); -- Tell other UI's (e.g., LaunchBar) this is closed
	
end

function CloseOtherPanels()
    LuaEvents.LaunchBar_CloseTechTree()
    LuaEvents.LaunchBar_CloseCivicsTree()
    LuaEvents.LaunchBar_CloseGovernmentPanel()
    LuaEvents.LaunchBar_CloseReligionPanel()
    LuaEvents.LaunchBar_CloseGreatPeoplePopup()
    LuaEvents.LaunchBar_CloseGreatWorksOverview()
    if m_IsXP1Active then
        LuaEvents.GovernorPanel_Close()
        LuaEvents.HistoricMoments_Close()
    end
    if m_IsXP2Active then
        LuaEvents.Launchbar_Expansion2_ClimateScreen_Close()
    end
end

-- ===========================================================================
function On_ML_Mementos_Debug()

end

-- ===========================================================================
function Initialize()
	
	-- UI Events
	ContextPtr:SetHide(true);
	ContextPtr:SetInitHandler( OnInit );
	ContextPtr:SetShutdown( OnShutdown );
	ContextPtr:SetInputHandler( OnInputHandler, true );

	Controls.ML_Mementos_CloseButton:RegisterCallback(Mouse.eLClick, Close)
	--Controls.ConfirmSelected:RegisterCallback(Mouse.eLClick, OnConfirmSelected)
	--if debug then
		--Controls.ML_Mementos_Debug:RegisterCallback(Mouse.eLClick, On_ML_Mementos_Debug)
	--else
		--Controls.ML_Mementos_Debug:SetHide(true)
	--end
	
	--Events.TurnBegin.Add(Close)
	LuaEvents.MLMementosViewer_Button_TogglePopup.Add(OnTogglePanel);
	
	LuaEvents.DiplomacyActionView_HideIngameUI.Add(Close)
    LuaEvents.EndGameMenu_Shown.Add(Close)
    LuaEvents.FullscreenMap_Shown.Add(Close)
    LuaEvents.NaturalWonderPopup_Shown.Add(Close)
    LuaEvents.ProjectBuiltPopup_Shown.Add(Close)
    LuaEvents.Tutorial_ToggleInGameOptionsMenu.Add(Close)
    LuaEvents.WonderBuiltPopup_Shown.Add(Close)
    LuaEvents.NaturalDisasterPopup_Shown.Add(Close)  
    LuaEvents.RockBandMoviePopup_Shown.Add(Close)
	LuaEvents.CivicsTree_OpenCivicsTree.Add(Close);	
	LuaEvents.Government_OpenGovernment.Add(Close);
	LuaEvents.GovernorPanel_Opened.Add(Close);	
	LuaEvents.GreatPeople_OpenGreatPeople.Add(Close);
	LuaEvents.GreatWorks_OpenGreatWorks.Add(Close);
	LuaEvents.HistoricMoments_Opened.Add(Close);
	LuaEvents.Religion_OpenReligion.Add(Close);	
	LuaEvents.PantheonChooser_OpenReligion.Add(Close);	
	LuaEvents.TechTree_OpenTechTree.Add(Close);
	LuaEvents.ClimateScreen_Opened.Add(Close);


	m_TopPanelHeight = Controls.Vignette:GetSizeY() - TOP_PANEL_OFFSET;
	

	print("ML Mementos Ready!")
end

--No capability means never initialize this so it can never be used.
if GameCapabilities.HasCapability("CAPABILITY_ML_MEMENTOS") then
	Initialize();
end


