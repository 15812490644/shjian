-- MLME_GameplayScript
-- Author: Maple_Leaves
-- DateCreated: 5/12/2025 10:23:39 PM
--------------------------------------------------------------

-- ===========================================================================
--	INCLUDE
-- ===========================================================================
include("MLME_SupportFunctions");

-- ===========================================================================
--	CONST
-- ===========================================================================
local player_mementos_key = "MAPLE_LEAVES_MEMENTOS_KEY"

local player_mementos_change_num_used_key = "MAPLE_LEAVES_MEMENTOS_CHANGE_NUM_USED_KEY"

--========================================================================================================================
-- FUNC
--========================================================================================================================
	function MLME_SetPlotProperty(iPlayer, kParam)
		local pPlayer = Players[iPlayer]

		local pPlot = Map.GetPlot( kParam.PlotX, kParam.PlotY );

		pPlot:SetProperty(kParam.Key, kParam.Value)
		pPlot:SetProperty(kParam.Key2, kParam.Value2)

		if kParam.Key3 ~= nil and kParam.Key3 ~= "" then
			pPlot:SetProperty(kParam.Key3, kParam.Value3)
		end

		pPlot:SetProperty(kParam.Key4, kParam.Value4)

		print("MLME_SetPlotProperty success!")

	end

--========================================================================================================================
	function MLME_ChangeMementos(iPlayer, kParam)
		print("into MLME_ChangeMementos")
		local pPlayer = Players[iPlayer]

		local target_memento_list = kParam.Mementos

		local pCapital = pPlayer:GetCities():GetCapitalCity()
		if pCapital == nil then
			--print("Error: player have no capital!")
			return
		end

		local pPlayerConfig	:table	= PlayerConfigurations[iPlayer];
		local civType:string = pPlayerConfig:GetCivilizationTypeName();
		local leaderType:string = pPlayerConfig:GetLeaderTypeName();

		local cCityBuildings = pCapital:GetBuildings();
		if cCityBuildings == nil then
			print("Error: cCityBuildings is nil!")
			return
		end

		for row in GameInfo.ML_Mementos_Mode() do
			local memento = row.MementoType
			local buildingType = "BUILDING_"..memento.."_MLME"
			local buildingItem = GameInfo.Buildings[buildingType]
			if buildingItem ~= nil then
				if TableIncludeValue_MLME(target_memento_list, memento) then
					--����ڱ��У�������
					if not cCityBuildings:HasBuilding( buildingItem.Index ) then
						--����
						pCapital:GetBuildQueue():CreateBuilding(buildingItem.Index)
						print("give building ".. buildingType .. " to " .. leaderType)
					else
						--������Ӷ���
						if cCityBuildings:IsPillaged(buildingItem.BuildingType) then
							--���Ƴ���������
							pCapital:GetBuildings():RemoveBuilding(buildingItem.Index)
							pCapital:GetBuildQueue():CreateBuilding(buildingItem.Index)
							print("give building ".. buildingType .. " to " .. leaderType)
						end
					end
				else
					--������ڱ��У����Ƴ�
					if cCityBuildings:HasBuilding( buildingItem.Index ) then
						pCapital:GetBuildings():RemoveBuilding(buildingItem.Index)
						print("remove invalid building ".. buildingType .. " for " .. leaderType)
					end
				end

			end
		end

		pPlayer:SetProperty(player_mementos_key, target_memento_list)

		--�Ѿ�ʹ�õĴ���
		local num_used = pPlayer:GetProperty(player_mementos_change_num_used_key) or 0
		num_used = num_used + 1
		pPlayer:SetProperty(player_mementos_change_num_used_key, num_used)

		print("end MLME_ChangeMementos")
	end

--========================================================================================================================
function findAssociatedMementosForLeader(leader)
	local associated_memento_list = {}
	for row in GameInfo.ML_LeaderMementos_Mode() do	
		if row.LeaderType == leader then
			local MementoItem = GameInfo.ML_Mementos_Mode[row.MementoType]
			if MementoItem ~= nil and (not MementoItem.Disabled) then
			
				table.insert(associated_memento_list, row.MementoType)
			end
		end
	end

	return associated_memento_list
end

--========================================================================================================================
--���н���ʱˢ�¼�������AI�����඼��Ч
--function OnCityBuilt_MLME_Gameplay( playerID: number, cityID : number, iX : number, iY : number )
--end

--function OnCapitalCityChanged_MLME_Gameplay( playerID: number, cityID : number )
--end

function OnCityAddedToMap_MLME_Gameplay( playerID: number, cityID : number, iX : number, iY : number )
	--print("into OnCityAddedToMap_MLME_Gameplay")

	--print("playerID=\t", playerID)
	--print("cityID=\t", cityID)

	--ɨһ��������ҵ��׶�������׶�û�м����ｨ��������

	for j, iPlayer in ipairs(PlayerManager.GetAliveMajorIDs()) do
		--print("dealing with player ".. tostring(iPlayer))
		addMementosForPlayer(iPlayer)
	end

	--Ȼ��ɨһ�鵱ǰ���У��Ѳ�Ӧ��ӵ�е�����������ɾ�������Ӧ���������е�����

	--����Ĵ����ǰ�д�ˣ�Ŀǰ����֪������Ϊû��PrereqDistrict����ObsoleteEra��Զ��ʱ�������ã��³���Ȼ���ᱣ���������Ӧ�����⽨����������
	
	local pCity = CityManager.GetCity(playerID, cityID);
	if pCity == nil then
		return
	end

	local pPlayer = Players[playerID];
	if pPlayer == nil then
		return
	end

	local pPlayerConfig	:table	= PlayerConfigurations[playerID];
	local civType:string = pPlayerConfig:GetCivilizationTypeName();
	local leaderType:string = pPlayerConfig:GetLeaderTypeName();

	local applied_memento_list = pPlayer:GetProperty(player_mementos_key) or {}

	for row in GameInfo.ML_Mementos_Mode() do
		--�����ǷǷ���
		if not TableIncludeValue_MLME(applied_memento_list, row.MementoType) then
			local buildingType = "BUILDING_".. row.MementoType .. "_MLME"
			local buildingItem = GameInfo.Buildings[buildingType]
			if buildingItem ~= nil then
				if pCity:GetBuildings():HasBuilding( buildingItem.Index ) then
					--�Ƴ�
					pCity:GetBuildings():RemoveBuilding( buildingItem.Index )

					print("remove invalid building ".. buildingType .. " for " .. leaderType)
				end
			end
		end
	end

	--print("end OnCityAddedToMap_MLME_Gameplay")
end

--ʵ��Ϊĳ��������Ӽ�����
function addMementosForPlayer(playerID)
	local pPlayer = Players[playerID];
	if pPlayer == nil then
		return
	end

	--�֣��ڽ�����һ�����е� GameEvents.CityBuilt �¼����޷���� pPlayer:GetCities():GetCapitalCity
	local pCapital = pPlayer:GetCities():GetCapitalCity()
	if pCapital == nil then
		--print("Error: player have no capital!")
		return
	end

	local pPlayerConfig	:table	= PlayerConfigurations[playerID];
	local civType:string = pPlayerConfig:GetCivilizationTypeName();
	local leaderType:string = pPlayerConfig:GetLeaderTypeName();
	
	local applied_memento_list = pPlayer:GetProperty(player_mementos_key) or {}

	if #applied_memento_list == 0 then
		return
	end

	local cCityBuildings = pCapital:GetBuildings();
	if cCityBuildings == nil then
		print("Error: cCityBuildings is nil!")
		return
	end

	for k, memento in ipairs(applied_memento_list) do
		local buildingType = "BUILDING_"..memento.."_MLME"
		local buildingItem = GameInfo.Buildings[buildingType]
		if buildingItem ~= nil then
			
			if not cCityBuildings:HasBuilding( buildingItem.Index ) then
				--����
				pCapital:GetBuildQueue():CreateBuilding(buildingItem.Index)
				print("give building ".. buildingType .. " to " .. leaderType)
			else
				if cCityBuildings:IsPillaged(buildingItem.BuildingType) then
					--���Ƴ���������
					pCapital:GetBuildings():RemoveBuilding(buildingItem.Index)
					pCapital:GetBuildQueue():CreateBuilding(buildingItem.Index)
					print("give building ".. buildingType .. " to " .. leaderType)
				end
			end

		end
	end

end

--========================================================================================================================
-- Register
--========================================================================================================================
function Initialize()
	print("000")

	--local ruleset =	GameConfiguration.GetValue("RULESET")
	--print("ruleset=\t", ruleset)
--
	--local chosen_memento =	GameConfiguration.GetValue("CONFIG_ML_MEMENTOS")
	--print("chosen_memento=\t", chosen_memento)
	--
	--print("001")

	--Operations
	GameEvents.MLME_SetPlotProperty.Add(			MLME_SetPlotProperty			);

	GameEvents.MLME_ChangeMementos.Add(			MLME_ChangeMementos			);


	--ExposedMembers

	--ExposedMembers.MLME_EM = ExposedMembers.MLME_EM or {};
	--ExposedMembers.MLME_EM.MLME_SetPlotProperty_AI = MLME_SetPlotProperty_AI;
--
--
	--Events.ImprovementAddedToMap.Add(		OnImprovementAddedToMap_MLME_Gameplay			);
--
	--Events.ImprovementRemovedFromMap.Add(	OnImprovementRemovedFromMap_MLME_Gameplay		);
--
--
	--GameEvents.OnGameTurnStarted.Add(		OnGameTurnStarted_MLME_Gameplay					);
--
	--GameEvents.CityBuilt.Add( OnCityBuilt_MLME_Gameplay );

	--Events.CapitalCityChanged.Add( OnCapitalCityChanged_MLME_Gameplay );

	Events.CityAddedToMap.Add( OnCityAddedToMap_MLME_Gameplay );
end

Events.LoadGameViewStateDone.Add(Initialize);

function InitializeNewGame()
	--��ʼ�����������ֻ��ʼ��property

	--print("into InitializeNewGame")

	for i, iPlayer in ipairs(PlayerManager.GetWasEverAliveMajorIDs()) do
		local tPlayer = Players[iPlayer]

		if tPlayer:IsHuman() then
			if iPlayer == 0 then
				--Ϊ��������������ü�����
				local chosen_memento =	GameConfiguration.GetValue("CONFIG_ML_MEMENTOS") 
				local memento_list = {}

				if chosen_memento ~= nil and chosen_memento ~= "MEMENTO_EMPTY" then 
					memento_list = {chosen_memento}
				end
				tPlayer:SetProperty(player_mementos_key, memento_list)

				print("initialize mementos for human player 0")

			end
		else
			--ΪAI������ü�����
			local tPlayerConfig	:table	= PlayerConfigurations[iPlayer];
			local civType:string = tPlayerConfig:GetCivilizationTypeName();
			local leaderType:string = tPlayerConfig:GetLeaderTypeName();

			local memento_list = findAssociatedMementosForLeader(leaderType)
			if #memento_list > 0 then
			--�������óɵ�һ��������
				tPlayer:SetProperty(player_mementos_key, { memento_list[1] })
				print("initialize mementos for ai player " .. tostring(iPlayer) )
			end

		end

	end

	--print("end InitializeNewGame")
end

LuaEvents.NewGameInitialized.Add(InitializeNewGame);
print("MLME Gameplay Initialized!")