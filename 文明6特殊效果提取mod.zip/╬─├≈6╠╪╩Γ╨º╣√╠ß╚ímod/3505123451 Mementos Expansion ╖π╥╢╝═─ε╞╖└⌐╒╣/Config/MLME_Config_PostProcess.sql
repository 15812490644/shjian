-- MLME_Config_PostProcess
-- Author: Maple_Leaves
-- DateCreated: 4/25/2025 10:03:58 PM
--------------------------------------------------------------

--GameModePlayerItemOverrides
 
--1
INSERT OR REPLACE INTO GameModePlayerItemOverrides 
	(GameModeType,			Domain,							CivilizationType,																							LeaderType,	Type,			Icon,							Name,																	Description,															SortIndex)
SELECT	
	'GAMEMODE_ML_MEMENTOS',	'Players:Expansion2_Players',	(SELECT CivilizationType FROM Players WHERE LeaderType = Leader AND Domain='Players:Expansion2_Players'),	Leader,		'ML_MEMENTOS',	'ICON_'||Memento,				(SELECT MName FROM ML_Mementos_Config WHERE MementoType = Memento),		(SELECT MTooltip FROM ML_Mementos_Config WHERE MementoType = Memento),	151
FROM ML_LeaderMementos_Config WHERE Leader IN (SELECT LeaderType FROM Players WHERE Domain='Players:Expansion2_Players');

--2
INSERT OR REPLACE INTO GameModePlayerItemOverrides 
	(GameModeType,			Domain,							CivilizationType,																							LeaderType,	Type,				Icon,							Name,																	Description,															SortIndex)
SELECT	
	'GAMEMODE_ML_MEMENTOS',	'Players:Expansion2_Players',	(SELECT CivilizationType FROM Players WHERE LeaderType = Leader AND Domain='Players:Expansion2_Players'),	Leader,		'ML_MEMENTOS_2',	'ICON_'||Memento2,				(SELECT MName FROM ML_Mementos_Config WHERE MementoType = Memento2),	(SELECT MTooltip FROM ML_Mementos_Config WHERE MementoType = Memento2),	152
FROM ML_LeaderMementos_Config WHERE Leader IN (SELECT LeaderType FROM Players WHERE Domain='Players:Expansion2_Players') AND Memento2 IN (SELECT MementoType FROM ML_Mementos_Config);


--3
INSERT OR REPLACE INTO GameModePlayerItemOverrides 
	(GameModeType,			Domain,							CivilizationType,																							LeaderType,	Type,				Icon,							Name,																	Description,															SortIndex)
SELECT	
	'GAMEMODE_ML_MEMENTOS',	'Players:Expansion2_Players',	(SELECT CivilizationType FROM Players WHERE LeaderType = Leader AND Domain='Players:Expansion2_Players'),	Leader,		'ML_MEMENTOS_3',	'ICON_'||Memento3,				(SELECT MName FROM ML_Mementos_Config WHERE MementoType = Memento3),	(SELECT MTooltip FROM ML_Mementos_Config WHERE MementoType = Memento3),	153
FROM ML_LeaderMementos_Config WHERE Leader IN (SELECT LeaderType FROM Players WHERE Domain='Players:Expansion2_Players') AND Memento3 IN (SELECT MementoType FROM ML_Mementos_Config);


--'ICON_'||MementoType
--'ICON_GAMEMODE_ML_MEMENTOS'


--Parameters

CREATE TEMPORARY TABLE TEMP_ML_Mementos_Config AS
SELECT 
    MementoType,
	MName,
	MDescription,
	MEffect,
	MTooltip,
    rowid AS MIndex  -- ��1��ʼ
FROM ML_Mementos_Config;


INSERT INTO DomainValues 
	(Domain,				Value,			Name,		Description,	SortIndex	)
SELECT
	'DOMAIN_ML_MEMENTOS',	MementoType,	MName,		MTooltip,		MIndex
FROM TEMP_ML_Mementos_Config;


INSERT INTO DomainValues 
	(Domain,				Value,				Name,							Description,						SortIndex	)
VALUES
	('DOMAIN_ML_MEMENTOS',	'MEMENTO_EMPTY',	'LOC_MEMENTO_EMPTY_NAME',		'LOC_MEMENTO_EMPTY_DESCRIPTION',	0			);