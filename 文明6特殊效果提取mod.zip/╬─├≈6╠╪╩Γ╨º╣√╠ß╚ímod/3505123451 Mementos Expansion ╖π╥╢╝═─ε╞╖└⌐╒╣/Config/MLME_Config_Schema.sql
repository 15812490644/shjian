-- MLME_Config_Schema
-- Author: Maple_Leaves
-- DateCreated: 4/25/2025 10:06:22 PM
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS 'ML_Mementos_Config'
(
MementoType TEXT NOT NULL,
MName TEXT NOT NULL,
MDescription TEXT NOT NULL,
MEffect TEXT NOT NULL,
MTooltip TEXT NOT NULL,
PRIMARY KEY (MementoType)
);

CREATE TABLE IF NOT EXISTS 'ML_LeaderMementos_Config'
(
Leader TEXT NOT NULL,
Memento TEXT NOT NULL,
Memento2 TEXT,
Memento3 TEXT,
PRIMARY KEY (Leader),
FOREIGN KEY (Memento) REFERENCES ML_Mementos_Config(MementoType) ON DELETE CASCADE ON UPDATE CASCADE
);