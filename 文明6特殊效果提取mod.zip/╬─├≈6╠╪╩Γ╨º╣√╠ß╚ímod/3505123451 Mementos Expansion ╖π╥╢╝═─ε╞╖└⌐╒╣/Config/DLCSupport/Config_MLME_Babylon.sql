-- Config_MLME_Babylon
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:18:24 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_CODE_OF_HAMMURABI',				'LOC_MEMENTO_CODE_OF_HAMMURABI_NAME',				'LOC_MEMENTO_CODE_OF_HAMMURABI_EFFECT',					'LOC_MEMENTO_CODE_OF_HAMMURABI_DESCRIPTION',				'LOC_MEMENTO_CODE_OF_HAMMURABI_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,							Memento,											Memento2,						Memento3)
VALUES
	('LEADER_HAMMURABI',				'MEMENTO_CODE_OF_HAMMURABI',						NULL,							NULL);
