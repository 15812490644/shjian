-- Config_MLME_Great_Commanders_Persia_Macedon
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:51:42 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,											MTooltip)
VALUES
	('MEMENTO_PEACOCK_THRONE',					'LOC_MEMENTO_PEACOCK_THRONE_NAME',					'LOC_MEMENTO_PEACOCK_THRONE_EFFECT',					'LOC_MEMENTO_PEACOCK_THRONE_DESCRIPTION',				'LOC_MEMENTO_PEACOCK_THRONE_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,							Memento,										Memento2,						Memento3)
VALUES
	('LEADER_NADER_SHAH',				'MEMENTO_PEACOCK_THRONE',						NULL,							NULL);