-- Config_MLME_Rulers_of_Sahara
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:34:03 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_BAOBAB_CRUTCHES',					'LOC_MEMENTO_BAOBAB_CRUTCHES_NAME',					'LOC_MEMENTO_BAOBAB_CRUTCHES_EFFECT',					'LOC_MEMENTO_BAOBAB_CRUTCHES_DESCRIPTION',					'LOC_MEMENTO_BAOBAB_CRUTCHES_TOOLTIP'),
	('MEMENTO_KADESH_INSCRIPTIONS',				'LOC_MEMENTO_KADESH_INSCRIPTIONS_NAME',				'LOC_MEMENTO_KADESH_INSCRIPTIONS_EFFECT',				'LOC_MEMENTO_KADESH_INSCRIPTIONS_DESCRIPTION',				'LOC_MEMENTO_KADESH_INSCRIPTIONS_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,										Memento2,						Memento3)
VALUES
	('LEADER_SUNDIATA_KEITA',					'MEMENTO_BAOBAB_CRUTCHES',						NULL,							NULL),
	('LEADER_RAMSES',							'MEMENTO_KADESH_INSCRIPTIONS',					NULL,							NULL),
	('LEADER_CLEOPATRA_ALT',					'MEMENTO_QUEEN_S_CARPET',						NULL,							NULL);