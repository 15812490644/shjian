-- Config_MLME_Teddy_Roosevelt
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:36:05 PM
--------------------------------------------------------------


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,										Memento2,						Memento3)
VALUES
	('LEADER_T_ROOSEVELT_ROUGHRIDER',			'MEMENTO_THE_WILDERNESS_HUNTER',				NULL,							NULL);