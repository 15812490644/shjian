-- Config_MLME_Great_Builders_Byzantium_Gaul
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:47:51 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_MOSAIC_OF_THEODORA',				'LOC_MEMENTO_MOSAIC_OF_THEODORA_NAME',				'LOC_MEMENTO_MOSAIC_OF_THEODORA_EFFECT',					'LOC_MEMENTO_MOSAIC_OF_THEODORA_DESCRIPTION',				'LOC_MEMENTO_MOSAIC_OF_THEODORA_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,								Memento,											Memento2,						Memento3)
VALUES
	('LEADER_THEODORA',						'MEMENTO_MOSAIC_OF_THEODORA',						NULL,							NULL);