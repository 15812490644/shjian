-- Config_MLME_Nubia
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:22:24 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_TEMPLE_RELIEFS_OF_MEROE',			'LOC_MEMENTO_TEMPLE_RELIEFS_OF_MEROE_NAME',			'LOC_MEMENTO_TEMPLE_RELIEFS_OF_MEROE_EFFECT',			'LOC_MEMENTO_TEMPLE_RELIEFS_OF_MEROE_DESCRIPTION',			'LOC_MEMENTO_TEMPLE_RELIEFS_OF_MEROE_TOOLTIP');


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,									Memento2,						Memento3)
VALUES
	('LEADER_AMANITORE',						'MEMENTO_TEMPLE_RELIEFS_OF_MEROE',			NULL,							NULL);