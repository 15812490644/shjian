-- Config_MLME_Byzantium_Gaul
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:18:24 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_MENOLOGION_OF_BASIL_II',			'LOC_MEMENTO_MENOLOGION_OF_BASIL_II_NAME',			'LOC_MEMENTO_MENOLOGION_OF_BASIL_II_EFFECT',			'LOC_MEMENTO_MENOLOGION_OF_BASIL_II_DESCRIPTION',			'LOC_MEMENTO_MENOLOGION_OF_BASIL_II_TOOLTIP'),
	('MEMENTO_CELTIC_LONGSWORD',				'LOC_MEMENTO_CELTIC_LONGSWORD_NAME',				'LOC_MEMENTO_CELTIC_LONGSWORD_EFFECT',					'LOC_MEMENTO_CELTIC_LONGSWORD_DESCRIPTION',					'LOC_MEMENTO_CELTIC_LONGSWORD_TOOLTIP');


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,								Memento,											Memento2,						Memento3)
VALUES
	('LEADER_BASIL',						'MEMENTO_MENOLOGION_OF_BASIL_II',					NULL,							NULL),
	('LEADER_AMBIORIX',						'MEMENTO_CELTIC_LONGSWORD',							NULL,							NULL);
