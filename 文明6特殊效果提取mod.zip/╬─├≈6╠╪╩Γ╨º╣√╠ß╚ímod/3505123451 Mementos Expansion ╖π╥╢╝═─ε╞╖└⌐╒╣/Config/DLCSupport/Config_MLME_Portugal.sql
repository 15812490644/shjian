-- Config_MLME_Portugal
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:28:22 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,							MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_TREATY_OF_ZARAGOZA',			'LOC_MEMENTO_TREATY_OF_ZARAGOZA_NAME',				'LOC_MEMENTO_TREATY_OF_ZARAGOZA_EFFECT',				'LOC_MEMENTO_TREATY_OF_ZARAGOZA_DESCRIPTION',				'LOC_MEMENTO_TREATY_OF_ZARAGOZA_TOOLTIP');


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,								Memento,							Memento2,						Memento3)
VALUES
	('LEADER_JOAO_III',						'MEMENTO_TREATY_OF_ZARAGOZA',			NULL,							NULL);