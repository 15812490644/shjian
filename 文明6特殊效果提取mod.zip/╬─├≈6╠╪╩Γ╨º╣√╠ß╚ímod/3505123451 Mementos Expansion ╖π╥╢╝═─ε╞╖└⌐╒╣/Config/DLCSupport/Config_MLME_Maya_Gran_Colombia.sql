-- Config_MLME_Maya_Gran_Colombia
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:20:51 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_STELA_OF_NARANJO',				'LOC_MEMENTO_STELA_OF_NARANJO_NAME',				'LOC_MEMENTO_STELA_OF_NARANJO_EFFECT',					'LOC_MEMENTO_STELA_OF_NARANJO_DESCRIPTION',					'LOC_MEMENTO_STELA_OF_NARANJO_TOOLTIP'),
	('MEMENTO_JAMAICA_LETTER',					'LOC_MEMENTO_JAMAICA_LETTER_NAME',					'LOC_MEMENTO_JAMAICA_LETTER_EFFECT',					'LOC_MEMENTO_JAMAICA_LETTER_DESCRIPTION',					'LOC_MEMENTO_JAMAICA_LETTER_TOOLTIP');


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,								Memento2,						Memento3)
VALUES
	('LEADER_LADY_SIX_SKY',						'MEMENTO_STELA_OF_NARANJO',				NULL,							NULL),
	('LEADER_SIMON_BOLIVAR',					'MEMENTO_JAMAICA_LETTER',				NULL,							NULL);