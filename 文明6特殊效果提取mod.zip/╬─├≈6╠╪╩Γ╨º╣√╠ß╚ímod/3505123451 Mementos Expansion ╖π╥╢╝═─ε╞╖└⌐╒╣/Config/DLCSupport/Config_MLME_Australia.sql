-- Config_MLME_Australia
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:18:24 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,									MName,													MEffect,													MDescription,													MTooltip)
VALUES
	('MEMENTO_AUSTRALIA_LOOKS_TO_US',				'LOC_MEMENTO_AUSTRALIA_LOOKS_TO_US_NAME',				'LOC_MEMENTO_AUSTRALIA_LOOKS_TO_US_EFFECT',					'LOC_MEMENTO_AUSTRALIA_LOOKS_TO_US_DESCRIPTION',				'LOC_MEMENTO_AUSTRALIA_LOOKS_TO_US_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,							Memento,											Memento2,						Memento3)
VALUES
	('LEADER_JOHN_CURTIN',				'MEMENTO_AUSTRALIA_LOOKS_TO_US',					NULL,							NULL);