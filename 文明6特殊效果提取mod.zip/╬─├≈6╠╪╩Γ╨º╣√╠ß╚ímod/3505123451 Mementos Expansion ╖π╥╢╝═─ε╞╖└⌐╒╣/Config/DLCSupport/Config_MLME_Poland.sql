-- Config_MLME_Poland
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:26:50 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_FOOTPRINT_STONE',					'LOC_MEMENTO_FOOTPRINT_STONE_NAME',						'LOC_MEMENTO_FOOTPRINT_STONE_EFFECT',						'LOC_MEMENTO_FOOTPRINT_STONE_DESCRIPTION',						'LOC_MEMENTO_FOOTPRINT_STONE_TOOLTIP');


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,							Memento2,						Memento3)
VALUES
	('LEADER_JADWIGA',							'MEMENTO_FOOTPRINT_STONE',			NULL,							NULL);