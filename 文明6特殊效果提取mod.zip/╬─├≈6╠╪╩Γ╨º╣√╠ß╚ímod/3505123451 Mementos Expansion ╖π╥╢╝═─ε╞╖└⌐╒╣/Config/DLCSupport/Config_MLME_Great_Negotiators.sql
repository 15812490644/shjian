-- Config_MLME_Great_Negotiators
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:53:35 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_GETTYSBURG_ADDRESS',				'LOC_MEMENTO_GETTYSBURG_ADDRESS_NAME',				'LOC_MEMENTO_GETTYSBURG_ADDRESS_EFFECT',				'LOC_MEMENTO_GETTYSBURG_ADDRESS_DESCRIPTION',				'LOC_MEMENTO_GETTYSBURG_ADDRESS_TOOLTIP'),
	('MEMENTO_NEGOTIATION_STOOL',				'LOC_MEMENTO_NEGOTIATION_STOOL_NAME',				'LOC_MEMENTO_NEGOTIATION_STOOL_EFFECT',					'LOC_MEMENTO_NEGOTIATION_STOOL_DESCRIPTION',				'LOC_MEMENTO_NEGOTIATION_STOOL_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,											Memento2,						Memento3)
VALUES
	('LEADER_SALADIN_ALT',						'MEMENTO_TREATY_OF_JAFFA_1192',						NULL,							NULL),
	('LEADER_ABRAHAM_LINCOLN',					'MEMENTO_GETTYSBURG_ADDRESS',						NULL,							NULL),
	('LEADER_NZINGA_MBANDE',					'MEMENTO_NEGOTIATION_STOOL',						NULL,							NULL);