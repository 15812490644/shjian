-- Config_MLME_Khmer_Indonesia
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:18:06 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_SMILING_BUDDHA_STATUE',			'LOC_MEMENTO_SMILING_BUDDHA_STATUE_NAME',			'LOC_MEMENTO_SMILING_BUDDHA_STATUE_EFFECT',				'LOC_MEMENTO_SMILING_BUDDHA_STATUE_DESCRIPTION',			'LOC_MEMENTO_SMILING_BUDDHA_STATUE_TOOLTIP'),
	('MEMENTO_NAGARAKRETAGAMA',					'LOC_MEMENTO_NAGARAKRETAGAMA_NAME',					'LOC_MEMENTO_NAGARAKRETAGAMA_EFFECT',					'LOC_MEMENTO_NAGARAKRETAGAMA_DESCRIPTION',					'LOC_MEMENTO_NAGARAKRETAGAMA_TOOLTIP');


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,										Memento2,						Memento3)
VALUES
	('LEADER_JAYAVARMAN',						'MEMENTO_SMILING_BUDDHA_STATUE',				NULL,							NULL),
	('LEADER_GITARJA',							'MEMENTO_NAGARAKRETAGAMA',						NULL,							NULL);