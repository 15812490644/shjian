-- Config_MLME_Rulers_of_England
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:32:00 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,											MEffect,													MDescription,												MTooltip)
VALUES
	('MEMENTO_TILBURY_SPEECH',					'LOC_MEMENTO_TILBURY_SPEECH_NAME',				'LOC_MEMENTO_TILBURY_SPEECH_EFFECT',						'LOC_MEMENTO_TILBURY_SPEECH_DESCRIPTION',					'LOC_MEMENTO_TILBURY_SPEECH_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,										Memento2,						Memento3)
VALUES
	('LEADER_ELIZABETH',						'MEMENTO_TILBURY_SPEECH',						NULL,							NULL),
	('LEADER_VICTORIA_ALT',						'MEMENTO_QUEEN_VICTORIA_S_JOURNALS',			NULL,							NULL),
	('LEADER_HARALD_ALT',						'MEMENTO_SAGA_OF_HARALD_HARDRADA',				NULL,							NULL);