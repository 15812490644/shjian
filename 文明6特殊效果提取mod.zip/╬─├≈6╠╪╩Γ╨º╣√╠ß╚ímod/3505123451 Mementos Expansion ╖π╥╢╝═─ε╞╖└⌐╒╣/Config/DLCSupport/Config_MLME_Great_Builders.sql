-- Config_MLME_Great_Builders
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:45:17 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_HUNMINJEONGEUM',					'LOC_MEMENTO_HUNMINJEONGEUM_NAME',					'LOC_MEMENTO_HUNMINJEONGEUM_EFFECT',					'LOC_MEMENTO_HUNMINJEONGEUM_DESCRIPTION',					'LOC_MEMENTO_HUNMINJEONGEUM_TOOLTIP'),
	('MEMENTO_ROYAL_SLEIGH',					'LOC_MEMENTO_ROYAL_SLEIGH_NAME',					'LOC_MEMENTO_ROYAL_SLEIGH_EFFECT',						'LOC_MEMENTO_ROYAL_SLEIGH_DESCRIPTION',						'LOC_MEMENTO_ROYAL_SLEIGH_TOOLTIP');


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,								Memento,										Memento2,						Memento3)
VALUES
	('LEADER_SEJONG',						'MEMENTO_HUNMINJEONGEUM',						NULL,							NULL),
	('LEADER_LUDWIG',						'MEMENTO_ROYAL_SLEIGH',							NULL,							NULL);