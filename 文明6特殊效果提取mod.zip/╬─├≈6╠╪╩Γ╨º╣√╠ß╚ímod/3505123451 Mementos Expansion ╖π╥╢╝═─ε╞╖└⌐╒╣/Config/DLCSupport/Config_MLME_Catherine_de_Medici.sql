-- Config_MLME_Catherine_de_Medici
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:18:24 PM
--------------------------------------------------------------



--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,									Memento2,						Memento3)
VALUES
	('LEADER_CATHERINE_DE_MEDICI_ALT',			'MEMENTO_BLACK_CLOTH',						NULL,							NULL);
