-- Config_MLME_Ethiopia
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:43:28 PM
--------------------------------------------------------------

--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_TREATY_OF_ADDIS_ABABA',			'LOC_MEMENTO_TREATY_OF_ADDIS_ABABA_NAME',			'LOC_MEMENTO_TREATY_OF_ADDIS_ABABA_EFFECT',				'LOC_MEMENTO_TREATY_OF_ADDIS_ABABA_DESCRIPTION',			'LOC_MEMENTO_TREATY_OF_ADDIS_ABABA_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,							Memento,											Memento2,						Memento3)
VALUES
	('LEADER_MENELIK',					'MEMENTO_TREATY_OF_ADDIS_ABABA',					NULL,							NULL);