-- Config_MLME_Persia_Macedon
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:24:41 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_CYRUS_CYLINDER',					'LOC_MEMENTO_CYRUS_CYLINDER_NAME',					'LOC_MEMENTO_CYRUS_CYLINDER_EFFECT',					'LOC_MEMENTO_CYRUS_CYLINDER_DESCRIPTION',					'LOC_MEMENTO_CYRUS_CYLINDER_TOOLTIP'),
	('MEMENTO_LION_HELMET',						'LOC_MEMENTO_LION_HELMET_NAME',						'LOC_MEMENTO_LION_HELMET_EFFECT',						'LOC_MEMENTO_LION_HELMET_DESCRIPTION',						'LOC_MEMENTO_LION_HELMET_TOOLTIP');


--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,							Memento2,						Memento3)
VALUES
	('LEADER_CYRUS',							'MEMENTO_CYRUS_CYLINDER',			NULL,							NULL),
	('LEADER_ALEXANDER',						'MEMENTO_LION_HELMET',				NULL,							NULL);