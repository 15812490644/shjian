-- Config_MLME_Julius_Caesar
-- Author: Maple_Leaves
-- DateCreated: 6/21/2025 4:15:04 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,									MName,													MEffect,													MDescription,													MTooltip)
VALUES
	('MEMENTO_COMMENTARII_DE_BELLO_GALLICO',		'LOC_MEMENTO_COMMENTARII_DE_BELLO_GALLICO_NAME',		'LOC_MEMENTO_COMMENTARII_DE_BELLO_GALLICO_EFFECT',			'LOC_MEMENTO_COMMENTARII_DE_BELLO_GALLICO_DESCRIPTION',			'LOC_MEMENTO_COMMENTARII_DE_BELLO_GALLICO_TOOLTIP'),
	('MEMENTO_JULIAN_CALENDAR',						'LOC_MEMENTO_JULIAN_CALENDAR_NAME',						'LOC_MEMENTO_JULIAN_CALENDAR_EFFECT',						'LOC_MEMENTO_JULIAN_CALENDAR_DESCRIPTION',						'LOC_MEMENTO_JULIAN_CALENDAR_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,							Memento,											Memento2,						Memento3)
VALUES
	('LEADER_JULIUS_CAESAR',			'MEMENTO_COMMENTARII_DE_BELLO_GALLICO',				'MEMENTO_JULIAN_CALENDAR',		NULL);