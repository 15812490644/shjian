-- Config_MLME_Great_Commanders
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:49:18 PM
--------------------------------------------------------------


--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,								MName,												MEffect,												MDescription,												MTooltip)
VALUES
	('MEMENTO_GO',								'LOC_MEMENTO_GO_NAME',								'LOC_MEMENTO_GO_EFFECT',								'LOC_MEMENTO_GO_DESCRIPTION',								'LOC_MEMENTO_GO_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,									Memento,									Memento2,						Memento3)
VALUES
	('LEADER_SULEIMAN_ALT',						'MEMENTO_OTTOMAN_LAWS',						NULL,							NULL),
	('LEADER_TOKUGAWA',							'MEMENTO_GO',								NULL,							NULL);