-- Config_MLME_Aztec
-- Author: Maple_Leaves
-- DateCreated: 6/20/2025 11:15:38 PM
--------------------------------------------------------------

--Mementos

INSERT INTO ML_Mementos_Config 
	(MementoType,									MName,													MEffect,													MDescription,													MTooltip)
VALUES
	('MEMENTO_DOUBLE_HEADED_SERPENT',				'LOC_MEMENTO_DOUBLE_HEADED_SERPENT_NAME',				'LOC_MEMENTO_DOUBLE_HEADED_SERPENT_EFFECT',					'LOC_MEMENTO_DOUBLE_HEADED_SERPENT_DESCRIPTION',				'LOC_MEMENTO_DOUBLE_HEADED_SERPENT_TOOLTIP');

--LeaderMementos

INSERT INTO ML_LeaderMementos_Config 
	(Leader,							Memento,											Memento2,						Memento3)
VALUES
	('LEADER_MONTEZUMA',				'MEMENTO_DOUBLE_HEADED_SERPENT',					NULL,							NULL);