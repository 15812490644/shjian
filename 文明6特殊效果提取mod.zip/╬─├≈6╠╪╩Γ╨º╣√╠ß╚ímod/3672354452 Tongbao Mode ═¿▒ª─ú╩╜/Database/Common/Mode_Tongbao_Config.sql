-- Config
-- Author: Ophidy
-- DateCreated: 2/22/2026 12:36:52 AM
--------------------------------------------------------------
INSERT INTO GameModeItems
	(
		GameModeType,
		Name,
		Icon,
		Portrait,
		Background,
		SortIndex
	)
VALUES
	(
		'GAMEMODE_OPD_TONGBAO',
		'LOC_GAMEMODE_OPD_TONGBAO_NAME',
		'ICON_GAMEMODE_OPD_TONGBAO',
		'IMG_GAMEMODE_GAMEMODE_OPD_TONGBAO_FORE',
		'GAMEMODE_TREE_RANDOMIZER_BACKGROUND',
		10
	);

INSERT INTO Parameters
	(
		ParameterId,
		Name,
		Description,
		Domain,
		DefaultValue,
		ConfigurationGroup,
		NameArrayConfigurationId,
		ConfigurationId,
		GroupId
	)
VALUES
	(
		'GameMode_Opd_Tongbao',
		'LOC_GAMEMODE_OPD_TONGBAO_NAME',
		'LOC_GAMEMODE_OPD_TONGBAO_DESCRIPTION',
		'bool',
		0,
		'Game',
		'GAMEMODES_ENABLED_NAMES',
		'GAMEMODE_OPD_TONGBAO',
		'GameModes'
	),
	(
					
		'GameMode_Opd_Tongbao_MaxHuaNum',
		'LOC_GAMEMODE_OPD_TONGBAO_MAXHUANUM_NAME',
		'LOC_GAMEMODE_OPD_TONGBAO_MAXHUANUM_DESCRIPTION',
		'Opd_MaxHuaNum',
		1,
		'Game',
		NULL,
		'Opd_MaxHuaNum',
		'GameOptions'
	),
	(
					
		'GameMode_Opd_Tongbao_MaxLiNum',
		'LOC_GAMEMODE_OPD_TONGBAO_MAXLINUM_NAME',
		'LOC_GAMEMODE_OPD_TONGBAO_MAXLINUM_DESCRIPTION',
		'Opd_MaxLiNum',
		1,
		'Game',
		NULL,
		'Opd_MaxLiNum',
		'GameOptions'
	),
	(
					
		'GameMode_Opd_Tongbao_AIEntry',
		'LOC_GAMEMODE_OPD_TONGBAO_AIENTRY_NAME',
		'LOC_GAMEMODE_OPD_TONGBAO_AIENTRY_DESCRIPTION',
		'bool',
		1,
		'Game',
		NULL,
		'Opd_Tongbao_AIEntry',
		'AdvancedOptions'
	);

INSERT INTO DomainRanges
		(Domain,						MinimumValue,		MaximumValue)
VALUES	('Opd_MaxHuaNum',				0,					3),
		('Opd_MaxLiNum',				0,					3);

INSERT INTO ParameterDependencies
	(
		ParameterId,
		ConfigurationGroup,
		ConfigurationId,
		Operator,
		ConfigurationValue
	)
VALUES
	(
		'GameMode_Opd_Tongbao',
		'Game',
		'RULESET',
		'Exists',
		'RULESET_EXPANSION_2'
	),
	(
		'GameMode_Opd_Tongbao_MaxHuaNum',
		'Game',
		'GAMEMODE_OPD_TONGBAO',
		'Equals',
		1
	),
	(
		'GameMode_Opd_Tongbao_MaxLiNum',
		'Game',
		'GAMEMODE_OPD_TONGBAO',
		'Equals',
		1
	),
	(
		'GameMode_Opd_Tongbao_AIEntry',
		'Game',
		'GAMEMODE_OPD_TONGBAO',
		'Equals',
		1
	);