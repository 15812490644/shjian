-- Mode_Tongbao_Civilopedia
-- Author: Ophidy
-- DateCreated: 2/23/2026 7:44:05 PM
--------------------------------------------------------------
--=============================================================
-- CivilopediaSections
--=============================================================
	INSERT INTO CivilopediaSections
		(
			SectionId,
			Name,
			Icon,
			SortIndex
		)
	VALUES
		(
			'OPD_TONGBAO',
			'LOC_UI_CIVILOPEDIA_TONGBAO_TITLE',
			'ICON_CIVILOPEDIA_OPHIDY_TONGBAO',
			100
		);
--=============================================================
-- CivilopediaPages
--=============================================================
	INSERT INTO CivilopediaPageGroups
		(
			SectionID,
			PageGroupId,

			Name,
			Tooltip,

			VisibleIfEmpty,
			SortIndex
		)
	VALUES
		(
			'OPD_TONGBAO',
			'OPD_TONGBAO_HENG',

			'LOC_UI_OPD_TONGBAO_HENG_CLASS_NAME',
			'LOC_UI_OPD_TONGBAO_HENG_CLASS_TT',

			1,
			5
		),
		(
			'OPD_TONGBAO',
			'OPD_TONGBAO_HUA',

			'LOC_UI_OPD_TONGBAO_HUA_CLASS_NAME',
			'LOC_UI_OPD_TONGBAO_HUA_CLASS_TT',

			1,
			5
		),
		(
			'OPD_TONGBAO',
			'OPD_TONGBAO_LI',

			'LOC_UI_OPD_TONGBAO_LI_CLASS_NAME',
			'LOC_UI_OPD_TONGBAO_LI_CLASS_TT',

			1,
			5
		);
--=============================================================
-- CivilopediaPageQueries
--=============================================================
	INSERT INTO CivilopediaPageQueries
		(
			SectionId,
			PageGroupIdColumn,
			TooltipColumn,
			SortIndex,

			SQL
		)
	VALUES
		(
			'OPD_TONGBAO',
			'PageGroupId',
			'Tooltip',
			10,

			'SELECT TongbaoType AS PageId, "OPD_TONGBAO_" || TongbaoClass AS PageGroupId, "Ophidy_Tongbao" AS PageLayoutId, CASE WHEN Name IS NULL THEN "LOC_"||TongbaoType||"_NAME" ELSE Name END AS Name, NULL AS Tooltip FROM Yan_Tongbao'
		);
--=============================================================
-- CivilopediaPageLayouts
--=============================================================
	INSERT INTO CivilopediaPageLayouts
		(
			PageLayoutId,
			ScriptTemplate
		)
	VALUES
		(
			'Ophidy_Tongbao',
			'Ophidy_Tongbao'
		);
--=============================================================
-- CivilopediaPageLayoutChapters
--=============================================================
	INSERT INTO CivilopediaPageLayoutChapters
		(
			PageLayoutId,
			ChapterId,
			SortIndex
		)
	VALUES
		(
			'Ophidy_Tongbao',
			'HISTORY',
			10
		);
--=============================================================
--=============================================================