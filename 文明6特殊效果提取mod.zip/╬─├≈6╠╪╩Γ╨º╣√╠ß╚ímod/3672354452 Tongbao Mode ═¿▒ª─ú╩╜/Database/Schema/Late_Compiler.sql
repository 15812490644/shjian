-- Late_Compiler
-- Author: Ophidy
-- DateCreated: 2/21/2026 11:28:30 PM
--------------------------------------------------------------
--========================================================================================================================
-- Compiler
--========================================================================================================================
	--------------------------------------------------------------------
	-- Tongbao - compile for lua
	--------------------------------------------------------------------
		INSERT OR IGNORE INTO Modifiers
				(ModifierId,					ModifierType,								OwnerRequirementSetId)
		SELECT	ModifierId || '_' || EraType,	'MODIFIER_SINGLE_UNIT_ATTACH_MODIFIER',		'REQSET_YAN_RE_GAME_ERA_IS_' || EraType
		FROM Yan_TongbaoModifiers CROSS JOIN Eras;
		-- ///////////////////////////////////	'MODIFIER_SINGLE_UNIT_ATTACH_MODIFIER' here is just okay, no need to create a new modifiertype.

		INSERT OR IGNORE INTO ModifierArguments
				(ModifierId,					Name,				Value)
		SELECT	ModifierId || '_' || EraType,	'ModifierId',		ModifierId
		FROM Yan_TongbaoModifiers CROSS JOIN Eras;

		INSERT OR IGNORE INTO RequirementSets
				(RequirementSetId,								RequirementSetType)
		SELECT	'REQSET_YAN_RE_GAME_ERA_IS_' || EraType,		'REQUIREMENTSET_TEST_ALL'
		FROM Eras;

		INSERT OR IGNORE INTO RequirementSetRequirements
				(RequirementSetId,								RequirementId)
		SELECT	'REQSET_YAN_RE_GAME_ERA_IS_' || EraType,		'REQ_YAN_RE_GAME_ERA_IS_' || EraType || '_0'
		FROM Eras 
		UNION SELECT	'REQSET_YAN_RE_GAME_ERA_IS_' || EraType,		'REQ_YAN_RE_GAME_ERA_IS_' || EraType || '_1'
		FROM Eras;

		INSERT OR IGNORE INTO Requirements
				(RequirementId,									RequirementType,							Inverse)
		SELECT	'REQ_YAN_RE_GAME_ERA_IS_' || EraType || '_0',	'REQUIREMENT_GAME_ERA_ATLEAST_EXPANSION',	0
		FROM Eras 
		UNION SELECT	'REQ_YAN_RE_GAME_ERA_IS_' || EraType || '_1',	'REQUIREMENT_GAME_ERA_ATLEAST_EXPANSION',	1
		FROM Eras WHERE EraType != 'ERA_FUTURE';

		DELETE FROM RequirementSetRequirements WHERE RequirementSetId = 'REQSET_YAN_RE_GAME_ERA_IS_ERA_FUTURE' AND RequirementId = 'REQ_YAN_RE_GAME_ERA_IS_ERA_FUTURE_1';

		INSERT OR IGNORE INTO RequirementArguments 
				(RequirementId,									Name,				Value) 
		VALUES	('REQ_YAN_RE_GAME_ERA_IS_ERA_ANCIENT_0',		'EraType',			'ERA_ANCIENT'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_ANCIENT_1',		'EraType',			'ERA_CLASSICAL'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_CLASSICAL_0',		'EraType',			'ERA_CLASSICAL'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_CLASSICAL_1',		'EraType',			'ERA_MEDIEVAL'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_MEDIEVAL_0',		'EraType',			'ERA_MEDIEVAL'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_MEDIEVAL_1',		'EraType',			'ERA_RENAISSANCE'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_RENAISSANCE_0',	'EraType',			'ERA_RENAISSANCE'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_RENAISSANCE_1',	'EraType',			'ERA_INDUSTRIAL'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_INDUSTRIAL_0',		'EraType',			'ERA_INDUSTRIAL'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_INDUSTRIAL_1',		'EraType',			'ERA_MODERN'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_MODERN_0',			'EraType',			'ERA_MODERN'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_MODERN_1',			'EraType',			'ERA_ATOMIC'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_ATOMIC_0',			'EraType',			'ERA_ATOMIC'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_ATOMIC_1',			'EraType',			'ERA_INFORMATION'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_INFORMATION_0',	'EraType',			'ERA_INFORMATION'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_INFORMATION_1',	'EraType',			'ERA_FUTURE'), 
				('REQ_YAN_RE_GAME_ERA_IS_ERA_FUTURE_0',			'EraType',			'ERA_FUTURE');

	--------------------------------------------------------------------
	-- Tongbao - lua notification
	--------------------------------------------------------------------
		INSERT OR IGNORE INTO Types 
				(Type,									Kind)
		VALUES	('NOTIFICATION_MODE_TONGBAO_AVAILABLE',	'KIND_NOTIFICATION');

		INSERT OR IGNORE INTO Notifications
				(NotificationType,						SeverityType,	ExpiresEndOfTurn,	AutoNotify, AutoActivate)
		VALUES	('NOTIFICATION_MODE_TONGBAO_AVAILABLE',	'MID',			1,					0,			0);

	--------------------------------------------------------------------
	-- Tongbao - properties
	--------------------------------------------------------------------
	/*
		INSERT OR IGNORE INTO TraitModifiers
				(TraitType,							ModifierId)
		SELECT	'TRAIT_LEADER_MAJOR_CIV',			'MODFEAT_TONGBAO_PROPERTY_' || Name
		FROM Mode_TongbaoProperties;

		INSERT OR IGNORE INTO Modifiers
			(ModifierId,									ModifierType)
		SELECT
			'MODFEAT_TONGBAO_PROPERTY_' || Name,			'MODIFIER_PLAYER_ADJUST_PROPERTY'
		FROM Mode_TongbaoProperties;
		
		INSERT OR IGNORE INTO ModifierArguments
			(ModifierId,									Name,							Value)
		SELECT
			'MODFEAT_TONGBAO_PROPERTY_' || Name,			'Key',							Name
		FROM Mode_TongbaoProperties
		UNION SELECT
			'MODFEAT_TONGBAO_PROPERTY_' || Name,			'Amount',						Value
		FROM Mode_TongbaoProperties;

		DROP TABLE Mode_TongbaoProperties;
	*/