-- Base_Schema
-- Author: Ophidy
-- DateCreated: 2/21/2026 11:27:54 PM
--------------------------------------------------------------
--========================================================================================================================
-- Initialize
--========================================================================================================================
	DROP TABLE IF EXISTS Yan_Tongbao;
	DROP TABLE IF EXISTS Yan_TongbaoModifiers;

	CREATE TABLE IF NOT EXISTS Yan_Tongbao
		(
			TongbaoType		TEXT NOT NULL,	
			TongbaoClass	TEXT NOT NULL CHECK (TongbaoClass IN ('LI','HENG','HUA')) DEFAULT 'HENG',	
											-- LI HENG HUA, LI and HUA can only cast one at a time.	
			Name			TEXT,			-- If not given, will automatically lookup text with proper prefix and suffix.
			Description		TEXT,			-- If not given, will automatically lookup text with proper prefix and suffix.
			PRIMARY KEY (TongbaoType),
			FOREIGN KEY (TongbaoType) REFERENCES Types(Type) ON DELETE CASCADE ON UPDATE CASCADE
		);

	CREATE TABLE IF NOT EXISTS Yan_TongbaoModifiers
		(
			TongbaoType		TEXT NOT NULL,	
			ModifierId		TEXT NOT NULL,	
			PRIMARY KEY (TongbaoType,ModifierId),
			FOREIGN KEY (TongbaoType) REFERENCES Types(Type) ON DELETE CASCADE ON UPDATE CASCADE,
			FOREIGN KEY (ModifierId) REFERENCES Modifiers(ModifierId) ON DELETE CASCADE ON UPDATE CASCADE
		);