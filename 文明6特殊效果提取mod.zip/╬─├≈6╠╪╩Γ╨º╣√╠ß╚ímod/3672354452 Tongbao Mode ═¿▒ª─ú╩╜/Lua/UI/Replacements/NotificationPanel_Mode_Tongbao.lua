-- NotificationPanel_Mode_Tongbao
-- Author: Ophidy
-- DateCreated: 2/21/2026 11:58:52 PM
--------------------------------------------------------------
-- ===========================================================================
-- CACHE BASE FUNCTIONS
-- ===========================================================================
local BASE_RegisterHandlers					= RegisterHandlers;
local BASE_OnDefaultAddNotification			= OnDefaultAddNotification;

-- ===========================================================================
--	CONSTANTS
-- ===========================================================================
local NOTIFICATION_MODE_TONGBAO_AVAILABLE	= DB.MakeHash("NOTIFICATION_MODE_TONGBAO_AVAILABLE");

-- ===========================================================================
--	VARIABLES
-- ===========================================================================
local needAutoActivate			:boolean	= true;

--========================================================================================================================
--	CORE
--========================================================================================================================

-- ===========================================================================
	function OnModeTongbaoNotificationActivate( notificationEntry)
		if (notificationEntry ~= nil and notificationEntry.m_PlayerID == Game.GetLocalPlayer()) then
			local pNotification :table = GetActiveNotificationFromEntry(notificationEntry);
			if pNotification ~= nil then
				LuaEvents.Mode_Tongbao_TogglePopup();
				notificationEntry.m_kHandlers.TryDismiss(notificationEntry);
			end
		end
	end

	function OnModeTongbaoNotificationDismissed(notificationEntry)
		if (notificationEntry ~= nil and notificationEntry.m_PlayerID == Game.GetLocalPlayer()) then
			OnDefaultTryDismissNotification(notificationEntry);
		end
	end

	-- offset correction
	function OnDefaultAddNotification(pNotification)
		BASE_OnDefaultAddNotification(pNotification);
		local notificationID	:number				= pNotification:GetID();
		local playerID			:number				= Game.GetLocalPlayer();
		local notificationEntry	:NotificationType	= GetNotificationEntry( playerID, notificationID );
		if notificationEntry and notificationEntry.m_Instance and notificationEntry.m_Instance.Icon then
			notificationEntry.m_Instance.Icon:SetOffsetX(-3);
			notificationEntry.m_Instance.Icon:SetOffsetY(-1);
		end
	end
	
-- ========================================================================================================================
	function Mode_Tongbao_SendNotification()
		local tNotificationData = {}
		tNotificationData[ParameterTypes.MESSAGE] = Locale.Lookup('LOC_YAN_RE_TONGBAO_POPUP_TITLE');
		tNotificationData[ParameterTypes.SUMMARY] = Locale.Lookup('LOC_YAN_RE_TONGBAO_NOTIFICATION_SUMMARY');
		NotificationManager.SendNotification(Game.GetLocalPlayer(), NOTIFICATION_MODE_TONGBAO_AVAILABLE, tNotificationData)
	end

	function Mode_Check()
		local iPlayer = Game.GetLocalPlayer();
		local pPlayer = Players[iPlayer];
		local iEra = Game.GetEras():GetCurrentEra();
		local isActivated = pPlayer:GetProperty("Mode_TongbaoActivated_" .. iEra) or false;
		if not isActivated then
			Mode_Tongbao_SendNotification();
		end
	end
	
	function OnModeTongbaoNotificationAdded(iPlayer, iNotification)
		if iPlayer == Game.GetLocalPlayer()	then
			local pNotification : table = NotificationManager.Find( iPlayer, iNotification );
			if pNotification and pNotification:GetType() == NOTIFICATION_MODE_TONGBAO_AVAILABLE then
				if needAutoActivate then
					pNotification:Activate(true);
					needAutoActivate = false;
				end
			end
		end
	end
	
	function OnModeTongbaoTurnBegin()
		needAutoActivate = true;
	end	

-- ========================================================================================================================
	
	
function RegisterHandlers()

	BASE_RegisterHandlers();

	g_notificationHandlers[NOTIFICATION_MODE_TONGBAO_AVAILABLE]							= MakeDefaultHandlers();
	g_notificationHandlers[NOTIFICATION_MODE_TONGBAO_AVAILABLE].AddSound				= 'NOTIFICATION_MISC_POSITIVE';
	g_notificationHandlers[NOTIFICATION_MODE_TONGBAO_AVAILABLE].Activate				= OnModeTongbaoNotificationActivate;
	g_notificationHandlers[NOTIFICATION_MODE_TONGBAO_AVAILABLE].TryDismiss				= OnModeTongbaoNotificationDismissed;

	Events.LocalPlayerTurnBegin.Add(Mode_Check);
	Events.NotificationAdded.Add(OnModeTongbaoNotificationAdded);
	Events.TurnBegin.Add(OnModeTongbaoTurnBegin);

	LuaEvents.Mode_Tongbao_PanelClosed.Add(Mode_Check);
end