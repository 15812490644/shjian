-- EraProgressPanel_Patch_Mode_Tongbao
-- Author: Ophidy
-- DateCreated: 2/22/2026 1:16:37 AM
--------------------------------------------------------------
include("InstanceManager");

--========================================================================================================================
--	CONSTANTS
--========================================================================================================================


--========================================================================================================================
--	VARIABLES
--========================================================================================================================
local m_EraProgressIM 			:table		= InstanceManager:new("EraProgressExtra", "Root");
local m_InstanceAttached1 		:boolean	= false;
local m_InstanceAttached2 		:boolean	= false;
local m_EraProgressTongbao		:table;
local m_EraProgressTraits		:table;


--========================================================================================================================
--	CONTROL
--========================================================================================================================
	function RefreshEraProgressText()
		local iPlayer = Game.GetLocalPlayer();
		local pPlayer = Players[iPlayer];
		local iEra = Game.GetEras():GetCurrentEra();
		
		local effectiveTongbao = pPlayer:GetProperty("Mode_EffectiveTongbao") or {};
		if #effectiveTongbao > 0 then
			if not m_InstanceAttached1 then
				local EraProgressStack = ContextPtr:LookUpControl("/InGame/EraProgressPanel/EraEffects"):GetParent();
				m_InstanceAttached1 = true;
				m_EraProgressTongbao = m_EraProgressIM:GetInstance(EraProgressStack);
				--ContextPtr:BuildInstanceForControl("EraProgressExtra", m_EraProgressTongbao, EraProgressStack);
			end

			m_EraProgressTongbao.Header:SetText(Locale.Lookup("LOC_YAN_RE_TONGBAO_TOOLTIP_TITLE"));
			local text = "";
			for _, tongbao in ipairs(effectiveTongbao) do
				local tongbaoInfo = GameInfo.Yan_Tongbao[tongbao];
				local TongbaoType = tongbaoInfo.TongbaoType;
				local tongbaoName = tongbaoInfo.Name or "LOC_" .. TongbaoType .. "_NAME";
				local tongbaoDescription = tongbaoInfo.Description or "LOC_" .. TongbaoType .. "_DESCRIPTION";
				if string.len(text) > 0 then text = text .. "[newline][newline]"; end
				text = text .. "[icon_bullet]" .. Locale.Lookup(tongbaoName) .. "[newline]" .. Locale.Lookup(tongbaoDescription);
			end
			m_EraProgressTongbao.Description:SetText(text);
		end
	end



--========================================================================================================================
--	INIT
--========================================================================================================================
	function Initialize()
		LuaEvents.PartialScreenHooks_OpenEraProgressPanel.Add( RefreshEraProgressText );
	end
Initialize();