-- Mode_Tongbao_Popup
-- Author: Ophidy
-- DateCreated: 2/21/2026 11:51:04 PM
--------------------------------------------------------------
include("InstanceManager");

--========================================================================================================================
--	VARIABLES
--========================================================================================================================
local m_TongbaoIM 				:table		= InstanceManager:new("Tongbao", "SelectCheck", Controls.TongbaoStack);
local m_SelectedTongbao 		:table		= {};
local m_EraProgressExtra 		:table		= {};
local m_NumSelectedTongbao 		:number		= 0;
local m_NumAllowedTongbao 		:number		= 0;

--========================================================================================================================
--	UTILS
--========================================================================================================================


--========================================================================================================================
--	CORE
--========================================================================================================================
	function CastTongbao()
		local iPlayer = Game.GetLocalPlayer();

		if iPlayer == PlayerTypes.NONE then
			return;
		end

		local pPlayer = Players[iPlayer];

		local iEra = Game.GetEras():GetCurrentEra();

		if true then
			local numActivating = pPlayer:GetProperty("Mode_TongbaoActivated_" .. iEra) or 0;
			local tTongbao = GetTongbao(iPlayer);
			m_NumAllowedTongbao = math.min(1, #tTongbao);

			if m_NumAllowedTongbao <= numActivating then return; end
					print("Mode Cast Tongbao")
			m_NumSelectedTongbao = 0;
			Controls.Title:SetText(Locale.ToUpper(Locale.Lookup("LOC_YAN_RE_TONGBAO_POPUP_TITLE")));
			m_TongbaoIM:ResetInstances();

			for _, TongbaoType in ipairs(tTongbao) do
				AddItem(TongbaoType);
			end
			
			Controls.Subheader:SetText(Locale.Lookup("LOC_YAN_RE_TONGBAO_POPUP_SUBHEADER",m_NumAllowedTongbao));

			if m_TongbaoIM.m_iAllocatedInstances > 0 then
				ShowPopup();
				m_SelectedTongbao = {};
				Controls.Confirm:SetDisabled(true);
				Controls.TongbaoStack:CalculateSize();
				Controls.TongbaoScroller:CalculateSize();
			end

			Controls.TongbaoScroller:SetScrollValue(0);
		end
	end

	function GetTongbao(iPlayer)
		local pPlayer	= Players[iPlayer];
		local iEra		= GameInfo.Eras[Game.GetEras():GetCurrentEra()].Index;
		local numLi		= 0;
		local numHua	= 0;
		local tTongbao	= {};

		local maxCasts	= 4;
		local maxLi		= GameConfiguration.GetValue("Opd_MaxLiNum") or 1;
		local maxHua	= GameConfiguration.GetValue("Opd_MaxHuaNum") or 1;
		
		local Chest		= pPlayer:GetProperty("Mode_TongbaoChest") or {};
		local tRows		= Chest[iEra] or {};
		if #tRows > 0 then
			for _, tRow in ipairs(tRows) do
				if #tTongbao < maxCasts then

					-- To avaid repeatly activate a Tongbao when playing Yan, check if we've activated this Tongbao.
					local function Mode_TongbaoIsActivated(tongbaoType) 
						local tActive = pPlayer:GetProperty("Yan_Re_EffectiveTongbao") or {};
						for _, activeTongbao in ipairs(tActive) do
							if activeTongbao == tongbaoType then 
								return true;
							end
						end
						return false;
					end

					if not Mode_TongbaoIsActivated(tRow.TongbaoType) then
						if tRow.TongbaoClass == "HENG" then
							table.insert(tTongbao,tRow.TongbaoType);
						elseif tRow.TongbaoClass == "HUA" and numHua < maxHua then
							table.insert(tTongbao,tRow.TongbaoType);
							numHua = numHua + 1;
						elseif tRow.TongbaoClass == "LI" and numLi < maxLi then
							table.insert(tTongbao,tRow.TongbaoType);
							numLi = numLi + 1;
						end
					end
				else
					return tTongbao;
				end
			end
		end
		return tTongbao;
	end

	function AddItem(TongbaoType:string)
		local new = m_TongbaoIM:GetInstance();
		local tongbaoInfo = GameInfo.Yan_Tongbao[TongbaoType];
		new.TongbaoIcon:SetTexture("ICON_"..TongbaoType);

		local tongbaoName = tongbaoInfo.Name or "LOC_" .. TongbaoType .. "_NAME";
		new.TongbaoName:SetText(Locale.ToUpper(tongbaoName));

		local tongbaoDescription = tongbaoInfo.Description or "LOC_" .. TongbaoType .. "_DESCRIPTION";
		new.TongbaoDescription:SetText(Locale.ToUpper(tongbaoDescription));

		new.SelectCheck:SetSelected(false);
		new.SelectCheck:RegisterCallback(Mouse.eLClick, function() OnTongbaoSelected(new, TongbaoType) end);
	end

	function OnTongbaoSelected(instance, TongbaoType)
		if not instance.SelectCheck:IsSelected() then
			m_SelectedTongbao[TongbaoType] = true;
			instance.SelectCheck:SetSelected(true);
			m_NumSelectedTongbao = m_NumSelectedTongbao + 1;
		else
			m_SelectedTongbao[TongbaoType] = false;
			instance.SelectCheck:SetSelected(false);
			m_NumSelectedTongbao = m_NumSelectedTongbao - 1;
		end

		if m_NumSelectedTongbao ~= m_NumAllowedTongbao then
			Controls.Confirm:SetDisabled(true);
		else
			Controls.Confirm:SetDisabled(false);
		end
	end

	function OnConfirm()
		local kParam = {};
		local iPlayer = Game.GetLocalPlayer();
		kParam.OnStart = "Mode_TongbaoSelected";
		kParam.tTongbao = m_SelectedTongbao;
		UI.RequestPlayerOperation(iPlayer, PlayerOperations.EXECUTE_SCRIPT, kParam);
		Network.BroadcastPlayerInfo();
		UI.PlaySound("Confirm_Dedication");

		ContextPtr:SetHide(true);
	end

--========================================================================================================================
--	UI CONTROLLER
--========================================================================================================================
	function OnInputHandler(pInputStruct:table)
		local uiMsg = pInputStruct:GetMessageType();
		if uiMsg == KeyEvents.KeyUp and pInputStruct:GetKey() == Keys.VK_ESCAPE then
			if not ContextPtr:IsHidden() then
				OnClose();
			end
			return true;
		end
		return false;
	end
	
	function RestartAnimations()
		Controls.AlphaIn:SetToBeginning();
		Controls.AlphaIn:Play();
	end

	function ShowPopup()
		ContextPtr:SetHide(false);
		RestartAnimations();
		LuaEvents.Mode_Tongbao_PanelOpened();
	end

	function OnClose()
		ContextPtr:SetHide(true);
		LuaEvents.Mode_Tongbao_PanelClosed();
	end

	function OnUpdateUI( type:number, tag:string, iData1:number, iData2:number, strData1:string)
		if type == SystemUpdateUI.ScreenResize then
			Resize();
		end
	end
	
	function Resize()
		local x, y	= UIManager:GetScreenSizeVal();
		ContextPtr:SetSizeX(x); ContextPtr:SetSizeY(y); 
	end

--========================================================================================================================
--	INIT
--========================================================================================================================
	function Initialize()
		ContextPtr:SetHide( true );
		ContextPtr:SetInputHandler( OnInputHandler, true );

		Controls.Confirm:RegisterCallback(Mouse.eLClick, OnConfirm);
		Controls.CloseButton:RegisterCallback(Mouse.eLClick, OnClose);

		-- Lua Events
		LuaEvents.Mode_Tongbao_TogglePopup.Add( CastTongbao );

		Events.SystemUpdateUI.Add(OnUpdateUI);
	end
Initialize();