-- CivilopediaPage_Ophidy_Tongbao
-- Author: Ophidy
-- DateCreated: 2/24/2026 2:39:37 AM
--------------------------------------------------------------
PageLayouts["Ophidy_Tongbao"] = function(page)
	local sectionId = page.SectionId;
	local pageId = page.PageId;
	SetPageHeader(page.Title);
	
	local tongbao = GameInfo.Yan_Tongbao[pageId];
	if(tongbao == nil) then
		return;
	end

	local tongbaoType		= tongbao.TongbaoType;
	local quote				= 'LOC_'..tongbaoType..'_QUOTE';
	local description		= tongbao.Description or 'LOC_'..tongbaoType..'_DESCRIPTION';
	
	AddTallImageNoScale("ICON_" .. tongbaoType);

	AddChapter("LOC_UI_CIVILOPEDIA_TONGBAO_CHAPTER", description);

	AddQuote(quote);
end