-- Mode_Tongbao_Script_Gameplay
-- Author: Ophidy
-- DateCreated: 2/21/2026 11:45:35 PM
--------------------------------------------------------------
include("SupportFunctions");

--========================================================================================================================
-- CORE
--========================================================================================================================
	--------------------------------------------------------------------
	-- Request Call
	--------------------------------------------------------------------
		function Mode_TongbaoSelected(iPlayer, kParam)
			local tTongbao = kParam.tTongbao;
			local iEra = Game.GetEras():GetCurrentEra();
			local sEraType = GameInfo.Eras[iEra].EraType;
			local pPlayer = Players[iPlayer];
			local effectiveTongbao = {};

			-- To avaid repeatly activate a Tongbao when playing Yan, remove the Tongbao we activate.
			local function Mode_Tongbao_RemoveFromEraChest(tongbaoType)
				local grandChest = pPlayer:GetProperty("Yan_Re_TongbaoChest");
				if grandChest then
					local eraChest = grandChest[iEra];
					local copied_table = {};
					for _, tRow in ipairs(eraChest) do
						if tRow.TongbaoType ~= tongbaoType then
							table.insert(copied_table,tRow);
						end
					end
					grandChest[iEra] = ShuffleTable(copied_table);
					pPlayer:SetProperty("Yan_Re_TongbaoChest",grandChest);
				end
			end

			for tongbaoType, activate in pairs(tTongbao) do
				if activate then
					local tModifiers = DB.Query("SELECT ModifierId FROM Yan_TongbaoModifiers WHERE TongbaoType = ?",tongbaoType)
					for _,tModifier in ipairs(tModifiers) do
						pPlayer:AttachModifierByID(tModifier.ModifierId .. "_" .. sEraType);
					end
					table.insert(effectiveTongbao,tongbaoType);
					Mode_Tongbao_RemoveFromEraChest(tongbaoType);
				end
			end
			
			pPlayer:SetProperty("Mode_EffectiveTongbao", effectiveTongbao);
			pPlayer:SetProperty("Mode_TongbaoActivated_" .. iEra, #effectiveTongbao);
			--TongbaoRefresh(iPlayer, true);
		end

	--------------------------------------------------------------------
	-- Init Table
	--------------------------------------------------------------------
		function InitPlayerTongbaoChest()
			for _, iPlayer in ipairs(PlayerManager.GetAliveMajorIDs()) do
				local iStartEra = GameInfo.Eras[GameConfiguration.GetStartEra()].Index;
				GenerateTongbaoChest(iPlayer,iStartEra)
			end
		end

		function GenerateTongbaoChest(iPlayer,iStartEra)
			local pPlayer = Players[iPlayer];
			local iEra = iStartEra;

			local EraTongbao = pPlayer:GetProperty("Mode_TongbaoChest") or {};
			if EraTongbao[iEra] then return; end
			
			repeat 
				local tRows = DB.Query("SELECT * FROM Yan_Tongbao");
				tRows = ShuffleTable(tRows);
				EraTongbao[iEra] = tRows;
				iEra = iEra + 1;
			until(not GameInfo.Eras[iEra]);

			pPlayer:SetProperty("Mode_TongbaoChest",EraTongbao);
		end

	--------------------------------------------------------------------
	-- ai handler
	--------------------------------------------------------------------
		function Ai_Handler(iPlayer)
			local pPlayer = Players[iPlayer];
			if pPlayer:IsHuman() then return; end
			local iEra = Game.GetEras():GetCurrentEra();
			local numActivating = pPlayer:GetProperty("Mode_TongbaoActivated_" .. iEra) or 0;
			local tTongbao = GetTongbao(iPlayer);
			local numAllowedTongbao = math.min((pPlayer:GetProperty("Mode_NumAllowedTongbao") or 1), #tTongbao);

			if numAllowedTongbao > numActivating then
				local tSelect = {};
				local eSelect = 0;
				for _, TongbaoType in ipairs(tTongbao) do
					if GameInfo.Yan_Tongbao[TongbaoType].TongbaoClass ~= "LI" then
						tSelect[TongbaoType] = true;
						eSelect = eSelect + 1;
						print(string.format("AI player %d Activate Tongbao %s",iPlayer,TongbaoType));
					end	
					if eSelect == numAllowedTongbao then
						Mode_TongbaoSelected(iPlayer,{tTongbao = tSelect});
						break;
					end
				end
			end
		end

		function GetTongbao(iPlayer)
			local pPlayer	= Players[iPlayer];
			local iEra		= GameInfo.Eras[Game.GetEras():GetCurrentEra()].Index;
			local numLi		= 0;
			local numHua	= 0;
			local tTongbao	= {};

			local maxCasts	= 4;
			local maxLi		= GameConfiguration.GetValue("Opd_MaxLiNum") or 1;
			local maxHua	= GameConfiguration.GetValue("Opd_MaxHuaNum") or 1;
		
			local Chest		= pPlayer:GetProperty("Mode_TongbaoChest") or {};
			local tRows		= Chest[iEra] or {};
			if #tRows > 0 then
				for _, tRow in ipairs(tRows) do
					if #tTongbao < maxCasts then
						-- To avaid repeatly activate a Tongbao when playing Yan, check if we've activated this Tongbao.
						local function Mode_TongbaoIsActivated(tongbaoType) 
							local tActive = pPlayer:GetProperty("Yan_Re_EffectiveTongbao") or {};
							for _, activeTongbao in ipairs(tActive) do
								if activeTongbao == tongbaoType then 
									return true;
								end
							end
							return false;
						end

						if not Mode_TongbaoIsActivated(tRow.TongbaoType) then
							if tRow.TongbaoClass == "HENG" then
								table.insert(tTongbao,tRow.TongbaoType);
							elseif tRow.TongbaoClass == "HUA" and numHua < maxHua then
								table.insert(tTongbao,tRow.TongbaoType);
								numHua = numHua + 1;
							elseif tRow.TongbaoClass == "LI" and numLi < maxLi then
								table.insert(tTongbao,tRow.TongbaoType);
								numLi = numLi + 1;
							end
						end
					else
						return tTongbao;
					end
				end
			end
			return tTongbao;
		end
--========================================================================================================================
-- INIT
--========================================================================================================================
	function Init()
		GameEvents.Mode_TongbaoSelected.Add(Mode_TongbaoSelected);

		if GameConfiguration.GetValue("Opd_Tongbao_AIEntry") or false then
			GameEvents.PlayerTurnStartComplete.Add(Ai_Handler);
		end
	end

		InitPlayerTongbaoChest();

Events.LoadScreenClose.Add(Init);

include("Mode_Tongbao_Script_Gameplay_Patch",true);