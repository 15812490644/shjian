-- Collectibles_Handler
-- Author: Ophidy
-- DateCreated: 9/3/2025 9:37:57 PM
--------------------------------------------------------------
include("CollectibleManager");

--========================================================================================================================
-- CONSTANTS
--========================================================================================================================

--========================================================================================================================
-- VARIABLES
--========================================================================================================================
local m_GameCollectibles	= {};

--========================================================================================================================
-- UTILS
--========================================================================================================================
	function CreateMultiCollectibles(iPlayer,num)
		if type(num) ~= 'number' then return; end
		for i=1, num do
			CollectibleManager.GetCollectibles(iPlayer):CreateRandomCollectible({applyRarityBonus = true});
		end
	end

	function CreateInitMultiCollectibles(iPlayer,num)
		if type(num) ~= 'number' then return; end
		for i=1, num do
			CollectibleManager.GetCollectibles(iPlayer):CreateRandomCollectible({maxRarity = GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_MAX_RARITY_INIT, applyRarityBonus = true});
		end
	end

--========================================================================================================================
-- CORE
--========================================================================================================================
	function Iterator(iPlayer)
		local pPlayer = Players[iPlayer];
		local iStartEra = GameInfo.Eras[GameConfiguration.GetStartEra()].Index;
		local iEra = Game.GetEras():GetCurrentEra();

		if pPlayer:IsHuman() then
			--[[
			local Activatings = CollectibleManager.GetCollectibles(iPlayer):GetCollectiblesActivating();
			for iCollectible , cooldown in pairs(Activatings) do
				CollectibleManager.GetCollectibles(iPlayer):ChangeCollectibleCooldown(iCollectible);
			end
			]]--
			CollectibleManager.GetCollectibles(iPlayer):ChangeCollectiblesCooldown();

			local b = pPlayer:GetProperty("COLLECTIBLES_GOT_MEETING_GIFT") or false;
			if not b then
				local num = GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_ERA_CHANGE_GIFT * iStartEra + GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_MEETING_GIFT;
				CreateInitMultiCollectibles(iPlayer,num);
				CollectibleManager.GetCollectibles(iPlayer):GenerateGoods();
				pPlayer:SetProperty("COLLECTIBLES_GOT_MEETING_GIFT",true);
			end

			local b = pPlayer:GetProperty("COLLECTIBLES_GOT_ERA_CHANGE_GIFT_"..iEra) or false;
			if not b then
				if iStartEra ~= iEra then
					local num = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_ERA_CHANGE_GIFT") or GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_ERA_CHANGE_GIFT;
					CreateMultiCollectibles(iPlayer,num);
					CollectibleManager.GetCollectibles(iPlayer):GenerateGoods();
					pPlayer:SetProperty("COLLECTIBLES_GOT_ERA_CHANGE_GIFT_"..iEra,true);
				end
			end


			-- ===========================================================================
			--	TOKEN
			-- ===========================================================================
			local iEra = Game.GetEras():GetCurrentEra(); -- 0 for ancient.
			local Score = pPlayer:GetScore() or 0;
			local Stored = pPlayer:GetProperty("COLLECTIBLES_SCORE_STORED") or 0;
			local Increment = 0;
			-- Score
			local ScoreChange = Score - Stored;
			local Increment = Increment + ScoreChange;
			-- Interest
			local Token = CollectibleManager.GetCollectibles(iPlayer):GetToken();
			local InterestRate = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_TURN_TOKEN_INTEREST") or 0;
			local InterestChange = Token * InterestRate / 100;
			local InterestChange = math.min(InterestChange, (GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_MAX_INTEREST or 100));
			Increment = Increment + InterestChange;
			-- Era Wage
			local EraWage = iEra + 1;
			EraWage = EraWage * (1 + iEra * (GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS or 0.3));
			Increment = Increment + EraWage;
			-- Change By Era
			local ChangeEra = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_TURN_TOKEN_CHANGE_BY_ERA") or 0;
			ChangeEra = ChangeEra * (1 + iEra * (GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS or 0.3));
			Increment = Increment + ChangeEra;
			-- Normal Change
			local ChangeNormal = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_TURN_TOKEN_CHANGE") or 0;
			Increment = Increment + ChangeNormal;
			-- Modifier
			local Modifier = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_TURN_TOKEN_MODIFIER") or 0;
			local ChangeModifier = Increment * Modifier / 100;
			Increment = Increment + ChangeModifier;
			-- Game Multiplier
			local GameMultiplier = tonumber(GameConfiguration.GetValue("Opd_GameTokenMultiplier") or 10) / 10;
			Increment = Increment * GameMultiplier;

			CollectibleManager.GetCollectibles(iPlayer):ChangeToken(Increment);

			pPlayer:SetProperty("COLLECTIBLES_SCORE_STORED", Score);
			pPlayer:SetProperty("COLLECTIBLES_SCORE_CHANGED_INFO", 
				{
					Increment = Increment,
					ScoreChange = ScoreChange,
					InterestRate = InterestRate,
					InterestChange = InterestChange,
					EraWage = EraWage,
					ChangeEra = ChangeEra,
					ChangeNormal = ChangeNormal,
					Modifier = Modifier,
					ChangeModifier = ChangeModifier
				}
			);
		end
	end

	function Request_Ophidy_Collectibles_Activate(iPlayer,kParam)
		local Collectibles = kParam.Collectibles;
		for iCollectible , activate in pairs(Collectibles) do
			if activate then
				CollectibleManager.GetCollectibles(iPlayer):ActivateCollectible(iCollectible);
			end
		end
	end
	
	function Request_Ophidy_Collectibles_Purchase(iPlayer,kParam)
		local iCollectible,Cost = kParam.iCollectible,kParam.Cost;
		CollectibleManager.GetCollectibles(iPlayer):PurchaseGood(iCollectible,Cost);
	end
	
	function Request_Ophidy_Collectibles_Discover(iPlayer,kParam)
		local tBatch, iCollectible = kParam.tBatch, kParam.iCollectible;
		CollectibleManager.GetCollectibles(iPlayer):CreateDiscover(tBatch, iCollectible);
	end

	function Request_Ophidy_Collectibles_RefreshGoods(iPlayer,kParam)
		local pPlayer = Players[iPlayer];
		local Num = kParam.Num;
		local iEra = Game.GetEras():GetCurrentEra();
		if Num > 0 then
			pPlayer:SetProperty("COLLECTIBLES_GOODS_REFRESHED_ERA_" .. iEra, Num - 1);
			CollectibleManager.GetCollectibles(iPlayer):GenerateGoods();
		end
	end
	
--========================================================================================================================
-- INIT
--========================================================================================================================
	function Init()
		GameEvents.PlayerTurnStartComplete.Add(Iterator);
		GameEvents.Request_Ophidy_Collectibles_Activate.Add(Request_Ophidy_Collectibles_Activate);
		GameEvents.Request_Ophidy_Collectibles_Purchase.Add(Request_Ophidy_Collectibles_Purchase);
		GameEvents.Request_Ophidy_Collectibles_Discover.Add(Request_Ophidy_Collectibles_Discover);
		GameEvents.Request_Ophidy_Collectibles_RefreshGoods.Add(Request_Ophidy_Collectibles_RefreshGoods);
	end

Events.LoadScreenClose.Add(Init);