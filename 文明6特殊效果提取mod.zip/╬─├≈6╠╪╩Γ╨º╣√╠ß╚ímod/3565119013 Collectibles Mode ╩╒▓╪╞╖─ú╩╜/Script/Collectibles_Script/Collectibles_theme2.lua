-- Collectibles_theme2
-- Author: Ophidy
-- DateCreated: 4/29/2026 7:41:26 PM
--------------------------------------------------------------
include("CollectibleManager");

--========================================================================================================================
-- CONSTANTS 
--========================================================================================================================
local SpeedMultiplier 					:number = GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;

local SOLO_MUSIC_BOX					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_SOLO_MUSIC_BOX"].Index;
local ADMIN_ACCESS_CARD					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ADMIN_ACCESS_CARD"].Index;
local REGIONAL_ACTION_PLAN				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_REGIONAL_ACTION_PLAN"].Index;
local DUCK_LORDS_GOLDEN_BRICK			:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_DUCK_LORDS_GOLDEN_BRICK"].Index;
local CLAIRVOYANTS_REVEAL				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_CLAIRVOYANTS_REVEAL"].Index;
local CEREMONY_BELL						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_CEREMONY_BELL"].Index;
local ANCIENT_TREE_FRUIT				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ANCIENT_TREE_FRUIT"].Index;
local BOUNDLESS_GIFT					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_BOUNDLESS_GIFT"].Index;
local AMMAS_AFFECTION					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_AMMAS_AFFECTION"].Index;

--========================================================================================================================
-- VARIABLES 
--========================================================================================================================
ActivateFunc = {};
AddedFunc = {};
	--===================================================================================
	ActivateFunc[SOLO_MUSIC_BOX] = function(iPlayer,iCollectible,PlayerCollectibles)
		local eraScore = ExposedMembers.Ophidy_Collectibles.GetCurrentEraScore(iPlayer);
		PlayerCollectibles:ChangeToken(eraScore);
	end

	ActivateFunc[ADMIN_ACCESS_CARD] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:RemoveCollectible(iCollectible);
		PlayerCollectibles:CreateRandomCollectible({minRarity = 5});
	end

	ActivateFunc[REGIONAL_ACTION_PLAN] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateGoods();
	end

	ActivateFunc[DUCK_LORDS_GOLDEN_BRICK] = function(iPlayer,iCollectible,PlayerCollectibles)
		local Token = PlayerCollectibles:GetToken();
		local Modifier = Game.GetRandNum(80) + 20;
		PlayerCollectibles:ChangeToken(Token * Modifier / 100);
	end

	ActivateFunc[CLAIRVOYANTS_REVEAL] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateGoods();
	end

	ActivateFunc[CEREMONY_BELL] = function(iPlayer,iCollectible,PlayerCollectibles)
		local pPlayer = Players[iPlayer];
		local faithBalance = pPlayer:GetReligion():GetFaithBalance() or 0;
		local amount = math.ceil(faithBalance / 2);
		pPlayer:GetTechs():ChangeCurrentResearchProgress(amount);
		pPlayer:GetCulture():ChangeCurrentCulturalProgress(amount);
		PlayerCollectibles:ChangeToken(amount);
		pPlayer:GetReligion():ChangeFaithBalance(-faithBalance);
	end

	ActivateFunc[ANCIENT_TREE_FRUIT] = function(iPlayer,iCollectible,PlayerCollectibles)
		local collectiblesInfo = PlayerCollectibles:GetCollectiblesInfo();
		local amount = 0;
		for iCollectible, kCollectible in pairs(collectiblesInfo) do
			amount = amount + kCollectible.Rarity * kCollectible.StackCount;
		end

		local iEra = Game.GetEras():GetCurrentEra();
		amount = amount * (1 + iEra * (GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS or 0.3));
		PlayerCollectibles:ChangeToken(amount);
	end

	ActivateFunc[BOUNDLESS_GIFT] = function(iPlayer,iCollectible,PlayerCollectibles)
		local rarity = Game.GetRandNum(6) + 1;
		PlayerCollectibles:CreateRandomCollectible({minRarity = rarity, maxRarity = rarity});
	end

	ActivateFunc[AMMAS_AFFECTION] = function(iPlayer,iCollectible,PlayerCollectibles)
		local activatings = PlayerCollectibles:GetCollectiblesActivating();
		for activatingId, cooldown in pairs(activatings) do
			if activatingId ~= iCollectible and cooldown > 0 then
				PlayerCollectibles:ReleaseCollectible(activatingId);
			end
		end
	end

	--===================================================================================
	AddedFunc[ANCIENT_TREE_FRUIT] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:CreateRandomCollectible({maxRarity = 3});
		PlayerCollectibles:CreateRandomCollectible({maxRarity = 3});
		PlayerCollectibles:CreateRandomCollectible({maxRarity = 3});
	end
	
--========================================================================================================================
-- CORE
--========================================================================================================================
	function OnCollectibleActivated(kParam)
		local iPlayer,iCollectible = kParam.iPlayer , kParam.iCollectible;
		local PlayerCollectibles = CollectibleManager.GetCollectibles(iPlayer);

		if ActivateFunc[iCollectible] then
			ActivateFunc[iCollectible](iPlayer,iCollectible,PlayerCollectibles);
		end
	end

	function OnCollectibleAdded(kParam)
		local iPlayer,iCollectible = kParam.iPlayer , kParam.iCollectible;
		local PlayerCollectibles = CollectibleManager.GetCollectibles(iPlayer);
		
		if AddedFunc[iCollectible] then
			AddedFunc[iCollectible](iPlayer,iCollectible,PlayerCollectibles);
		end
	end

	function SurgingFeast_UnitDamageChanged(iPlayer,iUnit,newDamage)
		local pPlayer = Players[iPlayer];
		local key = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_SURGING_FEAST_KEY") or 0;
		if key > 0 then
			local pUnit = UnitManager.GetUnit(iPlayer,iUnit);
			if pUnit then
				local maxHP = pUnit:GetMaxDamage();
				local curHP = maxHP - newDamage;
				if curHP <= 20 or pUnit:IsDead() or pUnit:IsDelayedDeath() then
					local baseStrength = pUnit:GetCombat() or 0;
					pPlayer:GetTechs():ChangeCurrentResearchProgress(baseStrength * 2);
					pPlayer:GetCulture():ChangeCurrentCulturalProgress(baseStrength * 2);
					pPlayer:GetTreasury():ChangeGoldBalance(baseStrength * 2);

					UnitManager.Kill(pUnit);
				end
			end
		end 
	end

	function RouteweaveNet_OnCollectiblePurchased(kParam)
		local iPlayer, iCollectible, iCost = kParam.iPlayer, kParam.iCollectible, kParam.iCost;
		local pPlayer = Players[iPlayer];
		local key = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_ROUTEWEAVE_NET_KEY") or 0;
		if key > 0 then
			local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
			CollectibleManager.GetCollectibles(iPlayer):GenerateDiscover({maxRarity = collectibleData.Rarity});
		end
	end

	function CeremonyBell_OnCollectiblePurchased(kParam)
		local iPlayer, iCollectible, iCost = kParam.iPlayer, kParam.iCollectible, kParam.iCost;
		local pPlayer = Players[iPlayer];
		local key = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_CEREMONY_BELL_KEY") or 0;
		if key > 0 then
			pPlayer:GetReligion():ChangeFaithBalance(eCost);
		end
	end

--========================================================================================================================
-- INIT
--========================================================================================================================
	function Init()
		LuaEvents.Ophidy_Collectible_Activated.Add(			OnCollectibleActivated					);
		LuaEvents.Ophidy_Collectible_Added.Add(				OnCollectibleAdded						);
		LuaEvents.Ophidy_Collectible_Goods_Purchased.Add(	RouteweaveNet_OnCollectiblePurchased	);
		LuaEvents.Ophidy_Collectible_Goods_Purchased.Add(	CeremonyBell_OnCollectiblePurchased		);
				
		Events.UnitDamageChanged.Add(						SurgingFeast_UnitDamageChanged			);
	end

Events.LoadScreenClose.Add(Init);

include("Collectibles_theme2_Addition_",true);