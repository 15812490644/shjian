-- Collectibles_theme1
-- Author: Ophidy
-- DateCreated: 9/4/2025 10:39:37 PM
--------------------------------------------------------------
include("CollectibleManager");

--========================================================================================================================
-- CONSTANTS 
--========================================================================================================================
local SpeedMultiplier 					:number = GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;

local PROFF_OF_LONGEVITY				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_PROOF_OF_LONGEVITY"].Index;
local PRIED_OPEN_TOOLBOX				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_PRIED_OPEN_TOOLBOX"].Index;
local LETTER_OF_TERMINATION_CONTRACT	:number = GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_LETTER_OF_TERMINATION_CONTRACT"].Index;
local LAUGHING_JOKER					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_LAUGHING_JOKER"].Index;
local PETTING_TICKET					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_PETTING_TICKET"].Index;
local ANTIQUE_CASTING					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ANTIQUE_CASTING"].Index;
local DRAFT_OF_A_SPEECH					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_DRAFT_OF_A_SPEECH"].Index;
local FOURLEAF_CLOVER_FOSSIL			:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_FOURLEAF_CLOVER_FOSSIL"].Index;
local WORNOUT_GROUP_PHOTO				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_WORNOUT_GROUP_PHOTO"].Index;
local GOLDPLATED_DICE					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_GOLDPLATED_DICE"].Index;
--local PROFOUND_SILENCE					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_PROFOUND_SILENCE"].Index;
local BRILLIANT_LAMENT					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_BRILLIANT_LAMENT"].Index;
local DREAMBIND_CASTLE_MODEL			:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_DREAMBIND_CASTLE_MODEL"].Index;
local GLASS_BIRD						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_GLASS_BIRD"].Index;
local ORIGINIUM_IRIS					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ORIGINIUM_IRIS"].Index;
local PURE_GOLD_EXPEDITION				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_PURE_GOLD_EXPEDITION"].Index;
local DREAMING_ESSENCE					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_DREAMING_ESSENCE"].Index;
local COIN_OPERATED_TOY					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_COIN_OPERATED_TOY"].Index;
local GOLDEN_CHALICE					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_GOLDEN_CHALICE"].Index;
local ROYAL_ALLIANCE_TREATY				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ROYAL_ALLIANCE_TREATY"].Index;
local VICTORIA_CROWN					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_VICTORIA_CROWN"].Index;
local VICTORIA_CROWN_REFORGED			:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_VICTORIA_CROWN_REFORGED"].Index;
local LEITHANIEN_SCEPTRE				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_LEITHANIEN_SCEPTRE"].Index;
local LEITHANIEN_SCEPTRE_REFORGED		:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_LEITHANIEN_SCEPTRE_REFORGED"].Index;
local GAUL_MANTLE						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_GAUL_MANTLE"].Index;
local GAUL_MANTLE_REFORGED				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_GAUL_MANTLE_REFORGED"].Index;
local WHITEFLOWER						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_WHITEFLOWER"].Index;
local USELESS_SCISSORS					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_USELESS_SCISSORS"].Index;
local ROYAL_BROOCH						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ROYAL_BROOCH"].Index;
local TACTICAL_TRANSCEIVER				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_TACTICAL_TRANSCEIVER"].Index;
local ELYSEE_PURSE						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ELYSEE_PURSE"].Index;
local SECRET_HR_LETTER					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_SECRET_HR_LETTER"].Index;
local LUCKY_COIN						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_LUCKY_COIN"].Index;

--========================================================================================================================
-- VARIABLES 
--========================================================================================================================
ActivateFunc = {};
AddedFunc = {};
	--===================================================================================
	ActivateFunc[PROFF_OF_LONGEVITY] = function(iPlayer,iCollectible,PlayerCollectibles)
		local Existings = PlayerCollectibles:GetExistings();
		local iCollectible;
		local LowestRarity = 6;
		for _ , index in pairs(Existings) do
			local tRow = GameInfo.Ophidy_Collectibles[index];
			if not tRow.Unchangeable and tRow.Rarity < LowestRarity then
				iCollectible = index;
				LowestRarity = tRow.Rarity;
				if LowestRarity == 1 then
					break;
				end
			end
		end
		if iCollectible then
			PlayerCollectibles:RemoveCollectible(iCollectible);
			PlayerCollectibles:CreateRandomCollectible({minRarity = LowestRarity+1,maxRarity = LowestRarity+1});
		end
		return;
	end
	--===================================================================================
	ActivateFunc[LETTER_OF_TERMINATION_CONTRACT] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:RemoveCollectible(iCollectible);
		local Rarity = GameInfo.Ophidy_Collectibles[iCollectible].Rarity;
		PlayerCollectibles:CreateRandomCollectible({minRarity = Rarity+1, maxRarity = Rarity+1});
	end
	--===================================================================================
	ActivateFunc[LAUGHING_JOKER] = function(iPlayer,iCollectible,PlayerCollectibles)
		local Existings = PlayerCollectibles:GetExistings();
		local HighestRarity = 1;
		for _ , index in pairs(Existings) do
			local tRow = GameInfo.Ophidy_Collectibles[index];
			if tRow.Rarity > HighestRarity then
				HighestRarity = tRow.Rarity;
				if HighestRarity == 6 then
					break;
				end
			end
		end

		HighestRarity = math.min(HighestRarity,4);

		PlayerCollectibles:RemoveCollectible(iCollectible);
		PlayerCollectibles:CreateRandomCollectible({minRarity = HighestRarity, maxRarity = HighestRarity});
	end
	--===================================================================================
	ActivateFunc[ANTIQUE_CASTING] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateDiscover();
	end
	--===================================================================================
	ActivateFunc[DRAFT_OF_A_SPEECH] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateGoods();
	end
	--===================================================================================
	ActivateFunc[FOURLEAF_CLOVER_FOSSIL] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateDiscover();
	end
	--===================================================================================
	ActivateFunc[WORNOUT_GROUP_PHOTO] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:CreateRandomCollectible({maxRarity = 1});
	end
	--===================================================================================
	ActivateFunc[GOLDPLATED_DICE] = function(iPlayer,iCollectible,PlayerCollectibles)
		local Token = PlayerCollectibles:GetToken();
		local Modifier = Game.GetRandNum(41) - 20;
		PlayerCollectibles:ChangeToken(Token * Modifier / 100);
	end
	--===================================================================================
	--[[ 
	ActivateFunc[PROFOUND_SILENCE] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:CreateRandomCollectible();
	end
	]]--
	--===================================================================================
	ActivateFunc[BRILLIANT_LAMENT] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:RemoveCollectible(iCollectible);
		PlayerCollectibles:CreateRandomCollectible({maxRarity = 3});
		PlayerCollectibles:CreateRandomCollectible({maxRarity = 3});
	end
	--===================================================================================
	ActivateFunc[DREAMBIND_CASTLE_MODEL] = function(iPlayer,iCollectible,PlayerCollectibles)
		local pPlayer = Players[iPlayer];
		local EraScores = ExposedMembers.Ophidy_Collectibles.GetGoldenEraScore(iPlayer);
		Game.GetEras():ChangePlayerEraScore(iPlayer, EraScores);
	end
	--===================================================================================
	ActivateFunc[GLASS_BIRD] = function(iPlayer,iCollectible,PlayerCollectibles)
		local pPlayer = Players[iPlayer];
		local CultureYield = pPlayer:GetCulture():GetCultureYield();
		PlayerCollectibles:ChangeToken(CultureYield * 0.3);
	end
	--===================================================================================
	ActivateFunc[ORIGINIUM_IRIS] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateGoods({extraNum = 1});
	end
	--===================================================================================
	ActivateFunc[PURE_GOLD_EXPEDITION] = function(iPlayer,iCollectible,PlayerCollectibles)
		local pPlayer = Players[iPlayer];
		local GoldYield = pPlayer:GetTreasury():GetGoldYield();
		PlayerCollectibles:ChangeToken(GoldYield * 0.5);
	end
	--===================================================================================
	ActivateFunc[DREAMING_ESSENCE] = function(iPlayer,iCollectible,PlayerCollectibles)
		local Goods = PlayerCollectibles:GetGoods();
		if #Goods > 0 then
			local iCollectible = Goods[Game.GetRandNum(#Goods) + 1].Index;
			PlayerCollectibles:PurchaseGood(iCollectible,0);
		end
	end
	--===================================================================================
	ActivateFunc[COIN_OPERATED_TOY] = function(iPlayer,iCollectible,PlayerCollectibles)
		local pPlayer = Players[iPlayer];
		local pPlayerCulture = pPlayer:GetCulture();
		local pPlayerTech = pPlayer:GetTechs();
		local Token = PlayerCollectibles:GetToken();
		local Amount = Token * 0.25;
		PlayerCollectibles:ChangeToken(-Amount);
		pPlayerCulture:ChangeCurrentCulturalProgress(Amount);
		pPlayerTech:ChangeCurrentResearchProgress(Amount);
	end
	--===================================================================================
	ActivateFunc[GOLDEN_CHALICE] = function(iPlayer,iCollectible,PlayerCollectibles)
		local iEra = Game.GetEras():GetCurrentEra();
		local Rarity = PlayerCollectibles:DetermineRarity(1,6);
		local Amount = GlobalParameters["PARAMETER_OPHIDY_COLLECTIBLE_COST_"..tostring(Rarity)] or 0;
		Amount = Amount * (1 + iEra * GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS) * SpeedMultiplier;
		PlayerCollectibles:ChangeToken(Amount);
	end
	--===================================================================================
	ActivateFunc[ROYAL_ALLIANCE_TREATY] = function(iPlayer,iCollectible,PlayerCollectibles)
		local pPlayer = Players[iPlayer];
		if Players[63] then
			pPlayer:GetDiplomacy():MakePeaceWith(63,true);
		end
	end
	--===================================================================================
	ActivateFunc[VICTORIA_CROWN] = function(iPlayer,iCollectible,PlayerCollectibles)
		local luck = Players[iPlayer]:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_EXTRA_LUCKY") or 0;
		local tossVal = Game.GetRandNum(100,"Reforge");
		local needVal = 10 * ((luck + 30) / 30);
		--print(string.format("Try reforge %s, toss val: %d, luck: %d, need val: %d",GameInfo.Ophidy_Collectibles[iCollectible].CollectibleType,tossVal,luck,needVal));
		if tossVal < needVal then
			PlayerCollectibles:RemoveCollectible(iCollectible);
			PlayerCollectibles:CreateCollectible(GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_VICTORIA_CROWN_REFORGED"].Index,true);
		end
	end
	--===================================================================================
	ActivateFunc[VICTORIA_CROWN_REFORGED] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateDiscover({minRarity = 3});
	end
	--===================================================================================
	ActivateFunc[LEITHANIEN_SCEPTRE] = function(iPlayer,iCollectible,PlayerCollectibles)
		local luck = Players[iPlayer]:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_EXTRA_LUCKY") or 0;
		local tossVal = Game.GetRandNum(100,"Reforge");
		local needVal = 10 * ((luck + 30) / 30);
		--print(string.format("Try reforge %s, toss val: %d, luck: %d, need val: %d",GameInfo.Ophidy_Collectibles[iCollectible].CollectibleType,tossVal,luck,needVal));
		if tossVal < needVal then
			PlayerCollectibles:RemoveCollectible(iCollectible);
			PlayerCollectibles:CreateCollectible(GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_LEITHANIEN_SCEPTRE_REFORGED"].Index,true);
		end
	end
	--===================================================================================
	ActivateFunc[LEITHANIEN_SCEPTRE_REFORGED] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:CreateRandomCollectible({minRarity = 4});
	end
	--===================================================================================
	ActivateFunc[GAUL_MANTLE] = function(iPlayer,iCollectible,PlayerCollectibles)
		local luck = Players[iPlayer]:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_EXTRA_LUCKY") or 0;
		local tossVal = Game.GetRandNum(100,"Reforge");
		local needVal = 10 * ((luck + 30) / 30);
		--print(string.format("Try reforge %s, toss val: %d, luck: %d, need val: %d",GameInfo.Ophidy_Collectibles[iCollectible].CollectibleType,tossVal,luck,needVal));
		if tossVal < needVal then
			PlayerCollectibles:RemoveCollectible(iCollectible);
			PlayerCollectibles:CreateCollectible(GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_GAUL_MANTLE_REFORGED"].Index,true);
		end
	end
	--===================================================================================
	ActivateFunc[GAUL_MANTLE_REFORGED] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateDiscover({minRarity = 3});
	end
	--===================================================================================
	ActivateFunc[WHITEFLOWER] = function(iPlayer,iCollectible,PlayerCollectibles)
		local pPlayer = Players[iPlayer];
		local pCapital = pPlayer:GetCities():GetCapitalCity();
		if not pCapital then return false; end
		local iX,iY = pCapital:GetX(),pCapital:GetY();
		local Units = DB.Query("SELECT * FROM Units WHERE TraitType IS NOT NULL AND FormationClass = 'FORMATION_CLASS_LAND_COMBAT'");
		local Count = 0;
		while #Units > 0 and Count < 3 do
			local Unit = table.remove(Units,Game.GetRandNum(#Units)+1);
			if Unit.PrereqTech and pPlayer:GetTechs():HasTech(GameInfo.Technologies[Unit.PrereqTech].Index) then
				UnitManager.InitUnit(iPlayer, Unit.UnitType, iX,iY);
				Count = Count + 1;
			elseif Unit.PrereqCivic and pPlayer:GetCulture():HasCivic(GameInfo.Civics[Unit.PrereqCivic].Index) then
				UnitManager.InitUnit(iPlayer, Unit.UnitType, iX,iY);
				Count = Count + 1;
			elseif (not Unit.PrereqTech) and (not Unit.PrereqCivic) then
				UnitManager.InitUnit(iPlayer, Unit.UnitType, iX,iY);
				Count = Count + 1;
			end
		end
	end
	--===================================================================================
	ActivateFunc[USELESS_SCISSORS] = function(iPlayer,iCollectible,PlayerCollectibles)
		local iEra = Game.GetEras():GetCurrentEra();
		PlayerCollectibles:RemoveCollectible(iCollectible);
		local Amount = GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_COST_3 or 0;
		Amount = Amount * (1 + iEra * GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS) * SpeedMultiplier;
		PlayerCollectibles:ChangeToken(Amount);
	end
	--===================================================================================
	ActivateFunc[ROYAL_BROOCH] = function(iPlayer,iCollectible,PlayerCollectibles)
		local pPlayer = Players[iPlayer];
		local Amount = pPlayer:GetTreasury():GetGoldBalance();
		Amount = Amount * 0.1;
		pPlayer:GetTreasury():ChangeGoldBalance(-Amount);
		PlayerCollectibles:ChangeToken(Amount);
	end
	--===================================================================================
	ActivateFunc[TACTICAL_TRANSCEIVER] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateDiscover({maxRarity = 2});
	end
	--===================================================================================
	ActivateFunc[ELYSEE_PURSE] = function(iPlayer,iCollectible,PlayerCollectibles)
		local Rarity = PlayerCollectibles:DetermineRarity(1,6);
		local Amount = GlobalParameters["PARAMETER_OPHIDY_COLLECTIBLE_COST_"..tostring(Rarity)] or 0;
		Amount = Game.GetRandNum(Amount);
		PlayerCollectibles:RemoveCollectible(iCollectible);
		PlayerCollectibles:ChangeToken(Amount);
	end
	--===================================================================================
	ActivateFunc[SECRET_HR_LETTER] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateDiscover({maxRarity = 2});
	end
	--===================================================================================
	ActivateFunc[LUCKY_COIN] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:CreateCollectible(iCollectible);
	end
	--===================================================================================
	AddedFunc[PRIED_OPEN_TOOLBOX] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:CreateRandomCollectible();
	end
	--===================================================================================
	AddedFunc[PETTING_TICKET] = function(iPlayer,iCollectible,PlayerCollectibles)
		PlayerCollectibles:GenerateDiscover();
		PlayerCollectibles:GenerateDiscover();
	end

--========================================================================================================================
-- CORE
--========================================================================================================================
	function OnCollectibleActivated(kParam)
		local iPlayer,iCollectible = kParam.iPlayer , kParam.iCollectible;

		local PlayerCollectibles = CollectibleManager.GetCollectibles(iPlayer);

		if ActivateFunc[iCollectible] then
			ActivateFunc[iCollectible](iPlayer,iCollectible,PlayerCollectibles);
		end
	end


	function OnCollectibleAdded(kParam)
		local iPlayer,iCollectible = kParam.iPlayer , kParam.iCollectible;

		local PlayerCollectibles = CollectibleManager.GetCollectibles(iPlayer);
		
		if AddedFunc[iCollectible] then
			AddedFunc[iCollectible](iPlayer,iCollectible,PlayerCollectibles);
		end
	end


	function Avenger_CityConquered(iPlayer,iEx,iCity,iX,iY)
		local pCity = CityManager.GetCity(iPlayer,iCity);
		local pPlayer = Players[iPlayer];
		local pEx = Players[iEx];
		local Key = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_AVENGER_KEY") or 0;
		local Triggered = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_AVENGER_KEY_TRIGGERED") or false;
		--print("CityConquered",Key,Triggered);
		if Key > 0 and pEx:IsMajor() and not Triggered then
			local PlayerCollectibles = CollectibleManager.GetCollectibles(iPlayer);
			PlayerCollectibles:CreateRandomCollectible({minRarity = 5, maxRarity = 6});
			pPlayer:SetProperty("PARAMETER_OPHIDY_COLLECTIBLE_AVENGER_KEY_TRIGGERED", true);
			return;
		end
	end

	function OriginiumIris_OnCollectiblePurchased(kParam)
		local iPlayer, iCollectible, iCost = kParam.iPlayer, kParam.iCollectible, kParam.iCost;

		local pPlayer = Players[iPlayer];
		local PlayerCollectibles = CollectibleManager.GetCollectibles(iPlayer);

		local OriginiumIris = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_ORIGINIUM_IRIS_KEY") or 0;
		if OriginiumIris > 0 then
			PlayerCollectibles:ChangeToken(iCost * 0.1);
			pPlayer:GetCulture():ChangeCurrentCulturalProgress(iCost * 0.1);
		end
	end

	function Nachzehrers_OnUnitDamageChanged(iPlayer, iUnit, newDamage, prevDamage)	
		local pPlayer = Players[iPlayer];
		local Amount = newDamage - prevDamage;
		local Value = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_NACHZEHRERS_CANE_KEY") or 0;
		if Amount < 0 then
			pPlayer:GetCulture():ChangeCurrentCulturalProgress(-Amount * Value);
			pPlayer:GetTechs():ChangeCurrentResearchProgress(-Amount * Value);
		end
	end

--========================================================================================================================
-- INIT
--========================================================================================================================
	function Init()
		LuaEvents.Ophidy_Collectible_Activated.Add(			OnCollectibleActivated					);
		LuaEvents.Ophidy_Collectible_Added.Add(				OnCollectibleAdded						);
		LuaEvents.Ophidy_Collectible_Goods_Purchased.Add(	OriginiumIris_OnCollectiblePurchased	);

		GameEvents.CityConquered.Add(						Avenger_CityConquered					);
		Events.UnitDamageChanged.Add(						Nachzehrers_OnUnitDamageChanged			);
	end

Events.LoadScreenClose.Add(Init);

include("Collectibles_theme1_Addition_",true);