-- CivilopediaPage_Ophidy_Collectibles
-- Author: Ophidy
-- DateCreated: 9/9/2025 2:22:53 AM
--------------------------------------------------------------
PageLayouts["Ophidy_Collectibles"] = function(page)
	local sectionId = page.SectionId;
	local pageId = page.PageId;
	SetPageHeader(page.Title);
	
	local tCollectible = GameInfo.Ophidy_Collectibles[pageId];
	if(tCollectible == nil) then
		return;
	end

	local CollectibleType	= tCollectible.CollectibleType;
	local Description		= tCollectible.Description;
	local BirthDesc			= tCollectible.BirthDesc;
	local ActiveDesc		= tCollectible.ActiveDesc;
	local Rarity			= tCollectible.Rarity;
	local Cost				= tCollectible.Cost;
	local MustPurchase		= tCollectible.MustPurchase;
	local Tradable			= tCollectible.Tradable;
	local Cooldown			= tCollectible.Cooldown;
	local TraitType			= tCollectible.TraitType;

	local unique_to = {};
	if(TraitType) then
		for row in GameInfo.LeaderTraits() do
			if(row.TraitType == TraitType) then
				local leader = GameInfo.Leaders[row.LeaderType];
				if(leader) then
					-- If this is a city state, use the civilization type.
					local city_state_civilization = city_state_leaders[row.LeaderType];
					if(city_state_civilization) then
						local civ = GameInfo.Civilizations[city_state_civilization];
						if(civ) then
							table.insert(unique_to, {"ICON_" .. civ.CivilizationType, civ.Name, civ.CivilizationType});
						end
					else
						table.insert(unique_to, {"ICON_" .. row.LeaderType, leader.Name, row.LeaderType});
					end
				end
			end
		end

		for row in GameInfo.CivilizationTraits() do
			if(row.TraitType == TraitType) then
				local civ = GameInfo.Civilizations[row.CivilizationType];
				if(civ) then
					table.insert(unique_to, {"ICON_" .. row.CivilizationType, civ.Name, row.CivilizationType});
				end
			end
		end
	end
	
	AddTallImageNoScale("ICON_" .. CollectibleType);

	AddQuote(Description);

	AddRightColumnStatBox("LOC_UI_PEDIA_TRAITS",
			function(s)
				s:AddSeparator();

				if(#unique_to > 0) then
					s:AddHeader("LOC_UI_PEDIA_UNIQUE_TO");
					for _, icon in ipairs(unique_to) do
						s:AddIconLabel(icon, icon[2]);
					end
					
					s:AddSeparator();
				end

				s:AddLabel("[ICON_Bullet] " .. Locale.Lookup("LOC_UI_CIVILOPEDIA_COLLECTIBLES_RARITY",Rarity));

				s:AddLabel("[ICON_Bullet] " .. Locale.Lookup("LOC_UI_CIVILOPEDIA_COLLECTIBLES_COOLDOWN",Cooldown));

				s:AddSeparator();

				s:AddLabel("[ICON_Bullet] " .. Locale.Lookup("LOC_UI_CIVILOPEDIA_COLLECTIBLES_PRICE",Cost));

				if MustPurchase then
					s:AddLabel("[ICON_Bullet] " .. Locale.Lookup("LOC_UI_CIVILOPEDIA_COLLECTIBLES_MUSTPURCHASE"));
				end

				if not Tradable then
					s:AddLabel("[ICON_Bullet] " .. Locale.Lookup("LOC_UI_CIVILOPEDIA_COLLECTIBLES_NONTRADABLE"));
				end

				s:AddSeparator();
			end
		);

	local tBirthModifiers = DB.Query("SELECT ModifierId FROM Ophidy_Collectible_BirthModifier WHERE CollectibleType = ?",CollectibleType);
	local tActiveModifiers = DB.Query("SELECT ModifierId FROM Ophidy_Collectible_ActiveModifier WHERE CollectibleType = ?",CollectibleType);
			
	if tBirthModifiers and #tBirthModifiers > 0 then	
		AddChapter("LOC_UI_CIVILOPEDIA_COLLECTIBLES_BIRTH_DESC", BirthDesc);
	end
	if tActiveModifiers and #tActiveModifiers > 0 then	
		AddChapter("LOC_UI_CIVILOPEDIA_COLLECTIBLES_ACTIVE_DESC", ActiveDesc);
	end
end