-- CollectibleInfoHelper
-- Author: Ophidy
-- DateCreated: 4/29/2026 3:49:50 PM
--------------------------------------------------------------
include("CollectibleManager");
--===========================================================================================
-- CONSTANTS
--===========================================================================================
m_SpeedMul 			= GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;

--===========================================================================================
-- VARIABLES
--===========================================================================================
g_baseHandler		= {};
g_chestHandler		= {};

--===========================================================================================
function GetBaseStats(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];


	instance.CollectibleIcon:SetTexture("ICON_"..collectibleData.CollectibleType);
	instance.Name:SetText(Locale.Lookup(collectibleData.Name));

	if not instance.GreatWorkBanner then
		-- Don't color the discovers.
		local r,g,b = string.match(GlobalParameters["PARAMETER_OPHIDY_COLLECTIBLE_COLOR_"..collectibleData.Rarity],"([%d.]+),([%d.]+),([%d.]+)");
		instance.Name:SetColor(r,g,b,0.4,1)
	end
	
	local tBirthModifiers = DB.Query("SELECT ModifierId FROM Ophidy_Collectible_BirthModifier WHERE CollectibleType = ?",collectibleData.CollectibleType);
	local tActiveModifiers = DB.Query("SELECT ModifierId FROM Ophidy_Collectible_ActiveModifier WHERE CollectibleType = ?",collectibleData.CollectibleType);
	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	if tBirthModifiers and #tBirthModifiers > 0 then
		ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_BIRTH_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.BirthDesc);
	end

	if tActiveModifiers and #tActiveModifiers > 0 then
		ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc);
		ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);
	end

	instance.CollectibleIcon:SetToolTipString(ToolTip);
	
	if instance.CollectibleBox then
		instance.CollectibleBox:RegisterCallback(Mouse.eRClick,function() LuaEvents.OpenCivilopedia(collectibleData.CollectibleType) end);
	end
	
	if g_baseHandler[iCollectible] then
		g_baseHandler[iCollectible](iPlayer,iCollectible,instance);
	end
end

--===========================================================================================
function GetChestStats(iPlayer,iCollectible,instance)
	GetBaseStats(iPlayer,iCollectible,instance);

	local playerCollectibles = CollectibleManager.GetCollectibles(iPlayer);

	local num			= playerCollectibles:GetCollectibleNum(iCollectible);
	local cooldown		= playerCollectibles:GetCollectibleCooldown(iCollectible);
	local usable		= playerCollectibles:IsCollectibleUsable(iCollectible);
	
	if num > 1 then
		instance.StackFlag:SetHide(false);
		instance.Stack:SetText(num);
	else
		instance.StackFlag:SetHide(true);
	end

	if cooldown > 0 then
		instance.TurnIcon:SetText('[ICON_TURN]')
		instance.Cooldown:SetText(cooldown);
	end

	instance.usable		= usable; -- mark down for UI panel.

	if g_chestHandler[iCollectible] then
		g_chestHandler[iCollectible](iPlayer,iCollectible,instance);
	end
end

--===========================================================================================
-- import your custom stat handler by this prefix.

	include("CollectibleInfoHandler_",true);