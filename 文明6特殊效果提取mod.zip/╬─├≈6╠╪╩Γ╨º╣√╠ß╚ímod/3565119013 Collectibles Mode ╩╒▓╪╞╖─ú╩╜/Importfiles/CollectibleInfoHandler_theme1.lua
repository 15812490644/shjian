-- CollectibleInfoHandler_theme1
-- Author: Ophidy
-- DateCreated: 4/29/2026 10:30:08 PM
--------------------------------------------------------------
--===========================================================================================
-- CONSTANTS
--===========================================================================================
local ACTORS_JEWELRY_BOX				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ACTORS_JEWELRY_BOX"].Index;
local AVENGER							:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_AVENGER"].Index;
local GLASS_BIRD						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_GLASS_BIRD"].Index;
local PURE_GOLD_EXPEDITION				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_PURE_GOLD_EXPEDITION"].Index;
local USELESS_SCISSORS					:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_USELESS_SCISSORS"].Index;
local ROYAL_BROOCH						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ROYAL_BROOCH"].Index;

--===========================================================================================
g_baseHandler[ACTORS_JEWELRY_BOX] = function(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
	local pPlayer = Players[iPlayer];
	local cultureYield = pPlayer:GetCulture():GetCultureYield() or 0;
	local amount = cultureYield * 2;
	amount = math.floor(amount*10)/10;

	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_BIRTH_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.BirthDesc);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc)..Locale.Lookup('LOC_UI_COLLECTIBLES_AMOUNT_TT',amount);
	ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);

	instance.CollectibleIcon:SetToolTipString(ToolTip);
end

g_chestHandler[AVENGER] = function(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
	local pPlayer = Players[iPlayer];
	local Triggered = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_AVENGER_KEY_TRIGGERED") or false;
	local state : string
	if Triggered then
		state = Locale.Lookup("LOC_UI_COLLECTIBLES_TRIGGERED_TT");
	else
		state = Locale.Lookup("LOC_UI_COLLECTIBLES_NOT_TRIGGERED_TT");
	end

	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_BIRTH_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.BirthDesc)..state;
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc);
	ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);

	instance.CollectibleIcon:SetToolTipString(ToolTip);
end

g_baseHandler[GLASS_BIRD] = function(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
	local pPlayer = Players[iPlayer];
	local cultureYield = pPlayer:GetCulture():GetCultureYield() or 0;
	local amount = cultureYield * 0.3;
	amount = math.floor(amount*10)/10;

	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_BIRTH_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.BirthDesc);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc)..Locale.Lookup('LOC_UI_COLLECTIBLES_AMOUNT_TT',amount);
	ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);

	instance.CollectibleIcon:SetToolTipString(ToolTip);
end

g_baseHandler[PURE_GOLD_EXPEDITION] = function(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
	local pPlayer = Players[iPlayer];
	local playerTreasury = pPlayer:GetTreasury();
	local goldYield	 = playerTreasury:GetGoldYield() - playerTreasury:GetTotalMaintenance();
	local amount = goldYield * 0.5;
	amount = math.floor(amount*10)/10;

	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_BIRTH_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.BirthDesc);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc)..Locale.Lookup('LOC_UI_COLLECTIBLES_AMOUNT_TT',amount);
	ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);

	instance.CollectibleIcon:SetToolTipString(ToolTip);
end

g_baseHandler[USELESS_SCISSORS] = function(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
	local iEra = Game.GetEras():GetCurrentEra();
	local amount = GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_COST_3 or 0;
	amount = amount * (1 + iEra * GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS) * m_SpeedMul;
	amount = math.floor(amount*10)/10;

	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc)..Locale.Lookup('LOC_UI_COLLECTIBLES_AMOUNT_TT',amount);
	ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);

	instance.CollectibleIcon:SetToolTipString(ToolTip);
end

g_baseHandler[ROYAL_BROOCH] = function(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
	local pPlayer = Players[iPlayer];
	local goldYield = pPlayer:GetTreasury():GetGoldBalance() or 0;
	local amount = goldYield * 0.1;
	amount = math.floor(amount*10)/10;

	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_BIRTH_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.BirthDesc);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc)..Locale.Lookup('LOC_UI_COLLECTIBLES_AMOUNT_TT',amount);
	ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);

	instance.CollectibleIcon:SetToolTipString(ToolTip);
end