-- CollectibleManager
-- Author: Ophidy
-- DateCreated: 9/3/2025 12:27:33 PM
--------------------------------------------------------------
include("GameCapabilities");
include("SupportFunctions");
include("Ophidy_PropertyManager");

--===========================================================================================
-- CONSTANTS
--===========================================================================================
local SpeedMultiplier 		= 	GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;

--===========================================================================================
-- VARIABLES
--===========================================================================================
GoodAdjustFunc				=	{};
RarityAdjustFunc			=	{};

--===========================================================================================
-- UTILS
--===========================================================================================
	--------------------------------------
	--	Call Event
	--------------------------------------
		function CallLuaEvent(sEventName, tData) -- Use this on GP side, or might repeatly call once
			ReportingEvents.SendLuaEvent(sEventName, tData) -- Send the Event to the UI side
			LuaEvents[sEventName](tData)
		end

--===========================================================================================
-- CORE
--===========================================================================================
	CollectibleManager = {
		GetCollectibles = function(iPlayer)
			local pPlayer = Players[iPlayer];
			if pPlayer then
				local o = {};
				setmetatable(o, {__index = CollectibleManager });

				local savedData = pPlayer:GetProperty("Ophidy_CollectiblesData") or {};

				o.CollectiblesInfo		= savedData.CollectiblesInfo or {};
				o.BusyCapacity			= savedData.BusyCapacity or 0;
				o.Token					= savedData.Token or 0;
				o.Activatings			= savedData.Activatings or {};
				o.Existings				= savedData.Existings or {};						
				o.Waitings				= savedData.Waitings or o:InitPlayerWaitings(iPlayer);
				o.Goods					= savedData.Goods or {};
				o.iPlayer				= iPlayer;

				return o;
			end
		end;

		--=================================================================--
	
		GetCollectible = function(self,iCollectible)
			local CollectibleInfo = self.CollectiblesInfo[iCollectible];
			if CollectibleInfo then
				return CollectibleInfo;
			end

			return nil;
		end;

		GetCollectiblesInfo = function(self)
			return self.CollectiblesInfo;
		end;

		GetCollectiblesActivating = function(self)
			return self.Activatings;
		end;

		GetCapacity = function(self)
			local pPlayer = Players[self.iPlayer];
			return pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_ACTIVE_CAPACITY") or 0;
		end;

		GetBusyCapacity = function(self)
			return self.BusyCapacity;
		end;

		GetFreeCapacity = function(self)
			return self:GetCapacity() - self.BusyCapacity;
		end;

		GetToken = function(self)
			return self.Token;
		end;

		GetExistings = function(self)
			return self.Existings;
		end;

		IsCollectibleAvailable = function(self,iCollectible)
			local CollectibleInfo = self:GetCollectible(iCollectible);
			local DataInfo = GameInfo.Ophidy_Collectibles[iCollectible];

			if self.Waitings[iCollectible] and (self.Waitings[iCollectible] > 0 or self.Waitings[iCollectible] == -1) then
				if not CollectibleInfo then
					return true;
				else
					if CollectibleInfo.StackCount < DataInfo.StackLimit then
						return true;
					end
				end
			end

			return false;
		end;

		IsCollectibleActivating = function(self,iCollectible)
			if self.Activatings[iCollectible] and self.Activatings[iCollectible] > 0 then
				return true,self.Activatings[iCollectible];
			end
			return false;
		end;

		IsCollectibleUsable = function(self,iCollectible)
			local CollectibleInfo = self:GetCollectible(iCollectible);
			if self:IsCollectibleActivating(iCollectible) then return false; end
			if self:GetFreeCapacity() < 1 then return false; end
			if not CollectibleInfo or not CollectibleInfo.ActiveModifiers or #CollectibleInfo.ActiveModifiers == 0 then return false; end
			return true;
		end;

		IsCollectibleRemovable = function(self,iCollectible)
			local DataInfo = GameInfo.Ophidy_Collectibles[iCollectible];
			if not DataInfo.Unchangeable then
				return true;
			end
			return false;
		end;

		HasCollectible = function(self,iCollectible)
			local CollectibleInfo = self:GetCollectible(iCollectible);
			if CollectibleInfo and CollectibleInfo.StackCount > 0 then return true; end
			return false;
		end;

		GetCollectibleNum = function(self,iCollectible)
			local CollectibleInfo = self:GetCollectible(iCollectible);
			if not CollectibleInfo then return 0; end
			return CollectibleInfo.StackCount;
		end;

		GetCollectibleCooldown = function(self,iCollectible)
			local _, cooldown = self:IsCollectibleActivating(iCollectible);
			return cooldown or 0;
		end;


		--=================================================================--
		CreateCollectible = function(self,iCollectible, enableExplicitUnlock)
			local iCollectible = type(iCollectible) == "string" and GameInfo.Ophidy_Collectibles[iCollectible].Index or iCollectible;
			if self:IsCollectibleAvailable(iCollectible) or (enableExplicitUnlock and GameInfo.Ophidy_Collectibles[iCollectible].ExplicitUnlock) then
				local CollectibleInfo = self:GetCollectible(iCollectible) or self:InitCollectibleInfo(iCollectible);
				
				local pPlayer = Players[self.iPlayer];
				if pPlayer.DetachModifierByID or CollectibleInfo.Unchangeable then
					for _ , ModifierId in ipairs(CollectibleInfo.BirthModifiers) do
						pPlayer:AttachModifierByID(ModifierId);
					end
				else
					local propManager = Ophidy_PropertyManager.GetPlayerManager(self.iPlayer);
					if not propManager then print("ERROR: Cannot create a PropertyManager for "..self.iPlayer); return; end
					propManager:ChangePropertyAmount(CollectibleInfo.CollectibleType .. "_BIRTH",1);
				end

				CollectibleInfo.BuildCount = CollectibleInfo.BuildCount + 1;
				CollectibleInfo.StackCount = CollectibleInfo.StackCount + 1;
				
				table.insert(self.Existings,iCollectible);
				self.CollectiblesInfo[iCollectible] = CollectibleInfo;
				
				if self.Waitings[iCollectible] and self.Waitings[iCollectible] > 0 then
					self.Waitings[iCollectible] = self.Waitings[iCollectible] - 1;
				end

				self:SaveCollectiblesData();
				local iPlayer = self.iPlayer;

				CallLuaEvent("Ophidy_Collectible_Added",
					{
						iPlayer			= iPlayer,
						iCollectible	= iCollectible
					}
				);

				--GameEvents.Ophidy_Collectible_Added.Call(iPlayer,iCollectible);
				print(string.format("Collectible Added %d %d",iPlayer,iCollectible));
				return true;
			else
				print("Cant Create collectible ",iCollectible);
			end
			return false;
		end;

		CreateRandomCollectible = function(self,kParam)
			local kParam			= kParam or {};
			local minRarity			= kParam.minRarity or 1;
			local maxRarity			= kParam.maxRarity or 6;
			local includePurchase	= kParam.includePurchase;
			local mustPurchase		= kParam.mustPurchase;
			local extraLuck			= kParam.extraLuck;
			local applyRarityBonus	= kParam.applyRarityBonus or false;
			
			local Rarity = self:DetermineRarity(minRarity,maxRarity,extraLuck,applyRarityBonus);
			
			local iCollectible = self:FindRandomCollectible(Rarity,includePurchase,mustPurchase)
			if iCollectible > -1 then
				local iPlayer = self.iPlayer;

				CallLuaEvent("Ophidy_Collectible_Create_Random_Collectible",
					{
						iPlayer			= iPlayer,
						iCollectible	= iCollectible
					}
				);

				--ReportingEvents.SendLuaEvent('Ophidy_Collectible_Create_Random_Collectible',{iPlayer = iPlayer,iCollectible = iCollectible});
				return self:CreateCollectible(iCollectible);
			end
			return false;
		end;

		RemoveCollectible = function(self,iCollectible)
			if self:HasCollectible(iCollectible) and self:IsCollectibleRemovable(iCollectible) then
				local CollectibleInfo = self:GetCollectible(iCollectible);

				local pPlayer = Players[self.iPlayer];
				if pPlayer.DetachModifierByID then
					for _ , ModifierId in ipairs(CollectibleInfo.BirthModifiers) do
						pPlayer:DetachModifierByID(ModifierId);
					end
				else
					local propManager = Ophidy_PropertyManager.GetPlayerManager(self.iPlayer);
					if not propManager then print("ERROR: Cannot create a PropertyManager for "..self.iPlayer); return; end
					propManager:ChangePropertyAmount(CollectibleInfo.CollectibleType .. "_BIRTH",-1);
				end

				if self:IsCollectibleActivating(iCollectible) then
					self:ReleaseCollectible(iCollectible);
				end

				CollectibleInfo.StackCount = CollectibleInfo.StackCount -1;
				for _ , index in ipairs(self.Existings) do
					if index == iCollectible then
						table.remove(self.Existings, _);
						break;
					end
				end
				self.CollectiblesInfo[iCollectible] = CollectibleInfo;
				self:SaveCollectiblesData();
				local iPlayer = self.iPlayer;

				CallLuaEvent("Ophidy_Collectible_Removed",
					{
						iPlayer			= iPlayer,
						iCollectible	= iCollectible
					}
				);

				--GameEvents.Ophidy_Collectible_Removed.Call(iPlayer,iCollectible);
				return true;
			end
			return false;
		end;

		RemoveRandomCollectible = function(self,initRarity,maxRarity)
			ShuffleTable(self.Existings);
			for _ , index in ipairs(self.Existings) do
				local Rarity = self:GetCollectible(index).Rarity
				if Rarity <= maxRarity and Rarity >= initRarity and self:IsCollectibleRemovable(index) then
					self:RemoveCollectible(index);
					return true;
				end
			end
			return false;
		end;

		ActivateCollectible = function(self,iCollectible)
			if self:IsCollectibleUsable(iCollectible) then
				local CollectibleInfo = self:GetCollectible(iCollectible);

				local pPlayer = Players[self.iPlayer];
				if pPlayer.DetachModifierByID then
					for _ , ModifierId in ipairs(CollectibleInfo.ActiveModifiers) do
						pPlayer:AttachModifierByID(ModifierId);
					end
				else
					local propManager = Ophidy_PropertyManager.GetPlayerManager(self.iPlayer);
					if not propManager then print("ERROR: Cannot create a PropertyManager for "..self.iPlayer); return; end
					propManager:ChangePropertyAmount(CollectibleInfo.CollectibleType .. "_ACTIVE",1);
				end

				self.BusyCapacity = self.BusyCapacity + 1;
				self.Activatings[iCollectible] = math.ceil(CollectibleInfo.Cooldown * SpeedMultiplier);
				self:SaveCollectiblesData();
				local iPlayer = self.iPlayer;
				--GameEvents.Ophidy_Collectible_Activated.Call(iPlayer,iCollectible);
				print(string.format("Collectible Activated %d %d",iPlayer,iCollectible));
				--ReportingEvents.SendLuaEvent('Ophidy_Collectible_Activated',{iPlayer = iPlayer, iCollectible = iCollectible});

				CallLuaEvent("Ophidy_Collectible_Activated",
					{
						iPlayer			= iPlayer,
						iCollectible	= iCollectible
					}
				);

				return true;
			end
			return false;
		end;

		ReleaseCollectibles = function(self)
			for iCollectible, cooldown in pairs(self.Activatings) do
				self:ReleaseCollectible(iCollectible);
			end
		end;

		ReleaseCollectible = function(self,iCollectible)
			if self.Activatings[iCollectible] then
				local CollectibleInfo = self:GetCollectible(iCollectible);

				local pPlayer = Players[self.iPlayer];
				if pPlayer.DetachModifierByID then
					for _ , ModifierId in ipairs(CollectibleInfo.ActiveModifiers) do
						pPlayer:DetachModifierByID(ModifierId);
					end
				else
					local propManager = Ophidy_PropertyManager.GetPlayerManager(self.iPlayer);
					if not propManager then print("ERROR: Cannot create a PropertyManager for "..self.iPlayer); return; end
					propManager:ChangePropertyAmount(CollectibleInfo.CollectibleType .. "_ACTIVE",-1);
				end

				self.BusyCapacity = self.BusyCapacity - 1;
				self.Activatings[iCollectible] = nil;
				self:SaveCollectiblesData();
				local iPlayer = self.iPlayer;

				CallLuaEvent("Ophidy_Collectible_Released",
					{
						iPlayer			= iPlayer,
						iCollectible	= iCollectible
					}
				);

				--GameEvents.Ophidy_Collectible_Released.Call(iPlayer,iCollectible);
				--ReportingEvents.SendLuaEvent('Ophidy_Collectible_Released',{iPlayer = iPlayer, iCollectible = iCollectible});
				return true;
			end
			return false;
		end;

		ChangeCollectibleCooldown = function(self,iCollectible,amount)
			local amount = amount or 1;
			if self.Activatings[iCollectible] then
				self.Activatings[iCollectible] = self.Activatings[iCollectible] - amount;
				if self.Activatings[iCollectible] <= 0 then
					self:ReleaseCollectible(iCollectible);
				end
				self:SaveCollectiblesData();
				return true;
			end
			return false;
		end;

		ChangeCollectiblesCooldown = function(self,amount)
			local amount = amount or 1;
			for iCollectible, cooldown in pairs(self.Activatings) do
				self.Activatings[iCollectible] = cooldown - amount;
				if self.Activatings[iCollectible] <= 0 then
					self:ReleaseCollectible(iCollectible);
				end
			end
			self:SaveCollectiblesData();
			return 0;
		end;

		ChangeToken = function(self,eAmount)
			local eAmount = eAmount or 0;
			self.Token = self.Token + eAmount;
			self:SaveCollectiblesData();
			local iPlayer = self.iPlayer;
			GameEvents.Ophidy_Collectible_Token_Changed.Call(iPlayer,eAmount);
			return;
		end;

		SetToken = function(self,eAmount)
			self.Token = eAmount;
			self:SaveCollectiblesData();
			return;
		end;

		--=================================================================--
		GenerateGoods = function(self,kParam)
			local kParam		= kParam or {};
			local extraNum		= kParam.extraNum or 0;
			local numOverride	= kParam.numOverride;

			local pPlayer = Players[self.iPlayer];
			local Num = numOverride or pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_GOODS_NUM") or GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_GOODS_NUM;
			local Num = Num + extraNum;
			local Goods = {};
			local Pool = DB.Query("SELECT * FROM Ophidy_Collectibles WHERE Tradable = 1");
			while #Goods < Num and #Pool > 0 do
				local Good = table.remove(Pool,Game.GetRandNum(#Pool)+1);
				Good.Index = GameInfo.Ophidy_Collectibles[Good.CollectibleType].Index;
				
				local tBirthModifiers = DB.Query("SELECT ModifierId FROM Ophidy_Collectible_BirthModifier WHERE CollectibleType = ?",Good.CollectibleType);
				local tActiveModifiers = DB.Query("SELECT ModifierId FROM Ophidy_Collectible_ActiveModifier WHERE CollectibleType = ?",Good.CollectibleType);
				if tBirthModifiers and #tBirthModifiers > 0 then
					Good.BirthModifiers = tBirthModifiers;
				end
				if tActiveModifiers and #tActiveModifiers > 0 then
					Good.ActiveModifiers = tActiveModifiers;
				end
				
				if self:IsCollectibleAvailable(Good.Index) then
					table.insert(Goods,Good);
				end
			end
			self.Goods = Goods;
			self:SaveCollectiblesData();
			return true;
		end;

		GetGoods = function(self)
			local Goods = self.Goods;
			
			for i = #Goods, 1, -1 do
				if not self:IsCollectibleAvailable(Goods[i].Index) then
					table.remove(Goods,i);
				end
			end

			-- Set to preset.
			for i, o in ipairs(Goods) do
				Goods[i].Cost = GameInfo.Ophidy_Collectibles[o.Index].Cost;
			end

			
			if Goods and #Goods > 0 then
				for name, funcs in pairs(GoodAdjustFunc) do
					Goods = funcs(self, Goods) or Goods;
				end
				return Goods;
			end
			return {};
		end;

		PurchaseGood = function(self,iCollectible,cost)
			for i, kCollectible in ipairs(self.Goods) do
				if iCollectible == kCollectible.Index then
					table.remove(self.Goods,i);
					break;
				end
			end
			self:ChangeToken(-cost);
			self:SaveCollectiblesData();
			self:CreateCollectible(iCollectible);
			local iPlayer = self.iPlayer;

			CallLuaEvent("Ophidy_Collectible_Goods_Purchased",
				{
					iPlayer			= iPlayer,
					iCollectible	= iCollectible,
					iCost			= cost
				}
			);

			--GameEvents.Ophidy_Collectible_Goods_Purchased.Call(iPlayer,iCollectible,cost);
			return true;
		end;

		--=================================================================--
		GenerateDiscover = function(self,kParam)
			local kParam				= kParam or {};
			local minRarity				= kParam.minRarity;
			local maxRarity				= kParam.maxRarity;
			local includePurchase		= kParam.includePurchase or false;
			local mustPurchase			= kParam.mustPurchase or false;
			local amountOverride		= kParam.amountOverride;
			local specificDiscoverBatch	= kParam.specificDiscoverBatch;
			local extraNum				= kParam.extraNum or 0;

			local pPlayer = Players[self.iPlayer];
			local defaultAmount = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_NUM_DISCOVERS") or GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_NUM_DISCOVERS;
			local defaultAmount = defaultAmount + extraNum;
			local amount = amountOverride or defaultAmount;

			-- /// since a scroll panel arranged, it could be over 4 items, though it may be a little dowdy. ///
			--[[
			-- If more than 4, discover items will drawing off the screen!!!!!
			local amount = math.min(amount, 4);
			]]--
			
			local tBatch = {};

			if not specificDiscoverBatch or #specificDiscoverBatch == 0 then
				repeat
					local Rarity = self:DetermineRarity(minRarity,maxRarity);
					local iCollectible = self:FindRandomCollectible(Rarity,includePurchase,mustPurchase); 
					if iCollectible > -1 then
						table.insert(tBatch,iCollectible);
						-- Temporary Occupation
						if self.Waitings[iCollectible] and self.Waitings[iCollectible] > 0 then
							self.Waitings[iCollectible] = self.Waitings[iCollectible] - 1;
						end
					end
				until(#tBatch == amount);
			else	
				tBatch = specificDiscoverBatch;
				for _, iCollectible in ipairs(tBatch) do
					if self.Waitings[iCollectible] and self.Waitings[iCollectible] > 0 then
						self.Waitings[iCollectible] = self.Waitings[iCollectible] - 1;
					end
				end
			end

			self:SaveCollectiblesData();
			local iPlayer = self.iPlayer;

			CallLuaEvent("Ophidy_Collectible_Generate_DiscoverBatch",
				{
					iPlayer			= iPlayer,
					tBatch			= tBatch
				}
			);

			--ReportingEvents.SendLuaEvent('Ophidy_Collectible_Generate_DiscoverBatch',{iPlayer = iPlayer, tBatch = tBatch});
			return true;
		end;

		CreateDiscover = function(self,tBatch,iCollectible)
			-- Restore Instance
			for _ , index in ipairs(tBatch) do
				if self.Waitings[index] and self.Waitings[index] ~= -1 then
					self.Waitings[index] = self.Waitings[index] + 1;
				end
			end
			self:CreateCollectible(iCollectible,true);
			return true;
		end;

		RemoveWaitingsOfRarity = function(self,Rarity)
			if not Rarity then return false; end
			for row in GameInfo.Ophidy_Collectibles() do
				if row.Rarity == Rarity then
					self.Waitings[row.Index] = -9999;
				end
			end
			self:SaveCollectiblesData();
			return true;
		end;


		--=================================================================--
		FindRandomCollectible = function(self,Rarity,includePurchase,mustPurchase)
			local DataPool = self:GetCollectiblesOfRarity(Rarity,includePurchase,mustPurchase);
			local Rarity = Rarity or 1;
			while Rarity > -1 do 
				if DataPool then
					while #DataPool > 0 do
						local iCollectible = table.remove(DataPool,Game.GetRandNum(#DataPool)+1)
						if self:IsCollectibleAvailable(iCollectible) then
							return iCollectible;
						end
					end
				end
				Rarity = Rarity - 1;
				DataPool = self:GetCollectiblesOfRarity(Rarity,includePurchase,mustPurchase);
			end
			-- though some collectibles are always available
			-- but if we request mustPurchase, then usually it can't get a target
			-- and it might lead to a endless loop
			-- so we need to return a specific collectible
			-- that means we can't get a valid collectible within this rarity
			return GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ANTIQUE_COINS"].Index;
		end;

		DetermineRarity = function(self,minRarity,maxRarity,extraLuck,applyRarityBonus)
			local pPlayer = Players[self.iPlayer]
			local CheckDifficulty = tonumber(GameConfiguration.GetValue("Opd_Luck") or 40) + ((pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_EXTRA_LUCKY") or 0) + (extraLuck or 0)) * 0.3;
			local success = true;
			local Rarity = 1;
			local minRarity = minRarity or 1;
			local maxRarity = maxRarity or 6;

			if applyRarityBonus and (applyRarityBonus == true) then
				local minRarityOffset = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_ADJUST_INIT_RARITY") or 0;
				minRarity = minRarity + minRarityOffset;
			end

			for name, funcs in pairs(RarityAdjustFunc) do
				minRarity, maxRarity = funcs(self, minRarity, maxRarity) or minRarity, maxRarity;
			end

			while success and Rarity < maxRarity do
				local randnum = Game.GetRandNum(100,"Rarity Jump")+1;
				if randnum <= CheckDifficulty 
					then Rarity = Rarity + 1;
					else success = false;
				end
			end
			Rarity = math.max(Rarity,minRarity);
			return Rarity;
		end;

		InitCollectibleInfo = function(self,iCollectible)
			local row = GameInfo.Ophidy_Collectibles[iCollectible];
			if not row then return nil; end
			local tRow = DB.Query("SELECT * FROM Ophidy_Collectibles WHERE CollectibleType = ?", row.CollectibleType);

			local CollectibleInfo;
			if #tRow > 0 then
				CollectibleInfo = tRow[1];
			end
			CollectibleInfo.BuildCount	= 0;
			CollectibleInfo.StackCount	= 0;
			CollectibleInfo.CheckTurn	= 0;
			
			CollectibleInfo.BirthModifiers = {};
			local tRows = DB.Query("SELECT ModifierId FROM Ophidy_Collectible_BirthModifier WHERE CollectibleType = ?",CollectibleInfo.CollectibleType);
			for _, tRow in ipairs(tRows) do
				table.insert(CollectibleInfo.BirthModifiers,tRow.ModifierId);
			end
			CollectibleInfo.ActiveModifiers = {};
			local tRows = DB.Query("SELECT ModifierId FROM Ophidy_Collectible_ActiveModifier WHERE CollectibleType = ?",CollectibleInfo.CollectibleType);
			for _, tRow in ipairs(tRows) do
				table.insert(CollectibleInfo.ActiveModifiers,tRow.ModifierId);
			end
			
			--self.CollectiblesInfo[iCollectible] = CollectibleInfo;
			return CollectibleInfo;
		end;

		InitPlayerWaitings = function(self,iPlayer)
			local Waitings = {};
			for row in GameInfo.Ophidy_Collectibles() do
				if (not row.TraitType or HasTrait(row.TraitType,iPlayer)) and not row.ExplicitUnlock then
					Waitings[row.Index] = row.MaxInstance;
				end
			end
			return Waitings;
		end;

		GetCollectiblesOfRarity = function(self,Rarity,includePurchase,mustPurchase)
			local includePurchase = includePurchase or false;
			local mustPurchase = mustPurchase or false;
			local CollectiblesOfRarity = {};
			for row in GameInfo.Ophidy_Collectibles() do
				if row.Rarity == Rarity then
					if (mustPurchase and row.MustPurchase) or (not mustPurchase and includePurchase) or (not mustPurchase and not row.MustPurchase) then
						table.insert(CollectiblesOfRarity,row.Index);
					end
				end
			end
			return CollectiblesOfRarity;
		end;

		
		SaveCollectiblesData = function(self)
			local pPlayer = Players[self.iPlayer];
			local savedData = {};
			savedData.CollectiblesInfo		= self.CollectiblesInfo;
			savedData.BusyCapacity			= self.BusyCapacity;
			savedData.Token					= self.Token;
			savedData.Activatings			= self.Activatings;
			savedData.Existings				= self.Existings;
			savedData.Waitings				= self.Waitings;
			savedData.Goods					= self.Goods;
			pPlayer:SetProperty("Ophidy_CollectiblesData",savedData); 
			local iPlayer = self.iPlayer;

			CallLuaEvent("Ophidy_Collectible_Saved",
				{
					iPlayer			= iPlayer
				}
			);

			--GameEvents.Ophidy_Collectible_Saved.Call(iPlayer);
			--ReportingEvents.SendLuaEvent('Ophidy_Collectible_Saved',{iPlayer = iPlayer});
		end;
	}
--===========================================================================================

	-- Good Adjust Functions
	-- They should have different name!
	GoodAdjustFunc["EraProgress"] = function(CollectibleManager,Goods)
		for i, _ in ipairs(Goods) do
			Goods[i].Cost = math.floor(Goods[i].Cost * (1 + Game.GetEras():GetCurrentEra() * GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS) * SpeedMultiplier);
			
		end
		return Goods;
	end

	GoodAdjustFunc["FourleafDiscount"] = function(CollectibleManager,Goods)
		local iPlayer = CollectibleManager.iPlayer;
		local pPlayer = Players[iPlayer];

		local FourleafDiscount = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_TRADE_DISCOUNT_FOURLEAF") or 0;
		Goods[1].Cost = Goods[1].Cost * (100 - tonumber(FourleafDiscount))/100;
		return Goods;
	end

	GoodAdjustFunc["GeneralDiscount"] = function(CollectibleManager,Goods)
		local iPlayer = CollectibleManager.iPlayer;
		local pPlayer = Players[iPlayer];

		local discount = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_TRADE_DISCOUNT") or 0;
		for i, _ in ipairs(Goods) do
			Goods[i].Cost = math.ceil(Goods[i].Cost * (100 - math.min(tonumber(discount),GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_MAX_DISCOUNT))/100);
		end
		return Goods;
	end

	GoodAdjustFunc["SecretHRLetter"] = function(CollectibleManager,Goods)
		local iPlayer = CollectibleManager.iPlayer;
		local pPlayer = Players[iPlayer];

		local key = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_SECRET_HR_LETTER_KEY") or 0;
		for i, _ in ipairs(Goods) do
			if Goods[i].Rarity >= 5 then
				local currentCost = GlobalParameters["PARAMETER_OPHIDY_COLLECTIBLE_COST_"..tostring(Goods[i].Rarity)];
				local targetCost = GlobalParameters["PARAMETER_OPHIDY_COLLECTIBLE_COST_"..tostring(Goods[i].Rarity - key)];
				if currentCost and targetCost then
					Goods[i].Cost = Goods[i].Cost * targetCost / currentCost;
				end
			end
		end
		return Goods;
	end

	GoodAdjustFunc["RegionalActionPlan"] = function(CollectibleManager,Goods)
		local iPlayer = CollectibleManager.iPlayer;
		local pPlayer = Players[iPlayer];

		local key = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_REGIONAL_ACTION_PLAN_KEY") or 0;
		for i, _ in ipairs(Goods) do
			if Goods[i].Rarity == 4 then
				local currentCost = GlobalParameters["PARAMETER_OPHIDY_COLLECTIBLE_COST_"..tostring(Goods[i].Rarity)];
				local targetCost = GlobalParameters["PARAMETER_OPHIDY_COLLECTIBLE_COST_"..tostring(Goods[i].Rarity - key)];
				if currentCost and targetCost then
					Goods[i].Cost = Goods[i].Cost * targetCost / currentCost;
				end
			end
		end
		return Goods;
	end

	RarityAdjustFunc["ProfoundSilence"] = function(CollectibleManager,minRarity,maxRarity)
		local iPlayer = CollectibleManager.iPlayer;
		local pPlayer = Players[iPlayer];

		local key = pPlayer:GetProperty("PARAMETER_OPHIDY_COLLECTIBLE_PROFOUND_SILENCE_KEY") or -1;
		if key > 0 then
			maxRarity = math.min(maxRarity, key);
			minRarity = math.min(maxRarity, minRarity);
			--print(string.format("Return adjusted Rarity %d ~ %d",minRarity,maxRarity))
		end

		return minRarity, maxRarity;
	end
--===========================================================================================

include("CollectibleManager_Addition_",true);

