-- Ophidy_PropertyManager
-- Author: Ophidy
-- DateCreated: 5/31/2026 4:41:03 PM
--------------------------------------------------------------
-- �ѷ�װ��Property����ϵͳ��ͨ��GetPlayerManager/GetCityManager��������һ���й������ض�Property������
-- ��ʵ�屻�Ƴ�ʱ�Զ��Ƴ���¼��Property�����׶��䶯ʱ�Զ�Ǩ��PlayerProperty
-- ����Property���Ǽ�¼�ڵ�Ԫ��ģ��Ա���Modifier����

--===========================================================================================
DebugMode		= false;

--===========================================================================================
-- UTILS
--===========================================================================================
	function GetPlayerCapitalPlotIndex(iPlayer)
		local cities = Players[iPlayer]:GetCities();
		local capitalCity = cities:GetCapitalCity();
		return capitalCity and capitalCity:GetPlot():GetIndex() or -1;
	end

	function CompositeCityID(iPlayer, iCity)
		return string.format("P%dC%d", iPlayer, iCity)
	end

	function DecompositeCityID(sCity)
		local iPlayer, iCity = string.match(sCity, "P(%d+)C(%d+)")
		iPlayer	= tonumber(iPlayer)
		iCity	= tonumber(iCity)
		return iPlayer, iCity
	end

--===========================================================================================
-- CORE
--===========================================================================================
	Ophidy_PropertyManager = {
		--||==================== PlayerManager ====================||--
		GetPlayerManager = function(iPlayer)
			local pPlayer = Players[iPlayer];
			if pPlayer then
				local savedData = pPlayer:GetProperty("Ophidy_PlayerPropertiesData") or {};
				local o = {
					iPlayer			= iPlayer,
					iPlot			= savedData.iPlot or GetPlayerCapitalPlotIndex(iPlayer);
					kProperties		= savedData.kProperties or {}; -- a table of all recorded property names
					_Type			= "player",
				};
				setmetatable(o, {__index = Ophidy_PropertyManager });

				return o;
			end
		end;

		RefreshPlayer = function(self,newPlotIndex)
			local newPlotIndex = newPlotIndex or GetPlayerCapitalPlotIndex(self.iPlayer);
			local oldPlotIndex = self.iPlot;

			if newPlotIndex == oldPlotIndex then return; end

			local newPlot = Map.GetPlotByIndex(newPlotIndex);
			local oldPlot = Map.GetPlotByIndex(oldPlotIndex);

			for k, v in pairs(self.kProperties) do
				if oldPlot then
					local o = oldPlot:GetProperty(k) or 0;
					oldPlot:SetProperty(k,o-v);
				end

				if newPlot then
					local n = newPlot:GetProperty(k) or 0;
					newPlot:SetProperty(k,n+v);
				end

				if DebugMode then
					print(string.format("Change Plot(%d) Property(%s) (%d)",oldPlotIndex,k,-v));
					print(string.format("Change Plot(%d) Property(%s) (%d)",newPlotIndex,k,v));
				end
			end

			self.iPlot = newPlotIndex;
			self:SavePropertiesData();
		end;

		--||==================== CityManager ====================||--
		GetCityManager = function(iPlayer,iCity)
			local pPlayer			= Players[iPlayer];
	
			if pPlayer then
				local savedData		= pPlayer:GetProperty("Ophidy_CityPropertiesData"..iCity) or {};
				local pCity			= CityManager.GetCity(iPlayer,iCity);

				local o = {
					iPlayer			= iPlayer,
					iPlot			= savedData.iPlot or (pCity and pCity:GetPlot():GetIndex() or -1),
					kProperties		= savedData.kProperties or {}; -- a table of all recorded property names
					_Type			= "city",

					iCity			= iCity,
				};
				setmetatable(o, {__index = Ophidy_PropertyManager });

				return o;
			end
		end;

		ClearCity = function(self)
			local pCity = CityManager.GetCity(self.iPlayer,self.iCity);
			if not pCity then
				local pPlot = Map.GetPlotByIndex(self.iPlot);

				for k, v in pairs(self.kProperties) do
					local r = pPlot:GetProperty(k) or 0;
					pPlot:SetProperty(k, r-v);
					if DebugMode then
						print(string.format("Change Plot(%d) Property(%s) (%d)",self.iPlot,k,-v));
					end
				end

				local pPlayer = Players[self.iPlayer];
				pPlayer:SetProperty("Ophidy_CityPropertiesData"..self.iCity,nil);
			end
		end;

		--||==================== Common ====================||--
		ChangePropertyAmount = function(self,propertyName,propertyAmount)
			local pPlot			= Map.GetPlotByIndex(self.iPlot);

			--if not pPlot then print("ERROR: Cannot target plot "..self.iPlot); return; end

			local v1		= self.kProperties[propertyName] or 0;
			self.kProperties[propertyName] = v1+propertyAmount;

			if pPlot then
				local v2	= pPlot:GetProperty(propertyName) or 0;
				pPlot:SetProperty(propertyName, v2+propertyAmount);
			end
			if DebugMode then
				print(string.format("Change Plot(%d) Property(%s) (%d)",self.iPlot,propertyName,propertyAmount));
			end

			self:SavePropertiesData();
		end;

		SavePropertiesData = function(self)
			local pPlayer = Players[self.iPlayer];
			local savedData = {};
			savedData.iPlot = self.iPlot;
			savedData.kProperties = self.kProperties;

			if self._Type == "player" then
				pPlayer:SetProperty("Ophidy_PlayerPropertiesData", savedData); 
			elseif self._Type == "city" then
				pPlayer:SetProperty("Ophidy_CityPropertiesData"..self.iCity, savedData);
			end
		end;
	}

--===========================================================================================
--===========================================================================================
local function OnCapitalCityChanged(iPlayer,iCity)
	if UI then return; end
	local manager = Ophidy_PropertyManager.GetPlayerManager(iPlayer);
	if manager then
		manager:RefreshPlayer();
	end
end

local function OnCityRemovedFromMap(iPlayer,iCity)
	if UI then return; end
	local manager = Ophidy_PropertyManager.GetCityManager(iPlayer,iCity);
	if manager then
		manager:ClearCity();
	end
	local manager = Ophidy_PropertyManager.GetPlayerManager(iPlayer);
	if manager then
		manager:RefreshPlayer();
	end
end

local function OnPlayerDefeat(iPlayer)
	if UI then return; end
	local manager = Ophidy_PropertyManager.GetPlayerManager(iPlayer);
	if manager then
		manager:RefreshPlayer();
	end
end

local function Init()
	Events.CapitalCityChanged.Add(OnCapitalCityChanged);
	Events.CityRemovedFromMap.Add(OnCityRemovedFromMap);
	Events.PlayerDefeat.Add(OnPlayerDefeat);
end

Events.LoadScreenClose.Add(Init);