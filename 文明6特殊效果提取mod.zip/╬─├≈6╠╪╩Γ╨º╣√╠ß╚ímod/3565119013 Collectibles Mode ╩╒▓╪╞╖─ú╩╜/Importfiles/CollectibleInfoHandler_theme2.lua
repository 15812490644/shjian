-- CollectibleInfoHandler_theme2
-- Author: Ophidy
-- DateCreated: 4/29/2026 10:30:27 PM
--------------------------------------------------------------
--===========================================================================================
-- CONSTANTS
--===========================================================================================
local ANCIENT_TREE_FRUIT				:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_ANCIENT_TREE_FRUIT"].Index;
local CEREMONY_BELL						:number	= GameInfo.Ophidy_Collectibles["COLLECTIBLE_OPD_CEREMONY_BELL"].Index;

--===========================================================================================
g_baseHandler[ANCIENT_TREE_FRUIT] = function(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
	local playerCollectibles = CollectibleManager.GetCollectibles(iPlayer);
	local collectiblesInfo = playerCollectibles:GetCollectiblesInfo();
	local amount = 0;
	for iCollectible, kCollectible in pairs(collectiblesInfo) do
		amount = amount + kCollectible.Rarity * kCollectible.StackCount;
	end

	local iEra = Game.GetEras():GetCurrentEra();
	amount = amount * (1 + iEra * (GlobalParameters.PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS or 0.3));
	amount = math.floor(amount*10)/10;

	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_BIRTH_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.BirthDesc);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc)..Locale.Lookup('LOC_UI_COLLECTIBLES_AMOUNT_TT',amount);
	ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);

	instance.CollectibleIcon:SetToolTipString(ToolTip);
end

g_baseHandler[CEREMONY_BELL] = function(iPlayer,iCollectible,instance)
	local collectibleData = GameInfo.Ophidy_Collectibles[iCollectible];
	local pPlayer = Players[iPlayer];
	local faithBalance = pPlayer:GetReligion():GetFaithBalance() or 0;
	local amount = math.ceil(faithBalance / 2);
	amount = math.floor(amount*10)/10;

	local ToolTip = ""
	ToolTip = Locale.Lookup(collectibleData.Description);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_BIRTH_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.BirthDesc);
	ToolTip = ToolTip..'[NEWLINE]'..Locale.Lookup('LOC_UI_COLLECTIBLES_ACTIVE_TOOLTIP')..'[NEWLINE]'..Locale.Lookup(collectibleData.ActiveDesc)..Locale.Lookup('LOC_UI_COLLECTIBLES_AMOUNT_TT',amount);
	ToolTip = ToolTip..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(collectibleData.Cooldown * m_SpeedMul);

	instance.CollectibleIcon:SetToolTipString(ToolTip);
end