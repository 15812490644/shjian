-- Collectibles_Popup
-- Author: Ophidy
-- DateCreated: 9/6/2025 2:57:09 PM
--------------------------------------------------------------
include("InstanceManager");
include("CollectibleManager");
include("CollectibleInfoHelper");
--========================================================================================================================
-- CONSTANTS
--========================================================================================================================
local m_PopupInstance		:table 		= InstanceManager:new("PopupInstance", 	"Root",		Controls.PopupStack);
local m_SpeedMul 			:number		= GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;

--========================================================================================================================
-- VARIABLES
--========================================================================================================================
local m_LocalPlayer			:number		= Game.GetLocalPlayer();
local m_PlayerCollectibles;

local m_PopupQueues						= {};
--========================================================================================================================
-- CORE
--========================================================================================================================
	function Ophidy_Collectible_Generate_DiscoverBatch(kParam)
		if m_LocalPlayer == kParam.iPlayer then
			UI.PlaySound("NOTIFICATION_MISC_POSITIVE");
			
			m_PlayerCollectibles = CollectibleManager.GetCollectibles(m_LocalPlayer);
			local tBatch =kParam.tBatch
			
			if #tBatch > 0 then
				local PopupQueue = {};
				PopupQueue.Type = "Discover";
				PopupQueue.Collectibles = tBatch;
				
				table.insert(m_PopupQueues,PopupQueue);
				OpenPopup();
			end
		end
	end
	
	function Ophidy_Collectible_Create_Random_Collectible(kParam)
		local iPlayer, iCollectible = kParam.iPlayer, kParam.iCollectible;
		if m_LocalPlayer == iPlayer then
			UI.PlaySound("NOTIFICATION_MISC_POSITIVE");
			local PopupQueue = {}
			PopupQueue.Type = "Show";
			PopupQueue.iCollectible = iCollectible;
			
			table.insert(m_PopupQueues,PopupQueue);
			
			OpenPopup();
		end
	end
	
	function OpenPopup()
		if ContextPtr:IsHidden() then
			NextPopup();
		end
	end
	
	function NextPopup()
		RestartAnimations();
		m_PopupInstance:DestroyInstances();
		m_Batch = {};
		if #m_PopupQueues > 0 then
			local PopupQueue = table.remove(m_PopupQueues,1);
			if PopupQueue.Type == "Discover" then
				m_Batch = PopupQueue.Collectibles;
				for _, iCollectible in ipairs(m_Batch) do
					AddDiscoverInstance(iCollectible);
				end
				ContextPtr:SetHide(false);
				ContextPtr:SetInputHandler( function() return true; end, true );
				Controls.TitleName:SetText(Locale.Lookup("LOC_UI_COLLECTIBLES_POPUP_SELECT_TITLE"));
			else
				AddRandomCollectibleInstance(PopupQueue.iCollectible);
				ContextPtr:SetHide(false);
				ContextPtr:SetInputHandler( OnInputHandler, true );
				Controls.TitleName:SetText(Locale.Lookup("LOC_UI_COLLECTIBLES_POPUP_SHOW_TITLE"));
			end
		else
			ContextPtr:SetHide(true);
		end
	end
	

	function AddDiscoverInstance(iCollectible)
		local new = m_PopupInstance:GetInstance();
		GetBaseStats(m_LocalPlayer,iCollectible,new);
		
		new.PopupButton:SetVoid1(iCollectible);
		new.PopupButton:RegisterCallback(Mouse.eLClick,SelectDiscoverCollectible);
		new.PopupButton:SetText(Locale.Lookup("LOC_UI_COLLECTIBLES_POPUP_SELECT"));
	end
	
	function SelectDiscoverCollectible(iCollectible)
		local kParam = {};
		kParam.OnStart = "Request_Ophidy_Collectibles_Discover";
		kParam.iCollectible = iCollectible;
		kParam.tBatch = m_Batch;
		UI.RequestPlayerOperation(m_LocalPlayer, PlayerOperations.EXECUTE_SCRIPT, kParam);
		Network.BroadcastPlayerInfo();
		NextPopup()
		UI.PlaySound("UI_GREAT_WORKS_BONUS_ACHIEVED");
	end
	
	function AddRandomCollectibleInstance(iCollectible)
		local new = m_PopupInstance:GetInstance();
		GetBaseStats(m_LocalPlayer,iCollectible,new)
	
		new.PopupButton:RegisterCallback(Mouse.eLClick,NextPopup);
		new.PopupButton:SetText(Locale.Lookup("LOC_UI_COLLECTIBLES_POPUP_SHOW"));
	end
	
	function OnInputHandler(pInputStruct:table)
		local uiMsg = pInputStruct:GetMessageType();
		if uiMsg == KeyEvents.KeyUp and pInputStruct:GetKey() == Keys.VK_ESCAPE then
			if not ContextPtr:IsHidden() then
				NextPopup();
			end
			return true;
		end
		return true;
	end
	
	function RestartAnimations()
		Controls.AlphaIn:SetToBeginning();
		Controls.AlphaIn:Play();
	end
	
	function OnUpdateUI( type:number, tag:string, iData1:number, iData2:number, strData1:string)
		if type == SystemUpdateUI.ScreenResize then
			Resize();
		end
	end
	
	function Resize()
		local x, y	= UIManager:GetScreenSizeVal();
		ContextPtr:SetSizeX(x); ContextPtr:SetSizeY(y); 
	end

--========================================================================================================================
-- INIT
--========================================================================================================================
	function Initialize()
		--ContextPtr:SetAutoSize(true);
		ContextPtr:SetHide(true);
		LuaEvents.Ophidy_Collectible_Generate_DiscoverBatch.Add(Ophidy_Collectible_Generate_DiscoverBatch);
		LuaEvents.Ophidy_Collectible_Create_Random_Collectible.Add(Ophidy_Collectible_Create_Random_Collectible);
		
		Events.SystemUpdateUI.Add(OnUpdateUI);
	end
Initialize();