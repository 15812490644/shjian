-- Collectibles_Button
-- Author: Ophidy
-- DateCreated: 9/3/2025 10:31:06 PM
--------------------------------------------------------------
include("CollectibleManager");

--========================================================================================================================
-- VARIABLES
--========================================================================================================================
local m_LaunchButtonInstance = {};
local m_LaunchButtonLocked = false;
local m_LocalPlayer	= Game.GetLocalPlayer();

--========================================================================================================================
-- CORE
--========================================================================================================================
function TogglePopup()
	LuaEvents.Ophidy_CollectiblesPanel_Popup()
end

function AttachLaunchButton()
    local buttonStack = ContextPtr:LookUpControl("/InGame/LaunchBar/ButtonStack");

    ContextPtr:BuildInstanceForControl("ButtonInstance", m_LaunchButtonInstance, buttonStack);
    m_LaunchButtonInstance.Button:RegisterCallback(Mouse.eLClick, TogglePopup);
    ContextPtr:BuildInstanceForControl("PinInstance", {}, buttonStack);

    -- Resize.
    buttonStack:CalculateSize();

    local backing = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBacking");
    backing:SetSizeX(buttonStack:GetSizeX() + 116);

    local backingTile = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBackingTile");
    backingTile:SetSizeX(buttonStack:GetSizeX() - 20);

    LuaEvents.LaunchBar_Resize(buttonStack:GetSizeX());
end

function OnButtonSetup()
	local iPlayer = Game.GetLocalPlayer();
	local pPlayer = Players[iPlayer]
	if pPlayer and pPlayer:IsHuman() then
		if not m_LaunchButtonLocked then
			AttachLaunchButton();
			m_LaunchButtonLocked = true
		end
	end
end

function Ophidy_Collectible_Released(kParam)
	if kParam.iPlayer == m_LocalPlayer then
		RefreshIndicator()
	end
end

function Ophidy_Collectible_Actibated(kParam)
	if kParam.iPlayer == m_LocalPlayer then
		RefreshIndicator()
	end
end

function RefreshIndicator()
	local PlayerCollectibles = CollectibleManager.GetCollectibles(m_LocalPlayer);
	if PlayerCollectibles:GetFreeCapacity() > 0 then
		m_LaunchButtonInstance.AlertIndicator:SetHide(false);
	else
		m_LaunchButtonInstance.AlertIndicator:SetHide(true);
	end
end


--========================================================================================================================
-- INIT
--========================================================================================================================
function Initialize()
    Events.LoadGameViewStateDone.Add(OnButtonSetup);
	LuaEvents.Ophidy_Collectible_Released.Add(Ophidy_Collectible_Released);
	Events.LocalPlayerTurnBegin.Add(RefreshIndicator);
	LuaEvents.Ophidy_Collectible_Activated.Add(Ophidy_Collectible_Actibated);
end

Initialize();