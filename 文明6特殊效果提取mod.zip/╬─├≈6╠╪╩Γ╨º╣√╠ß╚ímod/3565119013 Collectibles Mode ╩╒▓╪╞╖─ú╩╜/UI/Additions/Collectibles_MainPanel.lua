-- Collectibles_MainPanel
-- Author: Ophidy
-- DateCreated: 9/3/2025 11:40:54 AM
--------------------------------------------------------------
include("GameCapabilities");
include("InstanceManager");
include("ModalScreen_PlayerYieldsHelper");
include("CollectibleManager");
include("PopupDialog");

include("CollectibleInfoHelper");
--========================================================================================================================
-- CONSTANTS
--========================================================================================================================
local m_SpeedMul 			:number		= GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;
local m_IsXP1Active			:boolean	= Modding.IsModActive("1B28771A-C749-434B-9053-D1380C553DE9");
local m_IsXP2Active			:boolean	= Modding.IsModActive("4873eb62-8ccc-4574-b784-dda455e74e68");

local m_CollectibleIM		:table 		= InstanceManager:new("CollectibleInstance", 	"Root", Controls.CollectiblesListStack);
local m_ActivedIM			:table 		= InstanceManager:new("CollectibleInstance", 	"Root", Controls.CollectiblesActivatedStack);

local m_GoodIM				:table 		= InstanceManager:new("GoodInstance", 			"Root",	Controls.GoodsStack);

--========================================================================================================================
-- VARIABLES
--========================================================================================================================
local debug					:boolean	= true;
local m_SelectedItems		:table		= {};
local m_numSelected			:number		= 0;
local m_LocalPlayer			:number		= Game.GetLocalPlayer();
local m_PlayerCollectibles;

--========================================================================================================================
-- SHOWCASE
--========================================================================================================================
	function RefreshShowcase()
		m_CollectibleIM:ResetInstances();
		m_ActivedIM:ResetInstances();
		m_SelectedItems = {};
		m_numSelected	= 0;
		Controls.ActivateButton:SetDisabled(true);

		PopulateCollectibles();
		
		local BusyCapacity = m_PlayerCollectibles:GetBusyCapacity();
		local Capacity = m_PlayerCollectibles:GetCapacity();
		Controls.CapacityTip:SetText(BusyCapacity.."/"..Capacity);
	end

	function PopulateCollectibles()
		local CollectiblesInfo = m_PlayerCollectibles:GetCollectiblesInfo();
		
		local SortData = {}
		for iCollectible, kCollectible in pairs(CollectiblesInfo) do
			if m_PlayerCollectibles:HasCollectible(iCollectible) then
				local kData = {};
				kData.iCollectible = iCollectible;
				kData.kCollectible = kCollectible;
				table.insert(SortData,kData);
			end
		end
		
		table.sort(SortData, function(a,b) return a.kCollectible.Rarity > b.kCollectible.Rarity; end)
		
		for _, kData in ipairs(SortData) do
			AddCollectibleInst(kData.iCollectible,kData.kCollectible)
		end
	end

	function AddCollectibleInst(iCollectible,kCollectible)
		local isActivating = m_PlayerCollectibles:IsCollectibleActivating(iCollectible);
		if isActivating then
			local new = m_ActivedIM:GetInstance();
			GetChestStats(m_LocalPlayer,iCollectible,new);
		else
			local new = m_CollectibleIM:GetInstance();
			GetChestStats(m_LocalPlayer,iCollectible,new);

			new.CollectibleBox:SetSelected(false);
			new.DefaultBG:SetAlpha(1)
			if new.usable then
				new.CollectibleBox:RegisterCallback(Mouse.eLClick,
				function()
					OnCollectibleSelected(iCollectible, new);
				end)
			else
				new.CollectibleBox:RegisterCallback(Mouse.eLClick,function() end);
			end
		end
	end

	function OnCollectibleSelected(iCollectible, instance)
		local FreeCapacity = m_PlayerCollectibles:GetFreeCapacity();
		if not instance.CollectibleBox:IsSelected() then
			m_SelectedItems[iCollectible] = true
			instance.CollectibleBox:SetSelected(true)
			instance.DefaultBG:SetAlpha(3)
			m_numSelected = m_numSelected + 1
		else
			m_SelectedItems[iCollectible] = false
			instance.CollectibleBox:SetSelected(false)
			instance.DefaultBG:SetAlpha(1)
			m_numSelected = m_numSelected - 1
		end
	
		if m_numSelected > FreeCapacity or m_numSelected == 0 then
			Controls.ActivateButton:SetDisabled(true)
		else
			Controls.ActivateButton:SetDisabled(false)
		end
	end

	function OnConfirmActivate()	
		local kParam = {};
		kParam.OnStart = "Request_Ophidy_Collectibles_Activate";
		kParam.Collectibles = m_SelectedItems;
		UI.RequestPlayerOperation(m_LocalPlayer, PlayerOperations.EXECUTE_SCRIPT, kParam);
		Network.BroadcastPlayerInfo();
		UI.PlaySound("UI_GREAT_WORKS_BONUS_ACHIEVED");
	end

--========================================================================================================================
-- TRADER
--========================================================================================================================
	function RefreshGoods()
		m_GoodIM:ResetInstances();
		PopulateGoods();
		ResetRefreshButton();
		local PlayerToken = m_PlayerCollectibles:GetToken();
		Controls.Tokens:SetText(math.floor(PlayerToken*10)/10);
		Controls.TokenIcon:SetToolTipString(GetTokenToolTip());
	end
	
	function PopulateGoods()
		local GoodsInfo = m_PlayerCollectibles:GetGoods();
		if not GoodsInfo or #GoodsInfo == 0 then 
			RandomizeCannotEmpty();
			return; 
		end
		for i = 1, #GoodsInfo do
			local kCollectible = GoodsInfo[i];
			local new = m_GoodIM:GetInstance();
			local iCollectible = kCollectible.Index;
			GetBaseStats(m_LocalPlayer,iCollectible,new);
			
			local TokenCost = kCollectible.Cost;
			new.Cost:SetText(math.ceil(TokenCost));
		
			new.CollectibleBox:SetVoids(iCollectible,TokenCost);
			
			local PlayerToken = m_PlayerCollectibles:GetToken();
			if PlayerToken >= TokenCost then
				new.CollectibleBox:RegisterCallback(Mouse.eLClick,OnGoodClicked);
				new.Cost:SetColorByName("White");
			else
				new.CollectibleBox:RegisterCallback(Mouse.eLClick,RandomizeCannotPoor);
				new.Cost:SetColorByName("Red");
			end
		end
	end
		
	function GetTokenToolTip()
		local pPlayer = Players[m_LocalPlayer];
		local ChangeInfo = pPlayer:GetProperty("COLLECTIBLES_SCORE_CHANGED_INFO") or {};
		local GameMultiplier = tonumber(GameConfiguration.GetValue("Opd_GameTokenMultiplier") or 1);

		local ToolTip = "";
		ToolTip = ToolTip .. Locale.Lookup("LOC_UI_COLLECTIBLES_TOKEN_TOOLTIP_SUM",math.floor(ChangeInfo.Increment*10)/10);
		ToolTip = ToolTip .. "[NEWLINE]" .. "----------------------";
		ToolTip = ToolTip .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_COLLECTIBLES_TOKEN_TOOLTIP_SCORE",math.floor(ChangeInfo.ScoreChange*10)/10);
		ToolTip = ToolTip .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_COLLECTIBLES_TOKEN_TOOLTIP_INTEREST",math.floor(ChangeInfo.InterestRate*10)/10,math.floor(ChangeInfo.InterestChange*10)/10);
		ToolTip = ToolTip .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_COLLECTIBLES_TOKEN_TOOLTIP_ERA",math.floor(ChangeInfo.EraWage*10)/10);
		ToolTip = ToolTip .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_COLLECTIBLES_TOKEN_TOOLTIP_CHANGE_BY_ERA",math.floor(ChangeInfo.ChangeEra*10)/10);
		ToolTip = ToolTip .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_COLLECTIBLES_TOKEN_TOOLTIP_CHANGE",math.floor(ChangeInfo.ChangeNormal*10)/10);
		ToolTip = ToolTip .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_COLLECTIBLES_TOKEN_TOOLTIP_MODIFIER",math.floor(ChangeInfo.Modifier*10)/10,math.floor(ChangeInfo.ChangeModifier*10)/10);
		ToolTip = ToolTip .. "[NEWLINE]" .. Locale.Lookup("LOC_UI_COLLECTIBLES_TOKEN_TOOLTIP_GAMEMULTIPLIER",GameMultiplier/10);
		return ToolTip;
	end
	
	function RandomizeCannotEmpty()
		local text = GetRandomizeCannotTextKey("LOC_UI_COLLECTIBLES_CANNOT_LOG_EMPTY_");
		GetCannotDialog(text);
	end
	
	function RandomizeCannotGreeting()
		local text = GetRandomizeCannotTextKey("LOC_UI_COLLECTIBLES_CANNOT_LOG_GREETING_");
		GetCannotDialog(text);
	end
	
	function RandomizeCannotPoor()
		local text = GetRandomizeCannotTextKey("LOC_UI_COLLECTIBLES_CANNOT_LOG_POOR_");
		GetCannotDialog(text);
	end
	
	function GetRandomizeCannotTextKey(prefix)
		local i = 1;
		local texts = {};
		repeat 
			local key = prefix .. i;
			local text;
			if Locale.HasTextKey(key) then
				text = key;
				table.insert(texts,text);
			end
			i = i + 1;
		until(text == nil);
		
		if #texts > 0 then
			return texts[math.random(#texts)];
		end
	end
	
	function GetCannotDialog(Text)
		Controls.DialogText:SetText(Locale.Lookup(Text));
		Controls.AlphaIn:SetToBeginning();
		Controls.SlideIn:SetToBeginning();
		Controls.AlphaIn:Play();
		Controls.SlideIn:Play();
	end
	
	function OnGoodClicked(iCollectible,Cost)
		local pPopupDialog :table = PopupDialogInGame:new("PurchaseCollectible");
		pPopupDialog:AddText(Locale.Lookup("LOC_UI_COLLECTIBLES_PURCHASE_CONFIRM"));
		pPopupDialog:AddConfirmButton(Locale.Lookup("LOC_YES"), function()
				local kParam = {};
				kParam.OnStart = "Request_Ophidy_Collectibles_Purchase";
				kParam.iCollectible = iCollectible;
				kParam.Cost = Cost;
				UI.RequestPlayerOperation(m_LocalPlayer, PlayerOperations.EXECUTE_SCRIPT, kParam);
				Network.BroadcastPlayerInfo();
				UI.PlaySound("UI_GREAT_WORKS_BONUS_ACHIEVED");
		end);
		pPopupDialog:AddCancelButton(Locale.Lookup("LOC_NO"), nil);
		pPopupDialog:Open();
	end

	function ResetRefreshButton()
		local iEra = Game.GetEras():GetCurrentEra();
		local pPlayer = Players[m_LocalPlayer];
		local num = pPlayer:GetProperty("COLLECTIBLES_GOODS_REFRESHED_ERA_" .. iEra) or tonumber(GameConfiguration.GetValue("Opd_RefreshChance") or 1);
		if num > 0 then
			Controls.RefreshButton:SetHide(false);
			Controls.RefreshButton:SetVoid1(num);
			Controls.RefreshButton:RegisterCallback(Mouse.eLClick,OnRefreshButtonClicked);
		else
			Controls.RefreshButton:SetHide(true);
		end
	end

	function OnRefreshButtonClicked(num)
		local pPopupDialog :table = PopupDialogInGame:new("RefreshCollectibles");
		pPopupDialog:AddText(Locale.Lookup("LOC_UI_COLLECTIBLES_REFRESH_POPUP",num));
		pPopupDialog:AddConfirmButton(Locale.Lookup("LOC_YES"), function()
				local kParam = {};
				kParam.OnStart = "Request_Ophidy_Collectibles_RefreshGoods";
				kParam.Num = num;
				UI.RequestPlayerOperation(m_LocalPlayer, PlayerOperations.EXECUTE_SCRIPT, kParam);
				UI.PlaySound("Confirm_Civic_CivicsTree");
				Network.BroadcastPlayerInfo();
		end);
		pPopupDialog:AddCancelButton(Locale.Lookup("LOC_NO"), nil);
		pPopupDialog:Open();
	end
	
--========================================================================================================================
-- UI CONTROLLER
--========================================================================================================================
	function OnInit( isReload:boolean )
		if isReload then
			Open();
		end
	end

	function OnInputHandler(pInputStruct:table)
		local uiMsg = pInputStruct:GetMessageType();
		if uiMsg == KeyEvents.KeyUp and pInputStruct:GetKey() == Keys.VK_ESCAPE then
			if not ContextPtr:IsHidden() then
				CloseCollectiblesPanel();
			end
			return true;
		end
		return false;
	end

	function Resize()
		local width, height	= UIManager:GetScreenSizeVal();
		width = math.max(math.min(width,1536),1024);
		
		Controls.Collectibles_MainContainer:SetSizeX(width);
		Controls.CollectiblesActivatedStack:SetWrapWidth(width);
		Controls.CollectiblesListStack:SetWrapWidth(width);
	end

	function OnUpdateUI( type:number, tag:string, iData1:number, iData2:number, strData1:string)
		if type == 0 then
			Resize();
		end
	end

-- ===========================================================================
	function OnTogglePanel()
		if ContextPtr:IsHidden() then
			Open();
		else
			CloseCollectiblesPanel();
		end
	end

	function Open()
		if (Game.GetLocalPlayer() == -1) then
			return false;
		end
		RefreshAll();
		ContextPtr:SetHide(false);
	
		if not UIManager:IsInPopupQueue(ContextPtr) then
			local kParameters = {};
			kParameters.RenderAtCurrentParent = true;
			kParameters.InputAtCurrentParent = true;
			kParameters.AlwaysVisibleInQueue = true;
			UIManager:QueuePopup(ContextPtr, PopupPriority.Low, kParameters);
			-- Change our parent to be 'Screens' so the navigational hooks draw on top of it.
			ContextPtr:ChangeParent(ContextPtr:LookUpControl("/InGame/Screens"));
			UI.PlaySound("UI_Screen_Open");
		end
		-- From ModalScreen_PlayerYieldsHelper
		if not RefreshYields() then
			local _, height	= UIManager:GetScreenSizeVal();
			Controls.Vignette:SetSizeY(height - TOP_PANEL_OFFSET);
		end
		
		Controls.ScreenAnimIn:SetToBeginning();
		Controls.ScreenAnimIn:Play();
		LuaEvents.Ophidy_CollectiblesPanel_Open();
		
		local launchContainer = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchContainer");
		local _, height	= UIManager:GetScreenSizeVal();
		if height <= 850 then
			launchContainer:SetOffsetY(-35);
		end
	end

	function Close()
		UIManager:DequeuePopup(ContextPtr);
		ContextPtr:SetHide(true);
	end
	
	function CloseCollectiblesPanel()
		if not ContextPtr:IsHidden() then
			Close();
			LuaEvents.Ophidy_CollectiblesPanel_Close();
			-- reset launchbar
			LuaEvents.GovernorPanel_Closed();
		end
	end

	function CloseOtherPanels()
		LuaEvents.LaunchBar_CloseTechTree();
		LuaEvents.LaunchBar_CloseCivicsTree();
		LuaEvents.LaunchBar_CloseGovernmentPanel();
		LuaEvents.LaunchBar_CloseReligionPanel();
		LuaEvents.LaunchBar_CloseGreatPeoplePopup();
		LuaEvents.LaunchBar_CloseGreatWorksOverview();
		if m_IsXP1Active then
			LuaEvents.GovernorPanel_Close()
			LuaEvents.HistoricMoments_Close()
		end
		if m_IsXP2Active then
			LuaEvents.Launchbar_Expansion2_ClimateScreen_Close()
		end
	end
	
	function Ophidy_Collectible_Saved(kParam)
		if kParam.iPlayer == m_LocalPlayer then
			RefreshAll();
		end
 	end
	
	function RefreshAll()
		m_PlayerCollectibles = CollectibleManager.GetCollectibles(m_LocalPlayer);
		RandomizeCannotGreeting();
		RefreshShowcase();
		RefreshGoods();
		
		local tabID : string = Controls.TabControl:GetSelectedTabID();
		if tabID == "Showcase" then
			Controls.CannotImage:SetHide(true);
			
		elseif tabID == "Trader" then
			Controls.CannotImage:SetHide(false);
			
			local iRatio = Controls.DummyImage:GetSizeX()/Controls.DummyImage:GetSizeY();
			
			local panelX = Controls.Collectibles_MainContainer:GetSizeX();
			local cannotY = Controls.CannotImage:GetSizeY();
			local entityX = iRatio * cannotY + 40;
			
			Controls.GoodsScroll:SetOffsetX(entityX)
			
			local spareX = panelX - entityX;
			
			Controls.GoodsStack:SetWrapWidth(spareX);
			
			Controls.GoodsStack:CalculateSize();
			local goodsX = Controls.GoodsStack:GetSizeX();
			Controls.GoodsScroll:SetSizeX(goodsX + 20);
			Controls.GoodsScrollbar:DoAutoSize();
		end
	end

--========================================================================================================================
-- INIT
--========================================================================================================================
	function Initialize()
		ContextPtr:SetHide(true);
		ContextPtr:SetInitHandler( OnInit );
		ContextPtr:SetInputHandler( OnInputHandler, true );

		Controls.CloseButton:RegisterCallback(Mouse.eLClick, CloseCollectiblesPanel);
		Controls.ActivateButton:RegisterCallback(Mouse.eLClick, OnConfirmActivate);
		
		Controls.SelectTab_Showcase:RegisterCallback(Mouse.eLClick, RefreshAll);
		Controls.SelectTab_Trader:RegisterCallback(Mouse.eLClick, RefreshAll);
		
		Controls.Debug:SetHide(true);
		--Events.TurnBegin.Add(Close);
		LuaEvents.Ophidy_CollectiblesPanel_Popup.Add(OnTogglePanel);
		LuaEvents.Ophidy_CollectiblesPanel_Open.Add(CloseOtherPanels);
	
		LuaEvents.DiplomacyActionView_HideIngameUI.Add(Close)
		LuaEvents.EndGameMenu_Shown.Add(Close)
		LuaEvents.FullscreenMap_Shown.Add(Close)
		LuaEvents.NaturalWonderPopup_Shown.Add(Close)
		LuaEvents.ProjectBuiltPopup_Shown.Add(Close)
		LuaEvents.Tutorial_ToggleInGameOptionsMenu.Add(Close)
		LuaEvents.WonderBuiltPopup_Shown.Add(Close)
		LuaEvents.NaturalDisasterPopup_Shown.Add(Close)  
		LuaEvents.RockBandMoviePopup_Shown.Add(Close)
		LuaEvents.CivicsTree_OpenCivicsTree.Add(Close);	
		LuaEvents.Government_OpenGovernment.Add(Close);
		LuaEvents.GovernorPanel_Opened.Add(Close);	
		LuaEvents.GreatPeople_OpenGreatPeople.Add(Close);
		LuaEvents.GreatWorks_OpenGreatWorks.Add(Close);
		LuaEvents.HistoricMoments_Opened.Add(Close);
		LuaEvents.Religion_OpenReligion.Add(Close);	
		LuaEvents.PantheonChooser_OpenReligion.Add(Close);	
		LuaEvents.TechTree_OpenTechTree.Add(Close);
		LuaEvents.ClimateScreen_Opened.Add(Close);
		-- Mod support
		LuaEvents.DetailedWonderReminderButton_TogglePopup.Add(Close);
		LuaEvents.ACSR_TogglePopup.Add(Close);
		LuaEvents.ACSF_TogglePopup.Add(Close);
		
		LuaEvents.Ophidy_Collectible_Saved.Add(Ophidy_Collectible_Saved);

		Events.SystemUpdateUI.Add(OnUpdateUI);
		Resize();
	end

Initialize();