-- Collectibles_theme2
-- Author: Ophidy
-- DateCreated: 4/29/2026 7:43:35 PM
--------------------------------------------------------------
function GetCurrentEraScore(iPlayer)
	return Game.GetEras():GetPlayerCurrentScore(iPlayer);
end

ExposedMembers.Ophidy_Collectibles = ExposedMembers.Ophidy_Collectibles or {};
ExposedMembers.Ophidy_Collectibles.GetCurrentEraScore = GetCurrentEraScore;