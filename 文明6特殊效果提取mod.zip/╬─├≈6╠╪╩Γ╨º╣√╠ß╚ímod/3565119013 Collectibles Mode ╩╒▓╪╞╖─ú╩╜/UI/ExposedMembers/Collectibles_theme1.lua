-- Collectibles_theme1
-- Author: Ophidy
-- DateCreated: 9/6/2025 10:12:18 PM
--------------------------------------------------------------




function GetGoldenEraScore(iPlayer)
	return Game.GetEras():GetPlayerGoldenAgeThreshold(iPlayer) - Game.GetEras():GetPlayerCurrentScore(iPlayer);
end

ExposedMembers.Ophidy_Collectibles = ExposedMembers.Ophidy_Collectibles or {};
ExposedMembers.Ophidy_Collectibles.GetGoldenEraScore = GetGoldenEraScore;