-- Config
-- Author: Ophidy
-- DateCreated: 9/4/2025 5:39:30 PM
--------------------------------------------------------------
INSERT OR IGNORE INTO GameModeItems
	(
		GameModeType,
		Name,
		Icon,
		Portrait,
		Background,
		SortIndex
	)
VALUES
	(
		'GAMEMODE_OPD_COLLECTIBLES',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_NAME',
		'ICON_GAMEMODE_OPD_COLLECTIBLES',
		'IMG_GAMEMODE_GAMEMODE_OPD_COLLECTIBLES_FORE',
		'OPHIDY_GAMEMODE_BACKGROUND',
		10
	);

INSERT OR IGNORE INTO Parameters
	(
		ParameterId,
		Name,
		Description,
		Domain,
		DefaultValue,
		ConfigurationGroup,
		NameArrayConfigurationId,
		ConfigurationId,
		GroupId
	)
VALUES
	(
		'GameMode_Opd_Collectibles',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_NAME',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_DESCRIPTION',
		'bool',
		0,
		'Game',
		'GAMEMODES_ENABLED_NAMES',
		'GAMEMODE_OPD_COLLECTIBLES',
		'GameModes'
	),
	(
					
		'GameMode_Opd_Collectibles_GameTokenMultiplier',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_GAMETOKENMULTIPLIER_NAME',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_GAMETOKENMULTIPLIER_DESCRIPTION',
		'Opd_GameTokenMultiplier',
		10,
		'Game',
		NULL,
		'Opd_GameTokenMultiplier',
		'GameOptions'
	),
	(
					
		'GameMode_Opd_Collectibles_RefreshChance',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_REFRESHCHANCE_NAME',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_REFRESHCHANCE_DESCRIPTION',
		'Opd_RefreshChance',
		1,
		'Game',
		NULL,
		'Opd_RefreshChance',
		'GameOptions'
	),
	(
					
		'GameMode_Opd_Collectibles_Luck',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_LUCK_NAME',
		'LOC_GAMEMODE_OPD_COLLECTIBLES_LUCK_DESCRIPTION',
		'Opd_Luck',
		40,
		'Game',
		NULL,
		'Opd_Luck',
		'GameOptions'
	);

INSERT OR IGNORE INTO DomainRanges
		(Domain,						MinimumValue,	MaximumValue)
VALUES	('Opd_GameTokenMultiplier',		5,				50),
		('Opd_RefreshChance',			0,				5),
		('Opd_Luck',					10,				100);

INSERT OR IGNORE INTO ParameterDependencies
	(
		ParameterId,
		ConfigurationGroup,
		ConfigurationId,
		Operator,
		ConfigurationValue
	)
VALUES
	(
		'GameMode_Opd_Collectibles',
		'Game',
		'RULESET',
		'Exists',
		'RULESET_EXPANSION_1,RULESET_EXPANSION_2'
	),
	(
		'GameMode_Opd_Collectibles_GameTokenMultiplier',
		'Game',
		'GAMEMODE_OPD_COLLECTIBLES',
		'Equals',
		1
	),
	(
		'GameMode_Opd_Collectibles_RefreshChance',
		'Game',
		'GAMEMODE_OPD_COLLECTIBLES',
		'Equals',
		1
	),
	(
		'GameMode_Opd_Collectibles_Luck',
		'Game',
		'GAMEMODE_OPD_COLLECTIBLES',
		'Equals',
		1
	);