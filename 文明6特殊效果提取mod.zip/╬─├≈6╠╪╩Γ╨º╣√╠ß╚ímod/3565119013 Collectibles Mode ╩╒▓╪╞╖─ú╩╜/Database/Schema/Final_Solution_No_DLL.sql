-- Final_Solution_No_DLL
-- Author: Ophidy
-- DateCreated: 5/31/2026 7:10:25 PM
--------------------------------------------------------------
-- this file has the largest LoadOrder
--========================================================================================================================
-- DynamicModifiers
--========================================================================================================================
	INSERT OR IGNORE INTO Types
			(Type,														Kind)
	VALUES	('MODTYPE_OPHIDY_ALL_CAPITAL_CITIES_ATTACH_MODIFIER',			'KIND_MODIFIER');

	INSERT OR IGNORE INTO DynamicModifiers
			(ModifierType,												CollectionType,						EffectType)
	VALUES	('MODTYPE_OPHIDY_ALL_CAPITAL_CITIES_ATTACH_MODIFIER',			'COLLECTION_ALL_CAPITAL_CITIES',	'EFFECT_ATTACH_MODIFIER');
					
--========================================================================================================================
-- Core
--========================================================================================================================
	CREATE TEMPORARY TABLE StackCounter AS
	WITH RECURSIVE recur(Counter) AS (
		SELECT 1
		UNION ALL
		SELECT Counter + 1
		FROM recur
		WHERE Counter < 99
	)
	SELECT DISTINCT Counter FROM recur;

--========================================================================================================================
-- Birth Modifiers
--========================================================================================================================
	INSERT OR IGNORE INTO GameModifiers (ModifierId)
	SELECT DISTINCT	b.CollectibleType || '_' || b.ModifierId || '_BIRTH_' || n.Counter
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_BirthModifier b ON c.CollectibleType = b.CollectibleType CROSS JOIN StackCounter n WHERE n.Counter <= c.StackLimit;

	INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, SubjectRequirementSetId)
	SELECT DISTINCT	b.CollectibleType || '_' || b.ModifierId || '_BIRTH_' || n.Counter, 'MODTYPE_OPHIDY_ALL_CAPITAL_CITIES_ATTACH_MODIFIER', 'REQSET_OPD_BIRTH_' || c.CollectibleType || '_' || n.Counter
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_BirthModifier b ON c.CollectibleType = b.CollectibleType CROSS JOIN StackCounter n WHERE n.Counter <= c.StackLimit;

	INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
	SELECT DISTINCT	b.CollectibleType || '_' || b.ModifierId || '_BIRTH_' || n.Counter, 'ModifierId', b.ModifierId
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_BirthModifier b ON c.CollectibleType = b.CollectibleType CROSS JOIN StackCounter n WHERE n.Counter <= c.StackLimit;

	INSERT OR IGNORE INTO RequirementSets (RequirementSetId, RequirementSetType)
	SELECT DISTINCT	'REQSET_OPD_BIRTH_' || c.CollectibleType || '_' || n.Counter, 'REQUIREMENTSET_TEST_ALL'
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_BirthModifier b ON c.CollectibleType = b.CollectibleType CROSS JOIN StackCounter n WHERE n.Counter <= c.StackLimit;

	INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
	SELECT DISTINCT	'REQSET_OPD_BIRTH_' || c.CollectibleType || '_' || n.Counter, 'REQ_OPD_BIRTH_' || c.CollectibleType || '_' || n.Counter
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_BirthModifier b ON c.CollectibleType = b.CollectibleType CROSS JOIN StackCounter n WHERE n.Counter <= c.StackLimit;

	INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
	SELECT DISTINCT	'REQ_OPD_BIRTH_' || c.CollectibleType || '_' || n.Counter, 'REQUIREMENT_PLOT_PROPERTY_MATCHES'
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_BirthModifier b ON c.CollectibleType = b.CollectibleType CROSS JOIN StackCounter n WHERE n.Counter <= c.StackLimit;

	INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
	SELECT DISTINCT	'REQ_OPD_BIRTH_' || c.CollectibleType || '_' || n.Counter, 'PropertyName', c.CollectibleType || '_BIRTH'
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_BirthModifier b ON c.CollectibleType = b.CollectibleType CROSS JOIN StackCounter n WHERE n.Counter <= c.StackLimit
	UNION
	SELECT DISTINCT	'REQ_OPD_BIRTH_' || c.CollectibleType || '_' || n.Counter, 'PropertyMinimum', n.Counter
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_BirthModifier b ON c.CollectibleType = b.CollectibleType CROSS JOIN StackCounter n WHERE n.Counter <= c.StackLimit;

--========================================================================================================================
-- Active Modifiers
--========================================================================================================================
	INSERT OR IGNORE INTO GameModifiers (ModifierId)
	SELECT DISTINCT	b.CollectibleType || '_' || b.ModifierId || '_ACTIVE'
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_ActiveModifier b ON c.CollectibleType = b.CollectibleType;

	INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, SubjectRequirementSetId)
	SELECT DISTINCT	b.CollectibleType || '_' || b.ModifierId || '_ACTIVE', 'MODTYPE_OPHIDY_ALL_CAPITAL_CITIES_ATTACH_MODIFIER', 'REQSET_OPD_ACTIVE_' || c.CollectibleType
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_ActiveModifier b ON c.CollectibleType = b.CollectibleType;

	INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
	SELECT DISTINCT	b.CollectibleType || '_' || b.ModifierId || '_ACTIVE', 'ModifierId', b.ModifierId
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_ActiveModifier b ON c.CollectibleType = b.CollectibleType;

	INSERT OR IGNORE INTO RequirementSets (RequirementSetId, RequirementSetType)
	SELECT DISTINCT	'REQSET_OPD_ACTIVE_' || c.CollectibleType, 'REQUIREMENTSET_TEST_ALL'
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_ActiveModifier b ON c.CollectibleType = b.CollectibleType;

	INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
	SELECT DISTINCT	'REQSET_OPD_ACTIVE_' || c.CollectibleType, 'REQ_OPD_ACTIVE_' || c.CollectibleType
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_ActiveModifier b ON c.CollectibleType = b.CollectibleType;

	INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
	SELECT DISTINCT	'REQ_OPD_ACTIVE_' || c.CollectibleType, 'REQUIREMENT_PLOT_PROPERTY_MATCHES'
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_ActiveModifier b ON c.CollectibleType = b.CollectibleType;

	INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
	SELECT DISTINCT	'REQ_OPD_ACTIVE_' || c.CollectibleType, 'PropertyName', c.CollectibleType || '_ACTIVE'
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_ActiveModifier b ON c.CollectibleType = b.CollectibleType
	UNION
	SELECT DISTINCT	'REQ_OPD_ACTIVE_' || c.CollectibleType, 'PropertyMinimum', 1
	FROM Ophidy_Collectibles c INNER JOIN Ophidy_Collectible_ActiveModifier b ON c.CollectibleType = b.CollectibleType;

--========================================================================================================================
-- Collectible Updates
--========================================================================================================================
	UPDATE Ophidy_Collectibles SET Unchangeable = 1 
		WHERE CollectibleType IN (
			'COLLECTIBLE_OPD_DREAMBIND_CASTLE_MODEL',
			'COLLECTIBLE_OPD_DOLL_HOUSE',
			'COLLECTIBLE_OPD_HOT_WATER_KETTLE'
		);