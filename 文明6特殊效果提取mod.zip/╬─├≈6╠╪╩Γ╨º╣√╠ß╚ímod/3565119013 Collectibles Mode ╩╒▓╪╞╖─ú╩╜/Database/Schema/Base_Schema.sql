-- Base_Schema
-- Author: Ophidy
-- DateCreated: 9/2/2025 11:45:04 PM
--------------------------------------------------------------
--========================================================================================================================
-- Kinds
--========================================================================================================================
	/*
	INSERT OR IGNORE INTO Kinds
			(Kind)
	VALUES	('KIND_OPD_COLLECTIBLE');
	*/
--========================================================================================================================
-- �½���
--========================================================================================================================
	CREATE TABLE IF NOT EXISTS 'Ophidy_Collectibles'
	(
		'CollectibleType'	TEXT NOT NULL,
		'Name'				TEXT NOT NULL,
		'Description'		TEXT NOT NULL,
		'BirthDesc'			TEXT,														
		'ActiveDesc'		TEXT,														-- 
		'Rarity'			INT NOT NULL CHECK (Rarity IN (0,1,2,3,4,5,6,7)) DEFAULT 1,	-- ϡ�ж�
		'Cooldown'			INT NOT NULL DEFAULT 20,									-- ��Ч/��ȴʱ��
		'TraitType'			TEXT DEFAULT NULL,											-- ר����ĳ�����Ĳ�Ʒ��δӵ�и�TraitType���޷���ȡ	
		'Unchangeable'		BOOLEAN NOT NULL CHECK (Unchangeable IN (0,1)) DEFAULT 0,	-- ��ȡ���Ƿ���Ա�ɾ��/�ı�
		'StackLimit'		INT NOT NULL DEFAULT 1,										-- ���ͬʱ�ѵ��������ﵽ����ʱ�ò�Ʒ�޷��ٻ�ã����Ϊ99
		'Tradable'			BOOLEAN NOT NULL CHECK (Tradable IN (0,1)) DEFAULT 1,		-- �����̵깺��
		'MustPurchase'		BOOLEAN NOT NULL CHECK (MustPurchase IN (0,1)) DEFAULT 0,	-- ֻ�����̵깺��
		'MaxInstance'		INT,														-- ������ɴ��������ֵĬ�ϸ���StackLimit����ϣ���������������ɣ�����-1��
		'Cost'				INT,														-- �������ģ���Զ��ʱ���ۼ�Ϊ��׼����ͨ����ϡ�жȾ�����������д�򸲸�Ĭ�ϼ��㷽ʽ
		'ExplicitUnlock'	BOOLEAN NOT NULL CHECK (ExplicitUnlock IN (0,1)) DEFAULT 0,	-- ֻͨ������;����ã�ʹ��CreateCollectible���ɣ�����2��ҪΪtrue��
		PRIMARY KEY (CollectibleType)
	);

	CREATE TABLE IF NOT EXISTS 'Ophidy_Collectible_BirthModifier'
	(
		'CollectibleType'	TEXT NOT NULL,
		'ModifierId'		TEXT NOT NULL
	);

	CREATE TABLE IF NOT EXISTS 'Ophidy_Collectible_ActiveModifier'
	(
		'CollectibleType'	TEXT NOT NULL,
		'ModifierId'		TEXT NOT NULL
	);

--========================================================================================================================
-- ��ʼ��
--========================================================================================================================
	INSERT OR IGNORE INTO Types
			(Type,															Kind)
	VALUES	('MODTYPE_OPD_ALL_PLAYERS_ADJUST_PROPERTY',						'KIND_MODIFIER');

	INSERT OR IGNORE INTO DynamicModifiers
			(ModifierType,													CollectionType,					EffectType)
	VALUES	('MODTYPE_OPD_ALL_PLAYERS_ADJUST_PROPERTY',						'COLLECTION_ALL_PLAYERS',		'EFFECT_ADJUST_PLAYER_PROPERTY');


	INSERT OR IGNORE INTO GlobalParameters
			(Name,												Value)
	VALUES	('PARAMETER_OPHIDY_COLLECTIBLE_GOODS_NUM',			7),
			('PARAMETER_OPHIDY_COLLECTIBLE_MAX_DISCOUNT',		80),
			('PARAMETER_OPHIDY_COLLECTIBLE_ERA_CHANGE_GIFT',	1),
			('PARAMETER_OPHIDY_COLLECTIBLE_MEETING_GIFT',		2),
			('PARAMETER_OPHIDY_COLLECTIBLE_ACTIVE_CAPACITY',	1),
			('PARAMETER_OPHIDY_COLLECTIBLE_NUM_DISCOVERS',		3),
			('PARAMETER_OPHIDY_COLLECTIBLE_MAX_RARITY_INIT',	3),
			('PARAMETER_OPHIDY_COLLECTIBLE_MAX_INTEREST',		100),
			('PARAMETER_OPHIDY_COLLECTIBLE_PRICE_ERA_PROGRESS',	0.3);

	INSERT OR IGNORE INTO GlobalParameters
			(Name,												Value)
	VALUES	('PARAMETER_OPHIDY_COLLECTIBLE_COST_0',				20),
			('PARAMETER_OPHIDY_COLLECTIBLE_COST_1',				60),
			('PARAMETER_OPHIDY_COLLECTIBLE_COST_2',				120),
			('PARAMETER_OPHIDY_COLLECTIBLE_COST_3',				200),
			('PARAMETER_OPHIDY_COLLECTIBLE_COST_4',				320),
			('PARAMETER_OPHIDY_COLLECTIBLE_COST_5',				480),
			('PARAMETER_OPHIDY_COLLECTIBLE_COST_6',				800);

	CREATE TEMPORARY TABLE Collectibles_BaseParam 
	(
			Parameter TEXT 
	);

	INSERT OR IGNORE INTO Collectibles_BaseParam
	VALUES	('PARAMETER_OPHIDY_COLLECTIBLE_GOODS_NUM'),
			('PARAMETER_OPHIDY_COLLECTIBLE_ERA_CHANGE_GIFT'),
			('PARAMETER_OPHIDY_COLLECTIBLE_ACTIVE_CAPACITY'),
			('PARAMETER_OPHIDY_COLLECTIBLE_NUM_DISCOVERS');

	CREATE TEMPORARY TABLE Collectibles_CapacityIncreaseEra 
	(
			EraType TEXT NOT NULL,
			Amount INT NOT NULL
	);

	INSERT OR IGNORE INTO Collectibles_CapacityIncreaseEra
	VALUES	('ERA_CLASSICAL',		1),
			('ERA_MEDIEVAL',		1),
			('ERA_RENAISSANCE',		2),
			('ERA_INDUSTRIAL',		1),
			('ERA_MODERN',			1),
			('ERA_ATOMIC',			2),
			('ERA_INFORMATION',		1),
			('ERA_FUTURE',			1);

	INSERT OR IGNORE INTO GlobalParameters
			(Name,											Value)
	VALUES	('PARAMETER_OPHIDY_COLLECTIBLE_COLOR_0',		'0.28,0.28,0.28'),
			('PARAMETER_OPHIDY_COLLECTIBLE_COLOR_1',		'0.28,0.28,0.28'),
			('PARAMETER_OPHIDY_COLLECTIBLE_COLOR_2',		'0.10,0.88,0.00'),
			('PARAMETER_OPHIDY_COLLECTIBLE_COLOR_3',		'0.00,0.52,0.93'),
			('PARAMETER_OPHIDY_COLLECTIBLE_COLOR_4',		'0.40,0.00,0.55'),
			('PARAMETER_OPHIDY_COLLECTIBLE_COLOR_5',		'1.00,0.46,0.94'),
			('PARAMETER_OPHIDY_COLLECTIBLE_COLOR_6',		'1.00,0.65,0.10'),
			('PARAMETER_OPHIDY_COLLECTIBLE_COLOR_7',		'1.00,0.12,0.12');