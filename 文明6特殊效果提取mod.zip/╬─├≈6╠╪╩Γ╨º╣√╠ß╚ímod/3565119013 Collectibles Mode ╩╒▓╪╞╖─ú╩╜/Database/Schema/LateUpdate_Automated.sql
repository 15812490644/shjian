-- LateUpdate_Automated
-- Author: Ophidy
-- DateCreated: 9/4/2025 6:58:20 PM
--------------------------------------------------------------
--========================================================================================================================
-- Automated
--========================================================================================================================
	UPDATE Ophidy_Collectibles 
	SET MaxInstance = 
		CASE 
			WHEN MaxInstance IS NULL THEN StackLimit 
			ELSE MaxInstance
		END;

	UPDATE Ophidy_Collectibles
	SET Cost = 
		COALESCE(
			(SELECT gp.Value 
			 FROM GlobalParameters gp 
			 WHERE gp.Name = 'PARAMETER_OPHIDY_COLLECTIBLE_COST_' || Ophidy_Collectibles.Rarity),
			9999
		)
	WHERE Cost IS NULL;

	UPDATE Ophidy_Collectibles
	SET StackLimit = 99 WHERE StackLimit > 99;

	INSERT OR IGNORE INTO GameModifiers
			(ModifierId)
	SELECT	'MODFEAT_OPD_COLLECTIBLE_BASE_PARAM_' || Parameter
	FROM Collectibles_BaseParam;

	INSERT OR IGNORE INTO Modifiers
			(ModifierId,										ModifierType)
	SELECT	'MODFEAT_OPD_COLLECTIBLE_BASE_PARAM_' || Parameter,	'MODTYPE_OPD_ALL_PLAYERS_ADJUST_PROPERTY'
	FROM Collectibles_BaseParam;

	INSERT OR IGNORE INTO ModifierArguments
			(ModifierId,										Name,			Value)
	SELECT	'MODFEAT_OPD_COLLECTIBLE_BASE_PARAM_' || Parameter,	'Key',			g.Name
	FROM Collectibles_BaseParam t JOIN GlobalParameters g ON t.Parameter = g.Name
	UNION 
	SELECT	'MODFEAT_OPD_COLLECTIBLE_BASE_PARAM_' || Parameter,	'Amount',		g.Value
	FROM Collectibles_BaseParam t JOIN GlobalParameters g ON t.Parameter = g.Name;

	INSERT OR IGNORE INTO GameModifiers
			(ModifierId)
	SELECT	'MODFEAT_OPD_COLLECTIBLE_CAPACITY_INCREASE_' || EraType
	FROM Collectibles_CapacityIncreaseEra;

	INSERT OR IGNORE INTO Modifiers
			(ModifierId,												ModifierType,									OwnerRequirementSetId)
	SELECT	'MODFEAT_OPD_COLLECTIBLE_CAPACITY_INCREASE_' || EraType,	'MODTYPE_OPD_ALL_PLAYERS_ADJUST_PROPERTY',		'REQSET_COLLECTIBLES_GAME_ERA_IS_' || EraType
	FROM Collectibles_CapacityIncreaseEra;

	INSERT OR IGNORE INTO ModifierArguments
			(ModifierId,												Name,			Value)
	SELECT	'MODFEAT_OPD_COLLECTIBLE_CAPACITY_INCREASE_' || EraType,	'Key',			'PARAMETER_OPHIDY_COLLECTIBLE_ACTIVE_CAPACITY'
	FROM Collectibles_CapacityIncreaseEra
	UNION 
	SELECT	'MODFEAT_OPD_COLLECTIBLE_CAPACITY_INCREASE_' || EraType,	'Amount',		Amount
	FROM Collectibles_CapacityIncreaseEra;

	INSERT OR IGNORE INTO RequirementSets
	SELECT	'REQSET_COLLECTIBLES_GAME_ERA_IS_' || EraType,	'REQUIREMENTSET_TEST_ALL'
	FROM Collectibles_CapacityIncreaseEra;

	INSERT OR IGNORE INTO RequirementSetRequirements
	SELECT	'REQSET_COLLECTIBLES_GAME_ERA_IS_' || EraType,	'REQ_COLLECTIBLES_GAME_ERA_IS_' || EraType
	FROM Collectibles_CapacityIncreaseEra;

	INSERT OR IGNORE INTO Requirements
			(RequirementId,									RequirementType)
	SELECT	'REQ_COLLECTIBLES_GAME_ERA_IS_' || EraType,		'REQUIREMENT_GAME_ERA_ATLEAST_EXPANSION'
	FROM Collectibles_CapacityIncreaseEra;

	INSERT OR IGNORE INTO RequirementArguments
			(RequirementId,									Name,					Value)
	SELECT	'REQ_COLLECTIBLES_GAME_ERA_IS_' || EraType,		'EraType',				EraType
	FROM Collectibles_CapacityIncreaseEra;
