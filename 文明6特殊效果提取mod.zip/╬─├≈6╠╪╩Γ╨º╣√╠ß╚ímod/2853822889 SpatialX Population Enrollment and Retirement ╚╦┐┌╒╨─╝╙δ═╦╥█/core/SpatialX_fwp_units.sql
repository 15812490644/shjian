UPDATE Units SET PopulationCost = 1, PrereqPopulation = 2 
WHERE UnitType IN (SELECT UnitType FROM Units WHERE Combat > 0 AND PrereqPopulation IS Null);

UPDATE StartEras	SET StartingPopulationCapital = 2	WHERE EraType = 'ERA_ANCIENT';