local POLICY_DISCIPLINE :number		= GameInfo.Policies["POLICY_DISCIPLINE"].Index;
local POLICY_SURVEY :number		= GameInfo.Policies["POLICY_SURVEY"].Index;
local POLICY_AGOGE :number		= GameInfo.Policies["POLICY_AGOGE"].Index;
local POLICY_CONSCRIPTION :number		= GameInfo.Policies["POLICY_CONSCRIPTION"].Index;
local POLICY_STRATEGOS :number		= GameInfo.Policies["POLICY_STRATEGOS"].Index;
local POLICY_MARITIME_INDUSTRIES :number		= GameInfo.Policies["POLICY_MARITIME_INDUSTRIES"].Index;
local POLICY_VETERANCY :number		= GameInfo.Policies["POLICY_VETERANCY"].Index;
local POLICY_FEUDAL_CONTRACT :number		= GameInfo.Policies["POLICY_FEUDAL_CONTRACT"].Index;
local POLICY_CHIVALRY :number		= GameInfo.Policies["POLICY_CHIVALRY"].Index;
local POLICY_GRANDE_ARMEE :number		= GameInfo.Policies["POLICY_GRANDE_ARMEE"].Index;
local POLICY_NAVIGATION :number		= GameInfo.Policies["POLICY_NAVIGATION"].Index;
local POLICY_PRESS_GANGS :number		= GameInfo.Policies["POLICY_PRESS_GANGS"].Index;
local POLICY_RATIONALISM :number		= GameInfo.Policies["POLICY_RATIONALISM"].Index;
local POLICY_NATIONAL_IDENTITY :number		= GameInfo.Policies["POLICY_NATIONAL_IDENTITY"].Index;
local POLICY_LIGHTNING_WARFARE :number		= GameInfo.Policies["POLICY_LIGHTNING_WARFARE"].Index;
local POLICY_TOTAL_WAR :number		= GameInfo.Policies["POLICY_TOTAL_WAR"].Index;
local POLICY_PROPAGANDA :number		= GameInfo.Policies["POLICY_PROPAGANDA"].Index;
local POLICY_LEVEE_EN_MASSE :number		= GameInfo.Policies["POLICY_LEVEE_EN_MASSE"].Index;
local POLICY_MARTIAL_LAW :number		= GameInfo.Policies["POLICY_MARTIAL_LAW"].Index;
local POLICY_FINEST_HOUR :number		= GameInfo.Policies["POLICY_FINEST_HOUR"].Index;
local POLICY_DEFENSE_OF_MOTHERLAND :number		= GameInfo.Policies["POLICY_DEFENSE_OF_MOTHERLAND"].Index;
local POLICY_ONLINE_COMMUNITIES :number		= GameInfo.Policies["POLICY_ONLINE_COMMUNITIES"].Index;
local POLICY_COLLECTIVE_ACTIVISM :number		= GameInfo.Policies["POLICY_COLLECTIVE_ACTIVISM"].Index;
local POLICY_STRATEGIC_AIR_FORCE :number		= GameInfo.Policies["POLICY_STRATEGIC_AIR_FORCE"].Index;

local BUILDING_MILITARY_GRAVE :number		= GameInfo.Buildings["BUILDING_MILITARY_GRAVE"].Index
local BUILDING_MONUMENT_TO_THE_DEADS :number		= GameInfo.Buildings["BUILDING_MONUMENT_TO_THE_DEADS"].Index
local BUILDING_PTSD_CARE_CENTER :number		= GameInfo.Buildings["BUILDING_PTSD_CARE_CENTER"].Index



local function CityPopulationOverflow(pCity)
    if (pCity == nil) then
        return false
    end
    
    local iHousing = pCity:GetGrowth():GetHousing()
    local iPopulation = pCity:GetPopulation()
    return (iHousing > iPopulation)
end

function RetireUnit(iPlayerID, iUnitID)
    local pUnit = UnitManager.GetUnit(iPlayerID, iUnitID)
	local pPlayer = Players[iPlayerID];
	local pTreasury = pPlayer:GetTreasury()
	local pCulture:object = pPlayer:GetCulture()
	
    if (pUnit ~= nil) then
        local x = pUnit:GetX()
        local y = pUnit:GetY()
		local unitpromotionclass = GameInfo.Units[pUnit:GetType()].PromotionClass
		local unitdomain = GameInfo.Units[pUnit:GetType()].Domain
        local pCity = CityManager.GetCityAt(x, y);
        if (pCity ~= nil) and CityPopulationOverflow(pCity) then
            
			pCity:ChangePopulation(1) --Add one citizen to the city
			
			local high_dice = 100 --By default dice. represent an 100% chance. Policy and buildings can reduce it.
			
			if (pCulture:IsPolicyActive(POLICY_DISCIPLINE)) then
				high_dice = high_dice - 2
			end
			if (pCulture:IsPolicyActive(POLICY_AGOGE)) then
				high_dice = high_dice - 3
			end
			if (pCulture:IsPolicyActive(POLICY_CONSCRIPTION)) then
				high_dice = high_dice + 2
			end
			if (pCulture:IsPolicyActive(POLICY_STRATEGOS)) then
				high_dice = high_dice - 2
			end
			if (pCulture:IsPolicyActive(POLICY_VETERANCY)) then
				high_dice = high_dice - 3
			end
			if (pCulture:IsPolicyActive(POLICY_NAVIGATION)) then
				high_dice = high_dice - 2
			end
			if (pCulture:IsPolicyActive(POLICY_PRESS_GANGS)) then
				high_dice = high_dice + 5
			end
			if (pCulture:IsPolicyActive(POLICY_RATIONALISM)) then
				high_dice = high_dice + 4
			end
			if (pCulture:IsPolicyActive(POLICY_NATIONAL_IDENTITY)) then
				high_dice = high_dice - 4
			end
			if (pCulture:IsPolicyActive(POLICY_TOTAL_WAR)) then
				high_dice = high_dice + 4
			end
			if (pCulture:IsPolicyActive(POLICY_PROPAGANDA)) then
				high_dice = high_dice - 10
			end
			if (pCulture:IsPolicyActive(POLICY_LEVEE_EN_MASSE)) then
				high_dice = high_dice + 6
			end
			if (pCulture:IsPolicyActive(POLICY_MARTIAL_LAW)) then
				high_dice = high_dice - 6
			end
			if (pCulture:IsPolicyActive(POLICY_FINEST_HOUR)) then
				high_dice = high_dice - 3
			end
			if (pCulture:IsPolicyActive(POLICY_DEFENSE_OF_MOTHERLAND)) then
				high_dice = high_dice - 4
			end
			if (pCulture:IsPolicyActive(POLICY_ONLINE_COMMUNITIES)) then
				high_dice = high_dice + 4
			end
			if (pCulture:IsPolicyActive(POLICY_COLLECTIVE_ACTIVISM)) then
				high_dice = high_dice + 4
			end
			
			if pCity:GetBuildings():HasBuilding(BUILDING_MILITARY_GRAVE) then
				high_dice = high_dice - 8
			end
			if pCity:GetBuildings():HasBuilding(BUILDING_MONUMENT_TO_THE_DEADS) then
				high_dice = high_dice - 3
				pCity:AttachModifierByID("SPATIALX_MONUMENT_TO_THE_DEADS_BONUS")
			end
			if pCity:GetBuildings():HasBuilding(BUILDING_PTSD_CARE_CENTER) then
				high_dice = high_dice - 5
			end
			
			
			math.randomseed(os.time())
			math.random()					--extra math.randoms to progress the seed and provide a greater degree of randomness
			math.random()
			math.random()
			math.random()
			local dice = math.random(high_dice)	--random dice. Smaller = better bonus. Higher = malus
			local small_dice = math.random(10)	--random dice used to select wich effect to get
			local two_choice = math.random(2)	--when there is only 2 choice
			
			print("SpatialX Retirement dices", "chance in percentage", high_dice, "dice picked number", dice, "small dice picked", small_dice, "two_choice picked", two_choice)
			
			local legendary_chances = 0
			local rare_chances = 0
			local good_chances = 26  --by default, only 25% of good bonus
			local neutral_chances = 100 --75% chance of nothing      we use an 'else' argument for bad effect, select if dice is over neutral_chances
			local terrible_chances = 0
			
			
			if pUnit:GetProperty("SPX_Promotion_level") ~= nil then
				--promotions counter
				if pUnit:GetProperty("SPX_Promotion_level") == 1 then
					rare_chances = 6
					good_chances = 26 --20%
					neutral_chances = 81 --55%	20% of bad
					
				elseif pUnit:GetProperty("SPX_Promotion_level") == 2 then
					legendary_chances = 6
					rare_chances = 13
					good_chances = 41 --28%
					neutral_chances = 71 --30%	30% of bad
					terrible_chances = 88 --11%
				elseif pUnit:GetProperty("SPX_Promotion_level") == 3 then
					legendary_chances = 6
					rare_chances = 13
					good_chances = 41 --28%
					neutral_chances = 71 --30%	30% of bad
					terrible_chances = 88 --11%
				elseif pUnit:GetProperty("SPX_Promotion_level") == 4 then
					legendary_chances = 9
					rare_chances = 16
					good_chances = 46 --30%
					neutral_chances = 61 --15%	40% of bad
					terrible_chances = 88 --11%
				else --5 and more
					legendary_chances = 13
					rare_chances = 21
					good_chances = 51 --30%
					neutral_chances = 61 --10%	40% of bad
					terrible_chances = 82 --17%
				end
			end
			print("SpatialX Retirement effects chance", "legendary_chances", legendary_chances, "rare_chances", rare_chances, "good_chances", good_chances, "neutral_chances", neutral_chances, "terrible_chances", terrible_chances)
			
			
			if dice < neutral_chances then		--gives production bonus toward this unit kind
				if (unitpromotionclass == "PROMOTION_CLASS_MELEE")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_MELEE")
					
				elseif (unitpromotionclass == "PROMOTION_CLASS_ANTI_CAVALRY")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_ANTI_CAV")

				elseif (unitpromotionclass == "PROMOTION_CLASS_RANGED")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_RANGED")

				elseif (unitpromotionclass == "PROMOTION_CLASS_RECON")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_RECON")

				elseif (unitpromotionclass == "SPATIALX_PRODUCTION_BOUNS_CAVALRY")then
					pCity:AttachModifierByID("PROMOTION_CLASS_LIGHT_CAVALRY")

				elseif (unitpromotionclass == "PROMOTION_CLASS_HEAVY_CAVALRY")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_HEAVY_CAV")

				elseif (unitpromotionclass == "PROMOTION_CLASS_SIEGE")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_SIEGE")

				elseif (unitpromotionclass == "PROMOTION_CLASS_AIR_FIGHTER")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_FIGHTER")

				elseif (unitpromotionclass == "PROMOTION_CLASS_AIR_BOMBER")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_BOMBER")

				elseif (unitpromotionclass == "PROMOTION_CLASS_NAVAL_MELEE")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_NAV_MELEE")

				elseif (unitpromotionclass == "PROMOTION_CLASS_NAVAL_RANGED")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_NAV_RANGED")

				elseif (unitpromotionclass == "PROMOTION_CLASS_NAVAL_RAIDER")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_NAV_RAID")
					pTreasury:ChangeGoldBalance(600)
					Game.AddWorldViewText(0, 'LOC_PIRATES_FORTUNE', x, y)
					Game.AddWorldViewText(0, 'LOC_PIRATES_FORTUNE_1', x, y)

				elseif (unitpromotionclass == "PROMOTION_CLASS_NAVAL_CARRIER")then
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_CARRIER")
				end
			end
			
			
			if dice< rare_chances then  -- should be 15% chance of strong bonus
				if dice< legendary_chances then -- should be 4% chance of additional legendary bonus
					if two_choice ==1 then --National War stories
						pPlayer:AttachModifierByID("SPATIALX_NATION_LOVE_WAR")
						pCity:AttachModifierByID("SPATIALX_WAR_MUSEUM")
						pCity:AttachModifierByID("SPATIALX_WAR_CULTURE_MUSEUM")
						pCity:AttachModifierByID("SPATIALX_WAR_STABLE_CULTURE_MUSEUM")
						Game.AddWorldViewText(0, 'LOC_GOT_NATION_LOVE_WAR', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_NATION_LOVE_WAR_1', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_war_museum_1', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_war_museum_2', x, y)
					else --Heroic unit  strong bonus
						pCity:AttachModifierByID("SPATIALX_PARADE_AMMENTY")
						pCity:AttachModifierByID("SPATIALX_LIKE_WARS")
						pCity:AttachModifierByID("SPATIALX_MILITARY_PARADE")
						pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_MELEE")
						pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_ANTI_CAV")
						pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_RECON")
						pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_CAVALRY")
						pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_HEAVY_CAV")
						pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_NAV_MELEE")
						pCity:AttachModifierByID("SPATIALX_PRODUCTION_BOUNS_FIGHTER")
						Game.AddWorldViewText(0, 'LOC_GOT_heroic_unit', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_heroic_unit_1', x, y)
						Game.AddWorldViewText(0, 'LOC_MILITARY_PARADE_1', x, y)
						Game.AddWorldViewText(0, 'LOC_MILITARY_PARADE_2', x, y)
						Game.AddWorldViewText(0, 'LOC_MILITARY_PARADE_3', x, y)
					end
				end
				
				if small_dice<6 then --Great General
					if (unitdomain == 'DOMAIN_SEA')then
						pCity:AttachModifierByID("SPATIALX_aspiring_naval_officier")
						pCity:AttachModifierByID("SPATIALX_aspiring_naval_officier")
						Game.AddWorldViewText(0, 'LOC_GOT_naval_admiral', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_naval_admiral_1', x, y)
					elseif (unitdomain == 'DOMAIN_AIR')then
						pCity:AttachModifierByID("SPATIALX_TEST_PILOT_ROCKET")
						Game.AddWorldViewText(0, 'LOC_GOT_test_pilot_rocket', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_test_pilot_rocket_1', x, y)
					else
						pCity:AttachModifierByID("SPATIALX_aspiring_officier")
						pCity:AttachModifierByID("SPATIALX_aspiring_officier")
						Game.AddWorldViewText(0, 'LOC_GOT_general', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_general_1', x, y)
					end
					
				else --War Museum
					if (unitdomain == 'DOMAIN_SEA')then
						pCity:AttachModifierByID("SPATIALX_MARITIME_MUSEUM")
						pCity:AttachModifierByID("SPATIALX_MARITIME_CULTURE_MUSEUM")
						Game.AddWorldViewText(0, 'LOC_GOT_naval_museum', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_naval_museum_1', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_naval_museum_2', x, y)
					elseif (unitdomain == 'DOMAIN_AIR')then
						pCity:AttachModifierByID("SPATIALX_AIR_MUSEUM")
						pCity:AttachModifierByID("SPATIALX_AIR_CULTURE_MUSEUM")
						Game.AddWorldViewText(0, 'LOC_GOT_air_museum', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_air_museum_1', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_air_museum_2', x, y)
					else
						pCity:AttachModifierByID("SPATIALX_WAR_MUSEUM")
						pCity:AttachModifierByID("SPATIALX_WAR_CULTURE_MUSEUM")
						pCity:AttachModifierByID("SPATIALX_WAR_STABLE_CULTURE_MUSEUM")
						Game.AddWorldViewText(0, 'LOC_GOT_war_museum', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_war_museum_1', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_war_museum_2', x, y)
					end
				end
				
			elseif dice< good_chances then
				if small_dice<4 then --military officier
					Game.AddWorldViewText(0, 'LOC_GOT_officier', x, y)
					if (unitdomain == 'DOMAIN_SEA')then
						pCity:AttachModifierByID("SPATIALX_aspiring_naval_officier")
						Game.AddWorldViewText(0, 'LOC_GOT_naval_officier_1', x, y)
					else
						pCity:AttachModifierByID("SPATIALX_aspiring_officier")
						Game.AddWorldViewText(0, 'LOC_GOT_land_officier_1', x, y)
					end
					
				elseif small_dice<7 then --MILITARY PARADE
					if (unitdomain == 'DOMAIN_SEA')then
						Game.AddWorldViewText(0, 'LOC_GOT_naval_show', x, y)
					elseif (unitdomain == 'DOMAIN_AIR')then
						pCity:AttachModifierByID("SPATIALX_PARADE_AMMENTY")
						Game.AddWorldViewText(0, 'LOC_GOT_air_show', x, y)
					else
						Game.AddWorldViewText(0, 'LOC_MILITARY_PARADE', x, y)
					end
					pCity:AttachModifierByID("SPATIALX_PARADE_AMMENTY")
					pCity:AttachModifierByID("SPATIALX_MILITARY_PARADE")
					pCity:AttachModifierByID("SPATIALX_LIKE_WARS")
					Game.AddWorldViewText(0, 'LOC_MILITARY_PARADE_1', x, y)
					Game.AddWorldViewText(0, 'LOC_MILITARY_PARADE_2', x, y)
					Game.AddWorldViewText(0, 'LOC_MILITARY_PARADE_3', x, y)
					
				else --reconversion
					if (unitdomain == 'DOMAIN_SEA')then
						UnitManager.InitUnit(pPlayer, "UNIT_TRADER", x, y);
						pPlayer:AttachModifierByID("GREATPERSON_EXTRA_TRADE_ROUTE_CAPACITY")
						Game.AddWorldViewText(0, 'LOC_GOT_NAVY_TRADER', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_NAVY_TRADER_1', x, y)
					elseif (unitdomain == 'DOMAIN_AIR')then
						UnitManager.InitUnit(pPlayer, "UNIT_TRADER", x, y);
						pPlayer:AttachModifierByID("GREATPERSON_EXTRA_TRADE_ROUTE_CAPACITY")
						Game.AddWorldViewText(0, 'LOC_GOT_AIR_TRADER', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_NAVY_TRADER_1', x, y)
					else
						UnitManager.InitUnit(pPlayer, "UNIT_MILITARY_ENGINEER", x, y);
						Game.AddWorldViewText(0, 'LOC_GOT_MILITARY_ENGINEER', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_MILITARY_ENGINEER_1', x, y)
					end
				end
					
			elseif dice< neutral_chances then
				Game.AddWorldViewText(0, 'LOC_HAPPY_RETIREMENT', x, y)
			
			
			
			else
				if dice > terrible_chances then
					if two_choice==1 then --Military JUNTA
						pCity:AttachModifierByID("SPATIALX_MILITARY_JUNTA")
						Game.AddWorldViewText(0, 'LOC_GOT_JUNTA', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_JUNTA_1', x, y)
					else --Nation wide anti war feels
						pPlayer:AttachModifierByID("SPATIALX_NATION_ANTI_WAR_WEARINESS")
						Game.AddWorldViewText(0, 'LOC_GOT_NATION_ANTI_WAR', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_NATION_ANTI_WAR_1', x, y)
					end
				end
				
				if (unitpromotionclass == "PROMOTION_CLASS_NAVAL_RAIDER")then --Pirates flees
					pTreasury:ChangeGoldBalance(-1000)
					pCity:ChangePopulation(-1)
					Game.AddWorldViewText(0, 'LOC_PIRATES_REBELLION', x, y)
					Game.AddWorldViewText(0, 'LOC_PIRATES_REBELLION_1', x, y)
				
				elseif small_dice<4 then --PTSD
					if pCity:GetBuildings():HasBuilding(BUILDING_PTSD_CARE_CENTER) then
						Game.AddWorldViewText(0, 'LOC_HAPPY_RETIREMENT', x, y)
					else
						pCity:AttachModifierByID("SPATIALX_PTSD_WAR_WEARINESS")
						pCity:AttachModifierByID("SPATIALX_PTSD_LOSE_GOLD")
						pCity:AttachModifierByID("SPATIALX_PTSD_LOSE_PROD")
						pCity:AttachModifierByID("SPATIALX_PTSD_LOSE_FOOD")
						Game.AddWorldViewText(0, 'LOC_GOT_PTSD', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_PTSD_1', x, y)
						Game.AddWorldViewText(0, 'LOC_GOT_PTSD_2', x, y)
					end
				elseif small_dice<5 then --Plague
					if (unitdomain == 'DOMAIN_AIR')then
						Game.AddWorldViewText(0, 'LOC_GOT_AIR_CRASH', x, y)
					else
						Game.AddWorldViewText(0, 'LOC_GOT_PLAGUE', x, y)
					end
					pCity:ChangePopulation(-3)
					Game.AddWorldViewText(0, 'LOC_PLAGUE_LOSE_POP', x, y)
				elseif small_dice<8 then --ANTI WAR FEELS
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_MELEE")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_ANTI_CAV")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_RECON")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_CAVALRY")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_FIGHTER")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_NAV_MELEE")
					pCity:AttachModifierByID("SPATIALX_ANTI_WAR_WEARINESS")
					Game.AddWorldViewText(0, 'LOC_ANTI_WAR_FEELINGS', x, y)
					Game.AddWorldViewText(0, 'LOC_ANTI_WAR_FEELINGS_1', x, y)
					Game.AddWorldViewText(0, 'LOC_ANTI_WAR_FEELINGS_2', x, y)
				else --ANTI WAR INDUSTRY
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_BARRACKS")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_STABLE")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_ARMORY")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_CASTLE")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_STAR_FORT")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_SHIPYARD")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_MILITARY_ACADEMY")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_HANGAR")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_AIRPORT")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_RANGED")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_HEAVY_CAV")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_SIEGE")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_FIGHTER")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_BOMBER")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_NAV_RAID")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_NAV_RANGED")
					pCity:AttachModifierByID("SPATIALX_PRODUCTION_MALUS_CARRIER")
					Game.AddWorldViewText(0, 'LOC_ANTI_WAR_INDUSTRY', x, y)
					Game.AddWorldViewText(0, 'LOC_ANTI_WAR_INDUSTRY_1', x, y)
					Game.AddWorldViewText(0, 'LOC_ANTI_WAR_INDUSTRY_2', x, y)
				end
			end
			
            UnitManager.Kill(pUnit) --Kill unit
			
        elseif (pCity == nil) then
			Game.AddWorldViewText(0, 'LOC_RETIRE_NOT_CITY', x, y)
		else
            Game.AddWorldViewText(0, 'LOC_RETIRE_NO_HOUSE', x, y)
        end
    end
end


if ExposedMembers.DEMO == nil then
    ExposedMembers.DEMO = {}
end

ExposedMembers.DEMO.RetireUnit = RetireUnit





ExposedMembers.UnitLifetime = {}
local iCPDTrain = CityProductionDirectives.TRAIN;
local iSETunit = EventSubTypes.UNIT;
local UATMplayerID;
local UATMunitID;
local propertyLifespan;
local g_lRemovedUnitPlayerID;
local g_lRemovedUnitID;
local g_UnitCache = {};
local durationLife = 25
function SetPropertiesValues(lifespan)
	propertyLifespan = lifespan;
end
ExposedMembers.UnitLifetime.SetPropertiesValues = SetPropertiesValues

Events.UnitRemovedFromMap.Add(function(playerID, unitID)
	g_lRemovedUnitPlayerID = playerID;
	g_lRemovedUnitID = unitID;
end)

-- Upragding Unit
function OnUnitUpgraded(playerID, unitID)
	local hUnit = UnitManager.GetUnit(playerID, unitID);
	if not hUnit then
		print("Classic civo6", playerID, unitID)
		return;
	end
	if g_lRemovedUnitPlayerID == playerID then
		local uid = g_lRemovedUnitPlayerID .. "u" .. g_lRemovedUnitID;
		if g_UnitCache[uid] and g_UnitCache[uid].Lifespan then
			hUnit:SetProperty(propertyLifespan, durationLife);
			hUnit:SetProperty("SPXLifespan", true)
			
			if g_UnitCache[playerID .. "u" .. unitID] then
				g_UnitCache[playerID .. "u" .. unitID].Lifespan = true;
			end
		end
	end
	g_lRemovedUnitPlayerID = nil;
	g_lRemovedUnitID = nil;
end

Events.UnitAddedToMap.Add(function(playerID, unitID, x, y)
	if g_UnitCache then
		UATMplayerID = playerID;
		UATMunitID = unitID;
		local iUnit = UnitManager.GetUnit(playerID, unitID);
		if not iUnit then
			return;
		end

		local uid = playerID .. "u" .. unitID;
		g_UnitCache[uid] = {Lifespan = iUnit:GetProperty("SPXLifespan")}
	end
end)


-- New unit created
function UnitTrainedOrPurchased(iPlayer, unitType, cityID, hType, h1,h2,h3,h4)
	--if GameInfo.Units[unitType].Combat == 0 then
		--if (not GameInfo.Units[unitType].UnitType == "UNIT_SETTLER" or not GameInfo.Units[unitType].UnitType == "UNIT_MISSIONARY" or not GameInfo.Units[unitType].UnitType == "UNIT_APOSTLE" or not GameInfo.Units[unitType].UnitType == "UNIT_INQUISITOR" or not GameInfo.Units[unitType].UnitType == "UNIT_GURU" or not GameInfo.Units[unitType].UnitType == "UNIT_MILITARY_ENGINEER" or not GameInfo.Units[unitType].UnitType == "UNIT_BATTERING_RAM" or not GameInfo.Units[unitType].UnitType == "UNIT_SIEGE_TOWER" or not GameInfo.Units[unitType].UnitType == "UNIT_MEDIC" or not GameInfo.Units[unitType].UnitType == "UNIT_ANTIAIR_GUN" or not GameInfo.Units[unitType].UnitType == "UNIT_MOBILE_SAM") then
			--return; 
		--end
	--end
	if UATMplayerID ~= iPlayer then
		print("UTLogicFailed incorrect players", UATMplayerID, iPlayer, unitType, cityID, hType, h1,h2,h3,h4)
		return;
	end
	
	local iUnit = UnitManager.GetUnit(iPlayer, UATMunitID);
	if not iUnit then
		return;
	end
	
	if iUnit:GetType() ~= unitType then
		print("UTLogicFailed incorrect unittype", iPlayer, iUnit:GetType(), unitType, cityID, hType, h1,h2,h3,h4)
		return;
	end
	
	--apply lifespan
	if (GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_SUPPORT" or GameInfo.Units[unitType].UnitType == "UNIT_TRADER" or GameInfo.Units[unitType].UnitType == "UNIT_SPY")then
		durationLife = 40
	elseif (GameInfo.Units[unitType].Domain == "DOMAIN_SEA" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_RECON") then 
		durationLife = 50
	elseif (GameInfo.Units[unitType].FormationClass == "FORMATION_CLASS_CIVILIAN") then
		durationLife = 30
	else 
		durationLife = 40
	end
	local pPlayer = Players[iPlayer];
	local pCulture = pPlayer:GetCulture()  
	local pCity = CityManager.GetCity(iPlayer, cityID)
	
	
	--while i'm at it, undo the popuplation cost of units for AI (we all know AI could not handle pop cost)
	if (pPlayer:IsHuman()) then 
		print ("human unit")
	else
		print ("AI unit")
		if (GameInfo.Units[unitType].Combat == 0) then
			print ("no combat")
		else 
			print ("combat stat")
			pCity:ChangePopulation(1)
		end
	end
	
	--detect policie and add durationlife bonus
	if (pCulture:IsPolicyActive(POLICY_SURVEY) and GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_RECON") then
		durationLife = durationLife + 5
	end
	if (pCulture:IsPolicyActive(POLICY_AGOGE)) then
		if (GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_MELEE" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_RANGED" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_ANTI_CAVALRY") then
			durationLife = durationLife + 5
		end
	end
	if (pCulture:IsPolicyActive(POLICY_MARITIME_INDUSTRIES) and GameInfo.Units[unitType].Domain == "DOMAIN_SEA") then
		durationLife = durationLife + 5
	end
	if (pCulture:IsPolicyActive(POLICY_VETERANCY)) then
		durationLife = durationLife + 5
	end
	if (pCulture:IsPolicyActive(POLICY_FEUDAL_CONTRACT)) then
		if (GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_MELEE" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_RANGED" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_ANTI_CAVALRY") then
			durationLife = durationLife + 8
		else
			durationLife = durationLife + 4
		end
	end
	if (pCulture:IsPolicyActive(POLICY_CHIVALRY)) then
		if (GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_HEAVY_CAVALRY" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_LIGHT_CAVALRY") then
			durationLife = durationLife + 10
		end
	end
	if (pCulture:IsPolicyActive(POLICY_PRESS_GANGS) and GameInfo.Units[unitType].Domain == "DOMAIN_SEA") then
		durationLife = durationLife - 8
	end
	if (pCulture:IsPolicyActive(POLICY_GRANDE_ARMEE)) then
		if (GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_MELEE" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_RANGED" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_ANTI_CAVALRY") then
			durationLife = durationLife + 10
		else
			durationLife = durationLife + 6
		end
	end
	if (pCulture:IsPolicyActive(POLICY_TOTAL_WAR)) then
		durationLife = durationLife + 14
	end
	if (pCulture:IsPolicyActive(POLICY_LEVEE_EN_MASSE)) then
		durationLife = durationLife + 10
	end
	if (pCulture:IsPolicyActive(POLICY_LIGHTNING_WARFARE)) then
		if (GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_HEAVY_CAVALRY" or GameInfo.Units[unitType].PromotionClass == "PROMOTION_CLASS_LIGHT_CAVALRY") then
			durationLife = durationLife - 8
		end
	end
	if (pCulture:IsPolicyActive(POLICY_FINEST_HOUR) and GameInfo.Units[unitType].Domain == "DOMAIN_AIR") then
		durationLife = durationLife + 12
	end
	if (pCulture:IsPolicyActive(POLICY_MARTIAL_LAW)) then
		durationLife = durationLife + 12
	end
	if (pCulture:IsPolicyActive(POLICY_DEFENSE_OF_MOTHERLAND)) then
		durationLife = durationLife + 12
	end
	if (pCulture:IsPolicyActive(POLICY_STRATEGIC_AIR_FORCE) and GameInfo.Units[unitType].Domain == "DOMAIN_AIR") then
		durationLife = durationLife + 15
	end
	
	iUnit:SetProperty(propertyLifespan, durationLife);
	iUnit:SetProperty("SPXLifespan", true)
	g_UnitCache[iPlayer .. "u" .. UATMunitID].Lifespan = true;
end




--Unit promotion
function OnUnitPromoted(iPlayer, unitID)
	local iUnit = UnitManager.GetUnit(iPlayer, unitID);
	if iUnit then
		if iUnit:GetProperty("SPXLifespan") then
			iUnit:SetProperty(propertyLifespan, iUnit:GetProperty(propertyLifespan) + 3)
		end
	end
	
	if iUnit:GetProperty("SPX_Promotion_level") ~= nil then --The game don't seems to have a method to know how much promotion a unit has. This is the best method.
		iUnit:SetProperty("SPX_Promotion_level", iUnit:GetProperty("SPX_Promotion_level") + 1)
	else
		iUnit:SetProperty("SPX_Promotion_level", 1)
	end
end


--Unit transformed into Army
function OnUnitArmyd(iPlayer, unitID)
	local iUnit = UnitManager.GetUnit(iPlayer, unitID);
	if iUnit then
		if iUnit:GetProperty("SPXLifespan") then
			iUnit:SetProperty(propertyLifespan, iUnit:GetProperty(propertyLifespan) + 15)
		end
	end
end


--Unit transformed into Corps
function OnUnitCorped(iPlayer, unitID)
	local iUnit = UnitManager.GetUnit(iPlayer, unitID);
	if iUnit then
		if iUnit:GetProperty("SPXLifespan") then
			iUnit:SetProperty(propertyLifespan, iUnit:GetProperty(propertyLifespan) + 10)
		end
	end
end


--Great Person recruitement
function OnGreatUnitRecruited(iPlayer, unitID)
	local iUnit = UnitManager.GetUnit(iPlayer, unitID);
	if iUnit then
		iUnit:SetProperty(propertyLifespan, 40);
		iUnit:SetProperty("SPXLifespan", true)
		g_UnitCache[iPlayer .. "u" .. UATMunitID].Lifespan = true;
	end
end


function OnCityProductionCompleted(iPlayer, cityID, cProdDirType, iItemType, bVal1, iVal1, iVal2)
	if cProdDirType == iCPDTrain then
		UnitTrainedOrPurchased(iPlayer, iItemType, cityID, 1, bVal1, iVal1, iVal2)
	end
end

function OnCityMadePurchase(iPlayer, cityID, iX, iY, iEventSubType, iItemType, ab, ac)
	if iEventSubType == iSETunit then
		UnitTrainedOrPurchased(iPlayer, iItemType, cityID, 2, iX, iY, ab, ac)
	end
end



function PrepareTraitTable()
--<<events>>

	Events.CityProductionCompleted.Add(OnCityProductionCompleted)
	Events.CityMadePurchase.Add(OnCityMadePurchase)
	Events.UnitUpgraded.Add(OnUnitUpgraded)
	Events.UnitPromoted.Add(OnUnitPromoted)
	Events.UnitFormArmy.Add(OnUnitArmyd)
	Events.UnitFormCorps.Add(OnUnitCorped)
	Events.UnitGreatPersonCreated.Add(OnGreatUnitRecruited)
end
Events.LoadScreenClose.Add(PrepareTraitTable)