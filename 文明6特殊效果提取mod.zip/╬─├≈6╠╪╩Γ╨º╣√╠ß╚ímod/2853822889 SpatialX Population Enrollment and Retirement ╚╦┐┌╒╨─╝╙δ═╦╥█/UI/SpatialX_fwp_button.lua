function RetirementButtonClicked()
    local pUnit = UI.GetHeadSelectedUnit()
    if (pUnit ~= nil) then
        ExposedMembers.DEMO.RetireUnit(Game.GetLocalPlayer(), pUnit:GetID())
    end
end


function RetirementSelectionChanged(iPlayerID, iUnitID, iPlotX, iPlotY, iPlotZ, bSelected, bEditable)
    if bSelected then
        local pUnit = UnitManager.GetUnit(iPlayerID, iUnitID)
        if (pUnit:GetCombat() == 0) or (GameInfo.Units["UNIT_MODE_ZOMBIE"] ~= nil and pUnit:GetType() == GameInfo.Units["UNIT_MODE_ZOMBIE"].Index) then
            Controls.TestButtonGrid:SetHide(true)
        else
            Controls.TestButtonGrid:SetHide(false)
        end
    end
end


function RetirementSetup()
    local path = '/InGame/UnitPanel/StandardActionsStack'
    local ctrl = ContextPtr:LookUpControl(path)
    if ctrl ~= nil then
        Controls.TestButtonGrid:ChangeParent(ctrl)
    end
    Controls.TestButton:RegisterCallback(Mouse.eLClick, RetirementButtonClicked)
end

ExposedMembers.UnitLifetime.SetPropertiesValues(UnitPropertyKeys.LifespanRemaining)

Events.LoadGameViewStateDone.Add(RetirementSetup)
Events.UnitSelectionChanged.Add(RetirementSelectionChanged)




