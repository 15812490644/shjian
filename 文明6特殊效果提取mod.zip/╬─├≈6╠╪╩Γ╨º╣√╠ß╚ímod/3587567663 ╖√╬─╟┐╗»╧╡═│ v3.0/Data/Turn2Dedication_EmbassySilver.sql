-- ============================================================================
-- Turn2Dedication Mod - 使馆银阶工业城邦里程碑
-- ============================================================================
-- 为所有已加载建筑生成“首都建造该建筑 +5%”modifier。
-- EFFECT_ADJUST_BUILDING_PRODUCTION 需要明确的 BuildingType 参数，因此不能
-- 直接复用原版提供平坦产能的首都建筑 modifier。
-- ============================================================================

INSERT OR IGNORE INTO Types (Type, Kind)
VALUES ('MODIFIER_TURN2_EMBASSY_INDUSTRIAL', 'KIND_MODIFIER');

INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
VALUES ('MODIFIER_TURN2_EMBASSY_INDUSTRIAL',
        'MODIFIER_TURN2_CAPITAL_ADJUST_BUILDING_PRODUCTION');

-- 原生 BuildingType 参数支持逗号分隔列表；合并后只需挂载一个 modifier。
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_EMBASSY_INDUSTRIAL',
       'BuildingType', GROUP_CONCAT(BuildingType, ',')
FROM Buildings;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
VALUES ('MODIFIER_TURN2_EMBASSY_INDUSTRIAL', 'Amount', '5');
