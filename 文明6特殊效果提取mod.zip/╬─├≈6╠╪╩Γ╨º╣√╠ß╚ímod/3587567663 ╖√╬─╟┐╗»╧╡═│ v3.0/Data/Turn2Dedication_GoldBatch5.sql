-- ============================================================================
-- Turn2Dedication - Golden batch 5 dynamic database content (runes 70-82)
-- ============================================================================

-- 70: one production modifier for every non-wonder building loaded before this
-- file. The shared owner/subject requirements are declared in the XML file.
INSERT OR IGNORE INTO Modifiers
    (ModifierId, ModifierType, OwnerRequirementSetId, SubjectRequirementSetId)
SELECT 'MODIFIER_TURN2_GOLD70_BUILDING_PRODUCTION_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_PRODUCTION',
       'REQSET_T2D_GOLD70_NOT_DARK_AGE',
       'REQSET_T2D_GOLD70_CITY_HAS_GOVERNOR'
FROM Buildings
WHERE COALESCE(IsWonder, 0) = 0;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD70_BUILDING_PRODUCTION_' || BuildingType,
       'BuildingType', BuildingType
FROM Buildings
WHERE COALESCE(IsWonder, 0) = 0;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD70_BUILDING_PRODUCTION_' || BuildingType,
       'Amount', '15'
FROM Buildings
WHERE COALESCE(IsWonder, 0) = 0;

-- 71: discover only the standard city-state suzerain chain:
-- specific MINOR_CIV trait -> ALL_PLAYERS_ATTACH_MODIFIER guarded by
-- PLAYER_IS_SUZERAIN -> ModifierId argument -> inner effect modifier.
-- Nonstandard city-state implementations intentionally do not enter this table.
DROP TABLE IF EXISTS T2D_Gold71Sources;
CREATE TABLE T2D_Gold71Sources (
    TraitType TEXT NOT NULL,
    LeaderType TEXT NOT NULL,
    OuterModifierId TEXT NOT NULL,
    InnerModifierId TEXT NOT NULL,
    CloneModifierId TEXT NOT NULL,
    PRIMARY KEY (TraitType, OuterModifierId)
);

INSERT OR IGNORE INTO T2D_Gold71Sources
    (TraitType, LeaderType, OuterModifierId, InnerModifierId, CloneModifierId)
SELECT lt.TraitType,
       lt.LeaderType,
       tm.ModifierId,
       outerArg.Value,
       'MODIFIER_TURN2_GOLD71_' || tm.ModifierId
FROM LeaderTraits lt
JOIN Leaders leader
  ON leader.LeaderType = lt.LeaderType
JOIN TraitModifiers tm
  ON tm.TraitType = lt.TraitType
JOIN Modifiers outerModifier
  ON outerModifier.ModifierId = tm.ModifierId
JOIN ModifierArguments outerArg
  ON outerArg.ModifierId = outerModifier.ModifierId
 AND outerArg.Name = 'ModifierId'
JOIN Modifiers innerModifier
  ON innerModifier.ModifierId = outerArg.Value
WHERE lt.LeaderType LIKE 'LEADER_MINOR_CIV_%'
  AND lt.TraitType LIKE 'MINOR_CIV_%_TRAIT'
  AND outerModifier.ModifierType = 'MODIFIER_ALL_PLAYERS_ATTACH_MODIFIER'
  AND (
      outerModifier.SubjectRequirementSetId = 'PLAYER_IS_SUZERAIN'
      -- Gathering Storm's Vilnius has three standard alliance-level variants;
      -- each outer set is SUZERAIN + the corresponding alliance requirement.
      OR (lt.TraitType = 'MINOR_CIV_VILNIUS_TRAIT'
          AND outerModifier.SubjectRequirementSetId IN (
              'PLAYER_IS_SUZERAIN_ALLY_LEVEL_1',
              'PLAYER_IS_SUZERAIN_ALLY_LEVEL_2',
              'PLAYER_IS_SUZERAIN_ALLY_LEVEL_3'
          ))
  );

DROP TABLE IF EXISTS T2D_Gold71Modifiers;
CREATE TABLE T2D_Gold71Modifiers (
    TraitType TEXT NOT NULL,
    ModifierId TEXT NOT NULL,
    PRIMARY KEY (TraitType, ModifierId)
);

INSERT OR IGNORE INTO T2D_Gold71Modifiers (TraitType, ModifierId)
SELECT TraitType, CloneModifierId
FROM T2D_Gold71Sources;

-- Each clone owns an always-dynamic "not suzerain of this exact leader type"
-- requirement. REQUIREMENT_PLAYER_IS_SUZERAIN_X_TYPE is the native requirement
-- used by the game for typed suzerain counts; Amount=1 plus a concrete
-- LeaderType narrows it to this city-state. Inverse=true prevents double effects
-- while the rune owner is the real suzerain and restores the clone afterwards.
INSERT OR IGNORE INTO RequirementSets (RequirementSetId, RequirementSetType)
SELECT 'REQSET_T2D_GOLD71_ACTIVE_' || OuterModifierId,
       'REQUIREMENTSET_TEST_ALL'
FROM T2D_Gold71Sources;

INSERT OR IGNORE INTO Requirements
    (RequirementId, RequirementType, Inverse)
SELECT 'REQ_T2D_GOLD71_NOT_SUZERAIN_' || LeaderType,
       'REQUIREMENT_PLAYER_IS_SUZERAIN_X_TYPE',
       1
FROM T2D_Gold71Sources;

INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_GOLD71_NOT_SUZERAIN_' || LeaderType,
       'Amount', '1'
FROM T2D_Gold71Sources;

INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_GOLD71_NOT_SUZERAIN_' || LeaderType,
       'LeaderType', LeaderType
FROM T2D_Gold71Sources;

INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_GOLD71_ACTIVE_' || OuterModifierId,
       'REQ_T2D_GOLD71_NOT_SUZERAIN_' || LeaderType
FROM T2D_Gold71Sources;

-- Vilnius retains the alliance-level half of its outer condition. The generic
-- REQUIREMENT_PLAYER_IS_SUZERAIN member is deliberately omitted because the
-- typed inverse requirement above already supplies the desired anti-double rule.
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_GOLD71_ACTIVE_' || src.OuterModifierId,
       rsr.RequirementId
FROM T2D_Gold71Sources src
JOIN Modifiers outerModifier
  ON outerModifier.ModifierId = src.OuterModifierId
JOIN RequirementSetRequirements rsr
  ON rsr.RequirementSetId = outerModifier.SubjectRequirementSetId
JOIN Requirements requirement
  ON requirement.RequirementId = rsr.RequirementId
WHERE src.TraitType = 'MINOR_CIV_VILNIUS_TRAIT'
  AND requirement.RequirementType <> 'REQUIREMENT_PLAYER_IS_SUZERAIN';

-- Preserve an inner modifier's pre-existing owner condition by nesting the
-- original set inside the clone's TEST_ALL set instead of overwriting it.
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_GOLD71_ORIGINAL_OWNER_' || src.OuterModifierId,
       'REQUIREMENT_REQUIREMENTSET_IS_MET'
FROM T2D_Gold71Sources src
JOIN Modifiers innerModifier
  ON innerModifier.ModifierId = src.InnerModifierId
WHERE innerModifier.OwnerRequirementSetId IS NOT NULL;

INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_GOLD71_ORIGINAL_OWNER_' || src.OuterModifierId,
       'RequirementSetId', innerModifier.OwnerRequirementSetId
FROM T2D_Gold71Sources src
JOIN Modifiers innerModifier
  ON innerModifier.ModifierId = src.InnerModifierId
WHERE innerModifier.OwnerRequirementSetId IS NOT NULL;

INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_GOLD71_ACTIVE_' || src.OuterModifierId,
       'REQ_T2D_GOLD71_ORIGINAL_OWNER_' || src.OuterModifierId
FROM T2D_Gold71Sources src
JOIN Modifiers innerModifier
  ON innerModifier.ModifierId = src.InnerModifierId
WHERE innerModifier.OwnerRequirementSetId IS NOT NULL;

INSERT OR IGNORE INTO Modifiers
    (ModifierId, ModifierType, RunOnce, NewOnly, Permanent, Repeatable,
     OwnerRequirementSetId, SubjectRequirementSetId,
     OwnerStackLimit, SubjectStackLimit)
SELECT src.CloneModifierId,
       innerModifier.ModifierType,
       innerModifier.RunOnce,
       innerModifier.NewOnly,
       innerModifier.Permanent,
       innerModifier.Repeatable,
       'REQSET_T2D_GOLD71_ACTIVE_' || src.OuterModifierId,
       innerModifier.SubjectRequirementSetId,
       innerModifier.OwnerStackLimit,
       innerModifier.SubjectStackLimit
FROM T2D_Gold71Sources src
JOIN Modifiers innerModifier
  ON innerModifier.ModifierId = src.InnerModifierId;

INSERT OR IGNORE INTO ModifierArguments
    (ModifierId, Name, Type, Value, Extra, SecondExtra)
SELECT src.CloneModifierId, arg.Name, arg.Type, arg.Value,
       arg.Extra, arg.SecondExtra
FROM T2D_Gold71Sources src
JOIN ModifierArguments arg
  ON arg.ModifierId = src.InnerModifierId;

-- 75: Holy Site and every unique replacement get +100% production.
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_GOLD75_HOLY_SITE_PRODUCTION_' || d.DistrictType,
       'MODIFIER_PLAYER_CITIES_ADJUST_DISTRICT_PRODUCTION'
FROM Districts d
LEFT JOIN DistrictReplaces r
  ON r.CivUniqueDistrictType = d.DistrictType
WHERE d.DistrictType = 'DISTRICT_HOLY_SITE'
   OR r.ReplacesDistrictType = 'DISTRICT_HOLY_SITE';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD75_HOLY_SITE_PRODUCTION_' || d.DistrictType,
       'DistrictType', d.DistrictType
FROM Districts d
LEFT JOIN DistrictReplaces r
  ON r.CivUniqueDistrictType = d.DistrictType
WHERE d.DistrictType = 'DISTRICT_HOLY_SITE'
   OR r.ReplacesDistrictType = 'DISTRICT_HOLY_SITE';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD75_HOLY_SITE_PRODUCTION_' || d.DistrictType,
       'Amount', '100'
FROM Districts d
LEFT JOIN DistrictReplaces r
  ON r.CivUniqueDistrictType = d.DistrictType
WHERE d.DistrictType = 'DISTRICT_HOLY_SITE'
   OR r.ReplacesDistrictType = 'DISTRICT_HOLY_SITE';

-- 82: use the same unit-specific production interface as policy cards. Civilian
-- formations (including religious units and spies) are excluded at generation
-- time; combat and non-civilian support formations are covered.
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_GOLD82_NON_CIVILIAN_PRODUCTION_' || UnitType,
       'MODIFIER_PLAYER_UNITS_ADJUST_UNIT_PRODUCTION'
FROM Units
WHERE COALESCE(FormationClass, '') <> 'FORMATION_CLASS_CIVILIAN';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD82_NON_CIVILIAN_PRODUCTION_' || UnitType,
       'UnitType', UnitType
FROM Units
WHERE COALESCE(FormationClass, '') <> 'FORMATION_CLASS_CIVILIAN';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD82_NON_CIVILIAN_PRODUCTION_' || UnitType,
       'Amount', '5'
FROM Units
WHERE COALESCE(FormationClass, '') <> 'FORMATION_CLASS_CIVILIAN';
