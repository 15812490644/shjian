-- ============================================================================
-- Turn2Dedication - transmutation/envoy batch (runes 142-145)
-- ============================================================================

-- 144 One Envoy Settles the State: Gameplay grants one reserve envoy at a
-- time and the local-player UI bridge immediately sends it to the city-state
-- selected by the first manual envoy. Unique RunOnce modifiers make every
-- step save-safe and idempotent without relying on an undocumented setter.
WITH RECURSIVE EnvoySteps(Step) AS (
    SELECT 1
    UNION ALL
    SELECT Step + 1 FROM EnvoySteps WHERE Step < 19
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, RunOnce, Permanent)
SELECT 'MODIFIER_TURN2_PRISMATIC144_ENVOY_STEP_' ||
       CASE WHEN Step < 10 THEN '0' || CAST(Step AS TEXT) ELSE CAST(Step AS TEXT) END,
       'MODIFIER_PLAYER_GRANT_INFLUENCE_TOKEN', 1, 1
FROM EnvoySteps;

WITH RECURSIVE EnvoySteps(Step) AS (
    SELECT 1
    UNION ALL
    SELECT Step + 1 FROM EnvoySteps WHERE Step < 19
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC144_ENVOY_STEP_' ||
       CASE WHEN Step < 10 THEN '0' || CAST(Step AS TEXT) ELSE CAST(Step AS TEXT) END,
       'Amount', '1'
FROM EnvoySteps;
