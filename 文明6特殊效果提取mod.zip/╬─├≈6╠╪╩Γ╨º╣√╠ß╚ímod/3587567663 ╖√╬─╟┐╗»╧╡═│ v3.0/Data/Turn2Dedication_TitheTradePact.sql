-- ============================================================================
-- Turn2Dedication Mod - 什一商约建筑收益动态 modifier
-- ============================================================================
-- 圣地建筑 +1 金币，商业中心建筑 +1 信仰。
-- 通过 Buildings.PrereqDistrict 动态覆盖原版、DLC 与文明独特替代建筑。
-- ============================================================================

INSERT OR IGNORE INTO Types (Type, Kind)
SELECT 'MODIFIER_TURN2_TITHE_HOLY_BUILDING_GOLD_' || BuildingType, 'KIND_MODIFIER'
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_HOLY_SITE';

INSERT OR IGNORE INTO Types (Type, Kind)
SELECT 'MODIFIER_TURN2_TITHE_COMMERCIAL_BUILDING_FAITH_' || BuildingType, 'KIND_MODIFIER'
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_COMMERCIAL_HUB';

INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_TITHE_HOLY_BUILDING_GOLD_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_HOLY_SITE';

INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_TITHE_COMMERCIAL_BUILDING_FAITH_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_COMMERCIAL_HUB';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_TITHE_HOLY_BUILDING_GOLD_' || BuildingType,
       'BuildingType',
       BuildingType
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_HOLY_SITE';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_TITHE_HOLY_BUILDING_GOLD_' || BuildingType,
       'YieldType',
       'YIELD_GOLD'
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_HOLY_SITE';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_TITHE_HOLY_BUILDING_GOLD_' || BuildingType,
       'Amount',
       '1'
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_HOLY_SITE';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_TITHE_COMMERCIAL_BUILDING_FAITH_' || BuildingType,
       'BuildingType',
       BuildingType
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_COMMERCIAL_HUB';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_TITHE_COMMERCIAL_BUILDING_FAITH_' || BuildingType,
       'YieldType',
       'YIELD_FAITH'
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_COMMERCIAL_HUB';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_TITHE_COMMERCIAL_BUILDING_FAITH_' || BuildingType,
       'Amount',
       '1'
FROM Buildings
WHERE PrereqDistrict = 'DISTRICT_COMMERCIAL_HUB';
