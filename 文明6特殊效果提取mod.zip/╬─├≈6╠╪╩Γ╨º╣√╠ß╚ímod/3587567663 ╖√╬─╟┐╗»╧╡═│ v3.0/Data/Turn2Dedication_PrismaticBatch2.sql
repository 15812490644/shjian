-- ============================================================================
-- Turn2Dedication - Prismatic batch 2 dynamic data (runes 127-141)
-- ============================================================================

-- Ability tags are local to this mod. They let the player-scoped grant
-- modifiers cover already loaded mod units without using a global collection.
INSERT OR IGNORE INTO TypeTags (Type, Tag)
SELECT UnitType, 'CLASS_T2D_PRISMATIC137_ALL_UNITS'
FROM Units;

INSERT OR IGNORE INTO TypeTags (Type, Tag)
SELECT UnitType, 'CLASS_T2D_PRISMATIC140_MILITARY'
FROM Units
WHERE COALESCE(FormationClass, '') <> 'FORMATION_CLASS_CIVILIAN';

-- 130 Faith Is Capital: one owner-scoped faith-purchase switch per specialty
-- district. The effect applies to normal buildings in that district; wonders
-- remain invalid purchases under the base game's own rules.
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC130_FAITH_PURCHASE_' || DistrictType,
       'MODIFIER_PLAYER_CITIES_ENABLE_BUILDING_FAITH_PURCHASE'
FROM Districts
WHERE COALESCE(RequiresPopulation, 0) = 1;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC130_FAITH_PURCHASE_' || DistrictType,
       'DistrictType', DistrictType
FROM Districts
WHERE COALESCE(RequiresPopulation, 0) = 1;

-- 131 City-State Federation: a unique permanent RunOnce grant per assembled
-- database era. Gameplay Lua attaches only the current global era's row.
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, RunOnce, Permanent)
SELECT 'MODIFIER_TURN2_PRISMATIC131_ERA_ENVOYS_' || EraType,
       'MODIFIER_PLAYER_GRANT_INFLUENCE_TOKEN', 1, 1
FROM Eras;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC131_ERA_ENVOYS_' || EraType,
       'Amount', '2'
FROM Eras;

-- 139 Mountain Construction Method: fixed +2 yield for Campus, Industrial
-- Zone and Theater families when the completed district plot is adjacent to
-- at least one mountain. This is a yield change, not adjacency, so adjacency
-- policy cards cannot double it and multiple mountains cannot stack it.
WITH RECURSIVE DistrictFamilies(DistrictType, YieldType, Suffix) AS (
    SELECT 'DISTRICT_CAMPUS', 'YIELD_SCIENCE', 'CAMPUS'
    UNION ALL SELECT 'DISTRICT_INDUSTRIAL_ZONE', 'YIELD_PRODUCTION', 'INDUSTRIAL'
    UNION ALL SELECT 'DISTRICT_THEATER', 'YIELD_CULTURE', 'THEATER'
    UNION
    SELECT replacement.CivUniqueDistrictType, family.YieldType, family.Suffix
    FROM DistrictReplaces replacement
    JOIN DistrictFamilies family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_PRISMATIC139_DISTRICT_IS_' || DistrictType,
       'REQUIREMENT_DISTRICT_TYPE_MATCHES'
FROM DistrictFamilies;

WITH RECURSIVE DistrictFamilies(DistrictType, YieldType, Suffix) AS (
    SELECT 'DISTRICT_CAMPUS', 'YIELD_SCIENCE', 'CAMPUS'
    UNION ALL SELECT 'DISTRICT_INDUSTRIAL_ZONE', 'YIELD_PRODUCTION', 'INDUSTRIAL'
    UNION ALL SELECT 'DISTRICT_THEATER', 'YIELD_CULTURE', 'THEATER'
    UNION
    SELECT replacement.CivUniqueDistrictType, family.YieldType, family.Suffix
    FROM DistrictReplaces replacement
    JOIN DistrictFamilies family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_PRISMATIC139_DISTRICT_IS_' || DistrictType,
       'DistrictType', DistrictType
FROM DistrictFamilies;

WITH RECURSIVE DistrictFamilies(DistrictType, YieldType, Suffix) AS (
    SELECT 'DISTRICT_CAMPUS', 'YIELD_SCIENCE', 'CAMPUS'
    UNION ALL SELECT 'DISTRICT_INDUSTRIAL_ZONE', 'YIELD_PRODUCTION', 'INDUSTRIAL'
    UNION ALL SELECT 'DISTRICT_THEATER', 'YIELD_CULTURE', 'THEATER'
    UNION
    SELECT replacement.CivUniqueDistrictType, family.YieldType, family.Suffix
    FROM DistrictReplaces replacement
    JOIN DistrictFamilies family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO RequirementSets (RequirementSetId, RequirementSetType)
SELECT 'REQSET_T2D_PRISMATIC139_MOUNTAIN_' || DistrictType,
       'REQUIREMENTSET_TEST_ALL'
FROM DistrictFamilies;

WITH RECURSIVE DistrictFamilies(DistrictType, YieldType, Suffix) AS (
    SELECT 'DISTRICT_CAMPUS', 'YIELD_SCIENCE', 'CAMPUS'
    UNION ALL SELECT 'DISTRICT_INDUSTRIAL_ZONE', 'YIELD_PRODUCTION', 'INDUSTRIAL'
    UNION ALL SELECT 'DISTRICT_THEATER', 'YIELD_CULTURE', 'THEATER'
    UNION
    SELECT replacement.CivUniqueDistrictType, family.YieldType, family.Suffix
    FROM DistrictReplaces replacement
    JOIN DistrictFamilies family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_PRISMATIC139_MOUNTAIN_' || DistrictType,
       'REQ_T2D_PRISMATIC139_DISTRICT_IS_' || DistrictType
FROM DistrictFamilies
UNION ALL
SELECT 'REQSET_T2D_PRISMATIC139_MOUNTAIN_' || DistrictType,
       'REQUIRES_PLOT_ADJACENT_TO_MOUNTAIN'
FROM DistrictFamilies;

WITH RECURSIVE DistrictFamilies(DistrictType, YieldType, Suffix) AS (
    SELECT 'DISTRICT_CAMPUS', 'YIELD_SCIENCE', 'CAMPUS'
    UNION ALL SELECT 'DISTRICT_INDUSTRIAL_ZONE', 'YIELD_PRODUCTION', 'INDUSTRIAL'
    UNION ALL SELECT 'DISTRICT_THEATER', 'YIELD_CULTURE', 'THEATER'
    UNION
    SELECT replacement.CivUniqueDistrictType, family.YieldType, family.Suffix
    FROM DistrictReplaces replacement
    JOIN DistrictFamilies family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, SubjectRequirementSetId)
SELECT 'MODIFIER_TURN2_PRISMATIC139_FLAT_YIELD_' || DistrictType,
       'MODIFIER_PLAYER_DISTRICTS_ADJUST_YIELD_CHANGE',
       'REQSET_T2D_PRISMATIC139_MOUNTAIN_' || DistrictType
FROM DistrictFamilies;

WITH RECURSIVE DistrictFamilies(DistrictType, YieldType, Suffix) AS (
    SELECT 'DISTRICT_CAMPUS', 'YIELD_SCIENCE', 'CAMPUS'
    UNION ALL SELECT 'DISTRICT_INDUSTRIAL_ZONE', 'YIELD_PRODUCTION', 'INDUSTRIAL'
    UNION ALL SELECT 'DISTRICT_THEATER', 'YIELD_CULTURE', 'THEATER'
    UNION
    SELECT replacement.CivUniqueDistrictType, family.YieldType, family.Suffix
    FROM DistrictReplaces replacement
    JOIN DistrictFamilies family
      ON replacement.ReplacesDistrictType = family.DistrictType
), Generated(ModifierId, DistrictType, YieldType) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC139_FLAT_YIELD_' || DistrictType,
           DistrictType, YieldType
    FROM DistrictFamilies
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'DistrictType', DistrictType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldType', YieldType FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', '2' FROM Generated;

-- Commercial Hub family: true +2 Gold adjacency per adjacent mountain tile.
-- One row per mountain terrain is required because the adjacency effect
-- accepts a single TerrainType argument.
WITH RECURSIVE CommercialFamily(DistrictType) AS (
    SELECT 'DISTRICT_COMMERCIAL_HUB'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CommercialFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), MountainTerrains(TerrainType) AS (
    SELECT 'TERRAIN_GRASS_MOUNTAIN'
    UNION ALL SELECT 'TERRAIN_PLAINS_MOUNTAIN'
    UNION ALL SELECT 'TERRAIN_DESERT_MOUNTAIN'
    UNION ALL SELECT 'TERRAIN_TUNDRA_MOUNTAIN'
    UNION ALL SELECT 'TERRAIN_SNOW_MOUNTAIN'
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC139_COMMERCIAL_MOUNTAIN_' || family.DistrictType || '_' || terrain.TerrainType,
       'MODIFIER_PLAYER_CITIES_TERRAIN_ADJACENCY'
FROM CommercialFamily family
CROSS JOIN MountainTerrains terrain;

WITH RECURSIVE CommercialFamily(DistrictType) AS (
    SELECT 'DISTRICT_COMMERCIAL_HUB'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CommercialFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), MountainTerrains(TerrainType) AS (
    SELECT 'TERRAIN_GRASS_MOUNTAIN'
    UNION ALL SELECT 'TERRAIN_PLAINS_MOUNTAIN'
    UNION ALL SELECT 'TERRAIN_DESERT_MOUNTAIN'
    UNION ALL SELECT 'TERRAIN_TUNDRA_MOUNTAIN'
    UNION ALL SELECT 'TERRAIN_SNOW_MOUNTAIN'
), Generated(ModifierId, DistrictType, TerrainType) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC139_COMMERCIAL_MOUNTAIN_' || family.DistrictType || '_' || terrain.TerrainType,
           family.DistrictType, terrain.TerrainType
    FROM CommercialFamily family
    CROSS JOIN MountainTerrains terrain
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'DistrictType', DistrictType FROM Generated
UNION ALL
SELECT ModifierId, 'TerrainType', TerrainType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldType', 'YIELD_GOLD' FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', '2' FROM Generated
UNION ALL
SELECT ModifierId, 'Description', 'LOC_T2D_PRISMATIC139_COMMERCIAL_MOUNTAIN_ADJACENCY' FROM Generated;

-- 140 Temple Military System: recursive Holy Site district and building
-- families. The production and maintenance compensation remain player scoped.
WITH RECURSIVE HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family
      ON replacement.ReplacesDistrictType = family.DistrictType
), HolyBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolyDistricts family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN HolyBuildings family ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC140_BUILDING_PRODUCTION_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_PRODUCTION'
FROM HolyBuildings;

WITH RECURSIVE HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family ON replacement.ReplacesDistrictType = family.DistrictType
), HolyBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolyDistricts family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN HolyBuildings family ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC140_BUILDING_PRODUCTION_' || BuildingType,
       'BuildingType', BuildingType
FROM HolyBuildings
UNION ALL
SELECT 'MODIFIER_TURN2_PRISMATIC140_BUILDING_PRODUCTION_' || BuildingType,
       'Amount', '100'
FROM HolyBuildings;

-- District maintenance compensation.
WITH RECURSIVE HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC140_DISTRICT_MAINTENANCE_' || family.DistrictType,
       'MODIFIER_PLAYER_DISTRICTS_ADJUST_YIELD_CHANGE'
FROM HolyDistricts family
JOIN Districts district ON district.DistrictType = family.DistrictType
WHERE COALESCE(district.Maintenance, 0) > 0;

WITH RECURSIVE HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family ON replacement.ReplacesDistrictType = family.DistrictType
), Generated(ModifierId, DistrictType, Amount) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC140_DISTRICT_MAINTENANCE_' || family.DistrictType,
           family.DistrictType, CAST(district.Maintenance AS TEXT)
    FROM HolyDistricts family
    JOIN Districts district ON district.DistrictType = family.DistrictType
    WHERE COALESCE(district.Maintenance, 0) > 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'DistrictType', DistrictType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldType', 'YIELD_GOLD' FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', Amount FROM Generated;

-- Building maintenance compensation.
WITH RECURSIVE HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family ON replacement.ReplacesDistrictType = family.DistrictType
), HolyBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolyDistricts family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN HolyBuildings family ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC140_BUILDING_MAINTENANCE_' || family.BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM HolyBuildings family
JOIN Buildings building ON building.BuildingType = family.BuildingType
WHERE COALESCE(building.Maintenance, 0) > 0;

WITH RECURSIVE HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family ON replacement.ReplacesDistrictType = family.DistrictType
), HolyBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolyDistricts family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN HolyBuildings family ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
), Generated(ModifierId, BuildingType, Amount) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC140_BUILDING_MAINTENANCE_' || family.BuildingType,
           family.BuildingType, CAST(building.Maintenance AS TEXT)
    FROM HolyBuildings family
    JOIN Buildings building ON building.BuildingType = family.BuildingType
    WHERE COALESCE(building.Maintenance, 0) > 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'BuildingType', BuildingType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldType', 'YIELD_GOLD' FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', Amount FROM Generated;

-- Shrine, Temple and worship-building city requirements.
WITH RECURSIVE ShrineFamily(BuildingType) AS (
    SELECT 'BUILDING_SHRINE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN ShrineFamily family ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_PRISMATIC140_CITY_HAS_' || BuildingType,
       'REQUIREMENT_CITY_HAS_BUILDING'
FROM ShrineFamily;

WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_PRISMATIC140_CITY_HAS_' || BuildingType,
       'REQUIREMENT_CITY_HAS_BUILDING'
FROM TempleFamily;

WITH RECURSIVE HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family ON replacement.ReplacesDistrictType = family.DistrictType
), WorshipFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolyDistricts family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
      AND COALESCE(building.EnabledByReligion, 0) = 1
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN WorshipFamily family ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_PRISMATIC140_CITY_HAS_' || BuildingType,
       'REQUIREMENT_CITY_HAS_BUILDING'
FROM WorshipFamily;

WITH RECURSIVE BuildingFamilies(BuildingType, FamilySet) AS (
    SELECT 'BUILDING_SHRINE', 'REQSET_T2D_PRISMATIC140_CITY_HAS_SHRINE_FAMILY'
    UNION ALL SELECT 'BUILDING_TEMPLE', 'REQSET_T2D_PRISMATIC140_CITY_HAS_TEMPLE_FAMILY'
    UNION
    SELECT replacement.CivUniqueBuildingType, family.FamilySet
    FROM BuildingReplaces replacement
    JOIN BuildingFamilies family ON replacement.ReplacesBuildingType = family.BuildingType
), HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family ON replacement.ReplacesDistrictType = family.DistrictType
), WorshipFamily(BuildingType, FamilySet) AS (
    SELECT building.BuildingType, 'REQSET_T2D_PRISMATIC140_CITY_HAS_WORSHIP_FAMILY'
    FROM Buildings building
    JOIN HolyDistricts family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
      AND COALESCE(building.EnabledByReligion, 0) = 1
    UNION
    SELECT replacement.CivUniqueBuildingType, family.FamilySet
    FROM BuildingReplaces replacement
    JOIN WorshipFamily family ON replacement.ReplacesBuildingType = family.BuildingType
), AllFamilies(BuildingType, FamilySet) AS (
    SELECT BuildingType, FamilySet FROM BuildingFamilies
    UNION
    SELECT BuildingType, FamilySet FROM WorshipFamily
)
INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_PRISMATIC140_CITY_HAS_' || BuildingType,
       'BuildingType', BuildingType
FROM AllFamilies;

WITH RECURSIVE BuildingFamilies(BuildingType, FamilySet) AS (
    SELECT 'BUILDING_SHRINE', 'REQSET_T2D_PRISMATIC140_CITY_HAS_SHRINE_FAMILY'
    UNION ALL SELECT 'BUILDING_TEMPLE', 'REQSET_T2D_PRISMATIC140_CITY_HAS_TEMPLE_FAMILY'
    UNION
    SELECT replacement.CivUniqueBuildingType, family.FamilySet
    FROM BuildingReplaces replacement
    JOIN BuildingFamilies family ON replacement.ReplacesBuildingType = family.BuildingType
), HolyDistricts(DistrictType) AS (
    SELECT 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolyDistricts family ON replacement.ReplacesDistrictType = family.DistrictType
), WorshipFamily(BuildingType, FamilySet) AS (
    SELECT building.BuildingType, 'REQSET_T2D_PRISMATIC140_CITY_HAS_WORSHIP_FAMILY'
    FROM Buildings building
    JOIN HolyDistricts family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
      AND COALESCE(building.EnabledByReligion, 0) = 1
    UNION
    SELECT replacement.CivUniqueBuildingType, family.FamilySet
    FROM BuildingReplaces replacement
    JOIN WorshipFamily family ON replacement.ReplacesBuildingType = family.BuildingType
), AllFamilies(BuildingType, FamilySet) AS (
    SELECT BuildingType, FamilySet FROM BuildingFamilies
    UNION
    SELECT BuildingType, FamilySet FROM WorshipFamily
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT FamilySet, 'REQ_T2D_PRISMATIC140_CITY_HAS_' || BuildingType
FROM AllFamilies;

-- 141 All Under the Pivot. A threshold modifier represents exactly one city,
-- so losing a city automatically disables the highest active thresholds. The
-- capital collection follows capital relocation without Lua removing effects.
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType, Inverse) VALUES
('REQ_T2D_PRISMATIC141_HAS_POLITICAL_PHILOSOPHY', 'REQUIREMENT_PLAYER_HAS_CIVIC', 0),
('REQ_T2D_PRISMATIC141_HAS_DIVINE_RIGHT',         'REQUIREMENT_PLAYER_HAS_CIVIC', 0),
('REQ_T2D_PRISMATIC141_NOT_DIVINE_RIGHT',         'REQUIREMENT_PLAYER_HAS_CIVIC', 1),
('REQ_T2D_PRISMATIC141_HAS_REFORMED_CHURCH',      'REQUIREMENT_PLAYER_HAS_CIVIC', 0),
('REQ_T2D_PRISMATIC141_NOT_REFORMED_CHURCH',      'REQUIREMENT_PLAYER_HAS_CIVIC', 1),
('REQ_T2D_PRISMATIC141_HAS_EXPLORATION',          'REQUIREMENT_PLAYER_HAS_CIVIC', 0),
('REQ_T2D_PRISMATIC141_HAS_NATIONALISM',          'REQUIREMENT_PLAYER_HAS_CIVIC', 0);

INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value) VALUES
('REQ_T2D_PRISMATIC141_HAS_POLITICAL_PHILOSOPHY', 'CivicType', 'CIVIC_POLITICAL_PHILOSOPHY'),
('REQ_T2D_PRISMATIC141_HAS_DIVINE_RIGHT',         'CivicType', 'CIVIC_DIVINE_RIGHT'),
('REQ_T2D_PRISMATIC141_NOT_DIVINE_RIGHT',         'CivicType', 'CIVIC_DIVINE_RIGHT'),
('REQ_T2D_PRISMATIC141_HAS_REFORMED_CHURCH',      'CivicType', 'CIVIC_REFORMED_CHURCH'),
('REQ_T2D_PRISMATIC141_NOT_REFORMED_CHURCH',      'CivicType', 'CIVIC_REFORMED_CHURCH'),
('REQ_T2D_PRISMATIC141_HAS_EXPLORATION',          'CivicType', 'CIVIC_EXPLORATION'),
('REQ_T2D_PRISMATIC141_HAS_NATIONALISM',          'CivicType', 'CIVIC_NATIONALISM');

WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_PRISMATIC141_CITYCOUNT_' || N,
       'REQUIREMENT_PLAYER_HAS_AT_LEAST_NUMBER_CITIES'
FROM Numbers;

WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
)
INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_PRISMATIC141_CITYCOUNT_' || N, 'Amount', CAST(N AS TEXT)
FROM Numbers;

WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
), SetKinds(Suffix) AS (
    SELECT 'BASE'
    UNION ALL SELECT 'POLITICAL_PHILOSOPHY'
    UNION ALL SELECT 'GOV_DIVINE_RIGHT'
    UNION ALL SELECT 'GOV_REFORMED_CHURCH'
    UNION ALL SELECT 'GOV_EXPLORATION'
    UNION ALL SELECT 'NATIONALISM'
)
INSERT OR IGNORE INTO RequirementSets (RequirementSetId, RequirementSetType)
SELECT 'REQSET_T2D_PRISMATIC141_' || Suffix || '_' || N,
       'REQUIREMENTSET_TEST_ALL'
FROM Numbers CROSS JOIN SetKinds;

WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
), SetKinds(Suffix) AS (
    SELECT 'BASE'
    UNION ALL SELECT 'POLITICAL_PHILOSOPHY'
    UNION ALL SELECT 'GOV_DIVINE_RIGHT'
    UNION ALL SELECT 'GOV_REFORMED_CHURCH'
    UNION ALL SELECT 'GOV_EXPLORATION'
    UNION ALL SELECT 'NATIONALISM'
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_PRISMATIC141_' || Suffix || '_' || N,
       'REQ_T2D_PRISMATIC141_CITYCOUNT_' || N
FROM Numbers CROSS JOIN SetKinds;

WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_PRISMATIC141_POLITICAL_PHILOSOPHY_' || N,
       'REQ_T2D_PRISMATIC141_HAS_POLITICAL_PHILOSOPHY'
FROM Numbers
UNION ALL
SELECT 'REQSET_T2D_PRISMATIC141_GOV_DIVINE_RIGHT_' || N,
       'REQ_T2D_PRISMATIC141_HAS_DIVINE_RIGHT'
FROM Numbers
UNION ALL
SELECT 'REQSET_T2D_PRISMATIC141_GOV_REFORMED_CHURCH_' || N,
       'REQ_T2D_PRISMATIC141_HAS_REFORMED_CHURCH'
FROM Numbers
UNION ALL
SELECT 'REQSET_T2D_PRISMATIC141_GOV_REFORMED_CHURCH_' || N,
       'REQ_T2D_PRISMATIC141_NOT_DIVINE_RIGHT'
FROM Numbers
UNION ALL
SELECT 'REQSET_T2D_PRISMATIC141_GOV_EXPLORATION_' || N,
       'REQ_T2D_PRISMATIC141_HAS_EXPLORATION'
FROM Numbers
UNION ALL
SELECT 'REQSET_T2D_PRISMATIC141_GOV_EXPLORATION_' || N,
       'REQ_T2D_PRISMATIC141_NOT_DIVINE_RIGHT'
FROM Numbers
UNION ALL
SELECT 'REQSET_T2D_PRISMATIC141_GOV_EXPLORATION_' || N,
       'REQ_T2D_PRISMATIC141_NOT_REFORMED_CHURCH'
FROM Numbers
UNION ALL
SELECT 'REQSET_T2D_PRISMATIC141_NATIONALISM_' || N,
       'REQ_T2D_PRISMATIC141_HAS_NATIONALISM'
FROM Numbers;

-- Base, Political Philosophy and Nationalism threshold modifiers.
WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
), Specs(GroupName, Suffix, ModifierType, RequirementPrefix) AS (
    SELECT 'BASE', 'PRODUCTION', 'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_CITY_YIELD_CHANGE', 'BASE'
    UNION ALL SELECT 'BASE', 'GOLD', 'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_CITY_YIELD_CHANGE', 'BASE'
    UNION ALL SELECT 'BASE', 'FAITH', 'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_CITY_YIELD_CHANGE', 'BASE'
    UNION ALL SELECT 'POLITICAL', 'SCIENCE', 'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_CITY_YIELD_CHANGE', 'POLITICAL_PHILOSOPHY'
    UNION ALL SELECT 'POLITICAL', 'CULTURE', 'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_CITY_YIELD_CHANGE', 'POLITICAL_PHILOSOPHY'
    UNION ALL SELECT 'POLITICAL', 'HOUSING', 'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_BUILDING_HOUSING', 'POLITICAL_PHILOSOPHY'
    UNION ALL SELECT 'NATIONALISM', 'SCIENCE', 'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_CITY_YIELD_CHANGE', 'NATIONALISM'
    UNION ALL SELECT 'NATIONALISM', 'CULTURE', 'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_CITY_YIELD_CHANGE', 'NATIONALISM'
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, OwnerRequirementSetId)
SELECT 'MODIFIER_TURN2_PRISMATIC141_' || GroupName || '_' || Suffix || '_' || N,
       ModifierType,
       'REQSET_T2D_PRISMATIC141_' || RequirementPrefix || '_' || N
FROM Numbers CROSS JOIN Specs;

-- Government milestone uses mutually exclusive priority branches, preventing
-- a player who knows two or three qualifying civics from receiving duplicates.
WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
), GovBranches(Branch) AS (
    SELECT 'DIVINE_RIGHT'
    UNION ALL SELECT 'REFORMED_CHURCH'
    UNION ALL SELECT 'EXPLORATION'
), YieldSpecs(Suffix) AS (
    SELECT 'PRODUCTION' UNION ALL SELECT 'GOLD' UNION ALL SELECT 'FAITH'
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, OwnerRequirementSetId)
SELECT 'MODIFIER_TURN2_PRISMATIC141_GOV_' || Branch || '_' || Suffix || '_' || N,
       'MODIFIER_PLAYER_CAPITAL_CITY_ADJUST_CITY_YIELD_CHANGE',
       'REQSET_T2D_PRISMATIC141_GOV_' || Branch || '_' || N
FROM Numbers CROSS JOIN GovBranches CROSS JOIN YieldSpecs;

WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
), YieldSpecs(GroupName, Suffix, YieldType, Amount) AS (
    SELECT 'BASE', 'PRODUCTION', 'YIELD_PRODUCTION', '2'
    UNION ALL SELECT 'BASE', 'GOLD', 'YIELD_GOLD', '2'
    UNION ALL SELECT 'BASE', 'FAITH', 'YIELD_FAITH', '2'
    UNION ALL SELECT 'POLITICAL', 'SCIENCE', 'YIELD_SCIENCE', '1'
    UNION ALL SELECT 'POLITICAL', 'CULTURE', 'YIELD_CULTURE', '1'
    UNION ALL SELECT 'NATIONALISM', 'SCIENCE', 'YIELD_SCIENCE', '2'
    UNION ALL SELECT 'NATIONALISM', 'CULTURE', 'YIELD_CULTURE', '2'
), Generated(ModifierId, YieldType, Amount) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC141_' || GroupName || '_' || Suffix || '_' || N,
           YieldType, Amount
    FROM Numbers CROSS JOIN YieldSpecs
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'YieldType', YieldType FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', Amount FROM Generated;

WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
), GovBranches(Branch) AS (
    SELECT 'DIVINE_RIGHT'
    UNION ALL SELECT 'REFORMED_CHURCH'
    UNION ALL SELECT 'EXPLORATION'
), YieldSpecs(Suffix, YieldType) AS (
    SELECT 'PRODUCTION', 'YIELD_PRODUCTION'
    UNION ALL SELECT 'GOLD', 'YIELD_GOLD'
    UNION ALL SELECT 'FAITH', 'YIELD_FAITH'
), Generated(ModifierId, YieldType) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC141_GOV_' || Branch || '_' || Suffix || '_' || N,
           YieldType
    FROM Numbers CROSS JOIN GovBranches CROSS JOIN YieldSpecs
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'YieldType', YieldType FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', '2' FROM Generated;

WITH RECURSIVE Numbers(N) AS (
    SELECT 1 UNION ALL SELECT N + 1 FROM Numbers WHERE N < 256
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC141_POLITICAL_HOUSING_' || N,
       'Amount', '1'
FROM Numbers;
