-- ============================================================================
-- Turn2Dedication Mod - 自定义重装枪兵单位定义
-- ============================================================================
-- 此单位专为"龟型阵"符文设计：
-- - 移动力：1（普通枪兵是2）
-- - 战斗力：25（与普通枪兵相同）
-- - 晋升类别：反骑兵（PROMOTION_CLASS_ANTI_CAVALRY）
-- - 特殊限制：无法通过科技树解锁，只能通过符文效果获得
-- ============================================================================

-- 1. 定义单位类型
INSERT INTO Types (Type, Kind)
VALUES ('UNIT_TURN2_SLOW_SPEARMAN', 'KIND_UNIT');

-- 2. 定义单位基本属性（基于枪兵，但移动力为1）
INSERT INTO Units 
    (UnitType, Cost, Maintenance, BaseMoves, BaseSightRange, ZoneOfControl, Domain, 
     Combat, FormationClass, PromotionClass, AdvisorType, 
     Name, Description, 
     MandatoryObsoleteTech, PrereqTech, CanTrain)
VALUES 
    ('UNIT_TURN2_SLOW_SPEARMAN', 
     65,         -- 成本（与枪兵相同）
     1,          -- 维护费
     1,          -- ★ 移动力改为1（枪兵是2）
     2,          -- 视野
     1,          -- 控制区
     'DOMAIN_LAND',  -- 陆地单位
     25,         -- 战斗力（与枪兵相同）
     'FORMATION_CLASS_LAND_COMBAT',  -- 编队类型
     'PROMOTION_CLASS_ANTI_CAVALRY', -- 晋升类别（反骑兵）
     'ADVISOR_CONQUEST',  -- 顾问类型
     'LOC_UNIT_TURN2_SLOW_SPEARMAN_NAME',  -- 名称
     'LOC_UNIT_TURN2_SLOW_SPEARMAN_DESCRIPTION',  -- 描述
     'TECH_METAL_CASTING',  -- 过时科技（冶金术）
     NULL,  -- ★ 不设置前置科技，无法通过科技树解锁
     0  -- ★★★ CanTrain=0 禁止训练/生产
    );

-- 3. 添加单位标签（使其属于反骑兵类别）
INSERT INTO TypeTags (Type, Tag)
VALUES 
    ('UNIT_TURN2_SLOW_SPEARMAN', 'CLASS_ANTI_CAVALRY');

-- 4. 添加AI使用提示
INSERT INTO UnitAIInfos (UnitType, AiType)
VALUES 
    ('UNIT_TURN2_SLOW_SPEARMAN', 'UNITAI_COMBAT'),
    ('UNIT_TURN2_SLOW_SPEARMAN', 'UNITAI_EXPLORE'),
    ('UNIT_TURN2_SLOW_SPEARMAN', 'UNITTYPE_MELEE'),
    ('UNIT_TURN2_SLOW_SPEARMAN', 'UNITTYPE_ANTI_CAVALRY'),
    ('UNIT_TURN2_SLOW_SPEARMAN', 'UNITTYPE_LAND_COMBAT');

-- 5. 设置升级路径（可升级为长矛兵）
INSERT INTO UnitUpgrades (Unit, UpgradeUnit)
VALUES ('UNIT_TURN2_SLOW_SPEARMAN', 'UNIT_PIKEMAN');

-- 6. 3D模型映射通过 ArtDefs/Units.artdef + Turn2Dedication.dep 实现
--    不使用 UnitReplaces（会导致科技树上被替换的单位图标消失）

-- ============================================================================
-- 说明：
-- - 移动力固定为1，适合防御作战
-- - 可正常晋升为长矛兵（UNIT_PIKEMAN）
-- - AI会将其视为反骑兵单位进行部署
-- - 玩家无法生产或购买（CanTrain=0），只能通过符文效果获得
-- ============================================================================

