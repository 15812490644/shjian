-- ============================================================================
-- Turn2Dedication Mod - 第三批白银符文特色元素动态 modifier
-- ============================================================================
-- 祖制回响：特色区域/建筑/改良设施 +1 文化、金币、生产力。
-- 学派银环：特色区域/建筑/改良设施 +1 科技、金币、生产力。
-- 动态生成可覆盖原版、DLC 及在本文件前加载的其他内容。
-- ============================================================================

CREATE TABLE IF NOT EXISTS T2D_UniqueElements (
    ElementKind TEXT NOT NULL,
    ElementType TEXT NOT NULL,
    PRIMARY KEY (ElementKind, ElementType)
);

-- 该表仅为本文件的生成清单；重建以兼容旧版单主键结构。
DROP TABLE IF EXISTS T2D_UniqueRuneYields;
CREATE TABLE T2D_UniqueRuneYields (
    RunePrefix TEXT NOT NULL,
    ModifierSuffix TEXT NOT NULL,
    YieldType TEXT NOT NULL,
    PRIMARY KEY (RunePrefix, YieldType)
);

INSERT OR IGNORE INTO T2D_UniqueRuneYields (RunePrefix, ModifierSuffix, YieldType)
VALUES ('ANCESTRAL',  '',            'YIELD_CULTURE'),
       ('ANCESTRAL',  '_GOLD',       'YIELD_GOLD'),
       ('ANCESTRAL',  '_PRODUCTION', 'YIELD_PRODUCTION'),
       ('SCHOLASTIC', '',            'YIELD_SCIENCE'),
       ('SCHOLASTIC', '_GOLD',       'YIELD_GOLD'),
       ('SCHOLASTIC', '_PRODUCTION', 'YIELD_PRODUCTION');

-- 替代表中的元素直接视为特色元素；trait 兜底只接纳文明/领袖专属内容。
INSERT OR IGNORE INTO T2D_UniqueElements (ElementKind, ElementType)
SELECT 'DISTRICT', d.DistrictType
FROM Districts d
LEFT JOIN DistrictReplaces r ON r.CivUniqueDistrictType = d.DistrictType
WHERE r.CivUniqueDistrictType IS NOT NULL
   OR d.TraitType LIKE 'TRAIT_CIVILIZATION_DISTRICT_%'
   OR d.TraitType LIKE 'TRAIT_LEADER_%DISTRICT_%';

INSERT OR IGNORE INTO T2D_UniqueElements (ElementKind, ElementType)
SELECT 'BUILDING', b.BuildingType
FROM Buildings b
LEFT JOIN BuildingReplaces r ON r.CivUniqueBuildingType = b.BuildingType
WHERE r.CivUniqueBuildingType IS NOT NULL
   OR b.TraitType LIKE 'TRAIT_CIVILIZATION_BUILDING_%'
   OR b.TraitType LIKE 'TRAIT_LEADER_%BUILDING_%';

INSERT OR IGNORE INTO T2D_UniqueElements (ElementKind, ElementType)
SELECT 'IMPROVEMENT', i.ImprovementType
FROM Improvements i
WHERE i.Buildable = 1
  AND (i.TraitType LIKE 'TRAIT_CIVILIZATION_IMPROVEMENT_%'
       OR i.TraitType LIKE 'TRAIT_LEADER_%IMPROVEMENT_%')
  AND i.TraitType NOT LIKE 'TRAIT_SECRET_SOCIETY%'
  AND i.TraitType NOT LIKE 'MINOR_CIV_%'
  AND i.TraitType NOT LIKE 'TRAIT_BARBARIAN%'
  AND i.TraitType <> 'TRAIT_CIVILIZATION_NO_PLAYER';

-- 区域和改良设施共享类型匹配需求；建筑可直接使用 BuildingType 参数。
INSERT OR IGNORE INTO RequirementSets (RequirementSetId, RequirementSetType)
SELECT 'REQSET_TURN2_UNIQUE_DISTRICT_' || ElementType, 'REQUIREMENTSET_TEST_ALL'
FROM T2D_UniqueElements
WHERE ElementKind = 'DISTRICT';

INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_TURN2_UNIQUE_DISTRICT_' || ElementType, 'REQUIREMENT_DISTRICT_TYPE_MATCHES'
FROM T2D_UniqueElements
WHERE ElementKind = 'DISTRICT';

INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_TURN2_UNIQUE_DISTRICT_' || ElementType, 'DistrictType', ElementType
FROM T2D_UniqueElements
WHERE ElementKind = 'DISTRICT';

INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_TURN2_UNIQUE_DISTRICT_' || ElementType,
       'REQ_TURN2_UNIQUE_DISTRICT_' || ElementType
FROM T2D_UniqueElements
WHERE ElementKind = 'DISTRICT';

INSERT OR IGNORE INTO RequirementSets (RequirementSetId, RequirementSetType)
SELECT 'REQSET_TURN2_UNIQUE_IMPROVEMENT_' || ElementType, 'REQUIREMENTSET_TEST_ALL'
FROM T2D_UniqueElements
WHERE ElementKind = 'IMPROVEMENT';

INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_TURN2_UNIQUE_IMPROVEMENT_' || ElementType, 'REQUIREMENT_PLOT_IMPROVEMENT_TYPE_MATCHES'
FROM T2D_UniqueElements
WHERE ElementKind = 'IMPROVEMENT';

INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_TURN2_UNIQUE_IMPROVEMENT_' || ElementType, 'ImprovementType', ElementType
FROM T2D_UniqueElements
WHERE ElementKind = 'IMPROVEMENT';

INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_TURN2_UNIQUE_IMPROVEMENT_' || ElementType,
       'REQ_TURN2_UNIQUE_IMPROVEMENT_' || ElementType
FROM T2D_UniqueElements
WHERE ElementKind = 'IMPROVEMENT';

-- 为两枚符文和全部特色元素生成独立 modifier。
INSERT OR IGNORE INTO Types (Type, Kind)
SELECT 'MODIFIER_TURN2_' || y.RunePrefix || y.ModifierSuffix || '_' || e.ElementKind || '_' || e.ElementType,
       'KIND_MODIFIER'
FROM T2D_UniqueElements e
CROSS JOIN T2D_UniqueRuneYields y;

INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_' || y.RunePrefix || y.ModifierSuffix || '_BUILDING_' || e.ElementType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM T2D_UniqueElements e
CROSS JOIN T2D_UniqueRuneYields y
WHERE e.ElementKind = 'BUILDING';

INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, SubjectRequirementSetId)
SELECT 'MODIFIER_TURN2_' || y.RunePrefix || y.ModifierSuffix || '_DISTRICT_' || e.ElementType,
       'MODIFIER_PLAYER_DISTRICTS_ADJUST_YIELD_CHANGE',
       'REQSET_TURN2_UNIQUE_DISTRICT_' || e.ElementType
FROM T2D_UniqueElements e
CROSS JOIN T2D_UniqueRuneYields y
WHERE e.ElementKind = 'DISTRICT';

INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, SubjectRequirementSetId)
SELECT 'MODIFIER_TURN2_' || y.RunePrefix || y.ModifierSuffix || '_IMPROVEMENT_' || e.ElementType,
       'MODIFIER_PLAYER_ADJUST_PLOT_YIELD',
       'REQSET_TURN2_UNIQUE_IMPROVEMENT_' || e.ElementType
FROM T2D_UniqueElements e
CROSS JOIN T2D_UniqueRuneYields y
WHERE e.ElementKind = 'IMPROVEMENT';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_' || y.RunePrefix || y.ModifierSuffix || '_BUILDING_' || e.ElementType,
       'BuildingType', e.ElementType
FROM T2D_UniqueElements e
CROSS JOIN T2D_UniqueRuneYields y
WHERE e.ElementKind = 'BUILDING';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_' || y.RunePrefix || y.ModifierSuffix || '_' || e.ElementKind || '_' || e.ElementType,
       'YieldType', y.YieldType
FROM T2D_UniqueElements e
CROSS JOIN T2D_UniqueRuneYields y;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_' || y.RunePrefix || y.ModifierSuffix || '_' || e.ElementKind || '_' || e.ElementType,
       'Amount', '1'
FROM T2D_UniqueElements e
CROSS JOIN T2D_UniqueRuneYields y;
