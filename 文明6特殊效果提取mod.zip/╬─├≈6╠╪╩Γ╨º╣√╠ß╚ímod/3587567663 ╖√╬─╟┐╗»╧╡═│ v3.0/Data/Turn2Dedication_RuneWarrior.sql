-- ============================================================================
-- Turn2Dedication Mod - 符文战士单位定义
-- ============================================================================
-- 此单位专为符文系统设计：
-- - 移动力：3（高机动性）
-- - 战斗力：36（中期战力）
-- - 晋升类别：近战（PROMOTION_CLASS_MELEE）
-- - 特殊限制：无法通过科技树解锁，只能通过符文效果获得
-- ============================================================================

-- 1. 定义单位类型
INSERT INTO Types (Type, Kind)
VALUES ('UNIT_TURN2_RUNE_WARRIOR', 'KIND_UNIT');

-- 2. 定义单位基本属性
INSERT INTO Units 
    (UnitType, Cost, Maintenance, BaseMoves, BaseSightRange, ZoneOfControl, Domain, 
     Combat, FormationClass, PromotionClass, AdvisorType, 
     Name, Description, 
     MandatoryObsoleteTech, PrereqTech, CanTrain)
VALUES 
    ('UNIT_TURN2_RUNE_WARRIOR', 
     120,        -- 成本（参考价值，实际无法生产）
     2,          -- 维护费
     3,          -- ★ 移动力3（高机动性）
     2,          -- 视野
     1,          -- 控制区
     'DOMAIN_LAND',  -- 陆地单位
     36,         -- ★ 战斗力36（介于剑客35和骑手36之间）
     'FORMATION_CLASS_LAND_COMBAT',  -- 编队类型
     'PROMOTION_CLASS_MELEE', -- ★ 晋升类别：近战
     'ADVISOR_CONQUEST',  -- 顾问类型
     'LOC_UNIT_TURN2_RUNE_WARRIOR_NAME',  -- 名称
     'LOC_UNIT_TURN2_RUNE_WARRIOR_DESCRIPTION',  -- 描述
     'TECH_REPLACEABLE_PARTS',  -- 过时科技（可更换部件）
     NULL,  -- ★ 不设置前置科技，无法通过科技树解锁
     0  -- ★★★ CanTrain=0 禁止训练/生产
    );

-- 3. 添加单位标签（使其属于近战类别）
INSERT INTO TypeTags (Type, Tag)
VALUES 
    ('UNIT_TURN2_RUNE_WARRIOR', 'CLASS_MELEE');

-- 4. 添加AI使用提示
INSERT INTO UnitAIInfos (UnitType, AiType)
VALUES 
    ('UNIT_TURN2_RUNE_WARRIOR', 'UNITAI_COMBAT'),
    ('UNIT_TURN2_RUNE_WARRIOR', 'UNITAI_EXPLORE'),
    ('UNIT_TURN2_RUNE_WARRIOR', 'UNITTYPE_MELEE'),
    ('UNIT_TURN2_RUNE_WARRIOR', 'UNITTYPE_LAND_COMBAT');

-- 5. 设置升级路径（可升级为剑士步兵，近战单位的中世纪后续）
INSERT INTO UnitUpgrades (Unit, UpgradeUnit)
VALUES ('UNIT_TURN2_RUNE_WARRIOR', 'UNIT_MAN_AT_ARMS');

-- 6. 3D模型映射通过 ArtDefs/Units.artdef + Turn2Dedication.dep 实现
--    不使用 UnitReplaces（会导致科技树上被替换的单位图标消失）

-- ============================================================================
-- 说明：
-- - 移动力3提供出色的机动性，适合快速部署和包抄
-- - 战斗力36在古典-中世纪时代具有压制力
-- - AI会将其视为近战单位进行部署
-- - 玩家无法生产或购买（CanTrain=0），只能通过符文效果获得
-- - 可正常升级为剑士步兵（UNIT_MAN_AT_ARMS）
-- ============================================================================

