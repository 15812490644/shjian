-- ============================================================================
-- Turn2Dedication - Golden batch 7 dynamic data (runes 110-117)
-- ============================================================================

-- 114 Relief Synod: every non-wonder building belonging to the Holy Site
-- family gains +2 Food. District and building replacement chains are expanded
-- recursively from the database assembled before this file is loaded.
WITH RECURSIVE HolySiteFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_GOLD114_HOLY_BUILDING_FOOD_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM EligibleBuildings;

WITH RECURSIVE HolySiteFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteFamily family ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteFamily family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD114_HOLY_BUILDING_FOOD_' || BuildingType,
       'BuildingType', BuildingType
FROM EligibleBuildings;

WITH RECURSIVE HolySiteFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteFamily family ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteFamily family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD114_HOLY_BUILDING_FOOD_' || BuildingType,
       'YieldType', 'YIELD_FOOD'
FROM EligibleBuildings;

WITH RECURSIVE HolySiteFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteFamily family ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteFamily family ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD114_HOLY_BUILDING_FOOD_' || BuildingType,
       'Amount', '2'
FROM EligibleBuildings;

-- Temple plus every recursively nested replacement feeds one TEST_ANY city
-- requirement. Housing and amenity therefore apply once per eligible city.
WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_GOLD114_CITY_HAS_' || BuildingType,
       'REQUIREMENT_CITY_HAS_BUILDING'
FROM TempleFamily;

WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType FROM Buildings WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_GOLD114_CITY_HAS_' || BuildingType,
       'BuildingType', BuildingType
FROM TempleFamily;

WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType FROM Buildings WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_GOLD114_CITY_HAS_TEMPLE_FAMILY',
       'REQ_T2D_GOLD114_CITY_HAS_' || BuildingType
FROM TempleFamily;
