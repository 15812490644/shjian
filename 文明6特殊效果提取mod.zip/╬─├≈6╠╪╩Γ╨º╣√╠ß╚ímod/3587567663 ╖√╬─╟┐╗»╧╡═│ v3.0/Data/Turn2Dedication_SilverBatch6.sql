-- ============================================================================
-- Turn2Dedication - Silver batch 6 dynamic database content (runes 102-109)
-- ============================================================================

-- 107 Central Procurement: DISTRICT_GOVERNMENT recursively plus every unique
-- replacement already registered by the assembled gameplay database.
WITH RECURSIVE GovernmentPlazaFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_GOVERNMENT'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN GovernmentPlazaFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_SILVER107_CITY_HAS_' || DistrictType,
       'REQUIREMENT_CITY_HAS_DISTRICT'
FROM GovernmentPlazaFamily;

WITH RECURSIVE GovernmentPlazaFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_GOVERNMENT'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN GovernmentPlazaFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_SILVER107_CITY_HAS_' || DistrictType,
       'DistrictType', DistrictType
FROM GovernmentPlazaFamily;

WITH RECURSIVE GovernmentPlazaFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_GOVERNMENT'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN GovernmentPlazaFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_SILVER107_CITY_HAS_GOVERNMENT_PLAZA_FAMILY',
       'REQ_T2D_SILVER107_CITY_HAS_' || DistrictType
FROM GovernmentPlazaFamily;

-- One player-cities modifier per non-wonder building allows the engine to
-- apply its native purchase-cost effect while the city Subject requirement
-- keeps the discount strictly inside the Government Plaza city.
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, SubjectRequirementSetId)
SELECT 'MODIFIER_TURN2_SILVER107_CENTRAL_PROCUREMENT_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_PURCHASE_COST',
       'REQSET_T2D_SILVER107_CITY_HAS_GOVERNMENT_PLAZA_FAMILY'
FROM Buildings
WHERE COALESCE(IsWonder, 0) = 0;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER107_CENTRAL_PROCUREMENT_' || BuildingType,
       'BuildingType', BuildingType
FROM Buildings
WHERE COALESCE(IsWonder, 0) = 0;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER107_CENTRAL_PROCUREMENT_' || BuildingType,
       'Amount', '20'
FROM Buildings
WHERE COALESCE(IsWonder, 0) = 0;
