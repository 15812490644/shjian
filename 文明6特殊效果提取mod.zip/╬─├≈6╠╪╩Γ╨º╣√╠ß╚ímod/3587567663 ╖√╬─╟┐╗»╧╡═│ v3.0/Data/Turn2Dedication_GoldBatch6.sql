-- ============================================================================
-- Turn2Dedication - Golden batch 6 dynamic database content (runes 83-92)
-- ============================================================================

-- 84: every non-civilian formation receives +15% production. A separate fixed
-- modifier uses the engine's identity-list argument for all civilian units, so
-- Gameplay only needs to attach one -5% modifier for that side of the tradeoff.
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_GOLD84_NON_CIVILIAN_PRODUCTION_' || UnitType,
       'MODIFIER_PLAYER_UNITS_ADJUST_UNIT_PRODUCTION'
FROM Units
WHERE COALESCE(FormationClass, '') <> 'FORMATION_CLASS_CIVILIAN';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD84_NON_CIVILIAN_PRODUCTION_' || UnitType,
       'UnitType', UnitType
FROM Units
WHERE COALESCE(FormationClass, '') <> 'FORMATION_CLASS_CIVILIAN';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD84_NON_CIVILIAN_PRODUCTION_' || UnitType,
       'Amount', '15'
FROM Units
WHERE COALESCE(FormationClass, '') <> 'FORMATION_CLASS_CIVILIAN';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD84_CIVILIAN_PRODUCTION',
       'UnitType', GROUP_CONCAT(UnitType, ',')
FROM (
    SELECT UnitType
    FROM Units
    WHERE FormationClass = 'FORMATION_CLASS_CIVILIAN'
    ORDER BY UnitType
)
GROUP BY 1;

-- 86: cover the complete era range present in the assembled gameplay database,
-- including ERA_FUTURE and any higher era added by a compatible mod.
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD86_GRANT_TECH_BOOSTS',
       'EndEraType', EraType
FROM Eras
ORDER BY ChronologyIndex DESC, EraType DESC
LIMIT 1;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD86_GRANT_CIVIC_BOOSTS',
       'EndEraType', EraType
FROM Eras
ORDER BY ChronologyIndex DESC, EraType DESC
LIMIT 1;

-- 87: BUILDING_UNIVERSITY plus every recursively nested unique replacement.
-- Recursive expansion also supports a modded unique replacing another unique.
WITH RECURSIVE UniversityFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_UNIVERSITY'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN UniversityFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_GOLD87_UNIVERSITY_PRODUCTION_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM UniversityFamily;

WITH RECURSIVE UniversityFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_UNIVERSITY'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN UniversityFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD87_UNIVERSITY_PRODUCTION_' || BuildingType,
       'BuildingType', BuildingType
FROM UniversityFamily;

WITH RECURSIVE UniversityFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_UNIVERSITY'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN UniversityFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD87_UNIVERSITY_PRODUCTION_' || BuildingType,
       'YieldType', 'YIELD_PRODUCTION'
FROM UniversityFamily;

WITH RECURSIVE UniversityFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_UNIVERSITY'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN UniversityFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD87_UNIVERSITY_PRODUCTION_' || BuildingType,
       'Amount', '3'
FROM UniversityFamily;

-- 92: ensure every database air unit participates in CLASS_AIRCRAFT, including
-- modded units that only declared DOMAIN_AIR/FORMATION_CLASS_AIR. Production is
-- kept as one identity-list modifier for deterministic Gameplay attachment.
INSERT OR IGNORE INTO TypeTags (Type, Tag)
SELECT UnitType, 'CLASS_AIRCRAFT'
FROM Units
WHERE Domain = 'DOMAIN_AIR'
   OR FormationClass = 'FORMATION_CLASS_AIR';

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_GOLD92_AIR_PRODUCTION',
       'UnitType', GROUP_CONCAT(UnitType, ',')
FROM (
    SELECT UnitType
    FROM Units
    WHERE Domain = 'DOMAIN_AIR'
       OR FormationClass = 'FORMATION_CLASS_AIR'
    ORDER BY UnitType
)
GROUP BY 1;
