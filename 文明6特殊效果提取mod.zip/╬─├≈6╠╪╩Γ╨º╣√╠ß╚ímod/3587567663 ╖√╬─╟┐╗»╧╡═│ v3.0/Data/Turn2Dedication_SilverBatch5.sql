-- ============================================================================
-- Turn2Dedication - Silver batch 5 dynamic database content (runes 93-101)
--
-- Every generated modifier uses a COLLECTION_PLAYER_CITIES native modifier
-- type. No COLLECTION_ALL_* attachment is used, so effects remain scoped to
-- the player to whom Gameplay attaches the modifier.
-- ============================================================================

-- 95 Peer Review: Campus plus every recursively nested unique replacement,
-- then every repeatable project belonging to one of those districts.
WITH RECURSIVE CampusFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_CAMPUS'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CampusFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleProjects(ProjectType) AS (
    SELECT project.ProjectType
    FROM Projects project
    JOIN CampusFamily family
      ON project.PrereqDistrict = family.DistrictType
    WHERE COALESCE(project.MaxPlayerInstances, 0) <= 0
      AND COALESCE(project.SpaceRace, 0) = 0
      AND COALESCE(project.WMD, 0) = 0
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_SILVER95_PEER_REVIEW_PROJECT_' || ProjectType,
       'MODIFIER_PLAYER_CITIES_ADJUST_PROJECT_PRODUCTION'
FROM EligibleProjects;

WITH RECURSIVE CampusFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_CAMPUS'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CampusFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleProjects(ProjectType) AS (
    SELECT project.ProjectType
    FROM Projects project
    JOIN CampusFamily family
      ON project.PrereqDistrict = family.DistrictType
    WHERE COALESCE(project.MaxPlayerInstances, 0) <= 0
      AND COALESCE(project.SpaceRace, 0) = 0
      AND COALESCE(project.WMD, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER95_PEER_REVIEW_PROJECT_' || ProjectType,
       'ProjectType', ProjectType
FROM EligibleProjects;

WITH RECURSIVE CampusFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_CAMPUS'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CampusFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleProjects(ProjectType) AS (
    SELECT project.ProjectType
    FROM Projects project
    JOIN CampusFamily family
      ON project.PrereqDistrict = family.DistrictType
    WHERE COALESCE(project.MaxPlayerInstances, 0) <= 0
      AND COALESCE(project.SpaceRace, 0) = 0
      AND COALESCE(project.WMD, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER95_PEER_REVIEW_PROJECT_' || ProjectType,
       'Amount', '25'
FROM EligibleProjects;

-- 96 Civic Festival: both land and water entertainment district families.
WITH RECURSIVE EntertainmentFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType IN (
        'DISTRICT_ENTERTAINMENT_COMPLEX',
        'DISTRICT_WATER_ENTERTAINMENT_COMPLEX'
    )
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN EntertainmentFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_DISTRICT_' || DistrictType,
       'MODIFIER_PLAYER_CITIES_ADJUST_DISTRICT_PRODUCTION'
FROM EntertainmentFamily;

WITH RECURSIVE EntertainmentFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType IN (
        'DISTRICT_ENTERTAINMENT_COMPLEX',
        'DISTRICT_WATER_ENTERTAINMENT_COMPLEX'
    )
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN EntertainmentFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_DISTRICT_' || DistrictType,
       'DistrictType', DistrictType
FROM EntertainmentFamily;

WITH RECURSIVE EntertainmentFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType IN (
        'DISTRICT_ENTERTAINMENT_COMPLEX',
        'DISTRICT_WATER_ENTERTAINMENT_COMPLEX'
    )
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN EntertainmentFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_DISTRICT_' || DistrictType,
       'Amount', '20'
FROM EntertainmentFamily;

WITH RECURSIVE EntertainmentFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType IN (
        'DISTRICT_ENTERTAINMENT_COMPLEX',
        'DISTRICT_WATER_ENTERTAINMENT_COMPLEX'
    )
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN EntertainmentFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN EntertainmentFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_BUILDING_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM EligibleBuildings;

WITH RECURSIVE EntertainmentFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType IN (
        'DISTRICT_ENTERTAINMENT_COMPLEX',
        'DISTRICT_WATER_ENTERTAINMENT_COMPLEX'
    )
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN EntertainmentFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN EntertainmentFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_BUILDING_' || BuildingType,
       'BuildingType', BuildingType
FROM EligibleBuildings;

WITH RECURSIVE EntertainmentFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType IN (
        'DISTRICT_ENTERTAINMENT_COMPLEX',
        'DISTRICT_WATER_ENTERTAINMENT_COMPLEX'
    )
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN EntertainmentFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN EntertainmentFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_BUILDING_' || BuildingType,
       'YieldType', 'YIELD_CULTURE'
FROM EligibleBuildings;

WITH RECURSIVE EntertainmentFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType IN (
        'DISTRICT_ENTERTAINMENT_COMPLEX',
        'DISTRICT_WATER_ENTERTAINMENT_COMPLEX'
    )
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN EntertainmentFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN EntertainmentFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_BUILDING_' || BuildingType,
       'Amount', '1'
FROM EligibleBuildings;

-- 98 Charity Parish: every non-wonder building usable in the Holy Site family
-- gets +1 Food. Only Temple and recursive Temple replacements get +1 Housing.
WITH RECURSIVE HolySiteFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_SILVER98_CHARITY_PARISH_FOOD_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM EligibleBuildings;

WITH RECURSIVE HolySiteFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER98_CHARITY_PARISH_FOOD_' || BuildingType,
       'BuildingType', BuildingType
FROM EligibleBuildings;

WITH RECURSIVE HolySiteFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER98_CHARITY_PARISH_FOOD_' || BuildingType,
       'YieldType', 'YIELD_FOOD'
FROM EligibleBuildings;

WITH RECURSIVE HolySiteFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), EligibleBuildings(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER98_CHARITY_PARISH_FOOD_' || BuildingType,
       'Amount', '1'
FROM EligibleBuildings;

-- EFFECT_ADJUST_BUILDING_HOUSING is a city-level adjustment and does not take
-- a BuildingType argument. Feed every Temple-family requirement into one
-- TEST_ANY set consumed by the single XML-defined Housing modifier. This also
-- prevents a unique replacement that satisfies a base-building check from
-- receiving the +1 Housing more than once.
WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_SILVER98_CITY_HAS_' || BuildingType,
       'REQUIREMENT_CITY_HAS_BUILDING'
FROM TempleFamily;

WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_SILVER98_CITY_HAS_' || BuildingType,
       'BuildingType', BuildingType
FROM TempleFamily;

WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_SILVER98_CITY_HAS_TEMPLE_FAMILY',
       'REQ_T2D_SILVER98_CITY_HAS_' || BuildingType
FROM TempleFamily;

-- 101 Public Tender: every repeatable project tied to a district, while
-- explicitly excluding Space Race and WMD projects. MaxPlayerInstances being
-- NULL/zero/negative is the database's repeatable-project convention.
WITH EligibleProjects(ProjectType) AS (
    SELECT ProjectType
    FROM Projects
    WHERE PrereqDistrict IS NOT NULL
      AND COALESCE(MaxPlayerInstances, 0) <= 0
      AND COALESCE(SpaceRace, 0) = 0
      AND COALESCE(WMD, 0) = 0
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_SILVER101_PUBLIC_TENDER_PROJECT_' || ProjectType,
       'MODIFIER_PLAYER_CITIES_ADJUST_PROJECT_PRODUCTION'
FROM EligibleProjects;

WITH EligibleProjects(ProjectType) AS (
    SELECT ProjectType
    FROM Projects
    WHERE PrereqDistrict IS NOT NULL
      AND COALESCE(MaxPlayerInstances, 0) <= 0
      AND COALESCE(SpaceRace, 0) = 0
      AND COALESCE(WMD, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER101_PUBLIC_TENDER_PROJECT_' || ProjectType,
       'ProjectType', ProjectType
FROM EligibleProjects;

WITH EligibleProjects(ProjectType) AS (
    SELECT ProjectType
    FROM Projects
    WHERE PrereqDistrict IS NOT NULL
      AND COALESCE(MaxPlayerInstances, 0) <= 0
      AND COALESCE(SpaceRace, 0) = 0
      AND COALESCE(WMD, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_SILVER101_PUBLIC_TENDER_PROJECT_' || ProjectType,
       'Amount', '10'
FROM EligibleProjects;
