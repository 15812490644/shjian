-- ============================================================================
-- Turn2Dedication Mod - 特色单位动态标签
-- ============================================================================
-- 战誓银刃使用 UnitAbility + TypeTags 限定目标。这里把原版/DLC 已载入的
-- 特色单位统一标记为 CLASS_T2D_UNIQUE_UNIT，供 ABILITY_TURN2_WAROATH_UNIQUE_COMBAT 使用。
-- ============================================================================

INSERT OR IGNORE INTO Tags (Tag, Vocabulary)
VALUES ('CLASS_T2D_UNIQUE_UNIT', 'ABILITY_CLASS');

-- 大多数文明/领袖特色单位在 Units.TraitType 上有专属 trait。
INSERT OR IGNORE INTO TypeTags (Type, Tag)
SELECT UnitType, 'CLASS_T2D_UNIQUE_UNIT'
FROM Units
WHERE TraitType IS NOT NULL;

-- 兜底：替换表里声明的文明特色单位也纳入。
INSERT OR IGNORE INTO TypeTags (Type, Tag)
SELECT CivUniqueUnitType, 'CLASS_T2D_UNIQUE_UNIT'
FROM UnitReplaces
WHERE CivUniqueUnitType IS NOT NULL;
