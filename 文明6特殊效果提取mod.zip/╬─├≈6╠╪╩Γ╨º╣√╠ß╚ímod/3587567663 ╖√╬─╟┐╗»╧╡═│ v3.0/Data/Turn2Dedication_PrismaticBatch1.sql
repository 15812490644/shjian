-- ============================================================================
-- Turn2Dedication - Prismatic batch 1 dynamic data (runes 118-126)
-- ============================================================================

-- 120 Knowledge Singularity: cover the highest era in the assembled database,
-- including Future Era and any later era registered by another loaded mod.
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC120_GRANT_TECH_BOOSTS',
       'EndEraType', EraType
FROM Eras
ORDER BY ChronologyIndex DESC, EraType DESC
LIMIT 1;

INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC120_GRANT_CIVIC_BOOSTS',
       'EndEraType', EraType
FROM Eras
ORDER BY ChronologyIndex DESC, EraType DESC
LIMIT 1;

-- 121 Universal Holy See: recursively expand both the Holy Site district
-- family and building replacement chains. UNION (not UNION ALL) prevents a
-- building that is reachable through both routes from receiving duplicates.
WITH RECURSIVE HolySiteDistrictFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), HolySiteBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN HolySiteBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
), YieldSpecs(Suffix, YieldType, Amount) AS (
    SELECT 'FOOD', 'YIELD_FOOD', '2'
    UNION ALL
    SELECT 'PRODUCTION', 'YIELD_PRODUCTION', '2'
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC121_HOLY_BUILDING_' || specs.Suffix || '_' || family.BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM HolySiteBuildingFamily family
CROSS JOIN YieldSpecs specs;

WITH RECURSIVE HolySiteDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_HOLY_SITE'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN HolySiteDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), HolySiteBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN HolySiteDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN HolySiteBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
), YieldSpecs(Suffix, YieldType, Amount) AS (
    SELECT 'FOOD', 'YIELD_FOOD', '2'
    UNION ALL
    SELECT 'PRODUCTION', 'YIELD_PRODUCTION', '2'
), Generated(ModifierId, BuildingType, YieldType, Amount) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC121_HOLY_BUILDING_' || specs.Suffix || '_' || family.BuildingType,
           family.BuildingType, specs.YieldType, specs.Amount
    FROM HolySiteBuildingFamily family
    CROSS JOIN YieldSpecs specs
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'BuildingType', BuildingType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldType', YieldType FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', Amount FROM Generated;

-- Temple plus every recursively nested replacement feeds a single TEST_ANY
-- city requirement. Housing and Amenity consequently apply only once per city.
WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType
    FROM Buildings
    WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_PRISMATIC121_CITY_HAS_' || BuildingType,
       'REQUIREMENT_CITY_HAS_BUILDING'
FROM TempleFamily;

WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType FROM Buildings WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_PRISMATIC121_CITY_HAS_' || BuildingType,
       'BuildingType', BuildingType
FROM TempleFamily;

WITH RECURSIVE TempleFamily(BuildingType) AS (
    SELECT BuildingType FROM Buildings WHERE BuildingType = 'BUILDING_TEMPLE'
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN TempleFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_PRISMATIC121_CITY_HAS_TEMPLE_FAMILY',
       'REQ_T2D_PRISMATIC121_CITY_HAS_' || BuildingType
FROM TempleFamily;

-- 122 Palace of Human Memory: one Science and one Gold modifier per Great Work
-- object type. This automatically includes all expansion and already-loaded
-- modded Great Work categories without hard-coding the vanilla eight types.
WITH YieldSpecs(Suffix, YieldType, Amount) AS (
    SELECT 'SCIENCE', 'YIELD_SCIENCE', '2'
    UNION ALL
    SELECT 'GOLD', 'YIELD_GOLD', '2'
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC122_GREATWORK_' || specs.Suffix || '_' || object.GreatWorkObjectType,
       'MODIFIER_PLAYER_CITIES_ADJUST_GREATWORK_YIELD'
FROM GreatWorkObjectTypes object
CROSS JOIN YieldSpecs specs;

WITH YieldSpecs(Suffix, YieldType, Amount) AS (
    SELECT 'SCIENCE', 'YIELD_SCIENCE', '2'
    UNION ALL
    SELECT 'GOLD', 'YIELD_GOLD', '2'
), Generated(ModifierId, GreatWorkObjectType, YieldType, Amount) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC122_GREATWORK_' || specs.Suffix || '_' || object.GreatWorkObjectType,
           object.GreatWorkObjectType, specs.YieldType, specs.Amount
    FROM GreatWorkObjectTypes object
    CROSS JOIN YieldSpecs specs
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'GreatWorkObjectType', GreatWorkObjectType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldType', YieldType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldChange', Amount FROM Generated;

-- 126 Pillars of Every City: recursively expand City Center district and
-- building replacement chains. Every generated row is a player-cities
-- modifier, so no other civilization's buildings can receive these effects.
WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType
    FROM Districts
    WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC126_CITY_CENTER_PRODUCTION_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_PRODUCTION'
FROM CityCenterBuildingFamily;

WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC126_CITY_CENTER_PRODUCTION_' || BuildingType,
       'BuildingType', BuildingType
FROM CityCenterBuildingFamily
UNION ALL
SELECT 'MODIFIER_TURN2_PRISMATIC126_CITY_CENTER_PRODUCTION_' || BuildingType,
       'Amount', '100'
FROM CityCenterBuildingFamily;

-- Base yields: every eligible building supplies +1 Food and +1 Production.
WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
), YieldSpecs(Suffix, YieldType, Amount) AS (
    SELECT 'FOOD', 'YIELD_FOOD', '1'
    UNION ALL
    SELECT 'PRODUCTION', 'YIELD_PRODUCTION', '1'
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType)
SELECT 'MODIFIER_TURN2_PRISMATIC126_BASE_' || specs.Suffix || '_' || family.BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE'
FROM CityCenterBuildingFamily family
CROSS JOIN YieldSpecs specs;

WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
), YieldSpecs(Suffix, YieldType, Amount) AS (
    SELECT 'FOOD', 'YIELD_FOOD', '1'
    UNION ALL
    SELECT 'PRODUCTION', 'YIELD_PRODUCTION', '1'
), Generated(ModifierId, BuildingType, YieldType, Amount) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC126_BASE_' || specs.Suffix || '_' || family.BuildingType,
           family.BuildingType, specs.YieldType, specs.Amount
    FROM CityCenterBuildingFamily family
    CROSS JOIN YieldSpecs specs
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'BuildingType', BuildingType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldType', YieldType FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', Amount FROM Generated;

-- Enlightenment tier: an additional +1 Food, +1 Production, and +2 Gold per
-- eligible building. OwnerRequirementSetId reevaluates immediately on unlock.
WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
), YieldSpecs(Suffix, YieldType, Amount) AS (
    SELECT 'FOOD', 'YIELD_FOOD', '1'
    UNION ALL
    SELECT 'PRODUCTION', 'YIELD_PRODUCTION', '1'
    UNION ALL
    SELECT 'GOLD', 'YIELD_GOLD', '2'
)
INSERT OR IGNORE INTO Modifiers (ModifierId, ModifierType, OwnerRequirementSetId)
SELECT 'MODIFIER_TURN2_PRISMATIC126_ENLIGHTENMENT_' || specs.Suffix || '_' || family.BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_YIELD_CHANGE',
       'REQSET_T2D_PRISMATIC126_PLAYER_HAS_ENLIGHTENMENT'
FROM CityCenterBuildingFamily family
CROSS JOIN YieldSpecs specs;

WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
), YieldSpecs(Suffix, YieldType, Amount) AS (
    SELECT 'FOOD', 'YIELD_FOOD', '1'
    UNION ALL
    SELECT 'PRODUCTION', 'YIELD_PRODUCTION', '1'
    UNION ALL
    SELECT 'GOLD', 'YIELD_GOLD', '2'
), Generated(ModifierId, BuildingType, YieldType, Amount) AS (
    SELECT 'MODIFIER_TURN2_PRISMATIC126_ENLIGHTENMENT_' || specs.Suffix || '_' || family.BuildingType,
           family.BuildingType, specs.YieldType, specs.Amount
    FROM CityCenterBuildingFamily family
    CROSS JOIN YieldSpecs specs
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT ModifierId, 'BuildingType', BuildingType FROM Generated
UNION ALL
SELECT ModifierId, 'YieldType', YieldType FROM Generated
UNION ALL
SELECT ModifierId, 'Amount', Amount FROM Generated;

-- Building housing is a city-level effect without a BuildingType argument.
-- Give every eligible building its own city-has-building requirement and its
-- own +1 Housing modifier, preserving the intended per-building scaling.
WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO RequirementSets (RequirementSetId, RequirementSetType)
SELECT 'REQSET_T2D_PRISMATIC126_CITY_HAS_' || BuildingType,
       'REQUIREMENTSET_TEST_ALL'
FROM CityCenterBuildingFamily;

WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO Requirements (RequirementId, RequirementType)
SELECT 'REQ_T2D_PRISMATIC126_CITY_HAS_' || BuildingType,
       'REQUIREMENT_CITY_HAS_BUILDING'
FROM CityCenterBuildingFamily;

WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO RequirementArguments (RequirementId, Name, Value)
SELECT 'REQ_T2D_PRISMATIC126_CITY_HAS_' || BuildingType,
       'BuildingType', BuildingType
FROM CityCenterBuildingFamily;

WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO RequirementSetRequirements (RequirementSetId, RequirementId)
SELECT 'REQSET_T2D_PRISMATIC126_CITY_HAS_' || BuildingType,
       'REQ_T2D_PRISMATIC126_CITY_HAS_' || BuildingType
FROM CityCenterBuildingFamily;

WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO Modifiers
    (ModifierId, ModifierType, OwnerRequirementSetId, SubjectRequirementSetId)
SELECT 'MODIFIER_TURN2_PRISMATIC126_ENLIGHTENMENT_HOUSING_' || BuildingType,
       'MODIFIER_PLAYER_CITIES_ADJUST_BUILDING_HOUSING',
       'REQSET_T2D_PRISMATIC126_PLAYER_HAS_ENLIGHTENMENT',
       'REQSET_T2D_PRISMATIC126_CITY_HAS_' || BuildingType
FROM CityCenterBuildingFamily;

WITH RECURSIVE CityCenterDistrictFamily(DistrictType) AS (
    SELECT DistrictType FROM Districts WHERE DistrictType = 'DISTRICT_CITY_CENTER'
    UNION
    SELECT replacement.CivUniqueDistrictType
    FROM DistrictReplaces replacement
    JOIN CityCenterDistrictFamily family
      ON replacement.ReplacesDistrictType = family.DistrictType
), CityCenterBuildingFamily(BuildingType) AS (
    SELECT building.BuildingType
    FROM Buildings building
    JOIN CityCenterDistrictFamily family
      ON building.PrereqDistrict = family.DistrictType
    WHERE COALESCE(building.IsWonder, 0) = 0
    UNION
    SELECT replacement.CivUniqueBuildingType
    FROM BuildingReplaces replacement
    JOIN CityCenterBuildingFamily family
      ON replacement.ReplacesBuildingType = family.BuildingType
    JOIN Buildings building
      ON building.BuildingType = replacement.CivUniqueBuildingType
    WHERE COALESCE(building.IsWonder, 0) = 0
)
INSERT OR IGNORE INTO ModifierArguments (ModifierId, Name, Value)
SELECT 'MODIFIER_TURN2_PRISMATIC126_ENLIGHTENMENT_HOUSING_' || BuildingType,
       'Amount', '1'
FROM CityCenterBuildingFamily;
