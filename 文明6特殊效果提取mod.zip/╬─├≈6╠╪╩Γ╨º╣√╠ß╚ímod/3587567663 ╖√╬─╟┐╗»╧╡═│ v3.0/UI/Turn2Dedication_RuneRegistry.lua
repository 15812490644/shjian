-- ===========================================================================
-- 符文强化系统 - 符文注册表（单一数据源 / Single Source of Truth）
-- ---------------------------------------------------------------------------
-- 本文件被 UI 上下文脚本 include：
--   - UI/Turn2DedicationPopup.lua          （符文选择弹窗）
--   - UI/EraProgressPanel_Turn2Dedication.lua（时代进度面板追加显示）
-- 用于取代原先分散在两处且彼此漂移的 RUNE_DATABASE / RUNE_DISPLAY。
--
-- 注意：Gameplay 脚本(Scripts/Turn2DedicationTrigger.lua)运行在独立 Lua VM，
-- 无法 include 本文件；其效果分发(HANDLERS)与一次性符文的金价拆分(valueProfile)
-- 保留在 Trigger.lua 内。阶段品质由房主写入全局 Property，选择消息(端口655001)
-- 仅回传符文与品质供 Gameplay 交叉校验，客户端值不再作为权威来源。
--
-- 每条符文字段：
--   name     符文名称（玩家可见）
--   icon     图标（复用引擎原生图集）
--   category 分类: military/science/culture/economy/religion/expansion/mechanic
--   kind     价值类型: "oneshot"(一次性,随阶段缩放) / "longterm"(长线,固定量,一般pin第1-2阶段) / "mechanic"(机制,按单位成本)
--   rarity   稀有度: "silver" / "gold" / "prismatic"
--   stages   可出现阶段(数组)，抽卡分池由此派生
--   conflictGroup 可选；同组符文互斥，抽卡与开发者应用均应阻止同时拥有
--   effect   效果描述文本（玩家可见，取代两处重复文本）
--   summary  简短风味描述（可选；缺省时按玩法分类生成）
-- ===========================================================================

-- 稀有度常量与展示
T2D_RARITY = { SILVER = "silver", GOLD = "gold", PRISMATIC = "prismatic" };

T2D_RARITY_NAME = {
    silver    = "白银",
    gold      = "黄金",
    prismatic = "棱彩",
};

-- 稀有度颜色（ABGR 供 SetColor 使用；UI 也可按需取十六进制）
T2D_RARITY_COLOR = {
    silver    = "FFCCB7AE",  -- 冷钢灰
    gold      = "FF3AA9E3",  -- 琥珀金 (ABGR)
    prismatic = "FFFF8CB9",  -- 棱彩紫
};

-- 价值预算表（金币等价）: [rarity][stage] -> 预算
T2D_BUDGET = {
    silver    = { 200,  600,  1200 },
    gold      = { 400,  1200, 2400 },
    prismatic = { 600,  1800, 3600 },
};

-- 稀有度 <-> 数字编码（用于隐藏聊天消息的网络同步，字符串不便随消息传递）
T2D_RARITY_CODE    = { silver = 1, gold = 2, prismatic = 3 };
T2D_RARITY_BY_CODE = { [1] = "silver", [2] = "gold", [3] = "prismatic" };

-- 符文池模式白名单（仅控制"广度/可出现哪些符文"；具体阶段放置以各符文 stages 字段为准）
-- 模式3(全符文)无白名单=该阶段全部可出现符文。模式1/2与 stages 取交集。
T2D_POOL_WHITELIST = {
    -- 模式1 精简：白银为主的均衡子集
    [1] = {1,2,3,4,5,7,10,11,13,14,15,16,17,18,22,23,24,25,28,33,38,39,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,72,73,74,75,76,77,78,82,83,86,87,88,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145},
    -- 模式2 完整：去除死/重复后的大部分符文（含第四轮新符文 44-51）
    [2] = {1,2,3,4,5,6,7,10,11,12,13,14,15,16,17,18,20,21,22,23,24,25,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145},
};

-- ===========================================================================
-- 符文注册表
-- ===========================================================================
T2D_Runes = {
    [1]  = { name="实战训练",   icon="ICON_UNITOPERATION_MAKE_FORTIFICATION", category="military",  kind="mechanic", rarity="silver",    stages={2},
             effect="下回合开始:获得1个最强近战单位[NEWLINE]首都+1[ICON_Production]生产力[NEWLINE]首都每回合+1[ICON_Gold]金币" },
    [2]  = { name="知识下载",   icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="longterm", rarity="silver",    stages={2},
             effect="下回合开始:每回合+1大科学家点数[NEWLINE]首都+2[ICON_Science]科技" },
    [3]  = { name="鼓舞人心",   icon="ICON_DISTRICT_THEATER",                 category="culture",   kind="longterm", rarity="silver",    stages={2},
             effect="下回合开始:每回合+1大作家点数[NEWLINE]首都+1[ICON_Culture]文化" },
    [4]  = { name="贸易大亨",   icon="ICON_DISTRICT_COMMERCIAL_HUB",          category="economy",   kind="longterm", rarity="silver",    stages={1},
             effect="下回合开始:首都每回合+2[ICON_Gold]金币[NEWLINE]并获得1条商路容量" },
    [5]  = { name="文化传承",   icon="ICON_DISTRICT_THEATER",                 category="culture",   kind="oneshot",  rarity="silver",    stages={1,2},
             effect="立即获得:文化进度(随阶段缩放)[NEWLINE]下回合开始:首都+1[ICON_Culture]文化[NEWLINE]剧院广场+1[ICON_Culture]文化" },
    [6]  = { name="战略储备",   icon="ICON_RESOURCECLASS_STRATEGIC",          category="military",  kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:战略资源储备上限+20[NEWLINE]每回合获得已解锁的各类战略资源+2" },
    [7]  = { name="探索者",     icon="ICON_UNIT_SCOUT",                       category="expansion", kind="mechanic", rarity="silver",    stages={1},
             effect="下回合开始:获得1个侦察兵[NEWLINE]所有侦察兵+1移速[NEWLINE]首都+1[ICON_Housing]住房" },
    [10] = { name="建筑大师",   icon="ICON_GREATWORK_SCULPTURE_1",            category="economy",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:建造奇观速度+10%" },
    [11] = { name="外交联盟",   icon="ICON_ENVOY",                            category="mechanic",  kind="mechanic", rarity="gold",      stages={1,2},
             effect="下回合开始:获得1个使者[NEWLINE]每进入新时代获得1个使者" },
    [12] = { name="开疆拓土",   icon="ICON_GOVERNOR_THE_FOUNDER",             category="expansion", kind="longterm", rarity="prismatic", stages={1,2},
             effect="[任务]达成城市数量目标后,所有城市获得加成:[NEWLINE]古典(6城):+1[ICON_Culture]+1[ICON_Production][NEWLINE]中世纪(8城):+1[ICON_Science]+1[ICON_Production][NEWLINE]文艺复兴(11城):+2[ICON_Gold]+1[ICON_Production]" },
    [13] = { name="宗教信仰",   icon="ICON_RELIGION",                         category="religion",  kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:首都+2[ICON_Faith]信仰[NEWLINE]每回合+1大预言家点数[NEWLINE]每次过时代后,首都出现传教士" },
    [14] = { name="学术精英",   icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:学院+1[ICON_Science]科技[NEWLINE]学院建造速度+15%" },
    [15] = { name="商贸网络",   icon="ICON_TRADEROUTE",                       category="economy",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:每回合+1大商人点数[NEWLINE]国际商路每经过国外城市+1[ICON_Production]+1[ICON_Gold][NEWLINE]古典时代后:+1商路容量和1个商人" },
    [16] = { name="农业革新",   icon="ICON_IMPROVEMENT_FARM",                 category="economy",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:所有农场+1[ICON_Food]食物[NEWLINE]粮仓建造速度+100%" },
    [17] = { name="军事主义",   icon="ICON_DISTRICT_ENCAMPMENT",              category="military",  kind="mechanic", rarity="silver",    stages={1},
             effect="下回合开始:获得1个投石兵[NEWLINE]军营建造速度+25%" },
    [18] = { name="防御工事",   icon="ICON_IMPROVEMENT_FORT",                 category="military",  kind="longterm", rarity="silver",    stages={1},
             effect="下回合开始:远古城墙建造速度+50%" },
    [20] = { name="探索先锋",   icon="ICON_TERRAIN_MOUNTAIN",                 category="expansion", kind="longterm", rarity="silver",    stages={2},
             effect="[任务]发现自然奇观获得增益:[NEWLINE]第1个:首都+1[ICON_Gold]+1[ICON_Science]+1[ICON_Production][NEWLINE]第2个:首都+10%[ICON_Gold]+10%[ICON_Culture]+10%[ICON_Production][NEWLINE]第3个:首都+3宜居度" },
    [21] = { name="文艺复兴",   icon="ICON_GREATWORK_WRITING_4",              category="culture",   kind="longterm", rarity="prismatic", stages={2},
             effect="下回合开始:进入中世纪和文艺复兴后[NEWLINE]除大将军外,所有伟人点数+1" },
    [22] = { name="奇观狂魔",   icon="ICON_DISTRICT_WONDER",                  category="economy",   kind="oneshot",  rarity="prismatic", stages={1,2},
             effect="下回合开始:奇观建造速度+5%[NEWLINE]完成奇观时,获得实际成本一定比例的金币(有次数上限)" },
    [23] = { name="龟型阵",     icon="ICON_UNIT_SPEARMAN",                    category="military",  kind="mechanic", rarity="silver",    stages={2},
             effect="下回合开始:抗骑兵单位建造速度+15%[NEWLINE]选择符文的15回合后和25回合后首都获得1个移动力为1的枪兵" },
    [24] = { name="学术网络",   icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="longterm", rarity="gold",      stages={2},
             effect="完成2个学院:+2大科学家点数/回合[NEWLINE]完成4个学院:学院建筑建造速度+25%[NEWLINE]完成6个学院:根据时代获得大科学家点数[NEWLINE]完成8个学院:随机获得工业+现代科技尤里卡" },
    [25] = { name="海上贸易",   icon="ICON_DISTRICT_HARBOR",                  category="economy",   kind="longterm", rarity="silver",    stages={1},
             effect="下回合开始:首都+3[ICON_Gold]金币[NEWLINE]港口+1[ICON_Gold]金币" },
    [27] = { name="骑兵突击",   icon="ICON_UNIT_HORSEMAN",                    category="military",  kind="mechanic", rarity="silver",    stages={2},
             effect="选择后3回合:首都获得2个骑手[NEWLINE]下回合开始:轻骑兵和重骑兵建造速度+20%" },
    [28] = { name="黄金贸易",   icon="ICON_TRADEROUTE",                       category="economy",   kind="oneshot",  rarity="silver",    stages={2},
             effect="立即获得:金币(随阶段缩放)[NEWLINE]下回合开始:国际商路+1[ICON_Science]+2[ICON_Gold][NEWLINE]+1商路容量" },
    [29] = { name="宗教扩张",   icon="ICON_GREATPERSON_CLASS_APOSTLE",        category="religion",  kind="mechanic", rarity="silver",    stages={2},
             effect="下回合开始:获得1个使徒[NEWLINE]所有城市+1[ICON_Faith]信仰[NEWLINE]购买传教士费用-25%" },
    [30] = { name="封建萌芽",   icon="ICON_UNIT_BUILDER",                     category="expansion", kind="mechanic", rarity="gold",      stages={2},
             effect="下回合开始:首都获得1个工人[NEWLINE]生产工人速度+15%[NEWLINE]进入新时代时:首都再获得1个工人(有上限)" },
    [31] = { name="商业垄断",   icon="ICON_TRADEROUTE",                       category="economy",   kind="longterm", rarity="gold",      stages={2},
             effect="下回合开始:国际商路+2[ICON_Gold]+2[ICON_Production][NEWLINE]国内商路+1[ICON_Food]+1[ICON_Culture]+1[ICON_Production][NEWLINE]首都+5[ICON_Gold]" },
    [32] = { name="丰收祝福",   icon="ICON_IMPROVEMENT_FARM",                 category="expansion", kind="longterm", rarity="gold",      stages={2},
             effect="下回合开始:所有城市市中心+3[ICON_Food]食物[NEWLINE]所有城市+2[ICON_Housing]住房[NEWLINE]包括未来建立的城市" },
    [33] = { name="财富自由",   icon="ICON_YIELD_GOLD_5",                     category="economy",   kind="oneshot",  rarity="silver",    stages={1,2,3},
             effect="下回合开始:获得金币(随阶段缩放:200/600/1200)" },
    [34] = { name="智慧之光",   icon="ICON_GREATWORK_WRITING_3",              category="science",   kind="longterm", rarity="gold",      stages={1,2},
             effect="下回合开始:所有城市+1[ICON_Science]+1[ICON_Culture][NEWLINE]进入中世纪后:所有城市+2[ICON_Science]+2[ICON_Culture]" },
    [35] = { name="快速扩张",   icon="ICON_DISTRICT_CAMPUS",                  category="expansion", kind="longterm", rarity="gold",      stages={1,2},
             effect="下回合开始:每座城市的第一个区域建造速度+900%[NEWLINE](相当于成本减少90%)[NEWLINE]第一个区域建造完成后效果失效" },
    [36] = { name="符文召唤",   icon="ICON_UNIT_SWORDSMAN",                   category="mechanic",  kind="mechanic", rarity="gold",      stages={1,2},
             effect="立即获得:2个符文战士(战斗力36,移动力3)[NEWLINE]符文战士可升级为剑士步兵[NEWLINE]无法通过正常途径生产" },
    [37] = { name="远程精通",   icon="ICON_UNIT_ARCHER",                      category="military",  kind="mechanic", rarity="gold",      stages={1,2},
             effect="立即获得:1个弓箭手[NEWLINE]远程单位建造速度+20%(全时代)[NEWLINE]远程单位在平坦地形开始回合时+1[ICON_Movement]移动力" },
    [38] = { name="塔玛丽之魂", icon="ICON_BUILDING_WALLS",                   category="military",  kind="mechanic", rarity="silver",    stages={1,2},
             effect="立即解锁:砌砖术科技[NEWLINE]首都获得:远古城墙[NEWLINE]所有城墙(远古/中世纪/文艺复兴)+1[ICON_Faith]信仰/回合" },
    [39] = { name="千里眼",     icon="ICON_UNIT_SCOUT",                       category="expansion", kind="mechanic", rarity="silver",    stages={1},
             effect="立即获得:1个侦察兵[NEWLINE]所有侦察兵+1[ICON_Movement]移动力[NEWLINE]侦察兵获得的经验+100%" },
    [40] = { name="治国之才",   icon="ICON_GOVERNOR_THE_EDUCATOR",            category="expansion", kind="longterm", rarity="gold",      stages={1,2},
             effect="立即获得:1个总督头衔[NEWLINE]有总督的城市+2[ICON_Production]生产力[NEWLINE]有总督的城市+2[ICON_Gold]金币" },
    [41] = { name="千政之心",   icon="ICON_GOVERNOR_THE_EDUCATOR",            category="expansion", kind="longterm", rarity="gold",      stages={1,2},
             effect="立即获得:1个总督头衔[NEWLINE]有总督城市按总督等级+1[ICON_Production]+1[ICON_Gold]+1[ICON_Science]/级[NEWLINE]3级时额外+3[ICON_Culture]文化" },
    [42] = { name="税收改革",   icon="ICON_YIELD_GOLD_5",                     category="economy",   kind="longterm", rarity="gold",      stages={2},
             effect="所有城市每1人口+1[ICON_Gold]金币/回合[NEWLINE]城市达到10人口后:每1人口+2[ICON_Gold]金币/回合" },
    [43] = { name="骑士精神",   icon="ICON_UNIT_KNIGHT",                      category="military",  kind="mechanic", rarity="gold",      stages={3},
             effect="立即获得:2个骑士[NEWLINE]重骑兵生产速度+10%（全时代）" },

    -- ===== 第四轮新符文(44-51) =====
    [44] = { name="海权霸主",   icon="ICON_DISTRICT_HARBOR",                  category="military",  kind="mechanic", rarity="gold",      stages={2,3},
             effect="下回合开始:全时代海军近战单位建造速度+25%[NEWLINE]立即获得1艘当前最强战舰(需沿海城市,否则折算金币)" },
    [45] = { name="本土壁垒",   icon="ICON_IMPROVEMENT_FORT",                 category="military",  kind="longterm", rarity="gold",      stages={1,2},
             effect="下回合开始:己方领土内单位+3[ICON_Strength]战斗力[NEWLINE]所有城市内外防御+10[NEWLINE]所有单位每回合额外+5治疗" },
    [46] = { name="百战精兵",   icon="ICON_DISTRICT_ENCAMPMENT",              category="military",  kind="longterm", rarity="gold",      stages={2},
             effect="下回合开始:本城训练的单位获得额外经验(更快晋升)[NEWLINE]所有单位经验获取+25%" },
    [47] = { name="荣耀史诗",   icon="ICON_GREATWORK_WRITING_4",              category="expansion", kind="longterm", rarity="prismatic", stages={1,2},
             effect="下回合开始:每建造1区域/每获得1伟人/每完成1条商路 +1[ICON_GLORY_SCORE]时代得分(推动黄金时代)" },
    [48] = { name="铁腕统治",   icon="ICON_GOVERNOR_THE_EDUCATOR",            category="military",  kind="mechanic", rarity="gold",      stages={2},
             effect="下回合开始:攻击敌方城市使其忠诚度-15(更易占领)[NEWLINE]选取时己方所有城市立即+25忠诚度" },
    [49] = { name="山河形胜",   icon="ICON_TERRAIN_MOUNTAIN",                 category="economy",   kind="longterm", rarity="prismatic", stages={1,2},
             effect="下回合开始:所有区域的相邻加成额外产出等量[ICON_Gold]金币[NEWLINE](科技/文化/信仰/生产相邻均镜像为金币)" },
    [50] = { name="灵光乍现",   icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="oneshot",  rarity="gold",      stages={1,2,3},
             effect="下回合开始:立即获得随机科技尤里卡与市政鼓舞(数量随阶段:2/4/6)" },
    [51] = { name="百废俱兴",   icon="ICON_GREATWORK_SCULPTURE_1",            category="economy",   kind="oneshot",  rarity="gold",      stages={1,2},
             effect="下回合开始:首都(及更多城市,随阶段)立即免费获得若干关键建筑" },

    -- ===== 白银机制符文扩展(52-58) =====
    [52] = { name="战誓银刃",   icon="ICON_UNIT_SWORDSMAN",                   category="military",  kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:特色单位+1[ICON_Strength]战斗力[NEWLINE]所有战斗单位在己方领土内+2[ICON_Strength]战斗力" },
    [53] = { name="凯旋铭记",   icon="ICON_GREATWORK_WRITING_4",              category="military",  kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:击杀单位时获得被击杀单位基础战斗力50%的[ICON_Gold]金币和30%的[ICON_Culture]文化" },
    [54] = { name="王权铭文",   icon="ICON_GOVERNOR_THE_EDUCATOR",            category="culture",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:有总督城市+1[ICON_Culture]文化[NEWLINE]有总督且满忠诚城市额外+1[ICON_Gold]金币" },
    [55] = { name="河谷工坊",   icon="ICON_DISTRICT_INDUSTRIAL_ZONE",         category="economy",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:邻河城市+1[ICON_Housing]住房[NEWLINE]邻河且有工业区或商业中心城市+1[ICON_Production]生产力" },
    [56] = { name="山寺钟声",   icon="ICON_RELIGION",                         category="religion",  kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:相邻山脉的圣地+1[ICON_Faith]信仰与+1[ICON_Science]科技[NEWLINE]拥有山脉圣地+学院组合城市时:+1大科学家点数/回合" },
    [57] = { name="什一商约",   icon="ICON_DISTRICT_COMMERCIAL_HUB",          category="economy",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:圣地+2[ICON_Gold]金币,每个圣地建筑+1[ICON_Gold]金币[NEWLINE]商业中心+1[ICON_Faith]信仰,每个商业中心建筑+1[ICON_Faith]信仰[NEWLINE]国内商路终点有圣地时每条+1[ICON_Gold]金币/回合" },
    [58] = { name="民兵史诗",   icon="ICON_BUILDING_WALLS",                   category="military",  kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:有纪念碑城市训练远程/抗骑兵单位+10%[NEWLINE]首次拥有远古城墙时获得1个远古-古典市政鼓舞" },

    -- ===== 白银机制符文第三批(59-64) =====
    [59] = { name="祖制回响",   icon="ICON_CIVILIZATION_UNKNOWN",             category="culture",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:拥有的特色区域、特色建筑与特色改良设施各+1[ICON_Culture]文化、+1[ICON_Gold]金币、+1[ICON_Production]生产力" },
    [60] = { name="学派银环",   icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:拥有的特色区域、特色建筑与特色改良设施各+1[ICON_Science]科技、+1[ICON_Gold]金币、+1[ICON_Production]生产力" },
    [61] = { name="测绘学院",   icon="ICON_UNIT_SCOUT",                       category="expansion", kind="mechanic", rarity="silver",    stages={1,2},
             effect="下回合开始:侦察类单位+1视野[NEWLINE]此后新建的邻山城市获得1个远古-古典科技尤里卡,最多触发2次" },
    [62] = { name="银缆商约",   icon="ICON_TRADEROUTE",                       category="economy",   kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:通往城邦的商路+1[ICON_Gold]金币与+1[ICON_Culture]文化[NEWLINE]通往宗主城邦的商路额外+1[ICON_Gold]金币" },
    [63] = { name="使馆银阶",   icon="ICON_ENVOY",                            category="mechanic",  kind="longterm", rarity="silver",    stages={1,2},
             effect="下回合开始:每类城邦首次达到3使者时永久解锁一项首都小型收益[NEWLINE]科技/文化/金币/信仰+2,军事单位或建筑生产+5%" },
    [64] = { name="林地书院",   icon="ICON_FEATURE_FOREST",                   category="science",   kind="mechanic", rarity="silver",    stages={1,2},
             effect="下回合开始:邻接森林或雨林的学院+1[ICON_Culture]文化,剧院广场+1[ICON_Science]科技[NEWLINE]此后新建伐木场获得10[ICON_Culture]文化,最多触发3次" },

    -- ===== 白银符文第四批(65-69) =====
    [65] = { name="公民沙龙",   icon="ICON_DISTRICT_ENTERTAINMENT_COMPLEX",   category="culture",   kind="longterm", rarity="silver",    stages={2,3},
             effect="快乐城市+5%[ICON_Science]科技与+5%[ICON_Culture]文化[NEWLINE]欣喜若狂城市改为+10%[ICON_Science]科技与+10%[ICON_Culture]文化" },
    [66] = { name="同盟银契",   icon="ICON_ENVOY",                            category="mechanic",  kind="longterm", rarity="silver",    stages={2,3},
             effect="拥有有效同盟时每回合+2[ICON_Favor]外交支持[NEWLINE]通往盟友城市的商路+2[ICON_Gold]金币、+1[ICON_Science]科技、+1[ICON_Culture]文化" },
    [67] = { name="工坊讲席",   icon="ICON_BUILDING_UNIVERSITY",              category="science",   kind="mechanic", rarity="silver",    stages={2,3},
             effect="首次拥有同时建有大学与工作坊的城市时,该城市永久+5[ICON_Science]科技、+5[ICON_Production]生产力、+3大科学家点数与+3大工程师点数/回合[NEWLINE]每名玩家至多触发1次,特色替代建筑有效" },
    [68] = { name="圣卷互证",   icon="ICON_GREATWORKOBJECT_WRITING",            category="religion",  kind="longterm", rarity="silver",    stages={2,3},
             effect="每件著作与遗物分别+2[ICON_Culture]文化、+2[ICON_Food]食物、+2[ICON_Production]生产力[NEWLINE]其他巨作类型不受影响" },
    [69] = { name="海外宪章",   icon="ICON_UNIT_SETTLER",                     category="expansion", kind="longterm", rarity="silver",    stages={2,3},
             effect="不在首都所在大陆的城市+5%[ICON_Production]生产力且每回合+2忠诚度" },

    -- ===== 黄金符文第五批(70-82) =====
    [70] = { name="内阁议会",   icon="ICON_GOVERNOR_THE_EDUCATOR",            category="expansion", kind="longterm", rarity="gold", stages={2,3},
             effect="非黑暗时代时,有总督城市每回合+4忠诚度、+4[ICON_Food]食物、+1[ICON_Amenities]宜居度[NEWLINE]并获得非奇观建筑+15%[ICON_Production]生产力" },
    [71] = { name="求知使团",   icon="ICON_ENVOY",                            category="mechanic",  kind="mechanic", rarity="gold", stages={2,3},
             effect="单个城邦首次达到6使者后,永久获得该城邦的特色宗主奖励[NEWLINE]无需成为宗主,与该城邦交战时仍然生效;不包含视野、征兵等宗主权限" },
    [72] = { name="生态廊道",   icon="ICON_DISTRICT_PRESERVE",                category="culture",   kind="longterm", rarity="gold", stages={1,2},
             effect="邻接保护区的未改良森林、雨林与沼泽+1[ICON_Science]科技、+1[ICON_Culture]文化" },
    [73] = { name="万国调停",   icon="ICON_ENVOY",                            category="mechanic",  kind="longterm", rarity="gold", stages={2,3},
             effect="与所有主要文明和平时,每回合+1影响力点、+1[ICON_Favor]外交支持[NEWLINE]与任一主要文明交战时失效" },
    [74] = { name="暗线议会",   icon="ICON_UNIT_SPY",                         category="mechanic",  kind="mechanic", rarity="gold", stages={2,3},
             effect="间谍建立据点所需时间-50%,间谍初始等级+1[NEWLINE]有总督城市防谍等级+1;取得符文时现有间谍也提升1级" },
    [75] = { name="行脚修会",   icon="ICON_UNIT_MISSIONARY",                  category="religion",  kind="longterm", rarity="gold", stages={1,2},
             effect="传教士+1传播次数;传教士与使徒在己方领土外+1[ICON_Movement]移动力[NEWLINE]圣地及其特色替代区域建造速度+100%" },
    [76] = { name="文化互访",   icon="ICON_TRADEROUTE",                       category="culture",   kind="longterm", rarity="gold", stages={2,3},
             effect="+2商路容量;国际商路+2[ICON_Culture]文化、+2[ICON_Gold]金币、+1[ICON_Production]生产力[NEWLINE]对存在己方商路的文明旅游业绩+25%" },
    [77] = { name="次级中心",   icon="ICON_DISTRICT_CITY_CENTER",              category="expansion", kind="longterm", rarity="gold", stages={1,2},
             effect="人口低于7且恰有1个专业区域的城市:区域生产+25%、人口成长+20%[NEWLINE]达到7人口或完成第二个专业区域后失效" },
    [78] = { name="土地改造",   icon="ICON_IMPROVEMENT_MINE",                 category="economy",   kind="longterm", rarity="gold", stages={1,2},
             effect="己方未被掠夺的矿山+3[ICON_Gold]金币、+1[ICON_Food]食物" },
    [79] = { name="幕后黑手",   icon="ICON_UNIT_SPY",                         category="mechanic",  kind="longterm", rarity="gold", stages={2,3}, conflictGroup="SPY_PRODUCTION_PENALTY",
             effect="间谍所有进攻与防守行动等级+4[NEWLINE]生产间谍时-60%[ICON_Production]生产力,基准生产耗时约为原来的2.5倍" },
    [80] = { name="竭泽而渔",   icon="ICON_YIELD_GOLD_5",                    category="economy",   kind="mechanic", rarity="gold", stages={1,2},
             effect="立即获得1000[ICON_Gold]金币、300[ICON_Faith]信仰[NEWLINE]从下一玩家回合起连续30回合,每回合扣除50[ICON_Gold]金币" },
    [81] = { name="焦土计划",   icon="ICON_UNITOPERATION_PILLAGE",             category="military",  kind="longterm", rarity="gold", stages={2,3},
             effect="改良设施与区域掠夺收益+100%[NEWLINE]掠夺矿山额外获得科技;掠夺采石场、种植园、牧场与营地额外获得文化[NEWLINE]所有单位维护费+2[ICON_Gold]金币" },
    [82] = { name="冲刺冲刺冲刺", icon="ICON_BUILDING_TERRACOTTA_ARMY",         category="military",  kind="mechanic", rarity="gold", stages={2,3},
             effect="生产非平民单位+5%[ICON_Production]生产力[NEWLINE]取得符文时,现有可晋升单位获得1个晋升等级;之后新造单位不获得免费晋升" },

    -- ===== 黄金符文第六批(83-92) =====
    [83] = { name="合成作战",   icon="ICON_UNIT_WARRIOR",                     category="military",  kind="longterm", rarity="gold", stages={1,2},
             effect="所有战斗单位的夹击与支援加成+100%" },
    [84] = { name="军械标准化", icon="ICON_DISTRICT_ENCAMPMENT",              category="military",  kind="longterm", rarity="gold", stages={1,2},
             effect="单位升级的[ICON_Gold]金币与战略资源消耗-25%[NEWLINE]军事单位生产+15%[ICON_Production]生产力,平民单位生产-5%[ICON_Production]生产力" },
    [85] = { name="全域监听",   icon="ICON_UNIT_SPY",                         category="mechanic",  kind="longterm", rarity="gold", stages={2,3}, conflictGroup="SPY_PRODUCTION_PENALTY",
             effect="对所有主要文明的外交可见度+1;每级可见度优势额外+1[ICON_Strength]战斗力[NEWLINE]仅在我方对该主要文明的可见度高于对方时显示战斗加成;城邦与蛮族没有外交可见度等级[NEWLINE]生产间谍时-67%[ICON_Production]生产力,基准生产耗时约为原来的3倍[NEWLINE]与【幕后黑手】互斥" },
    [86] = { name="实证革命",   icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="mechanic", rarity="gold", stages={1,2},
             effect="科技尤里卡与市政鼓舞的研究进度各提高10个百分点[NEWLINE]立即随机触发5项科技尤里卡与5项市政鼓舞" },
    [87] = { name="科研产业化", icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="longterm", rarity="gold", stages={2,3},
             effect="学院相邻加成同时提供等量[ICON_Production]生产力[NEWLINE]太空竞赛项目生产+15%;大学及其特色替代建筑+3[ICON_Production]生产力" },
    [88] = { name="国家策展",   icon="ICON_BUILDING_MUSEUM_ART",              category="culture",   kind="longterm", rarity="gold", stages={2,3},
             effect="拥有至少3个巨作槽位且已填满的非奇观建筑自动主题化[NEWLINE]已主题化巨作的产出与[ICON_Tourism]旅游业绩+50%" },
    [89] = { name="全球巡演",   icon="ICON_UNIT_ROCK_BAND",                   category="culture",   kind="longterm", rarity="gold", stages={2,3},
             effect="摇滚乐队可选择任意晋升,演唱会产生的[ICON_Tourism]旅游业绩+50%[NEWLINE]购买摇滚乐队的[ICON_Faith]信仰花费+50%" },
    [90] = { name="产业电网",   icon="ICON_DISTRICT_INDUSTRIAL_ZONE",         category="economy",   kind="longterm", rarity="gold", stages={2,3},
             effect="当前正常供电的建筑+2[ICON_Production]生产力、+2[ICON_Gold]金币" },
    [91] = { name="都会引擎",   icon="ICON_DISTRICT_CITY_CENTER",              category="expansion", kind="longterm", rarity="gold", stages={2,3},
             effect="拥有至少3个专业区域的城市:+15%[ICON_Production]生产力、+15%[ICON_Gold]金币、+1[ICON_Amenities]宜居度[NEWLINE]达到5个专业区域后再+10%[ICON_Science]科技与+10%[ICON_Culture]文化" },
    [92] = { name="制空权",     icon="ICON_UNIT_FIGHTER",                     category="military",  kind="longterm", rarity="gold", stages={2,3},
             effect="空军单位生产+25%[ICON_Production]生产力、+3[ICON_Strength]战斗力、+1作战半径" },

    -- ===== 白银符文第五批(93-101) =====
    [93] = { name="地籍清丈",   icon="ICON_UNIT_SETTLER",                     category="expansion", kind="longterm", rarity="silver", stages={1,2,3},
             effect="购买地块费用-15%[NEWLINE]取得后新建城市初始额外获得1个地块" },
    [94] = { name="田野勘察",   icon="ICON_IMPROVEMENT_QUARRY",               category="science",   kind="longterm", rarity="silver", stages={1,2,3},
             effect="己方未被掠夺的采石场与营地+1[ICON_Science]科技" },
    [95] = { name="同行评议",   icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="longterm", rarity="silver", stages={1,2,3},
             effect="学院研究拨款及学院特色替代区域对应的可重复科研项目+25%[ICON_Production]生产力" },
    [96] = { name="公民节庆",   icon="ICON_DISTRICT_ENTERTAINMENT_COMPLEX",   category="culture",   kind="longterm", rarity="silver", stages={1,2,3},
             effect="娱乐中心、水上乐园及特色替代区域建造速度+20%[NEWLINE]其中每座非奇观建筑+1[ICON_Culture]文化" },
    [97] = { name="奢品陈列",   icon="ICON_RESOURCE_SILK",                    category="culture",   kind="longterm", rarity="silver", stages={1,2,3},
             effect="已改良且未被掠夺的奢侈资源地块+1[ICON_Culture]文化、+1[ICON_Gold]金币" },
    [98] = { name="慈善教区",   icon="ICON_DISTRICT_HOLY_SITE",               category="religion",  kind="longterm", rarity="silver", stages={1,2,3},
             effect="每座圣地建筑及特色替代建筑+1[ICON_Food]食物[NEWLINE]寺庙及其替代建筑额外+1[ICON_Housing]住房" },
    [99] = { name="巡回讲坛",   icon="ICON_UNIT_MISSIONARY",                  category="religion",  kind="longterm", rarity="silver", stages={1,2,3},
             effect="已创立宗教的被动传播距离+2、传播压力+15%[NEWLINE]解锁印刷术后再增加15%传播压力;未创立宗教时保持休眠" },
    [100] = { name="外交先遣",  icon="ICON_ENVOY",                            category="mechanic",  kind="longterm", rarity="silver", stages={1,2,3},
              effect="向每个城邦派出的第一名使者视为两名[NEWLINE]不追溯取得前已派出的使者" },
    [101] = { name="公共竞标",  icon="ICON_DISTRICT_CITY_CENTER",             category="mechanic",  kind="longterm", rarity="silver", stages={1,2,3},
              effect="可重复区域项目+10%[ICON_Production]生产力[NEWLINE]不影响太空竞赛与核武器项目" },

    -- ===== 白银符文第六批(102-109) =====
    [102] = { name="博闻强识",  icon="ICON_DISTRICT_CAMPUS",                  category="science",   kind="longterm", rarity="silver", stages={1,2,3},
              effect="科技尤里卡与市政鼓舞提供的研究进度各增加5个百分点[NEWLINE]不会立即随机触发项目" },
    [103] = { name="丰收折算",  icon="ICON_GOVERNOR_THE_RESOURCE_MANAGER",    category="economy",   kind="longterm", rarity="silver", stages={1,2,3},
              effect="所有城市收割资源与移除地貌的产出+30%[NEWLINE]可与马格努斯的原生加成叠加" },
    [104] = { name="京畿迁入",  icon="ICON_DISTRICT_CITY_CENTER",             category="expansion", kind="oneshot",  rarity="silver", stages={1,2,3},
              effect="当前首都立即增加人口[NEWLINE]阶段1/2/3分别增加1/2/3人口" },
    [105] = { name="丰育新政",  icon="ICON_YIELD_FOOD_5",                    category="expansion", kind="longterm", rarity="silver", stages={1,2,3},
              effect="所有城市人口增长速度+10%[NEWLINE]不直接增加地块[ICON_Food]食物产出" },
    [106] = { name="畜贸行会",  icon="ICON_IMPROVEMENT_PASTURE",             category="economy",   kind="longterm", rarity="silver", stages={1,2,3},
              effect="牧场与营地+2[ICON_Gold]金币[NEWLINE]解锁重商主义后再+2[ICON_Gold]金币,总计+4" },
    [107] = { name="中央采办",  icon="ICON_DISTRICT_GOVERNMENT",              category="economy",   kind="longterm", rarity="silver", stages={1,2,3},
              effect="政府广场及其特色替代区域所在城市购买所有非奇观建筑费用-20%" },
    [108] = { name="牧界拓殖",  icon="ICON_IMPROVEMENT_PASTURE",             category="expansion", kind="longterm", rarity="silver", stages={1,2,3},
              effect="取得后新建的牧场触发文化炸弹[NEWLINE]已有牧场不追溯" },
    [109] = { name="星纹贡礼",  icon="ICON_RESOURCE_T2D_STARWEAVE_BROCADE",   category="economy",   kind="longterm", rarity="silver", stages={1,2,3},
              effect="获得1份独特奢侈品[ICON_RESOURCE_T2D_STARWEAVE_BROCADE]星纹锦缎[NEWLINE]为至多6座城市各提供+1[ICON_Amenities]宜居度" },

    -- ===== 黄金符文第七批(110-117) =====
    [110] = { name="帝国战史",  icon="ICON_GREATWORK_WRITING_4",              category="military",  kind="longterm", rarity="gold", stages={2,3},
              effect="击杀单位时,获得相当于其战斗力100%的[ICON_Gold]金币、60%的[ICON_Culture]文化值和30%的[ICON_Science]科技值" },
    [111] = { name="帝国地籍",  icon="ICON_UNIT_SETTLER",                     category="expansion", kind="longterm", rarity="gold", stages={1,2},
              effect="购买地块费用-30%[NEWLINE]取得后新建城市初始额外获得2格领土;城市边界扩张速度+20%" },
    [112] = { name="国土资源院", icon="ICON_IMPROVEMENT_QUARRY",              category="science",   kind="longterm", rarity="gold", stages={1,2,3},
              effect="己方未被掠夺的采石场与营地+2[ICON_Science]科技、+1[ICON_Production]生产力" },
    [113] = { name="万国奢博",  icon="ICON_RESOURCE_SILK",                    category="culture",   kind="longterm", rarity="gold", stages={2,3},
              effect="已改良且未被掠夺的奢侈资源地块+2[ICON_Culture]文化、+2[ICON_Gold]金币[NEWLINE]每种拥有的奢侈资源额外为2座城市提供宜居度" },
    [114] = { name="济世圣会",  icon="ICON_DISTRICT_HOLY_SITE",               category="religion",  kind="longterm", rarity="gold", stages={1,2},
              effect="圣地及特色替代区域中的每座建筑+2[ICON_Food]食物[NEWLINE]寺庙及其替代建筑额外+2[ICON_Housing]住房、+1[ICON_Amenities]宜居度" },
    [115] = { name="机械化采收", icon="ICON_GOVERNOR_THE_RESOURCE_MANAGER",   category="economy",   kind="longterm", rarity="gold", stages={1,2},
              effect="收割资源和移除地貌的产出+60%[NEWLINE]取得符文后获得的建造者+1建造次数;现有建造者不受影响" },
    [116] = { name="都城大迁徙", icon="ICON_DISTRICT_CITY_CENTER",             category="expansion", kind="oneshot",  rarity="gold", stages={1,2,3},
              effect="当前首都立即增加人口:阶段1/2/3分别+2/+4/+6[NEWLINE]首都永久+3[ICON_Housing]住房、+1[ICON_Amenities]宜居度" },
    [117] = { name="共同体条约", icon="ICON_ENVOY",                            category="mechanic",  kind="longterm", rarity="gold", stages={2,3},
              effect="存在有效同盟时每回合+4外交支持;所有有效同盟每回合额外+1同盟点数[NEWLINE]通往盟友的商路+2[ICON_Gold]金币、+1[ICON_Production]生产力" },

    -- ===== 棱彩符文第一批(118-126) =====
    [118] = { name="战争神话",   icon="ICON_GREATWORK_WRITING_4",             category="military",  kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="击杀单位时,获得相当于其基础战斗力100%的[ICON_Gold]金币、60%的[ICON_Culture]文化和30%的[ICON_Science]科技,并回复15生命值" },
    [119] = { name="无垠疆界",   icon="ICON_UNIT_SETTLER",                    category="expansion", kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="取得后新建城市初始额外获得3格领土,城市边界扩张速度+40%[NEWLINE]首都训练开拓者不消耗人口" },
    [120] = { name="知识奇点",   icon="ICON_DISTRICT_CAMPUS",                 category="science",   kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="科技尤里卡与市政鼓舞提供的研究进度各增加20个百分点[NEWLINE]取得时随机获得最多8个尤里卡和8个鼓舞" },
    [121] = { name="普世圣座",   icon="ICON_DISTRICT_HOLY_SITE",              category="religion",  kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="圣地及特色替代区域中的每座建筑+2[ICON_Food]食物、+2[ICON_Production]生产力[NEWLINE]寺庙及其替代建筑额外+2[ICON_Housing]住房、+1[ICON_Amenities]宜居度[NEWLINE]传教士、使徒和审判官+1传播次数" },
    [122] = { name="人类记忆宫", icon="ICON_BUILDING_MUSEUM_ART",             category="culture",   kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="所有巨作+2[ICON_Science]科技、+2[ICON_Gold]金币[NEWLINE]填满的非奇观、至少拥有3个巨作槽位的建筑自动主题化[NEWLINE]主题化建筑的产出与[ICON_Tourism]旅游业绩+100%" },
    [123] = { name="行政府矩阵", icon="ICON_GOVERNOR_THE_EDUCATOR",           category="expansion", kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="立即获得3个总督头衔[NEWLINE]有总督的城市按该总督每个已获得的头衔+2%[ICON_Science]科技、+2%[ICON_Culture]文化、+2%[ICON_Gold]金币、+2%[ICON_Production]生产力" },
    [124] = { name="命运共同体", icon="ICON_ENVOY",                           category="mechanic",  kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="存在任一有效同盟时每回合+6外交支持;每个同盟每回合额外+2同盟点数[NEWLINE]通往盟友的商路+3[ICON_Gold]金币、+2[ICON_Production]生产力、+1[ICON_Science]科技、+1[ICON_Culture]文化[NEWLINE]与盟友共享视野" },
    [125] = { name="无定宪章",   icon="ICON_GOVERNMENT_CLASSICAL_REPUBLIC",   category="mechanic",  kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="获得2个通用政策槽[NEWLINE]建成任意一级政府广场建筑后,解锁独裁政治、寡头政治与古典共和三张二级政体传承政策;已有任意一级政府广场建筑时立即解锁" },
    [126] = { name="万城柱石",   icon="ICON_DISTRICT_CITY_CENTER",            category="expansion", kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="仅取得后由你新建的城市,免费获得当前可用且生产成本最低的市中心建筑[NEWLINE]建造市中心建筑+100%[ICON_Production]生产力,每栋+1[ICON_Food]食物、+1[ICON_Production]生产力[NEWLINE]解锁启蒙运动后每栋再+1[ICON_Food]食物、+1[ICON_Production]生产力、+2[ICON_Gold]金币、+1[ICON_Housing]住房（总计+2[ICON_Food]食物、+2[ICON_Production]生产力、+2[ICON_Gold]金币、+1[ICON_Housing]住房）" },

    -- ===== 棱彩符文第二批(127-141) =====
    [127] = { name="战略军团制", icon="ICON_UNIT_SWORDSMAN",                   category="military",  kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="解锁雇佣兵后可组建陆军军团,重商主义后可组建舰队,民族主义后可组建集团军与无敌舰队[NEWLINE]直接生产这些编制单位所需[ICON_Production]生产力-25%,军团、集团军、舰队和无敌舰队+3战斗力" },
    [128] = { name="不间断指挥", icon="ICON_UNITOPERATION_MOVE_TO",             category="military",  kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="所有单位+1移动力[NEWLINE]晋升不会结束单位回合,并保留剩余移动力" },
    [129] = { name="群星议院",   icon="ICON_GREAT_PERSON",                     category="mechanic",  kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="使用[ICON_Gold]金币或[ICON_Faith]信仰赞助伟人的费用-40%[NEWLINE]招募伟人后返还该类别所需伟人点数的30%[NEWLINE]大科学家和大工程师+1使用次数" },
    [130] = { name="信仰即资本", icon="ICON_FAITH",                            category="religion",  kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="所有非奇观专业区域建筑及其特色替代建筑均可用[ICON_Faith]信仰购买" },
    [131] = { name="城邦联邦",   icon="ICON_ENVOY",                            category="mechanic",  kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="征兵费用-50%,每次成功征兵获得1名使者[NEWLINE]征召单位升级[ICON_Gold]金币-50%且不消耗战略资源[NEWLINE]每回合+3影响力;取得时及之后每个全球时代开始获得2名使者" },
    [132] = { name="超额区划",   icon="ICON_DISTRICT_CITY_CENTER",             category="expansion", kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="所有城市专业区域容量+1[NEWLINE]人口达到10后再+1" },
    [133] = { name="帝国动脉",   icon="ICON_UNIT_TRADER",                      category="expansion", kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="商人在己方城市三格范围内经过无主地块时将其纳入领土[NEWLINE]商路铺设的道路提高一个等级" },
    [134] = { name="山岳都市",   icon="ICON_TERRAIN_GRASS_MOUNTAIN",           category="science",   kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="己方山脉可被城市工作,并提供+2[ICON_Production]生产力、+2[ICON_Science]科技[NEWLINE]山脉仍不可通行、不可改良" },
    [135] = { name="万工会典",   icon="ICON_UNIT_BUILDER",                     category="expansion", kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="当前及之后获得的建造者+2建造次数[NEWLINE]消耗一次次数可推进区域20%生产进度,或推进远古、古典奇观15%生产进度" },
    [136] = { name="百家圣约",   icon="ICON_RELIGION",                         category="religion",  kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="获得城市中所有宗教的追随者信条效果[NEWLINE]使徒可以从全部晋升中选择;宗教单位+8宗教战斗力[NEWLINE]审判官可移除100%其他宗教压力" },
    [137] = { name="战略自由",   icon="ICON_RESOURCE_IRON",                    category="military",  kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="训练和升级单位不需要战略资源,单位每回合也不消耗战略资源[NEWLINE][ICON_Gold]金币和[ICON_Production]生产力费用不变" },
    [138] = { name="万军教范",   icon="ICON_UNIT_SCOUT",                       category="military",  kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="所有单位+1视野、获得经验+100%;驻扎时+3战斗力[NEWLINE]当前及之后获得的侦察单位获得一个初始晋升等级" },
    [139] = { name="山岳营造法", icon="ICON_DISTRICT_CAMPUS",                  category="economy",   kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="建造邻接山脉的区域及其中非奇观建筑时+100%[ICON_Production]生产力[NEWLINE]学院、工业区、剧院广场额外获得一次性+2对应产出[NEWLINE]商业区从每格相邻山脉获得+2[ICON_Gold]金币相邻加成" },
    [140] = { name="圣堂军制",   icon="ICON_DISTRICT_HOLY_SITE",               category="religion",  kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="建造普通圣地+60%[ICON_Production]生产力,所有圣地建筑+100%[ICON_Production]生产力[NEWLINE]已有或建成首座圣地时获得15点大预言家点数[NEWLINE]神社、寺庙、祭祀建筑分别使新训练军事单位获得+1移动力、+3战斗力、+50%经验[NEWLINE]圣地及建筑维护费获得等额[ICON_Gold]金币补偿" },
    [141] = { name="天下归枢",   icon="ICON_CITY_CAPITAL",                     category="economy",   kind="longterm", rarity="prismatic", stages={1,2,3},
              effect="帝国内每座城市使首都获得+2[ICON_Production]生产力、+2[ICON_Gold]金币、+2[ICON_Faith]信仰[NEWLINE]解锁政治哲学后每城再+1[ICON_Science]科技、+1[ICON_Culture]文化、+1[ICON_Housing]住房[NEWLINE]解锁君主制、神权政体或商业共和国任一后每城再+2[ICON_Production]生产力、+2[ICON_Gold]金币、+2[ICON_Faith]信仰[NEWLINE]解锁民族主义后每城再+2[ICON_Science]科技、+2[ICON_Culture]文化" },

    -- ===== 随机质变与使者符文(142-145) =====
    [142] = { name="质变：黄金", icon="ICON_GREAT_PERSON",                     category="mechanic",  kind="mechanic", rarity="silver",    stages={1,2,3},
              effect="随机获得1枚当前阶段可用、尚未拥有且不冲突的黄金品质符文[NEWLINE]随机结果会保存，不会因读取或重试而改变" },
    [143] = { name="质变：棱彩", icon="ICON_GREAT_PERSON",                     category="mechanic",  kind="mechanic", rarity="gold",      stages={1,2,3},
              effect="随机获得1枚当前阶段可用、尚未拥有且不冲突的棱彩品质符文[NEWLINE]随机结果会保存，不会因读取或重试而改变" },
    [144] = { name="一使定邦",   icon="ICON_ENVOY",                            category="mechanic",  kind="mechanic", rarity="prismatic", stages={1,2,3},
              effect="取得后首次主动向城邦派遣使者时，该次派遣总计按20名使者结算[NEWLINE]首次相遇、完成城邦任务及其他自动来源不会触发" },
    [145] = { name="使节贡赋",   icon="ICON_ENVOY",                            category="economy",   kind="longterm", rarity="gold",      stages={1,2,3},
              effect="每名已派驻城邦的使者提供+2[ICON_Gold]金币、+1[ICON_Faith]信仰[NEWLINE]每回合+3影响力" },
};

-- 选择页使用原版“科技/市政完成”弹窗的引语框展示一句简短描述。
-- 现有符文无需重复维护另一套长文本：未显式填写 summary 时，按玩法
-- 分类生成稳定、简短的风味句；未来符文可直接在注册项中覆盖该字段。
local T2D_SUMMARY_TEMPLATES = {
    military  = "以「%s」整合军队、纪律与战场经验。",
    science   = "让「%s」把求知转化为文明前进的动力。",
    culture   = "让「%s」塑造共同记忆与文化认同。",
    economy   = "以「%s」打通资源、生产与财富的循环。",
    expansion = "借「%s」拓展疆域，并夯实城市根基。",
    religion  = "让「%s」凝聚信仰，并将其传播至远方。",
    mechanic  = "「%s」将改写文明运行的既有规则。",
};

for _, rune in pairs(T2D_Runes) do
    if rune.summary == nil or rune.summary == "" then
        local template = T2D_SUMMARY_TEMPLATES[rune.category]
            or "以「%s」开启文明新的发展方向。";
        rune.summary = string.format(template, tostring(rune.name or "符文"));
    end
end

-- 部分旧图标键只存在于富文本、特定面板或非通用尺寸图集中，直接用于
-- Image:SetIcon/FindIconAtlas 会得到空白。统一替换为已验证可用于通用 UI
-- 图集的语义相近图标，使选择页、图鉴和时代面板共享同一套有效图标。
local T2D_ICON_ALIASES = {
    ICON_UNITOPERATION_MAKE_FORTIFICATION = "ICON_IMPROVEMENT_FORT",
    ICON_RESOURCECLASS_STRATEGIC          = "ICON_RESOURCE_IRON",
    ICON_GOVERNOR_THE_FOUNDER             = "ICON_UNIT_SETTLER",
    ICON_GREATWORK_WRITING_4              = "ICON_DISTRICT_THEATER",
    ICON_GREATPERSON_CLASS_APOSTLE        = "ICON_UNIT_MISSIONARY",
    ICON_TRADEROUTE                       = "ICON_UNIT_TRADER",
    ICON_GREATWORK_WRITING_3              = "ICON_DISTRICT_CAMPUS",
    ICON_YIELD_GOLD_5                     = "ICON_DISTRICT_COMMERCIAL_HUB",
    ICON_TERRAIN_MOUNTAIN                 = "ICON_TERRAIN_GRASS_MOUNTAIN",
    ICON_GREATWORK_SCULPTURE_1            = "ICON_BUILDING_MUSEUM_ART",
    ICON_GREATWORKOBJECT_WRITING          = "ICON_DISTRICT_THEATER",
    ICON_YIELD_FOOD_5                     = "ICON_IMPROVEMENT_FARM",
    ICON_ENVOY                            = "ICON_DISTRICT_GOVERNMENT",
    ICON_FAITH                            = "ICON_DISTRICT_HOLY_SITE",
    ICON_CITY_CAPITAL                     = "ICON_DISTRICT_CITY_CENTER",
};

for _, rune in pairs(T2D_Runes) do
    rune.icon = T2D_ICON_ALIASES[rune.icon] or rune.icon;
end

-- Every published rune has a generated Turn2Dedication icon.  The numeric key
-- is deliberately stable and matches atlas index (rune ID - 1), so all UI
-- surfaces use the same artwork without relying on base-game icon availability.
for runeID, rune in pairs(T2D_Runes) do
    rune.icon = string.format("ICON_T2D_RUNE_%03d", runeID);
end

-- ===========================================================================
-- 访问器
-- ===========================================================================

-- 取符文元数据；不存在则返回 nil
function T2D_GetRune(runeID)
    return T2D_Runes[runeID];
end

-- 取符文稀有度（默认 silver，便于旧消息/异常兜底）
function T2D_GetRarity(runeID)
    local r = T2D_Runes[runeID];
    return (r and r.rarity) or "silver";
end

-- 取互斥组；旧符文没有该字段时返回 nil。
function T2D_GetConflictGroup(runeID)
    local r = T2D_Runes[runeID];
    return r and r.conflictGroup or nil;
end

-- 两枚不同符文是否属于同一互斥组。
function T2D_RunesConflict(firstRuneID, secondRuneID)
    if firstRuneID == nil or secondRuneID == nil or firstRuneID == secondRuneID then return false; end
    local firstGroup = T2D_GetConflictGroup(firstRuneID);
    return firstGroup ~= nil and firstGroup == T2D_GetConflictGroup(secondRuneID);
end

-- 汇总 UI 可见的正常阶段、质变奖励、兼容 ActiveRune 与开发者拥有记录。
function T2D_GetPlayerOwnedRuneSet(playerID)
    local owned = {};
    if playerID == nil or playerID < 0 or not Game or not Game.GetProperty then return owned; end

    for stage = 1, 3 do
        local raw = Game.GetProperty("Turn2Dedication_Stage" .. stage .. "_P" .. playerID);
        local runeID = raw ~= nil and tonumber(raw) or nil;
        if runeID and T2D_Runes[runeID] then owned[runeID] = true; end
    end

    local rawActive = Game.GetProperty("Turn2Dedication_ActiveRune_P" .. playerID);
    local activeID = rawActive ~= nil and tonumber(rawActive) or nil;
    if activeID and T2D_Runes[activeID] then owned[activeID] = true; end

    for runeID, _ in pairs(T2D_Runes) do
        if Game.GetProperty("Turn2Dedication_BonusRune_P" .. playerID .. "_R" .. runeID) ~= nil then
            owned[runeID] = true;
        end
        if Game.GetProperty("Turn2Dedication_DevRune_P" .. playerID .. "_R" .. runeID) ~= nil then
            owned[runeID] = true;
        end
    end
    return owned;
end

-- 返回与目标符文冲突的已拥有符文 ID；没有冲突时返回 nil。
function T2D_FindOwnedConflict(playerID, runeID)
    for ownedRuneID, _ in pairs(T2D_GetPlayerOwnedRuneSet(playerID)) do
        if T2D_RunesConflict(runeID, ownedRuneID) then return ownedRuneID; end
    end
    return nil;
end

-- 取某稀有度在某阶段的金币预算
function T2D_GetBudget(rarity, stage)
    local row = T2D_BUDGET[rarity] or T2D_BUDGET.silver;
    return row[stage] or row[#row];
end

-- 取在指定阶段可出现的符文ID列表（抽卡分池由此派生，取代硬编码 POOL_PRESETS）
function T2D_GetStagePool(stage)
    local pool = {};
    for id, data in pairs(T2D_Runes) do
        for _, s in ipairs(data.stages) do
            if s == stage then
                table.insert(pool, id);
                break
            end
        end
    end
    table.sort(pool);
    return pool;
end

-- 取某模式(1精简/2完整/3全符文)在某阶段的可抽符文池 = 阶段可出现符文 ∩ 模式白名单
function T2D_GetPool(mode, stage)
    local eligible = T2D_GetStagePool(stage);
    local wl = T2D_POOL_WHITELIST[mode];
    if not wl then
        return eligible;  -- 模式3 或未知模式：该阶段全部
    end
    local allow = {};
    for _, id in ipairs(wl) do allow[id] = true; end
    local out = {};
    for _, id in ipairs(eligible) do
        if allow[id] then table.insert(out, id); end
    end
    return out;
end

print("Turn2Dedication: RuneRegistry 已加载，符文数=" .. tostring(#T2D_Runes > 0 and "ok" or "0"));
