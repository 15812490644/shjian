-- ===========================================================================

-- 过滤端口范围 655000-999999 的技术数据传输消息

-- ===========================================================================

include("ChatPanel");  -- 加载原版 ChatPanel

print("════════════════════════════════════════════════════════");
print("Turn2Dedication: Chat Filter Loading...");
print("════════════════════════════════════════════════════════");

local BASE_OnChat = OnChat;

-- 重写 OnChat 函数
function OnChat(fromPlayer, toPlayer, text, eTargetType, playSounds)
    if toPlayer >= 655000 and toPlayer <= 999999 then
        return;
    end
    
    if BASE_OnChat then
        BASE_OnChat(fromPlayer, toPlayer, text, eTargetType, playSounds);
    end
end

print("Turn2Dedication: Chat Filter Active");
print("  ✓ Filtering ports: 655000-999999");
print("  ✓ Compatible with Data Sync API standard");
print("════════════════════════════════════════════════════════");

