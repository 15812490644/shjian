-- Rune 144 UI bridge.
-- Gameplay owns all state and grants one reserve envoy per step. The local
-- player's UI is the only supported context for requesting GIVE_INFLUENCE_TOKEN,
-- so this listener immediately routes that envoy to the original city-state.

local POLL_INTERVAL = 0.20;
local RETRY_INTERVAL = 5.00;
local AUTH_PORT = 655013;
local m_pollElapsed = 0;
local m_requestElapsed = RETRY_INTERVAL;
local m_lastPlayerID = -1;
local m_currentStep = 0;
local m_lastAuthorizationStep = 0;
local m_lastRequestedStep = 0;
local m_tokensBeforeRequest = nil;

local function GetNumberProperty(key, defaultValue)
    local raw = Game.GetProperty(key);
    if raw == nil then return defaultValue; end
    local value = tonumber(raw);
    return value ~= nil and value or defaultValue;
end

local function PropertyKey(playerID, suffix)
    return "Turn2Dedication_Prismatic144_" .. suffix .. "_P" .. tostring(playerID);
end

local function ResetRequestState(playerID, step)
    m_lastPlayerID = playerID or -1;
    m_currentStep = step or 0;
    m_lastAuthorizationStep = 0;
    m_lastRequestedStep = 0;
    m_requestElapsed = RETRY_INTERVAL;
    m_tokensBeforeRequest = nil;
end

local function TrySendPendingEnvoy()
    local playerID = Game.GetLocalPlayer();
    if playerID == nil or playerID < 0 then return; end
    local pPlayer = Players[playerID];
    if not pPlayer or not pPlayer:IsTurnActive() then return; end

    local step = GetNumberProperty(PropertyKey(playerID, "AwaitingStep"), 0);
    local remaining = GetNumberProperty(PropertyKey(playerID, "Remaining"), 0);
    local targetMinorID = GetNumberProperty(PropertyKey(playerID, "TargetMinor"), -1);
    if step <= 0 or remaining <= 0 or targetMinorID < 0
        or Game.GetProperty(PropertyKey(playerID, "Complete")) ~= nil then
        if m_lastPlayerID ~= playerID or m_currentStep ~= 0 then
            ResetRequestState(playerID, 0);
        end
        return;
    end

    if m_lastPlayerID ~= playerID or m_currentStep ~= step then
        ResetRequestState(playerID, step);
    end

    local authorizedStep = GetNumberProperty(PropertyKey(playerID, "AuthorizedStep"), 0);
    if authorizedStep ~= step then
        if m_lastAuthorizationStep ~= step or m_requestElapsed >= RETRY_INTERVAL then
            if Network and Network.SendChat then
                local message = string.format("[T2D_ENVOY144]%d:%d:%d",
                    playerID, targetMinorID, step);
                Network.SendChat(message, ChatTargetTypes.CHATTARGET_ALL, AUTH_PORT);
                m_lastAuthorizationStep = step;
                m_requestElapsed = 0;
            end
        end
        return;
    end
    if m_lastRequestedStep == step and m_requestElapsed < RETRY_INTERVAL then
        return;
    end

    local pMinor = Players[targetMinorID];
    if not pMinor then return; end
    local pInfluence = pPlayer:GetInfluence();
    local pMinorInfluence = pMinor:GetInfluence();
    if not pInfluence or not pMinorInfluence then return; end
    if pInfluence:GetTokensToGive() < 1 then return; end
    if pInfluence.CanGiveInfluence and not pInfluence:CanGiveInfluence() then return; end
    if pInfluence.CanGiveTokensToPlayer
        and not pInfluence:CanGiveTokensToPlayer(targetMinorID) then return; end
    if pMinorInfluence.CanReceiveInfluence
        and not pMinorInfluence:CanReceiveInfluence() then return; end

    -- If the assignment already reached gamecore but the host Property update
    -- is merely delayed, never submit a duplicate operation on timeout.
    local currentAssigned = pMinorInfluence:GetTokensReceived(playerID);
    if m_lastRequestedStep == step and m_tokensBeforeRequest ~= nil
        and currentAssigned > m_tokensBeforeRequest then
        return;
    end

    local parameters = {};
    parameters[PlayerOperations.PARAM_PLAYER_ONE] = targetMinorID;
    local okRequest, requestError = pcall(function()
        UI.RequestPlayerOperation(playerID, PlayerOperations.GIVE_INFLUENCE_TOKEN, parameters);
    end);
    if not okRequest then
        print("Turn2EnvoyTopUpListener: 补派请求失败，稍后重试: " .. tostring(requestError));
        return;
    end

    m_lastPlayerID = playerID;
    m_lastRequestedStep = step;
    m_tokensBeforeRequest = currentAssigned;
    m_requestElapsed = 0;
    print("Turn2EnvoyTopUpListener: 一使定邦补派步骤 " .. tostring(step)
        .. " → 城邦 " .. tostring(targetMinorID));
end

local function OnUpdate(deltaTime)
    m_pollElapsed = m_pollElapsed + (deltaTime or 0);
    m_requestElapsed = m_requestElapsed + (deltaTime or 0);
    if m_pollElapsed < POLL_INTERVAL then return; end
    m_pollElapsed = 0;
    TrySendPendingEnvoy();
end

local function OnLocalPlayerChanged()
    ResetRequestState(Game.GetLocalPlayer(), 0);
    TrySendPendingEnvoy();
end

if ContextPtr and ContextPtr.SetUpdate then
    ContextPtr:SetUpdate(OnUpdate);
end
if Events then
    if Events.InfluenceChanged then Events.InfluenceChanged.Add(TrySendPendingEnvoy); end
    if Events.InfluenceGiven then Events.InfluenceGiven.Add(TrySendPendingEnvoy); end
    if Events.GameCoreEventPublishComplete then
        Events.GameCoreEventPublishComplete.Add(TrySendPendingEnvoy);
    end
    if Events.LocalPlayerTurnBegin then Events.LocalPlayerTurnBegin.Add(OnLocalPlayerChanged); end
    if Events.LocalPlayerChanged then Events.LocalPlayerChanged.Add(OnLocalPlayerChanged); end
end

print("Turn2EnvoyTopUpListener: 已加载一使定邦补派桥接（授权端口655013）");
