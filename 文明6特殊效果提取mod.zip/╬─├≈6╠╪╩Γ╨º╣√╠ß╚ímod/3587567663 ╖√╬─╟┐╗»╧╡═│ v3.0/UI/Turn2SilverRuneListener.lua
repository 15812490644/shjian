-- Third-batch silver rune UI events that are not exposed to Gameplay scripts.

local PORT_WOODLAND_LUMBER = 655012;

local function PlayerHasRune(playerID, runeID)
    if Game.GetProperty("Turn2Dedication_DevRune_P" .. playerID .. "_R" .. runeID) ~= nil then
        return true;
    end
    for stage = 1, 10 do
        if Game.GetProperty("Turn2Dedication_Stage" .. stage .. "_P" .. playerID) == runeID then
            return true;
        end
    end
    return false;
end

local function OnImprovementAddedToMap(x, y, improvementType, ownerID)
    local localPlayerID = Game.GetLocalPlayer();
    if localPlayerID < 0 or ownerID ~= localPlayerID or not PlayerHasRune(localPlayerID, 64) then
        return;
    end

    local lumberMill = GameInfo.Improvements["IMPROVEMENT_LUMBER_MILL"];
    if not lumberMill or improvementType ~= lumberMill.Index then return; end
    local plotIndex = Map.GetPlotIndex(x, y);
    if plotIndex == nil then return; end

    if Network and Network.SendChat then
        local message = string.format("[T2D_LUMBER]%d:%d", localPlayerID, plotIndex);
        Network.SendChat(message, ChatTargetTypes.CHATTARGET_ALL, PORT_WOODLAND_LUMBER);
        print("Turn2SilverRuneListener: 林地书院伐木场事件 → " .. message);
    else
        print("Turn2SilverRuneListener: Network.SendChat 不可用，等待回合扫描兜底");
    end
end

if Events and Events.ImprovementAddedToMap then
    Events.ImprovementAddedToMap.Add(OnImprovementAddedToMap);
    print("Turn2SilverRuneListener: 已注册伐木场建成监听（端口655012）");
end
