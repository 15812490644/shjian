-- ===========================================================================
-- 符文强化系统 - EraProgressPanel 替换脚本
-- 在原版时代进度面板的"此时代启用的效果"下方追加符文效果描述
-- ===========================================================================

include("EraProgressPanel");  -- 加载原版 EraProgressPanel
include("Turn2Dedication_RuneRegistry");  -- 单一数据源（符文显示数据唯一来源）

print("Turn2Dedication: EraProgressPanel 替换脚本加载中...");

-- ===========================================================================
-- 保存原版 Refresh 函数引用
-- ===========================================================================
local BASE_Refresh = Refresh;


local STAGE_NAMES = { "第1阶段", "第2阶段", "第3阶段", "第4阶段", "第5阶段" };

local function GetNumberGameProperty(propertyKey, defaultValue)
    local rawValue = Game.GetProperty(propertyKey);
    if rawValue == nil then return defaultValue; end
    local numberValue = tonumber(rawValue);
    if numberValue == nil then return defaultValue; end
    return numberValue;
end

local function GetGold80DebtStatus(localPlayerID)
    local remaining = GetNumberGameProperty(
        "Turn2Dedication_Gold80_Remaining_P" .. localPlayerID, nil);
    if remaining == nil then return ""; end
    if remaining > 0 then
        return "[NEWLINE]当前债务：每回合-50[ICON_Gold]金币，剩余"
            .. tostring(remaining) .. "回合";
    end
    return "[NEWLINE]当前债务：已偿清";
end

local function AppendRuneText(parts, displayedRunes, runeID, sourceName, localPlayerID)
    runeID = tonumber(runeID);
    if not runeID or displayedRunes[runeID] then return; end
    displayedRunes[runeID] = true;

    local runeInfo = T2D_GetRune(runeID);
    if not runeInfo then
        table.insert(parts, "[NEWLINE][NEWLINE][ICON_BULLET] [" .. sourceName
            .. "] 未知符文（ID:" .. tostring(runeID) .. "）");
        return;
    end

    local rarityName = (T2D_RARITY_NAME and T2D_RARITY_NAME[runeInfo.rarity]) or "";
    local rarityText = rarityName ~= "" and ("（" .. rarityName .. "）") or "";
    local statusText = runeID == 80 and GetGold80DebtStatus(localPlayerID) or "";
    table.insert(parts, "[NEWLINE][NEWLINE][ICON_BULLET] [" .. sourceName .. "] "
        .. runeInfo.name .. rarityText .. "[NEWLINE]" .. runeInfo.effect .. statusText);
end

-- ===========================================================================
-- 获取已选符文效果文本
-- ===========================================================================
function GetRuneEffectsText()
    local localPlayerID = Game.GetLocalPlayer();
    if localPlayerID < 0 then
        return "";
    end

    local parts = {};
    local displayedRunes = {};

    -- 正式阶段始终优先显示，并作为同一符文多来源时的展示归属。
    for stage = 1, 10 do
        local stageKey = "Turn2Dedication_Stage" .. stage .. "_P" .. localPlayerID;
        local runeID = GetNumberGameProperty(stageKey, nil);
        local stageName = STAGE_NAMES[stage] or ("第" .. stage .. "阶段");
        AppendRuneText(parts, displayedRunes, runeID, stageName, localPlayerID);
    end

    -- 质变奖励与图鉴测试都使用独立 Property；按 ID 排序，确保每次打开顺序稳定。
    local developerRuneIDs = {};
    for runeID, _ in pairs(T2D_Runes or {}) do
        table.insert(developerRuneIDs, runeID);
    end
    table.sort(developerRuneIDs);
    for _, runeID in ipairs(developerRuneIDs) do
        local bonusKey = "Turn2Dedication_BonusRune_P" .. localPlayerID .. "_R" .. runeID;
        if Game.GetProperty(bonusKey) ~= nil then
            AppendRuneText(parts, displayedRunes, runeID, "质变奖励", localPlayerID);
        end
    end
    for _, runeID in ipairs(developerRuneIDs) do
        local developerKey = "Turn2Dedication_DevRune_P" .. localPlayerID .. "_R" .. runeID;
        if Game.GetProperty(developerKey) ~= nil then
            AppendRuneText(parts, displayedRunes, runeID, "图鉴测试", localPlayerID);
        end
    end

    -- 旧存档可能只有 ActiveRune，没有阶段 Property；仅在尚未显示时兜底。
    local activeRuneID = GetNumberGameProperty(
        "Turn2Dedication_ActiveRune_P" .. localPlayerID, nil);
    AppendRuneText(parts, displayedRunes, activeRuneID, "旧存档", localPlayerID);

    return table.concat(parts);
end

-- ===========================================================================
-- 重写 Refresh：调用原版后追加符文效果
-- ===========================================================================
function Refresh()
    -- 调用原版 Refresh（设置所有原版UI内容，包括 Controls.EraEffects）
    BASE_Refresh();

    -- 获取符文效果文本
    local runeText = GetRuneEffectsText();
    if runeText ~= "" then
        -- 读取原版已设置的时代效果文本，追加符文内容
        local currentText = Controls.EraEffects:GetText();
        if currentText then
            Controls.EraEffects:SetText(currentText .. runeText);
        else
            Controls.EraEffects:SetText(runeText);
        end
    end
end

-- Open() 本身会调用 Refresh；再监听打开事件可覆盖同帧刚同步完成的 Property。
local function OnTurn2DedicationEraPanelOpen()
    Refresh();
end

local function OnTurn2DedicationLocalPlayerTurnBegin()
    if ContextPtr and not ContextPtr:IsHidden() then
        Refresh();
    end
end

if LuaEvents and LuaEvents.EraProgressPanel_Open then
    LuaEvents.EraProgressPanel_Open.Add(OnTurn2DedicationEraPanelOpen);
end
if Events and Events.LocalPlayerTurnBegin then
    Events.LocalPlayerTurnBegin.Add(OnTurn2DedicationLocalPlayerTurnBegin);
end

print("Turn2Dedication: EraProgressPanel 替换脚本已就绪");
print("  ✓ 正式、图鉴测试及旧存档符文将显示在时代进度面板底部");
