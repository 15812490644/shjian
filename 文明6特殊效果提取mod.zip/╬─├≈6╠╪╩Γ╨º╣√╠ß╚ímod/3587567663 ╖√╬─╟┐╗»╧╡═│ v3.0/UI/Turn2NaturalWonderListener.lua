-- ===========================================================================
-- 自然奇观发现监听器（UI Context）
-- 用于探索先锋符文
-- ===========================================================================

print("Turn2NaturalWonderListener: 初始化中...");

-- 端口定义（Data Sync API标准）
local PORT_NATURAL_WONDER = 655003;  -- 自然奇观发现事件端口

-- ===========================================================================
-- 自然奇观发现事件处理
-- ===========================================================================
function OnNaturalWonderRevealed(plotx:number, ploty:number, eFeature:number, isFirstToFind:boolean)
    print("╔════════════════════════════════════════════════════════");
    print("║ UI: 自然奇观发现事件触发");
    print("╚════════════════════════════════════════════════════════");
    print("  坐标: (" .. plotx .. ", " .. ploty .. ")");
    print("  奇观ID: " .. tostring(eFeature));
    print("  首次发现: " .. tostring(isFirstToFind));
    
    -- 获取本地玩家ID
    local localPlayerID = Game.GetLocalPlayer();
    if localPlayerID < 0 then
        print("  ⓘ 自动游玩模式，跳过");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    print("  本地玩家ID: " .. localPlayerID);
    
    -- 获取奇观名称
    local featureInfo = GameInfo.Features[eFeature];
    if featureInfo then
        print("  奇观名称: " .. (featureInfo.Name or "未知"));
    end
    
    -- 检查玩家是否在【任意阶段】选择了探索先锋符文（20）
    -- 修复：原先只查 Stage1（且依赖从未初始化的 ExposedMembers），导致第2/3阶段选取失效。
    local hasExploration = Game.GetProperty("Turn2Dedication_DevRune_P" .. localPlayerID .. "_R20") ~= nil
        or Game.GetProperty("Turn2Dedication_BonusRune_P" .. localPlayerID .. "_R20") ~= nil;
    for stage = 1, 10 do
        local c = Game.GetProperty("Turn2Dedication_Stage" .. stage .. "_P" .. localPlayerID);
        if c == 20 then
            hasExploration = true;
            break;
        end
    end

    if not hasExploration then
        print("  ⓘ 玩家未在任何阶段选择探索先锋符文，跳过");
        print("════════════════════════════════════════════════════════╝");
        return;
    end

    print("  ✓ 玩家选择了探索先锋符文！");
    
    -- 构造广播消息：[T2D_WONDER_NATURE]玩家ID:奇观ID
    local message = "[T2D_WONDER_NATURE]" .. localPlayerID .. ":" .. eFeature;
    
    print("  ► 广播消息: " .. message);
    print("  ► 端口: " .. PORT_NATURAL_WONDER);
    
    -- 通过隐藏聊天广播（所有客户端都能收到）
    if Network and Network.SendChat then
        Network.SendChat(message, ChatTargetTypes.CHATTARGET_ALL, PORT_NATURAL_WONDER);
        print("  ✓✓✓ 网络广播成功");
        print("  ► 所有客户端的Gameplay层将收到此消息");
    else
        -- UI Context 永远不写同步 Gameplay Property，避免联机重载。
        print("  ❌ Network.SendChat 不可用，未发送自然奇观事件");
    end
    
    print("  ► 里程碑检查将在下回合开始时执行");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 初始化
-- ===========================================================================
function Initialize()
    print("Turn2NaturalWonderListener: ========================================");
    print("Turn2NaturalWonderListener: 开始注册事件监听");
    print("Turn2NaturalWonderListener: ========================================");
    
    if Events and Events.NaturalWonderRevealed then
        Events.NaturalWonderRevealed.Add(OnNaturalWonderRevealed);
        print("Turn2NaturalWonderListener: ✓ 已注册 Events.NaturalWonderRevealed");
        print("Turn2NaturalWonderListener: ✓ 端口 " .. PORT_NATURAL_WONDER .. " 已分配");
    else
        print("Turn2NaturalWonderListener: ❌ 错误：Events.NaturalWonderRevealed 不可用");
    end
    
    print("Turn2NaturalWonderListener: ========================================");
end

Initialize();

