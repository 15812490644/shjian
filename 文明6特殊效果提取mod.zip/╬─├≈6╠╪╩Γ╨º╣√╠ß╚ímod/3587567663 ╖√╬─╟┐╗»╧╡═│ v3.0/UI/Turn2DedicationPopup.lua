-- ===========================================================================
-- 符文选择面板 - 原版“科技/市政完成”风格
-- 无共同外框、流式等高卡片、单卡独立刷新
-- ===========================================================================

include("InstanceManager");
include("Turn2Dedication_RuneRegistry");  -- 单一数据源：符文元数据/稀有度/预算/分池

-- ===========================================================================
-- 配置模块（从 GameConfiguration 动态读取，支持游戏设置界面配置）
-- ===========================================================================
-- 符文池由 RuneRegistry 的 stages 字段派生（T2D_GetPool），不再硬编码 POOL_PRESETS。

-- 从 GameConfiguration 读取设置（带默认值回退）
local function ReadGameConfig(key, defaultValue)
    if GameConfiguration and GameConfiguration.GetValue then
        local val = GameConfiguration.GetValue(key);
        if val ~= nil then
            return tonumber(val) or val;
        end
    end
    return defaultValue;
end

local cfgPoolMode    = ReadGameConfig("TURN2_RUNE_POOL_MODE", 1);
local cfgCardCount   = ReadGameConfig("TURN2_CARD_COUNT", 4);
local cfgRefreshCount = ReadGameConfig("TURN2_REFRESH_COUNT", 1);
local cfgStage1Turn  = ReadGameConfig("TURN2_STAGE1_TURN", 2);
local cfgStage2Turn  = ReadGameConfig("TURN2_STAGE2_TURN", 25);
local cfgStage3Turn  = ReadGameConfig("TURN2_STAGE3_TURN", 41);

print("Turn2DedicationPopup: 读取游戏配置:");
print("  符文池模式: " .. tostring(cfgPoolMode));
print("  卡片数量: " .. tostring(cfgCardCount));
print("  刷新次数: " .. tostring(cfgRefreshCount));
print("  第1阶段回合: " .. tostring(cfgStage1Turn));
print("  第2阶段回合: " .. tostring(cfgStage2Turn));
print("  第3阶段回合: " .. tostring(cfgStage3Turn));

-- 使用固定阶段编号，禁用任一阶段时不压缩后续阶段的编号。
local stageTurns:table = {};
local stageNames:table = {
    [1] = "初期",
    [2] = "中期",
    [3] = "后期",
};
if cfgStage1Turn > 0 then
    stageTurns[1] = cfgStage1Turn;
end
if cfgStage2Turn > 0 then
    stageTurns[2] = cfgStage2Turn;
end
if cfgStage3Turn > 0 then
    stageTurns[3] = cfgStage3Turn;
end

local MOD_CONFIG:table = {
    -- 阶段回合配置（从 GameConfiguration 读取）
    StageTurns = stageTurns,
    -- 阶段名称配置
    StageNames = stageNames,
    -- 符文池模式（1精简/2完整/3全符文），分池由 T2D_GetPool 按 registry 派生
    PoolMode = cfgPoolMode,
    -- 卡片配置（从 GameConfiguration 读取）
    CARD_COUNT = cfgCardCount,
    MAX_REFRESH_PER_CARD = cfgRefreshCount,
};


-- ===========================================================================
-- 符文显示数据（由单一数据源 RuneRegistry 派生，UI 仅此一处来源）
-- ===========================================================================
local RUNE_DATABASE = {};
for id, r in pairs(T2D_Runes) do
    RUNE_DATABASE[id] = {
        Name = r.name,
        Icon = r.icon,
        Effect = r.effect,
        Summary = r.summary,
        Rarity = r.rarity,
    };
end

-- 只使用能够完整放入原版徽章的图集尺寸。控件尺寸必须与图集尺寸完全一致；
-- Civ VI 的 Image:SetSizeVal 不会重采样已绑定的图集区域，尺寸不一致会裁掉右下部分。
local RUNE_ICON_SIZES = { 128, 80, 64, 50, 38, 32 };
local m_iconCache = {};
local m_warnedIcons = {};

local RARITY_UI_STYLE = {
    silver = {
        name = "白银",
        halo = UI.GetColorValue(0.68, 0.77, 0.87, 0.55),
        border = UI.GetColorValue(0.68, 0.77, 0.87, 0.58),
        hover = UI.GetColorValue(0.76, 0.85, 0.95, 0.86),
        selected = UI.GetColorValue(0.80, 0.89, 1.00, 1.00),
        wash = UI.GetColorValue(0.68, 0.77, 0.87, 0.10),
        rgb = "174,196,222",
    },
    gold = {
        name = "黄金",
        halo = UI.GetColorValue(0.94, 0.74, 0.25, 0.58),
        border = UI.GetColorValue(0.94, 0.74, 0.25, 0.62),
        hover = UI.GetColorValue(1.00, 0.83, 0.34, 0.88),
        selected = UI.GetColorValue(1.00, 0.86, 0.38, 1.00),
        wash = UI.GetColorValue(0.94, 0.74, 0.25, 0.10),
        rgb = "240,189,64",
    },
    prismatic = {
        name = "棱彩",
        halo = UI.GetColorValue(1.00, 0.36, 0.92, 0.58),
        border = UI.GetColorValue(1.00, 0.36, 0.92, 0.62),
        hover = UI.GetColorValue(1.00, 0.50, 0.96, 0.90),
        selected = UI.GetColorValue(1.00, 0.55, 0.98, 1.00),
        wash = UI.GetColorValue(1.00, 0.36, 0.92, 0.11),
        rgb = "255,92,235",
    },
};

local function IconCacheKey(iconName, sizes)
    return tostring(iconName) .. "@" .. table.concat(sizes, ",");
end

local function TryApplyIcon(iconControl, iconName, iconSize)
    if not iconControl or not iconName or not iconControl.TrySetIcon then return false; end
    -- 先调整控件，再绑定同尺寸图集；绝不在绑定后缩放或放大图集子区域。
    iconControl:SetSizeVal(iconSize, iconSize);
    local ok, applied = pcall(function()
        return iconControl:TrySetIcon(iconName, iconSize);
    end);
    if not ok or applied ~= true then return false; end
    return true;
end

local function SetRuneIcon(iconControl, runeID, iconName)
    if not iconControl then return false; end
    local cacheKey = IconCacheKey(iconName, RUNE_ICON_SIZES);
    local cachedSize = m_iconCache[cacheKey];
    if type(cachedSize) == "number" and TryApplyIcon(iconControl, iconName, cachedSize) then
        return true;
    end

    if cachedSize ~= false then
        for _, iconSize in ipairs(RUNE_ICON_SIZES) do
            if TryApplyIcon(iconControl, iconName, iconSize) then
                m_iconCache[cacheKey] = iconSize;
                return true;
            end
        end
        m_iconCache[cacheKey] = false;
    end

    local warningKey = "rune:" .. tostring(runeID);
    if not m_warnedIcons[warningKey] then
        m_warnedIcons[warningKey] = true;
        print("UIWARNING: Turn2DedicationPopup 找不到符文图标：ID="
            .. tostring(runeID) .. " Icon=" .. tostring(iconName));
    end

    local fallback = "ICON_CIVILIZATION_UNKNOWN";
    local fallbackKey = IconCacheKey(fallback, RUNE_ICON_SIZES);
    local fallbackSize = m_iconCache[fallbackKey];
    if type(fallbackSize) == "number" and TryApplyIcon(iconControl, fallback, fallbackSize) then
        return true;
    end
    for _, iconSize in ipairs(RUNE_ICON_SIZES) do
        if TryApplyIcon(iconControl, fallback, iconSize) then
            m_iconCache[fallbackKey] = iconSize;
            return true;
        end
    end
    m_iconCache[fallbackKey] = false;
    return false;
end

local function BuildRuneTooltip(runeInfo)
    local rarity = runeInfo.Rarity or "silver";
    local style = RARITY_UI_STYLE[rarity] or RARITY_UI_STYLE.silver;
    return "[COLOR:" .. style.rgb .. ",255]" .. tostring(runeInfo.Name or "")
        .. "[ENDCOLOR][NEWLINE][NEWLINE]" .. tostring(runeInfo.Effect or "")
        .. "[NEWLINE][NEWLINE][COLOR:201,193,188,255]"
        .. tostring(runeInfo.Summary or "") .. "[ENDCOLOR]";
end

-- ===========================================================================
-- 变量
-- ===========================================================================
local m_CardInstanceManager = nil;     -- 卡片实例管理器
local m_CardInstances = {};            -- 卡片UI实例数组
local m_CardData = {};                 -- 每个卡片的数据 {runeID, refreshCount}
local m_SelectedCardIndex = -1;        -- 当前选中的卡片索引
local m_HoveredCardIndex = -1;         -- 当前悬停卡片，用于独立悬停边框
local m_CurrentStage = 1;              -- 当前阶段
local m_CurrentRarityCode = nil;       -- Gameplay 房主写入的全局阶段品质编码
local m_CurrentRarity = nil;           -- silver/gold/prismatic
local m_AvailableRunes = {};           -- 当前阶段可用的符文池
local m_WaitingSelection = nil;        -- {runeID, name, stage, elapsed}
local m_PendingStageOpen = nil;        -- 等待全局品质同步后打开/重建面板
local m_CardsStage = nil;              -- 当前四张卡所属阶段；关闭/重开时保持不变
local m_IsQueued = false;              -- 是否已进入原生 Popup 队列
local SELECTION_ACK_TIMEOUT = 5.0;

local function SignalPendingSelectionChanged()
    if LuaEvents and LuaEvents.Turn2Dedication_PendingChanged then
        LuaEvents.Turn2Dedication_PendingChanged();
    end
end

local function ClosePanel(preserveCards)
    Controls.FullScreenBlocker:SetHide(true);
    if preserveCards ~= true then
        m_CardsStage = nil;
        m_CardData = {};
        m_SelectedCardIndex = -1;
    end
    if m_IsQueued and UIManager and UIManager.DequeuePopup then
        UIManager:DequeuePopup(ContextPtr);
    else
        ContextPtr:SetHide(true);
    end
    m_IsQueued = false;
    SignalPendingSelectionChanged();
end

local function GetGlobalStageRarity(stage)
    local rawValue = Game.GetProperty("Turn2Dedication_GlobalRarity_Stage" .. tostring(stage));
    local rarityCode = rawValue ~= nil and tonumber(rawValue) or nil;
    if not rarityCode or rarityCode ~= math.floor(rarityCode)
        or rarityCode < 1 or rarityCode > 3 then
        return nil, nil;
    end
    local rarity = T2D_RARITY_BY_CODE and T2D_RARITY_BY_CODE[rarityCode] or nil;
    if not rarity then return nil, nil; end
    return rarityCode, rarity;
end

-- ===========================================================================
-- 初始化
-- ===========================================================================
function Initialize()
    print("════════════════════════════════════════════════════════");
    print("║ 符文选择UI初始化（原版完成弹窗风格）");
    print("════════════════════════════════════════════════════════");

    -- 随机源一次性初始化（本地UI抽卡，多人各客户端独立，无需确定性）
    math.randomseed(os.time());

    -- 创建卡片管理器
    m_CardInstanceManager = InstanceManager:new("RuneCard", "CardContainer", Controls.CardsContainer);

    -- 注册事件
    Controls.ConfirmButton:RegisterCallback(Mouse.eLClick, OnConfirmSelection);
    Controls.CloseButton:RegisterCallback(Mouse.eLClick, OnClose);
    ContextPtr:SetInputHandler(OnInputHandler, true);
    
    -- 设置UI文字
    Controls.Title:SetText("符文选择");
    Controls.ConfirmButton:SetText("确认选择");
    
    -- 默认隐藏UI（等待回合触发）
    ContextPtr:SetHide(true);
    
    print("  ✓ UI初始化完成（等待触发回合）");
    print("════════════════════════════════════════════════════════");
end

-- ===========================================================================
-- 初始化符文池
-- ===========================================================================
function InitializeRunePool()
    -- 分池由 RuneRegistry 的 stages 字段 + 模式白名单派生（取代硬编码 POOL_PRESETS）
    local localPlayerID = Game.GetLocalPlayer();
    local stagePool = T2D_GetPool(MOD_CONFIG.PoolMode, m_CurrentStage);
    m_AvailableRunes = {};

    m_CurrentRarityCode, m_CurrentRarity = GetGlobalStageRarity(m_CurrentStage);
    if not m_CurrentRarityCode or not m_CurrentRarity then
        print("Turn2DedicationPopup: ⏳ 阶段" .. tostring(m_CurrentStage)
            .. "全局品质尚未同步，暂不构建候选池");
        return false;
    end

    -- 所有已拥有符文都永久退出后续候选：正式选择、质变奖励和图鉴测试均计入。
    local ownedRunes = {};
    local ownedConflictGroups = {};
    if localPlayerID ~= -1 then
        ownedRunes = T2D_GetPlayerOwnedRuneSet(localPlayerID);
        for chosenID, _ in pairs(ownedRunes) do
            local conflictGroup = T2D_GetConflictGroup(chosenID);
            if conflictGroup then
                ownedConflictGroups[conflictGroup] = chosenID;
            end
        end
    end

    for _, runeID in ipairs(stagePool) do
        local conflictGroup = T2D_GetConflictGroup(runeID);
        local conflictingOwnedID = conflictGroup and ownedConflictGroups[conflictGroup] or nil;
        if T2D_GetRarity(runeID) == m_CurrentRarity
            and not ownedRunes[runeID]
            and conflictingOwnedID == nil then
            table.insert(m_AvailableRunes, runeID);
        end
    end
    if #m_AvailableRunes < MOD_CONFIG.CARD_COUNT then
        print(string.format("UIERROR: Turn2DedicationPopup 阶段%d的%s候选仅%d个，少于卡牌数%d；拒绝跨品质或重复填充",
            m_CurrentStage, tostring(m_CurrentRarity), #m_AvailableRunes, MOD_CONFIG.CARD_COUNT));
        return false;
    end
    print(string.format("  ✓ 符文池已初始化: %d 个%s符文 (模式%s, 阶段%s)",
        #m_AvailableRunes, tostring(m_CurrentRarity),
        tostring(MOD_CONFIG.PoolMode), tostring(m_CurrentStage)));
    return true;
end

-- ===========================================================================
-- 初始化配置数量的卡片
-- ===========================================================================
function InitializeCards()
    m_CardsStage = nil;
    m_CardInstances = {};
    m_CardData = {};
    m_SelectedCardIndex = -1;
    m_HoveredCardIndex = -1;
    m_CardInstanceManager:ResetInstances();
    
    -- 创建配置数量的等高卡片
    for i = 1, MOD_CONFIG.CARD_COUNT do
        local cardInstance = m_CardInstanceManager:GetInstance();
        local runeID = GetRandomRune(nil, nil);
        if not runeID then
            print("  ❌ 当前阶段没有可抽取的符文，停止创建卡片");
            return false;
        end
        
        -- 初始化卡片数据
        m_CardData[i] = {
            runeID = runeID,
            refreshCount = MOD_CONFIG.MAX_REFRESH_PER_CARD,
        };
        
        -- 绑定事件
        cardInstance.SelectButton:RegisterCallback(Mouse.eLClick, function() OnCardSelected(i); end);
        cardInstance.SelectButton:RegisterCallback(Mouse.eMouseEnter, function() OnCardMouseEnter(i); end);
        cardInstance.SelectButton:RegisterCallback(Mouse.eMouseExit, function() OnCardMouseExit(i); end);
        cardInstance.RefreshButton:RegisterCallback(Mouse.eLClick, function() OnCardRefresh(i); end);
        
        -- 更新显示
        UpdateCardDisplay(cardInstance, i);
        
        table.insert(m_CardInstances, cardInstance);
    end

    -- InstanceManager 完成后统一计算内容尺寸，确保滚动范围和居中位置正确。
    Controls.CardsContainer:CalculateSize();
    local cardsWidth = Controls.CardsContainer:GetSizeX();
    local viewportWidth = Controls.CardsScrollPanel:GetSizeX();
    Controls.CardsContainer:SetOffsetX(math.max(0, math.floor((viewportWidth - cardsWidth) / 2)));
    Controls.CardsScrollPanel:CalculateSize();
    Controls.CardsScrollPanel:SetScrollValue(0);
    Controls.PageFlow:CalculateSize();

    print("  ✓ " .. tostring(#m_CardInstances) .. "张等高符文卡片已创建");
    m_CardsStage = m_CurrentStage;
    return true;
end

-- ===========================================================================
-- 在当前全局品质池中严格无放回抽取一枚符文。
-- ===========================================================================
function GetRandomRune(excludeCardIndex, excludedRuneID)
    if #m_AvailableRunes == 0 then return nil; end

    local excludedRunes = {};
    local visibleRunes = {};
    if excludedRuneID then excludedRunes[excludedRuneID] = true; end
    for idx, data in ipairs(m_CardData) do
        if data.runeID and idx ~= excludeCardIndex then
            excludedRunes[data.runeID] = true;
            visibleRunes[data.runeID] = true;
        end
    end

    local function ConflictsWithUsedRune(runeID)
        for usedRuneID, _ in pairs(visibleRunes) do
            if T2D_RunesConflict(runeID, usedRuneID) then return true; end
        end
        return false;
    end

    -- 不允许与可见卡重复，也不允许刷新回原符文；无候选时绝不降级或重复。
    local pool = {};
    for _, runeID in ipairs(m_AvailableRunes) do
        if not excludedRunes[runeID] and not ConflictsWithUsedRune(runeID) then
            table.insert(pool, runeID);
        end
    end
    if #pool == 0 then return nil; end
    return pool[math.random(#pool)];
end

-- ===========================================================================
-- 更新卡片显示
-- ===========================================================================
local function UpdateCardSelectionState(cardInstance, cardIndex)
    local isSelected = (m_SelectedCardIndex == cardIndex);
    local isHovered = (m_HoveredCardIndex == cardIndex) and not isSelected;
    cardInstance.SelectedGlow:SetHide(not isSelected);
    cardInstance.SelectedWash:SetHide(not isSelected);
    cardInstance.SelectedFrame:SetHide(not isSelected);
    cardInstance.HoverFrame:SetHide(not isHovered);
    cardInstance.SelectedMark:SetHide(not isSelected);
end

local function RefreshEffectLayout(cardInstance)
    -- 先清除上一枚符文留下的偏移，再读取本次换行后的实际文本高度。
    cardInstance.RuneEffect:SetOffsetY(0);
    cardInstance.EffectStack:CalculateSize();

    local viewportHeight = cardInstance.EffectViewport:GetSizeY();
    local textHeight = cardInstance.RuneEffect:GetSizeY();
    local topOffset = 0;
    if textHeight < viewportHeight then
        topOffset = math.floor((viewportHeight - textHeight) / 2);
    end

    -- 短效果垂直居中；长效果顶部对齐并保留完整滚动高度。
    cardInstance.RuneEffect:SetOffsetY(topOffset);
    cardInstance.EffectStack:CalculateSize();
    cardInstance.EffectStack:SetSizeY(math.max(viewportHeight, textHeight + topOffset));
    cardInstance.EffectViewport:CalculateSize();
    cardInstance.EffectViewport:SetScrollValue(0);
end

function UpdateCardDisplay(cardInstance, cardIndex)
    local data = m_CardData[cardIndex];
    if not data then return; end
    
    local runeInfo = RUNE_DATABASE[data.runeID];
    if not runeInfo then
        runeInfo = {
            Name = "未知符文",
            Icon = "ICON_UNIT_WARRIOR",
            Effect = "未定义效果",
            Summary = "这枚符文的描述尚未完成。",
            Rarity = "silver",
        };
    end

    -- 品质同时体现在徽章光晕、左上文字与整卡边框，避免只靠一种颜色判断。
    local rarity = runeInfo.Rarity or "silver";
    local style = RARITY_UI_STYLE[rarity] or RARITY_UI_STYLE.silver;

    -- Image:TrySetIcon 是安全入口；失败时使用未知文明图标，禁止直接访问图集指针。
    SetRuneIcon(cardInstance.RuneIcon, data.runeID, runeInfo.Icon);

    cardInstance.RarityHalo:SetColor(style.halo);
    cardInstance.RarityFrame:SetColor(style.border);
    cardInstance.HoverFrame:SetColor(style.hover);
    cardInstance.SelectedFrame:SetColor(style.selected);
    cardInstance.SelectedGlow:SetColor(style.selected);
    cardInstance.SelectedWash:SetColor(style.wash);
    cardInstance.SelectedMark:SetColor(style.selected);
    cardInstance.RarityLabel:SetColor(style.selected);
    cardInstance.RarityLabel:SetText(style.name);

    -- 名称沿用原版完成弹窗的深色横幅文字；效果不再添加品质前缀。
    cardInstance.RuneName:SetText(runeInfo.Name);
    cardInstance.RuneEffect:SetText(runeInfo.Effect);
    cardInstance.RuneSummary:SetText(runeInfo.Summary or "以这枚符文开启文明新的发展方向。");

    local tooltip = BuildRuneTooltip(runeInfo);
    cardInstance.SelectButton:SetToolTipString(tooltip);
    cardInstance.RuneName:SetToolTipString(tooltip);
    cardInstance.RuneIcon:SetToolTipString(tooltip);
    cardInstance.RuneEffect:SetToolTipString(tooltip);

    RefreshEffectLayout(cardInstance);
    
    -- 更新刷新按钮
    local refreshText = string.format("[ICON_Turn] 刷新（%d）", data.refreshCount);
    cardInstance.RefreshButton:SetText(refreshText);
    cardInstance.RefreshButton:SetDisabled(data.refreshCount <= 0);
    
    -- 选中状态使用独立光晕和勾选，不依赖透明按钮的贴图状态。
    UpdateCardSelectionState(cardInstance, cardIndex);
end

-- ===========================================================================
-- 卡片悬停状态
-- ===========================================================================
function OnCardMouseEnter(cardIndex)
    if m_WaitingSelection then return; end
    m_HoveredCardIndex = cardIndex;
    local cardInstance = m_CardInstances[cardIndex];
    if cardInstance then UpdateCardSelectionState(cardInstance, cardIndex); end
    if UI and UI.PlaySound then UI.PlaySound("Main_Menu_Mouse_Over"); end
end

function OnCardMouseExit(cardIndex)
    if m_HoveredCardIndex == cardIndex then m_HoveredCardIndex = -1; end
    local cardInstance = m_CardInstances[cardIndex];
    if cardInstance then UpdateCardSelectionState(cardInstance, cardIndex); end
end

-- ===========================================================================
-- 卡片被选中
-- ===========================================================================
function OnCardSelected(cardIndex)
    m_SelectedCardIndex = cardIndex;
    
    -- 只更新选择光效，避免重置玩家正在阅读的长效果滚动位置。
    for i, cardInstance in ipairs(m_CardInstances) do
        UpdateCardSelectionState(cardInstance, i);
    end
    
    -- 播放音效
    if UI and UI.PlaySound then
        UI.PlaySound("Play_UI_Click");
    end
    
    local runeID = m_CardData[cardIndex].runeID;
    local runeName = RUNE_DATABASE[runeID] and RUNE_DATABASE[runeID].Name or "未知";
    print("  ► 选中卡片 " .. cardIndex .. "，符文: " .. runeName .. " (ID:" .. runeID .. ")");
end

-- ===========================================================================
-- 刷新单个卡片
-- ===========================================================================
function OnCardRefresh(cardIndex)
    local data = m_CardData[cardIndex];
    if not data or data.refreshCount <= 0 then
        print("  ⚠ 卡片 " .. cardIndex .. " 已无刷新次数");
        return;
    end

    -- 先计算合法结果；候选不足时不消耗刷新次数，也绝不返回原符文。
    local oldRuneID = data.runeID;
    local newRuneID = GetRandomRune(cardIndex, oldRuneID);
    if not newRuneID then
        print("UIERROR: Turn2DedicationPopup 卡片" .. tostring(cardIndex)
            .. "没有满足同品质、必换且不重复的刷新候选");
        Controls.Title:SetText("没有可用的同品质刷新候选");
        if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
        return;
    end

    data.refreshCount = data.refreshCount - 1;
    data.runeID = newRuneID;
    
    -- 更新显示
    UpdateCardDisplay(m_CardInstances[cardIndex], cardIndex);
    
    -- 播放音效
    if UI and UI.PlaySound then
        UI.PlaySound("Play_UI_Click");
    end
    
    local oldName = RUNE_DATABASE[oldRuneID] and RUNE_DATABASE[oldRuneID].Name or "未知";
    local newName = RUNE_DATABASE[data.runeID] and RUNE_DATABASE[data.runeID].Name or "未知";
    print(string.format("  ► 刷新卡片 %d: %s → %s，剩余刷新次数: %d", 
          cardIndex, oldName, newName, data.refreshCount));
end


-- ===========================================================================
-- 确认选择
-- ===========================================================================
local function SetSelectionControlsDisabled(disabled)
    Controls.ConfirmButton:SetDisabled(disabled);
    if disabled then m_HoveredCardIndex = -1; end
    for index, card in ipairs(m_CardInstances) do
        card.SelectButton:SetDisabled(disabled);
        local cardData = m_CardData[index];
        card.RefreshButton:SetDisabled(disabled or cardData == nil or cardData.refreshCount <= 0);
        UpdateCardSelectionState(card, index);
    end
end

local function ShowSelectionConflict(selectedRune, conflictingRune)
    local selectedName = RUNE_DATABASE[selectedRune] and RUNE_DATABASE[selectedRune].Name or tostring(selectedRune);
    local conflictName = conflictingRune and RUNE_DATABASE[conflictingRune]
        and RUNE_DATABASE[conflictingRune].Name or "另一枚同组符文";
    Controls.Title:SetText("选择冲突：【" .. selectedName .. "】与已拥有的【" .. conflictName .. "】互斥");
    print("  ⚠ 选择冲突: " .. tostring(selectedRune) .. " 与 " .. tostring(conflictingRune) .. " 互斥");
    if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
end

local function FinishAcceptedSelection(waiting)
    local localPlayerID = Game.GetLocalPlayer();
    local playerConfig = PlayerConfigurations and PlayerConfigurations[localPlayerID];
    local playerName = playerConfig and Locale.Lookup(playerConfig:GetPlayerName()) or ("玩家" .. tostring(localPlayerID));
    local stageName = MOD_CONFIG.StageNames[waiting.stage] or ("阶段" .. waiting.stage);
    local publicMessage = string.format("%s 选择了符文：%s（%s）", playerName, waiting.name, stageName);
    if Network and Network.SendChat then
        Network.SendChat(publicMessage, ChatTargetTypes.CHATTARGET_ALL, -1);
    end

    print("  ✓ 符文选择已由 Gameplay 接受并广播");
    if UI and UI.PlaySound then UI.PlaySound("Confirm_Bed_Positive"); end
    m_WaitingSelection = nil;
    ContextPtr:ClearUpdate();
    SetSelectionControlsDisabled(false);
    ClosePanel(false);
end

local function GetAuthoritativeStageRuneID(playerID, stage)
    local rawValue = Game.GetProperty("Turn2Dedication_Stage" .. stage .. "_P" .. playerID);
    local runeID = rawValue ~= nil and tonumber(rawValue) or nil;
    if runeID and T2D_GetRune(runeID) then return runeID; end
    return nil;
end

-- 本阶段已由 Gameplay 保存选择时，只服从权威 Property 并关闭面板。
-- 该选择可能来自重连前的请求，绝不再次广播当前 UI 正在请求的符文。
local function FinishAuthoritativeExistingSelection(waiting, authoritativeRuneID)
    local rune = T2D_GetRune(authoritativeRuneID);
    print("  ⓘ 阶段" .. tostring(waiting.stage) .. "已有权威选择："
        .. tostring((rune and rune.name) or authoritativeRuneID) .. "；关闭面板且不重复广播");
    m_WaitingSelection = nil;
    ContextPtr:ClearUpdate();
    SetSelectionControlsDisabled(false);
    ClosePanel(false);
end

local function FinishConflictedSelection(waiting)
    local localPlayerID = Game.GetLocalPlayer();
    local conflictID = T2D_FindOwnedConflict(localPlayerID, waiting.runeID);
    m_WaitingSelection = nil;
    ContextPtr:ClearUpdate();
    SetSelectionControlsDisabled(false);
    ShowSelectionConflict(waiting.runeID, conflictID);

    -- Gameplay 可能在 UI 抽卡后才同步到另一枚互斥符文；按最新拥有记录重建合法候选。
    if InitializeRunePool() then InitializeCards(); end
end

local function FinishAlreadyOwnedSelection(waiting)
    m_WaitingSelection = nil;
    ContextPtr:ClearUpdate();
    SetSelectionControlsDisabled(false);
    m_AvailableRunes = {};
    print("Turn2DedicationPopup: ⚠ 选择的符文已在最新同步状态中拥有，重建候选池 ID="
        .. tostring(waiting.runeID));
    if InitializeRunePool() then
        InitializeCards();
        Controls.Title:SetText("该符文已经拥有，请重新选择");
    end
    if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
end

local function FinishRarityMismatch(waiting)
    m_WaitingSelection = nil;
    ContextPtr:ClearUpdate();
    SetSelectionControlsDisabled(false);
    m_AvailableRunes = {};
    m_CardsStage = nil;
    m_CurrentRarityCode, m_CurrentRarity = GetGlobalStageRarity(waiting.stage);

    print("Turn2DedicationPopup: ⚠ 房主拒绝了非全局品质选择，重新同步阶段"
        .. tostring(waiting.stage) .. "候选池");
    if m_CurrentRarityCode then
        ShowPanel();
        Controls.Title:SetText("品质已同步，请重新选择");
    else
        Controls.Title:SetText("正在等待全局品质同步……");
        BeginWaitingForGlobalRarity(waiting.stage, true);
    end
    if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
end

local function FinishExpiredSelection(waiting)
    print("Turn2DedicationPopup: ⏭ 阶段" .. tostring(waiting.stage)
        .. "选择回合已经结束，本次机会取消");
    m_WaitingSelection = nil;
    ContextPtr:ClearUpdate();
    SetSelectionControlsDisabled(false);
    if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
    ClosePanel(false);
end

function OnSelectionAckUpdate(deltaTime)
    if not m_WaitingSelection then
        ContextPtr:ClearUpdate();
        return;
    end

    m_WaitingSelection.elapsed = m_WaitingSelection.elapsed + (deltaTime or 0);
    local localPlayerID = Game.GetLocalPlayer();
    local expectedTurn = MOD_CONFIG.StageTurns[m_WaitingSelection.stage];
    if expectedTurn and Game.GetCurrentGameTurn() ~= expectedTurn then
        local waiting = m_WaitingSelection;
        local authoritativeRuneID = GetAuthoritativeStageRuneID(localPlayerID, waiting.stage);
        if authoritativeRuneID then
            FinishAuthoritativeExistingSelection(waiting, authoritativeRuneID);
        else
            FinishExpiredSelection(waiting);
        end
        return;
    end
    local rawAck = Game.GetProperty("Turn2Dedication_SelectionAck_P" .. localPlayerID);
    if rawAck ~= nil then
        local ackStage, ackRuneID, status = tostring(rawAck):match("^(%d+):(%d+):([A-Z_]+)$");
        if tonumber(ackStage) == m_WaitingSelection.stage
            and tonumber(ackRuneID) == m_WaitingSelection.runeID then
            local waiting = m_WaitingSelection;
            if status == "ACCEPTED" then
                FinishAcceptedSelection(waiting);
            elseif status == "CONFLICT" then
                FinishConflictedSelection(waiting);
            elseif status == "ALREADY_OWNED" then
                FinishAlreadyOwnedSelection(waiting);
            elseif status == "RARITY_MISMATCH" then
                FinishRarityMismatch(waiting);
            elseif status == "EXPIRED" then
                FinishExpiredSelection(waiting);
            elseif status == "ALREADY_SELECTED" then
                local authoritativeRuneID = GetAuthoritativeStageRuneID(
                    localPlayerID, waiting.stage);
                if authoritativeRuneID then
                    FinishAuthoritativeExistingSelection(waiting, authoritativeRuneID);
                    return;
                end
                -- ACK 可能先于 Stage Property 抵达；保持等待直到同步或超时。
                Controls.Title:SetText("正在读取本阶段已有选择……");
            else
                m_WaitingSelection = nil;
                ContextPtr:ClearUpdate();
                SetSelectionControlsDisabled(false);
                Controls.Title:SetText("选择未被接受，请重新确认");
                return;
            end
            if status ~= "ALREADY_SELECTED" then return; end
        end
    end

    if m_WaitingSelection.elapsed >= SELECTION_ACK_TIMEOUT then
        local waiting = m_WaitingSelection;
        local authoritativeRuneID = GetAuthoritativeStageRuneID(localPlayerID, waiting.stage);
        if authoritativeRuneID then
            FinishAuthoritativeExistingSelection(waiting, authoritativeRuneID);
        else
            m_WaitingSelection = nil;
            ContextPtr:ClearUpdate();
            SetSelectionControlsDisabled(false);
            Controls.Title:SetText("选择同步超时，请重新确认");
            if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
        end
    end
end

function OnConfirmSelection()
    if m_WaitingSelection then return; end
    if m_SelectedCardIndex == -1 then
        print("  ⚠ 未选择任何卡片，无法确认");
        -- 播放警告音效
        if UI and UI.PlaySound then
            UI.PlaySound("Play_UI_Notification_Negative");
        end
        return;
    end
    
    local selectedRune = m_CardData[m_SelectedCardIndex].runeID;
    local runeName = RUNE_DATABASE[selectedRune] and RUNE_DATABASE[selectedRune].Name or "未知";
    local localPlayerID = Game.GetLocalPlayer();
    local globalRarityCode, globalRarity = GetGlobalStageRarity(m_CurrentStage);
    if not globalRarityCode or globalRarityCode ~= m_CurrentRarityCode
        or T2D_GetRarity(selectedRune) ~= globalRarity then
        print("Turn2DedicationPopup: ⚠ 确认前检测到全局品质不同步，重新构建候选池");
        m_AvailableRunes = {};
        if globalRarityCode then
            ShowPanel();
            Controls.Title:SetText("品质已变化，请重新选择");
        else
            BeginWaitingForGlobalRarity(m_CurrentStage, true);
            Controls.Title:SetText("正在等待全局品质同步……");
        end
        return;
    end
    local conflictingRune = T2D_FindOwnedConflict(localPlayerID, selectedRune);
    if conflictingRune then
        ShowSelectionConflict(selectedRune, conflictingRune);
        return;
    end
    
    print("════════════════════════════════════════════════════════");
    print("║ 符文选择确认");
    print("  卡片索引: " .. m_SelectedCardIndex);
    print("  符文ID: " .. selectedRune);
    print("  符文名称: " .. runeName);
    print("  阶段: " .. m_CurrentStage);
    
    -- 发送网络同步消息
    local currentTurn = Game.GetCurrentGameTurn();
    
    -- 隐藏消息：[T2D]playerID:runeID:stage:turn:rarityCode
    -- 第5段回显房主同步的全局品质；Gameplay 会与注册品质和权威 Property 再次交叉校验。
    local rarityCode = globalRarityCode;
    local hiddenMessage = string.format("[T2D]%d:%d:%d:%d:%d",
        localPlayerID, selectedRune, m_CurrentStage, currentTurn, rarityCode);

    if Network and Network.SendChat then
        m_WaitingSelection = {
            runeID = selectedRune,
            name = runeName,
            stage = m_CurrentStage,
            elapsed = 0,
        };
        SetSelectionControlsDisabled(true);
        Controls.Title:SetText("正在同步选择：【" .. runeName .. "】……");
        Network.SendChat(hiddenMessage, ChatTargetTypes.CHATTARGET_ALL, 655001);
        print("  ✓ 网络消息已发送（端口655001, 稀有度" .. tostring(rarityCode) .. "）");
        ContextPtr:SetUpdate(OnSelectionAckUpdate);
    else
        Controls.Title:SetText("选择失败：Network.SendChat 不可用");
        if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
    end
    print("════════════════════════════════════════════════════════");
end

-- ===========================================================================
-- 关闭按钮
-- ===========================================================================
function OnClose()
    if m_WaitingSelection then
        Controls.Title:SetText("正在同步选择，请稍候……");
        if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
        return;
    end
    print("Turn2DedicationPopup: 面板已暂时收起，候选卡保持不变");
    if m_PendingStageOpen then
        m_PendingStageOpen = nil;
        ContextPtr:ClearUpdate();
    end
    if UI and UI.PlaySound then UI.PlaySound("Play_UI_Click"); end
    ClosePanel(true);
end

function OnInputHandler(inputStruct)
    if not inputStruct or ContextPtr:IsHidden() then return false; end
    if inputStruct.GetMessageType and inputStruct:GetMessageType() == KeyEvents.KeyUp
        and inputStruct:GetKey() == Keys.VK_ESCAPE then
        OnClose();
        return true;
    end
    return true;
end

-- ===========================================================================
-- 辅助函数：获取当前阶段
-- ===========================================================================
function GetCurrentStage(currentTurn)
    for stage = 1, 3 do
        local turn = MOD_CONFIG.StageTurns[stage];
        if currentTurn == turn then
            return stage;
        end
    end
    return nil;
end

-- ===========================================================================
-- 辅助函数：检查玩家是否已选择
-- ===========================================================================
function HasPlayerChosen(playerID, stage)
    local key = "Turn2Dedication_Stage" .. stage .. "_P" .. playerID;
    return Game.GetProperty(key) ~= nil;
end

function HasPlayerMissedStage(playerID, stage)
    local key = "Turn2Dedication_Stage" .. tostring(stage)
        .. "_Missed_P" .. tostring(playerID);
    return Game.GetProperty(key) ~= nil;
end

function FindEarliestPendingStage(playerID, currentTurn)
    for stage = 1, 3 do
        local selectionTurn = MOD_CONFIG.StageTurns[stage];
        if selectionTurn and currentTurn == selectionTurn
            and not HasPlayerChosen(playerID, stage)
            and not HasPlayerMissedStage(playerID, stage) then
            return stage;
        end
    end
    return nil;
end

-- ===========================================================================
-- 等待房主同步全局阶段品质。UI 永远不自行回退随机品质。
-- ===========================================================================
function BeginWaitingForGlobalRarity(stage, rebuildVisiblePanel)
    m_CurrentStage = stage;
    m_CurrentRarityCode = nil;
    m_CurrentRarity = nil;
    m_AvailableRunes = {};
    m_PendingStageOpen = {
        stage = stage,
        expectedTurn = MOD_CONFIG.StageTurns[stage],
        elapsed = 0,
        probeElapsed = 0.1,
        nextLog = 1,
        rebuildVisiblePanel = rebuildVisiblePanel == true,
    };
    ContextPtr:SetUpdate(OnStageRaritySyncUpdate);
    print("Turn2DedicationPopup: ⏳ 等待阶段" .. tostring(stage) .. "全局品质同步");
end

function OnStageRaritySyncUpdate(deltaTime)
    local pending = m_PendingStageOpen;
    if not pending then
        ContextPtr:ClearUpdate();
        return;
    end

    local dt = deltaTime or 0;
    pending.elapsed = pending.elapsed + dt;
    pending.probeElapsed = pending.probeElapsed + dt;
    if pending.probeElapsed < 0.1 then return; end
    pending.probeElapsed = 0;

    local currentTurn = Game.GetCurrentGameTurn();
    if pending.expectedTurn and currentTurn ~= pending.expectedTurn then
        print("UIERROR: Turn2DedicationPopup 阶段" .. tostring(pending.stage)
            .. "选择回合已经结束");
        m_PendingStageOpen = nil;
        ContextPtr:ClearUpdate();
        ClosePanel(false);
        return;
    end

    local rarityCode, rarity = GetGlobalStageRarity(pending.stage);
    if rarityCode and rarity then
        m_PendingStageOpen = nil;
        ContextPtr:ClearUpdate();
        m_CurrentStage = pending.stage;
        m_CurrentRarityCode = rarityCode;
        m_CurrentRarity = rarity;
        m_AvailableRunes = {};
        print("Turn2DedicationPopup: ✓ 已同步阶段" .. tostring(pending.stage)
            .. "全局品质=" .. tostring(rarity));
        ShowPanel();
        if pending.rebuildVisiblePanel then
            Controls.Title:SetText("品质已同步，请重新选择");
        end
        return;
    end

    if pending.elapsed >= pending.nextLog then
        print("Turn2DedicationPopup: ⏳ 仍在等待全局品质，已等待"
            .. string.format("%.1f", pending.elapsed) .. "秒");
        pending.nextLog = pending.nextLog + 1;
    end
end

-- ===========================================================================
-- 显示面板（从外部调用）
-- ===========================================================================
function ShowPanel()
    local localPlayerID = Game.GetLocalPlayer();
    if localPlayerID == -1 then return; end
    local selectionTurn = MOD_CONFIG.StageTurns[m_CurrentStage];
    if not selectionTurn or Game.GetCurrentGameTurn() ~= selectionTurn then
        ClosePanel(false);
        return;
    end
    
    -- 检查是否已选择
    if HasPlayerChosen(localPlayerID, m_CurrentStage) then
        print("  ⚠ 玩家已在当前阶段选择过符文");
        ClosePanel(false);
        return;
    end
    
    print("════════════════════════════════════════════════════════");
    print("║ 显示符文选择面板");
    print("════════════════════════════════════════════════════════");
    
    Controls.Title:SetText("符文选择");

    -- 每次打开都重读权威品质和拥有状态，但同阶段关闭/重开保留原四张卡，
    -- 避免把关闭按钮变成一次免费的整页刷新。
    local reuseCards = m_CardsStage == m_CurrentStage
        and #m_CardData == MOD_CONFIG.CARD_COUNT
        and #m_CardInstances == MOD_CONFIG.CARD_COUNT;
    if not InitializeRunePool() then
        if not m_CurrentRarityCode then
            BeginWaitingForGlobalRarity(m_CurrentStage, not ContextPtr:IsHidden());
        else
            Controls.Title:SetText("当前品质的可用符文不足");
        end
        return;
    end

    if not reuseCards and not InitializeCards() then return; end
    
    -- 阶段标题框已移除（不再设置 StageLabel）
    
    -- 进入原生弹窗队列；关闭时 Dequeue，和时代着力点/创立宗教一致。
    Controls.FullScreenBlocker:SetHide(false);
    if not m_IsQueued then
        if UIManager and UIManager.QueuePopup then
            UIManager:QueuePopup(ContextPtr, PopupPriority.MediumHigh);
            m_IsQueued = true;
        else
            ContextPtr:SetHide(false);
        end
    end
    SignalPendingSelectionChanged();
    
    print("  ✓ 面板已显示");
    print("════════════════════════════════════════════════════════");
end

function ShowPendingStage(requestedStage)
    local localPlayerID = Game.GetLocalPlayer();
    if localPlayerID == nil or localPlayerID < 0 then return; end
    local currentTurn = Game.GetCurrentGameTurn();
    local stage = tonumber(requestedStage)
        or FindEarliestPendingStage(localPlayerID, currentTurn);
    if not stage or stage < 1 or stage > 3
        or HasPlayerChosen(localPlayerID, stage)
        or HasPlayerMissedStage(localPlayerID, stage)
        or not MOD_CONFIG.StageTurns[stage]
        or currentTurn ~= MOD_CONFIG.StageTurns[stage] then
        SignalPendingSelectionChanged();
        return;
    end

    if m_CurrentStage ~= stage then
        m_CurrentStage = stage;
        m_CurrentRarityCode = nil;
        m_CurrentRarity = nil;
        m_AvailableRunes = {};
        m_CardsStage = nil;
        m_CardData = {};
        m_SelectedCardIndex = -1;
    end

    local rarityCode = GetGlobalStageRarity(stage);
    if rarityCode then
        ShowPanel();
    else
        BeginWaitingForGlobalRarity(stage, not ContextPtr:IsHidden());
    end
end

-- ===========================================================================
-- 当回合检查待选阶段；关闭后可在本回合重开，跨回合则立即过期。
-- ===========================================================================
function OnLocalPlayerTurnBegin()
    local localPlayerID = Game.GetLocalPlayer();
    if localPlayerID == -1 then return; end
    local currentTurn = Game.GetCurrentGameTurn();
    local stage = FindEarliestPendingStage(localPlayerID, currentTurn);
    if stage then
        print("Turn2DedicationPopup: 检测到到期待选阶段 " .. tostring(stage));
        ShowPendingStage(stage);
    else
        if m_CardsStage and MOD_CONFIG.StageTurns[m_CardsStage]
            and currentTurn > MOD_CONFIG.StageTurns[m_CardsStage] then
            print("Turn2DedicationPopup: ⏭ 当前符文选择已过期，关闭面板");
            m_WaitingSelection = nil;
            ContextPtr:ClearUpdate();
            SetSelectionControlsDisabled(false);
            ClosePanel(false);
        end
        SignalPendingSelectionChanged();
    end
end

function OnRuneSelectionNotificationActivated(playerID, notificationID, activatedByUser)
    if playerID ~= Game.GetLocalPlayer() or not NotificationManager then return; end
    local typeInfo = GameInfo and GameInfo.Types
        and GameInfo.Types["NOTIFICATION_T2D_RUNE_SELECTION"];
    local notification = NotificationManager.Find(playerID, notificationID);
    if notification and typeInfo and notification:GetType() == typeInfo.Hash then
        ShowPendingStage();
    end
end

-- ===========================================================================
-- 启动初始化
-- ===========================================================================
Initialize();

-- ===========================================================================
-- 注册事件监听
-- ===========================================================================
Events.LocalPlayerTurnBegin.Add(OnLocalPlayerTurnBegin);
if Events.LoadGameViewStateDone then Events.LoadGameViewStateDone.Add(OnLocalPlayerTurnBegin); end
if Events.LocalPlayerChanged then Events.LocalPlayerChanged.Add(OnLocalPlayerTurnBegin); end
if Events.NotificationActivated then
    Events.NotificationActivated.Add(OnRuneSelectionNotificationActivated);
end

-- 暴露给外部调用
LuaEvents.Turn2Dedication_ShowPanel.Add(ShowPendingStage);
LuaEvents.Turn2Dedication_ShowPendingStage.Add(ShowPendingStage);
