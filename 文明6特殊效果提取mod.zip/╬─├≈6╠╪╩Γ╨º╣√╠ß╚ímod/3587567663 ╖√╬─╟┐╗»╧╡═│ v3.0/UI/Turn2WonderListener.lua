-- ===========================================================================
-- 奇观狂魔符文 - 奇观完成监听与广播（UI层）
-- ===========================================================================

print("════════════════════════════════════════════════════════");
print("Turn2DedicationMod: Wonder Listener Loading...");
print("════════════════════════════════════════════════════════");

-- 端口定义（Data Sync API标准）
local PORT_WONDER_COMPLETED = 655002;  -- 奇观完成事件端口

-- ===========================================================================
-- 奇观完成事件处理
-- ===========================================================================
function OnWonderCompleted(locX:number, locY:number, buildingIndex:number, playerIndex:number, cityId:number, iPercentComplete:number, pillaged:number)
    -- 只处理100%完成的奇观
    if iPercentComplete ~= 100 then
        return;
    end
    
    -- 确认是奇观建筑
    local buildingInfo = GameInfo.Buildings[buildingIndex];
    if not buildingInfo or not buildingInfo.IsWonder then
        return;
    end
    
    -- 只广播本地玩家的奇观
    local localPlayerID = Game.GetLocalPlayer();
    if localPlayerID ~= playerIndex then
        return;
    end
    
    -- 检查玩家是否在【任意阶段】选择了奇观狂魔符文（22）
    -- 修复：原先只读从未初始化的 ExposedMembers，导致 choice 恒为 nil、广播从不触发、奇观狂魔完全失效。
    local hasWonderRune = Game.GetProperty("Turn2Dedication_DevRune_P" .. playerIndex .. "_R22") ~= nil
        or Game.GetProperty("Turn2Dedication_BonusRune_P" .. playerIndex .. "_R22") ~= nil;
    for stage = 1, 10 do
        local c = Game.GetProperty("Turn2Dedication_Stage" .. stage .. "_P" .. playerIndex);
        if c == 22 then
            hasWonderRune = true;
            break;
        end
    end
    if not hasWonderRune then
        return;  -- 未选择奇观狂魔符文，不处理
    end
    
    -- 构造广播消息：[T2D_WONDER]玩家ID:城市ID:奇观索引
    local message = "[T2D_WONDER]" .. playerIndex .. ":" .. cityId .. ":" .. buildingIndex;
    
    print("╔════════════════════════════════════════════════════════");
    print("║ 奇观狂魔 - UI层检测到奇观完成");
    print("╚════════════════════════════════════════════════════════");
    print("  玩家ID: " .. playerIndex);
    print("  城市ID: " .. cityId);
    print("  奇观索引: " .. buildingIndex);
    print("  奇观名称: " .. Locale.Lookup(buildingInfo.Name));
    print("  ► 广播消息: " .. message);
    print("  ► 端口: " .. PORT_WONDER_COMPLETED);
    
    -- 通过隐藏聊天广播（不会显示在聊天框）
    if Network and Network.SendChat then
        Network.SendChat(message, ChatTargetTypes.CHATTARGET_ALL, PORT_WONDER_COMPLETED);
        print("  ✓✓✓ 广播成功");
    else
        print("  ❌ Network.SendChat 不可用");
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 初始化
-- ===========================================================================
function Initialize()
    if Events and Events.WonderCompleted then
        Events.WonderCompleted.Add(OnWonderCompleted);
        print("Turn2WonderListener: ✓ 已注册 Events.WonderCompleted");
        print("Turn2WonderListener: ✓ 端口 " .. PORT_WONDER_COMPLETED .. " 已分配");
    else
        print("Turn2WonderListener: ❌ Events.WonderCompleted 不可用");
    end
    print("════════════════════════════════════════════════════════");
end

Initialize();

