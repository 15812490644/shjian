-- ===========================================================================
-- 符文系统：符文图鉴 + 玩家符文总览 + 单人开发者应用
-- - 所有功能控件由 Stack 流式排列
-- - 图鉴按棱彩、黄金、白银排列，每行六枚
-- - 玩家页按领袖列出正式选择与质变奖励
-- ===========================================================================

include("InstanceManager");
include("PopupDialog");
include("Turn2Dedication_RuneRegistry");

local DEV_PORT = 655010;
local DEV_ACK_TIMEOUT = 5.0;
local PLAYER_REFRESH_INTERVAL = 0.75;
local PLAYER_RUNE_COLUMNS = 5;
local PLAYER_RUNE_CELL_HEIGHT = 122;
local PLAYER_RUNE_ROW_PADDING = 8;
local VIEW_CODEX = "codex";
local VIEW_PLAYERS = "players";

local m_sectionIM = nil;
local m_iconIMs = {};
local m_rowIMs = {};
local m_cells = {};
local m_codexBuilt = false;

local m_playerRowIM = nil;
local m_playerRows = {};
local m_playerIDs = {};
local m_playerSignature = nil;
local m_playerRefreshElapsed = 0;

local m_currentView = VIEW_PLAYERS;
local m_devMode = false;
local m_stage = 1;
local m_isMP = false;
local m_pending = nil;
local m_waiting = nil;
local m_requestCounter = 0;
local m_confirmDialog = nil;
local m_launchBtn = {};
local m_launchAttached = false;
local m_warnedIcons = {};
local m_iconCache = {};

local STAGE_NAMES = { "初期", "中期", "后期" };
local CODEX_RUNE_ICON_SIZES = { 68, 64, 80, 52, 40, 32 };
local PLAYER_RUNE_ICON_SIZES = { 52, 40, 32, 64 };
local LEADER_ICON_SIZES = { 64, 55, 50, 45, 32 };

local RARITY_ORDER = {
    {
        key = "prismatic",
        name = "棱彩符文",
        rgb = "255,92,235",
        frameColor = UI.GetColorValue(1.00, 0.36, 0.92, 1.00),
        headerColor = UI.GetColorValue(0.31, 0.12, 0.38, 1.00),
    },
    {
        key = "gold",
        name = "黄金符文",
        rgb = "240,189,64",
        frameColor = UI.GetColorValue(0.94, 0.74, 0.25, 1.00),
        headerColor = UI.GetColorValue(0.34, 0.24, 0.07, 1.00),
    },
    {
        key = "silver",
        name = "白银符文",
        rgb = "174,196,222",
        frameColor = UI.GetColorValue(0.68, 0.77, 0.87, 1.00),
        headerColor = UI.GetColorValue(0.16, 0.24, 0.32, 1.00),
    },
};

local RARITY_STYLE = {};
local SORTED_RUNE_IDS = {};
for _, style in ipairs(RARITY_ORDER) do
    RARITY_STYLE[style.key] = style;
end
for runeID, _ in pairs(T2D_Runes or {}) do
    table.insert(SORTED_RUNE_IDS, runeID);
end
table.sort(SORTED_RUNE_IDS);

-- ===========================================================================
-- 图标与 Tooltip
-- ===========================================================================
local function IconCacheKey(iconName, sizes)
    return tostring(iconName) .. "@" .. table.concat(sizes, ",");
end

local function TryApplyIcon(iconControl, iconName, iconSize)
    if not iconControl or not iconName or not iconControl.TrySetIcon then return false; end
    local ok, applied = pcall(function()
        return iconControl:TrySetIcon(iconName, iconSize);
    end);
    if not ok or applied ~= true then return false; end
    iconControl:SetSizeVal(iconSize, iconSize);
    return true;
end

local function SetAtlasIcon(iconControl, iconName, sizes, fallbackIcon, warningKey)
    if not iconControl then return false; end
    sizes = sizes or RUNE_ICON_SIZES;

    -- 不直接调用 IconManager.FindIconAtlas：不同 UI 上下文中的原生绑定
    -- 会把错误调用转换为空纹理指针，严重时直接触发访问冲突。
    -- Image:TrySetIcon 是原版界面使用的安全入口，失败时只返回 false。
    local cacheKey = IconCacheKey(iconName, sizes);
    local cachedSize = m_iconCache[cacheKey];
    if type(cachedSize) == "number" and TryApplyIcon(iconControl, iconName, cachedSize) then
        return true;
    end
    if cachedSize ~= false then
        for _, iconSize in ipairs(sizes) do
            if TryApplyIcon(iconControl, iconName, iconSize) then
                m_iconCache[cacheKey] = iconSize;
                return true;
            end
        end
        m_iconCache[cacheKey] = false;
    end

    local key = warningKey or iconName or "<nil>";
    if not m_warnedIcons[key] then
        m_warnedIcons[key] = true;
        print("UIWARNING: Turn2DedicationCodex 找不到图标：" .. tostring(iconName));
    end

    local fallback = fallbackIcon or "ICON_CIVILIZATION_UNKNOWN";
    local fallbackKey = IconCacheKey(fallback, sizes);
    local fallbackSize = m_iconCache[fallbackKey];
    if type(fallbackSize) == "number" and TryApplyIcon(iconControl, fallback, fallbackSize) then
        return true;
    end
    for _, iconSize in ipairs(sizes) do
        if TryApplyIcon(iconControl, fallback, iconSize) then
            m_iconCache[fallbackKey] = iconSize;
            return true;
        end
    end
    m_iconCache[fallbackKey] = false;
    return false;
end

local function SetRuneIcon(iconControl, runeID, rune, sizes)
    return SetAtlasIcon(
        iconControl,
        rune and rune.icon,
        sizes or PLAYER_RUNE_ICON_SIZES,
        "ICON_CIVILIZATION_UNKNOWN",
        "rune:" .. tostring(runeID));
end

local function RuneTooltip(rune, isTransmuted)
    local style = RARITY_STYLE[rune.rarity] or { rgb = "255,255,255" };
    local prefix = isTransmuted and "质变：" or "";
    return "[COLOR:" .. style.rgb .. ",255]" .. prefix
        .. tostring(rune.name or "") .. "[ENDCOLOR]"
        .. "[NEWLINE][NEWLINE]" .. tostring(rune.effect or "");
end

local function RegisterRuneHover(button, nameLabel, glow, tooltip)
    button:SetToolTipString(tooltip);
    if nameLabel then nameLabel:SetToolTipString(tooltip); end
    button:RegisterCallback(Mouse.eMouseEnter, function()
        glow:SetHide(false);
        if UI and UI.PlaySound then UI.PlaySound("Main_Menu_Mouse_Over"); end
    end);
    button:RegisterCallback(Mouse.eMouseExit, function()
        glow:SetHide(true);
    end);
end

local function PopulateCodexRuneCell(cell, runeID)
    local rune = T2D_Runes[runeID];
    local style = RARITY_STYLE[rune.rarity] or RARITY_STYLE.silver;
    SetRuneIcon(cell.RuneIcon, runeID, rune, CODEX_RUNE_ICON_SIZES);
    cell.RuneBorder:SetColor(style.frameColor);
    cell.RuneGlow:SetColor(style.frameColor);
    cell.RuneGlow:SetHide(true);
    cell.RuneName:SetText(rune.name or ("符文" .. tostring(runeID)));
    RegisterRuneHover(cell.RuneButton, cell.RuneName, cell.RuneGlow, RuneTooltip(rune, false));
    cell.RuneButton:RegisterCallback(Mouse.eLClick, function() OnGetClicked(runeID); end);
end

-- ===========================================================================
-- 符文图鉴
-- ===========================================================================
function BuildCodex()
    if m_codexBuilt then return; end

    m_sectionIM = InstanceManager:new("RaritySection", "SectionRoot", Controls.CodexStack);
    m_iconIMs = {};
    m_rowIMs = {};
    m_cells = {};

    local byRarity = { prismatic = {}, gold = {}, silver = {} };
    for runeID, rune in pairs(T2D_Runes) do
        local bucket = byRarity[rune.rarity];
        if bucket then table.insert(bucket, runeID); end
    end

    for _, style in ipairs(RARITY_ORDER) do
        local runeIDs = byRarity[style.key];
        table.sort(runeIDs);

        local section = m_sectionIM:GetInstance();
        section.SectionTitle:SetText(style.name);
        section.SectionHeader:SetColor(style.headerColor);
        section.SectionAccent:SetColor(style.frameColor);

        local rowIM = InstanceManager:new("RuneGridRow", "RowRoot", section.RuneRows);
        m_rowIMs[style.key] = rowIM;
        local currentRow = nil;
        local currentIconIM = nil;

        for index, runeID in ipairs(runeIDs) do
            if ((index - 1) % 6) == 0 then
                if currentRow then currentRow.RowRoot:CalculateSize(); end
                currentRow = rowIM:GetInstance();
                currentIconIM = InstanceManager:new("RuneIconCell", "CellRoot", currentRow.RowRoot);
                table.insert(m_iconIMs, currentIconIM);
            end

            local cell = currentIconIM:GetInstance();
            PopulateCodexRuneCell(cell, runeID);
            table.insert(m_cells, { inst = cell, runeID = runeID });
        end
        if currentRow then currentRow.RowRoot:CalculateSize(); end

        section.RuneRows:CalculateSize();
        section.SectionRoot:CalculateSize();
    end

    Controls.CodexStack:CalculateSize();
    Controls.CodexScroll:CalculateSize();
    m_codexBuilt = true;
    print("Turn2DedicationCodex: 图鉴已构建，符文数=" .. tostring(#m_cells)
        .. "（棱彩=" .. tostring(#byRarity.prismatic)
        .. "，黄金=" .. tostring(#byRarity.gold)
        .. "，白银=" .. tostring(#byRarity.silver) .. "）");
end

-- ===========================================================================
-- 玩家符文总览
-- ===========================================================================
local function GetMajorPlayerIDs()
    local playerObjects = nil;
    if PlayerManager and PlayerManager.GetWasEverAliveMajors then
        playerObjects = PlayerManager.GetWasEverAliveMajors();
    elseif PlayerManager and PlayerManager.GetAliveMajors then
        playerObjects = PlayerManager.GetAliveMajors();
    end

    local ids = {};
    local seen = {};
    for _, player in ipairs(playerObjects or {}) do
        local playerID = player and player.GetID and player:GetID() or -1;
        if playerID >= 0 and not seen[playerID] and PlayerConfigurations[playerID] then
            seen[playerID] = true;
            table.insert(ids, playerID);
        end
    end

    local localPlayerID = Game.GetLocalPlayer();
    table.sort(ids, function(firstID, secondID)
        if firstID == localPlayerID then return true; end
        if secondID == localPlayerID then return false; end
        local firstAlive = Players[firstID] and Players[firstID]:IsAlive();
        local secondAlive = Players[secondID] and Players[secondID]:IsAlive();
        if firstAlive ~= secondAlive then return firstAlive; end
        return firstID < secondID;
    end);
    return ids;
end

local function SamePlayerRoster(first, second)
    if #first ~= #second then return false; end
    for index, playerID in ipairs(first) do
        if second[index] ~= playerID then return false; end
    end
    return true;
end

local function ReadRuneProperty(propertyKey)
    local raw = Game.GetProperty(propertyKey);
    local runeID = raw ~= nil and tonumber(raw) or nil;
    if runeID and T2D_Runes[runeID] then return runeID; end
    return nil;
end

local function GetPlayerRuneEntries(playerID)
    local entries = {};
    for stage = 1, 3 do
        local runeID = ReadRuneProperty("Turn2Dedication_Stage" .. stage .. "_P" .. playerID);
        if runeID then
            table.insert(entries, {
                runeID = runeID,
                isTransmuted = false,
                order = stage * 2,
            });
        end
    end

    for _, runeID in ipairs(SORTED_RUNE_IDS) do
        local bonusKey = "Turn2Dedication_BonusRune_P" .. playerID .. "_R" .. runeID;
        if Game.GetProperty(bonusKey) ~= nil then
            local stageKey = "Turn2Dedication_BonusRuneStage_P" .. playerID .. "_R" .. runeID;
            local rawStage = Game.GetProperty(stageKey);
            local bonusStage = rawStage ~= nil and tonumber(rawStage) or 99;
            table.insert(entries, {
                runeID = runeID,
                isTransmuted = true,
                -- 质变结果紧跟触发它的正式阶段符文，仍保持同阶段内 ID 稳定排序。
                order = bonusStage * 2 + 1,
            });
        end
    end
    table.sort(entries, function(first, second)
        if first.order ~= second.order then return first.order < second.order; end
        if first.isTransmuted ~= second.isTransmuted then return not first.isTransmuted; end
        return first.runeID < second.runeID;
    end);
    return entries;
end

local function CollectPlayerOverviewData(playerIDs)
    local data = {};
    local signature = {};
    for _, playerID in ipairs(playerIDs) do
        local entries = GetPlayerRuneEntries(playerID);
        data[playerID] = entries;
        local isAlive = Players[playerID] and Players[playerID]:IsAlive();
        table.insert(signature, "P" .. tostring(playerID) .. (isAlive and "A" or "D"));
        for _, entry in ipairs(entries) do
            table.insert(signature, (entry.isTransmuted and "B" or "S")
                .. tostring(entry.runeID) .. "@" .. tostring(entry.order));
        end
    end
    return data, table.concat(signature, ":");
end

local function PopulateLeader(row, playerID)
    local config = PlayerConfigurations[playerID];
    local leaderType = config and config.GetLeaderTypeName and config:GetLeaderTypeName() or nil;
    local leaderNameKey = config and config.GetLeaderName and config:GetLeaderName() or nil;
    local leaderName = leaderNameKey and Locale.Lookup(leaderNameKey) or "未知领袖";
    local iconName = leaderType and ("ICON_" .. leaderType) or "ICON_LEADER_DEFAULT";

    SetAtlasIcon(
        row.LeaderPortrait,
        iconName,
        LEADER_ICON_SIZES,
        "ICON_LEADER_DEFAULT",
        "leader:" .. tostring(leaderType));
    row.LeaderName:SetText(leaderName);
    row.LeaderPortrait:SetToolTipString(leaderName);

    local backColor, frontColor = UI.GetPlayerColors(playerID);
    row.LeaderFrame:SetColor(frontColor or backColor or UI.GetColorValue(1, 1, 1, 1));
    local isAlive = Players[playerID] and Players[playerID]:IsAlive();
    row.PlayerRowRoot:SetAlpha(isAlive and 1.0 or 0.55);
end

local function PopulatePlayerRuneCell(cell, entry)
    local rune = T2D_Runes[entry.runeID];
    local style = RARITY_STYLE[rune.rarity] or RARITY_STYLE.silver;
    local displayName = (entry.isTransmuted and "质变：" or "")
        .. tostring(rune.name or ("符文" .. tostring(entry.runeID)));

    SetRuneIcon(cell.RuneIcon, entry.runeID, rune, PLAYER_RUNE_ICON_SIZES);
    cell.RuneBorder:SetColor(style.frameColor);
    cell.RuneGlow:SetColor(style.frameColor);
    cell.RuneGlow:SetHide(true);
    cell.RuneName:SetText(displayName);
    RegisterRuneHover(
        cell.RuneButton,
        cell.RuneName,
        cell.RuneGlow,
        RuneTooltip(rune, entry.isTransmuted));
end

local function BuildPlayerRows(playerIDs)
    if not m_playerRowIM then
        m_playerRowIM = InstanceManager:new("PlayerRuneRow", "PlayerRowRoot", Controls.PlayerRuneStack);
    end

    for _, rowData in pairs(m_playerRows) do
        rowData.runeIM:ResetInstances();
        rowData.emptyIM:ResetInstances();
    end
    m_playerRowIM:ResetInstances();
    m_playerRows = {};
    m_playerIDs = {};

    for _, playerID in ipairs(playerIDs) do
        local row = m_playerRowIM:GetInstance();
        local rowData = {
            inst = row,
            runeIM = InstanceManager:new("PlayerRuneCell", "RuneCellRoot", row.PlayerRuneFlow),
            emptyIM = InstanceManager:new("PlayerRuneEmpty", "EmptyRoot", row.PlayerRuneFlow),
        };
        PopulateLeader(row, playerID);
        m_playerRows[playerID] = rowData;
        table.insert(m_playerIDs, playerID);
    end
end

function RefreshPlayerOverview(forceRefresh)
    local playerIDs = GetMajorPlayerIDs();
    local data, signature = CollectPlayerOverviewData(playerIDs);
    if not forceRefresh and SamePlayerRoster(playerIDs, m_playerIDs)
        and signature == m_playerSignature then
        return;
    end

    if not SamePlayerRoster(playerIDs, m_playerIDs) then
        BuildPlayerRows(playerIDs);
    end

    for _, playerID in ipairs(playerIDs) do
        local rowData = m_playerRows[playerID];
        if rowData then
            PopulateLeader(rowData.inst, playerID);
            rowData.runeIM:ResetInstances();
            rowData.emptyIM:ResetInstances();

            local entries = data[playerID] or {};
            if #entries == 0 then
                local empty = rowData.emptyIM:GetInstance();
                empty.EmptyLabel:SetText("尚未选择符文");
            else
                for _, entry in ipairs(entries) do
                    local cell = rowData.runeIM:GetInstance();
                    PopulatePlayerRuneCell(cell, entry);
                end
            end

            -- Wrap Stack 的高度由内容行数决定；显式写回高度后，外层 auto Grid
            -- 会按真实高度扩展，避免六枚以上符文换行时与下一位玩家重叠。
            local wrappedRows = math.max(1, math.ceil(#entries / PLAYER_RUNE_COLUMNS));
            local contentHeight = wrappedRows * PLAYER_RUNE_CELL_HEIGHT
                + (wrappedRows - 1) * PLAYER_RUNE_ROW_PADDING;

            -- CalculateSize 会按当前子项缩窄横向 Stack；计算完子项位置后必须恢复
            -- 固定列宽，才能保持“左侧领袖、右侧符文”的版式。
            rowData.inst.PlayerRuneFlow:CalculateSize();
            rowData.inst.PlayerRuneFlow:SetSizeX(730);
            rowData.inst.PlayerRuneFlow:SetSizeY(contentHeight);
            rowData.inst.PlayerRuneFlow:ReprocessAnchoring();

            -- 外层横向 Stack 只看固定宽度视口，不受内部符文数量影响。
            rowData.inst.PlayerRuneViewport:SetSizeX(730);
            rowData.inst.PlayerRuneViewport:SetSizeY(contentHeight);
            rowData.inst.PlayerRuneViewport:ReprocessAnchoring();

            rowData.inst.PlayerRowFlow:CalculateSize();
            rowData.inst.PlayerRowFlow:SetSizeX(898);
            rowData.inst.PlayerRowFlow:SetSizeY(contentHeight);
            rowData.inst.PlayerRowFlow:ReprocessAnchoring();

            -- Grid 没有 CalculateSize；直接设置实际高度并重新处理锚点。
            rowData.inst.PlayerRowRoot:SetSizeY(contentHeight + 14);
            rowData.inst.PlayerRowRoot:ReprocessAnchoring();
        end
    end

    Controls.PlayerRuneStack:CalculateSize();
    Controls.PlayerRuneScroll:CalculateSize();
    m_playerSignature = signature;
    print("Turn2DedicationCodex: 玩家符文页已刷新，玩家数=" .. tostring(#playerIDs));
end

-- ===========================================================================
-- 页面、开发者按钮与统一更新循环
-- ===========================================================================
local EnsureContextUpdate;

local function RefreshPageTabs()
    local isCodex = m_currentView == VIEW_CODEX;
    Controls.CodexTabButton:SetHide(isCodex);
    Controls.CodexTabSelected:SetHide(not isCodex);
    Controls.PlayersTabButton:SetHide(not isCodex);
    Controls.PlayersTabSelected:SetHide(isCodex);
end

function RefreshDevButtons()
    Controls.DevModeLabel:SetText("开发者模式：" .. (m_devMode and "开" or "关"));
    Controls.StageButton:SetHide(m_isMP or not m_devMode);
    Controls.StageLabel:SetText("应用阶段：" .. (STAGE_NAMES[m_stage] or tostring(m_stage)));
    Controls.DevControls:SetHide(m_isMP);
    Controls.DevControls:CalculateSize();

    for _, cell in ipairs(m_cells) do
        cell.inst.RuneButton:SetDisabled(false);
    end
end

function SwitchView(viewName, suppressSound)
    if viewName ~= VIEW_CODEX and viewName ~= VIEW_PLAYERS then return; end
    m_currentView = viewName;
    local isCodex = viewName == VIEW_CODEX;
    Controls.RuneCodexView:SetHide(not isCodex);
    Controls.PlayerRunesView:SetHide(isCodex);
    RefreshPageTabs();

    if isCodex then
        BuildCodex();
        Controls.CodexStack:CalculateSize();
        Controls.CodexScroll:CalculateSize();
    else
        RefreshPlayerOverview(true);
        m_playerRefreshElapsed = 0;
    end

    if not suppressSound and UI and UI.PlaySound then UI.PlaySound("Play_UI_Click"); end
    EnsureContextUpdate();
end

function OnDevModeToggle()
    if m_isMP then return; end
    m_devMode = not m_devMode;
    RefreshDevButtons();
end

function OnStageCycle()
    m_stage = (m_stage % 3) + 1;
    RefreshDevButtons();
end

-- ===========================================================================
-- 开发者应用 + 原生确认框
-- ===========================================================================
function HideConfirm()
    m_pending = nil;
    if m_confirmDialog and m_confirmDialog:IsOpen() then m_confirmDialog:Close(); end
end

function OnGetClicked(runeID)
    if not m_devMode or m_currentView ~= VIEW_CODEX then return; end
    if m_waiting then
        Controls.CodexStatus:SetText("正在等待上一条开发者请求完成……");
        return;
    end

    local conflictID = T2D_FindOwnedConflict(Game.GetLocalPlayer(), runeID);
    if conflictID then
        local targetRune = T2D_GetRune(runeID);
        local conflictRune = T2D_GetRune(conflictID);
        Controls.CodexStatus:SetText("无法获得：【" .. ((targetRune and targetRune.name) or tostring(runeID))
            .. "】与已拥有的【" .. ((conflictRune and conflictRune.name) or tostring(conflictID)) .. "】互斥");
        if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
        return;
    end

    m_pending = { runeID = runeID, stage = m_stage, rarity = T2D_GetRarity(runeID) };
    local rune = T2D_GetRune(runeID);
    local name = (rune and rune.name) or ("符文" .. runeID);
    local text = "确认立即获得【" .. name .. "】（"
        .. (STAGE_NAMES[m_stage] or tostring(m_stage)) .. "阶段）的效果？";
    m_confirmDialog:ShowOkCancelDialog(text, OnConfirmYes, HideConfirm);
end

local function FinishDeveloperRequest(status)
    if not m_waiting then return; end
    local name = m_waiting.name;
    if status == "APPLIED" then
        Controls.CodexStatus:SetText("已应用：【" .. name .. "】✓  效果已立即施加");
        if UI and UI.PlaySound then UI.PlaySound("Confirm_Bed_Positive"); end
    elseif status == "DEFERRED" then
        Controls.CodexStatus:SetText("已获得：【" .. name .. "】✓  效果等待对应条件触发");
        if UI and UI.PlaySound then UI.PlaySound("Confirm_Bed_Positive"); end
    elseif status == "DUPLICATE" then
        Controls.CodexStatus:SetText("已拥有：【" .. name .. "】；未重复叠加效果");
    elseif status == "CONFLICT" then
        Controls.CodexStatus:SetText("应用被拒绝：【" .. name .. "】与已拥有符文互斥");
        if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
    elseif status == "RETRY" then
        Controls.CodexStatus:SetText("暂未应用：【" .. name .. "】；前置条件尚未满足，可稍后重试");
    else
        Controls.CodexStatus:SetText("应用失败：【" .. name .. "】；请检查 Lua.log 后重试");
    end
    m_waiting = nil;
    RefreshDevButtons();
    EnsureContextUpdate();
end

local function CheckDeveloperAck(deltaTime)
    if not m_waiting then return; end
    m_waiting.elapsed = m_waiting.elapsed + (deltaTime or 0);
    local pid = Game.GetLocalPlayer();
    local rawAck = Game.GetProperty("Turn2Dedication_DevAck_P" .. pid);
    if rawAck ~= nil then
        local nonce, runeID, status = tostring(rawAck):match("^([%-]?%d+):(%d+):([A-Z]+)$");
        if tonumber(nonce) == m_waiting.nonce and tonumber(runeID) == m_waiting.runeID then
            FinishDeveloperRequest(status);
            return;
        end
    end

    if m_waiting and m_waiting.elapsed >= DEV_ACK_TIMEOUT then FinishDeveloperRequest("ERROR"); end
end

local function NextDeveloperNonce()
    m_requestCounter = (m_requestCounter % 999) + 1;
    local elapsed = (UI and UI.GetElapsedTime and UI.GetElapsedTime()) or 0;
    local elapsedMs = math.floor(math.max(0, elapsed) * 1000);
    -- string.format("%d") 在 Civ VI 中按 32 位有符号整数处理。先取模再
    -- 乘，保证 nonce 始终位于 1,000,000,000 以下，不再溢出为 -2147483648。
    return (elapsedMs % 1000000) * 1000 + m_requestCounter;
end

function OnConfirmYes()
    if m_pending then
        local conflictID = T2D_FindOwnedConflict(Game.GetLocalPlayer(), m_pending.runeID);
        if conflictID then
            local targetRune = T2D_GetRune(m_pending.runeID);
            local conflictRune = T2D_GetRune(conflictID);
            Controls.CodexStatus:SetText("无法获得：【" .. ((targetRune and targetRune.name) or tostring(m_pending.runeID))
                .. "】与已拥有的【" .. ((conflictRune and conflictRune.name) or tostring(conflictID)) .. "】互斥");
            if UI and UI.PlaySound then UI.PlaySound("Play_UI_Notification_Negative"); end
            HideConfirm();
            RefreshDevButtons();
            return;
        end

        local rarityCode = (T2D_RARITY_CODE and T2D_RARITY_CODE[m_pending.rarity]) or 1;
        local playerID = Game.GetLocalPlayer();
        local nonce = NextDeveloperNonce();
        local msg = string.format(
            "[T2D_DEV]%d:%d:%d:%d:%d",
            playerID,
            m_pending.runeID,
            m_pending.stage,
            rarityCode,
            nonce);
        if Network and Network.SendChat then
            local rune = T2D_GetRune(m_pending.runeID);
            m_waiting = {
                nonce = nonce,
                runeID = m_pending.runeID,
                name = (rune and rune.name) or tostring(m_pending.runeID),
                elapsed = 0,
            };
            Network.SendChat(msg, ChatTargetTypes.CHATTARGET_ALL, DEV_PORT);
            print("Turn2DedicationCodex: 开发者应用 → " .. msg);
            Controls.CodexStatus:SetText("正在应用：【" .. m_waiting.name .. "】……");
            EnsureContextUpdate();
        else
            Controls.CodexStatus:SetText("应用失败：Network.SendChat 不可用");
        end
    end
    HideConfirm();
end

function OnContextUpdate(deltaTime)
    CheckDeveloperAck(deltaTime);
    if m_currentView == VIEW_PLAYERS and not Controls.CodexPanel:IsHidden() then
        m_playerRefreshElapsed = m_playerRefreshElapsed + (deltaTime or 0);
        if m_playerRefreshElapsed >= PLAYER_REFRESH_INTERVAL then
            m_playerRefreshElapsed = 0;
            RefreshPlayerOverview(false);
        end
    end

    local needsPlayerRefresh = m_currentView == VIEW_PLAYERS and not Controls.CodexPanel:IsHidden();
    if not m_waiting and not needsPlayerRefresh then ContextPtr:ClearUpdate(); end
end

EnsureContextUpdate = function()
    local needsPlayerRefresh = m_currentView == VIEW_PLAYERS and not Controls.CodexPanel:IsHidden();
    if m_waiting or needsPlayerRefresh then
        ContextPtr:SetUpdate(OnContextUpdate);
    else
        ContextPtr:ClearUpdate();
    end
end

-- ===========================================================================
-- 面板开关与输入
-- ===========================================================================
local function GetConfiguredSelectionTurn(stage)
    local defaults = { [1] = 2, [2] = 25, [3] = 41 };
    local keys = {
        [1] = "TURN2_STAGE1_TURN",
        [2] = "TURN2_STAGE2_TURN",
        [3] = "TURN2_STAGE3_TURN",
    };
    local turn = defaults[stage];
    if turn and GameConfiguration and GameConfiguration.GetValue then
        turn = tonumber(GameConfiguration.GetValue(keys[stage])) or turn;
    end
    if not turn or turn <= 0 then return nil; end
    return turn;
end

local function FindPendingSelectionStage()
    local playerID = Game.GetLocalPlayer();
    if playerID == nil or playerID < 0 then return nil; end
    local currentTurn = Game.GetCurrentGameTurn();
    for stage = 1, 3 do
        local selectionTurn = GetConfiguredSelectionTurn(stage);
        local stageKey = "Turn2Dedication_Stage" .. tostring(stage) .. "_P" .. tostring(playerID);
        local missedKey = "Turn2Dedication_Stage" .. tostring(stage)
            .. "_Missed_P" .. tostring(playerID);
        if selectionTurn and currentTurn == selectionTurn
            and Game.GetProperty(stageKey) == nil
            and Game.GetProperty(missedKey) == nil then
            return stage;
        end
    end
    return nil;
end

local function RefreshLaunchButtonState()
    if not m_launchAttached or not m_launchBtn.LaunchItemButton then return; end
    local pendingStage = FindPendingSelectionStage();
    if m_launchBtn.AlertIndicator then
        m_launchBtn.AlertIndicator:SetHide(pendingStage == nil);
    end
    if pendingStage then
        m_launchBtn.LaunchItemButton:SetToolTipString(
            "有尚未完成的符文选择（" .. tostring(STAGE_NAMES[pendingStage] or pendingStage)
                .. "，仅本回合有效）");
    else
        m_launchBtn.LaunchItemButton:SetToolTipString("符文系统");
    end
end

local function OnLaunchButtonClicked()
    local pendingStage = FindPendingSelectionStage();
    if pendingStage and LuaEvents and LuaEvents.Turn2Dedication_ShowPendingStage then
        LuaEvents.Turn2Dedication_ShowPendingStage(pendingStage);
        return;
    end
    ToggleCodex();
end

function ToggleCodex()
    local willShow = Controls.CodexPanel:IsHidden();
    if willShow then
        m_isMP = GameConfiguration and GameConfiguration.IsAnyMultiplayer
            and GameConfiguration.IsAnyMultiplayer();
        if m_isMP then m_devMode = false; end
        Controls.CodexBlocker:SetHide(false);
        Controls.CodexPanel:SetHide(false);
        RefreshDevButtons();
        SwitchView(m_currentView, true);
        if UI and UI.PlaySound then UI.PlaySound("Play_UI_Click"); end
    else
        CloseCodex();
    end
end

function CloseCodex()
    HideConfirm();
    Controls.CodexBlocker:SetHide(true);
    Controls.CodexPanel:SetHide(true);
    EnsureContextUpdate();
end

function InputHandler(uiMsg, wParam, lParam)
    if m_confirmDialog and m_confirmDialog:IsOpen() then
        if uiMsg == KeyEvents.KeyUp then
            if wParam == Keys.VK_ESCAPE then
                m_confirmDialog:ActivateCommand(PopupDialog.COMMAND_CANCEL);
            elseif wParam == Keys.VK_RETURN then
                m_confirmDialog:ActivateCommand(PopupDialog.COMMAND_CONFIRM);
            end
        end
        return true;
    end

    if uiMsg == KeyEvents.KeyUp and wParam == Keys.VK_ESCAPE and not Controls.CodexPanel:IsHidden() then
        CloseCodex();
        return true;
    end
    return false;
end

local function OnLocalPlayerTurnBegin()
    RefreshLaunchButtonState();
    if m_currentView == VIEW_PLAYERS and not Controls.CodexPanel:IsHidden() then
        RefreshPlayerOverview(true);
    end
end

-- ===========================================================================
-- 启动栏按钮
-- ===========================================================================
function AttachLaunchButton()
    if m_launchAttached then return; end
    local buttonStack = ContextPtr:LookUpControl("/InGame/LaunchBar/ButtonStack");
    if not buttonStack then
        print("Turn2DedicationCodex: ⚠ 未找到 /InGame/LaunchBar/ButtonStack，按钮挂载跳过");
        return;
    end

    ContextPtr:BuildInstanceForControl("LaunchBarItem", m_launchBtn, buttonStack);
    m_launchBtn.LaunchItemButton:RegisterCallback(Mouse.eLClick, OnLaunchButtonClicked);

    ContextPtr:BuildInstanceForControl("LaunchBarPinInstance", {}, buttonStack);
    buttonStack:CalculateSize();
    local width = buttonStack:GetSizeX();
    local backing = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBacking");
    if backing then backing:SetSizeX(width + 116); end
    local tile = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBackingTile");
    if tile then tile:SetSizeX(width - 20); end
    if LuaEvents and LuaEvents.LaunchBar_Resize then LuaEvents.LaunchBar_Resize(width); end

    m_launchAttached = true;
    RefreshLaunchButtonState();
    print("Turn2DedicationCodex: ✓ 启动栏「符文系统」按钮已挂载");
end

-- ===========================================================================
-- 初始化
-- ===========================================================================
function Initialize()
    m_confirmDialog = PopupDialog:new("Turn2DedicationCodexConfirm");

    Controls.CodexClose:RegisterCallback(Mouse.eLClick, CloseCodex);
    Controls.DevModeButton:RegisterCallback(Mouse.eLClick, OnDevModeToggle);
    Controls.StageButton:RegisterCallback(Mouse.eLClick, OnStageCycle);
    Controls.CodexTabButton:RegisterCallback(Mouse.eLClick, function() SwitchView(VIEW_CODEX); end);
    Controls.PlayersTabButton:RegisterCallback(Mouse.eLClick, function() SwitchView(VIEW_PLAYERS); end);

    Controls.CodexTitle:SetText("符文系统");
    Controls.CodexTabButton:SetText("符文图鉴");
    Controls.CodexTabSelected:SetText("符文图鉴");
    Controls.PlayersTabButton:SetText("玩家符文");
    Controls.PlayersTabSelected:SetText("玩家符文");
    Controls.DevModeButton:SetToolTipString("单人游戏中可点击图鉴符文并立即应用效果");
    Controls.StageButton:SetToolTipString("切换开发者应用时使用的符文阶段");

    RefreshPageTabs();
    ContextPtr:SetInputHandler(InputHandler, true);
    ContextPtr:SetHide(false);

    Events.LoadGameViewStateDone.Add(AttachLaunchButton);
    if Events.LocalPlayerTurnBegin then Events.LocalPlayerTurnBegin.Add(OnLocalPlayerTurnBegin); end
    if Events.LocalPlayerChanged then Events.LocalPlayerChanged.Add(OnLocalPlayerTurnBegin); end
    if LuaEvents and LuaEvents.Turn2Dedication_PendingChanged then
        LuaEvents.Turn2Dedication_PendingChanged.Add(RefreshLaunchButtonState);
    end
    print("Turn2DedicationCodex: 初始化完成");
end

Initialize();
