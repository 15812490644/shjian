-- ===========================================================================
-- 第二回合着力点游戏逻辑脚本
-- 处理玩家选择后的游戏效果
-- ===========================================================================

-- ===========================================================================
-- 全局变量定义（必须在所有函数之前！）
-- ===========================================================================
local g_PlayerDedications:table = {};  -- 记录每个玩家的选择
local g_ProcessedPlayers:table = {};   -- 记录已处理的玩家
local g_LastCheckedEra:number = -1;    -- 上次检查的时代索引（用于轮询检测）
local g_CityWonderCounts:table = {};   -- 奇观狂魔：记录每个城市的奇观数量（用于计算产出加成）
local g_FeudalBudPlayers:table = {};   -- 封建萌芽：记录选择该符文的玩家及其时代信息
local g_CommercialMonopolyPlayers:table = {};  -- 商业垄断：记录选择该符文的玩家
local g_WisdomLightPlayers:table = {};  -- 智慧之光：记录选择该符文的玩家及升级状态
local T2D_HandleCartographyCityReward = nil; -- 定义在第三批白银辅助区，供早期城市事件调用

-- ===========================================================================
-- 近战单位列表（按科技递进，战斗力递增）
-- ===========================================================================
local MELEE_UNITS:table = {
    -- 格式：{单位类型, 所需科技, 战斗力}
    {Type = "UNIT_WARRIOR", Tech = nil, Combat = 20},
    {Type = "UNIT_SPEARMAN", Tech = "TECH_BRONZE_WORKING", Combat = 25},
    {Type = "UNIT_SWORDSMAN", Tech = "TECH_IRON_WORKING", Combat = 36},
    {Type = "UNIT_MAN_AT_ARMS", Tech = "TECH_APPRENTICESHIP", Combat = 45},
    {Type = "UNIT_MUSKETMAN", Tech = "TECH_MILITARY_SCIENCE", Combat = 55},
    {Type = "UNIT_INFANTRY", Tech = "TECH_REPLACEABLE_PARTS", Combat = 70},
    {Type = "UNIT_MECHANIZED_INFANTRY", Tech = "TECH_SYNTHETIC_MATERIALS", Combat = 85},
};

-- ===========================================================================
-- 获取玩家能生产的最强近战单位
-- ===========================================================================
function GetStrongestMeleeUnit(pPlayer:table)
    if not pPlayer.GetTechs then
        return "UNIT_WARRIOR";
    end
    
    local pPlayerTechs = pPlayer:GetTechs();
    if not pPlayerTechs then
        return "UNIT_WARRIOR";
    end
    
    local bestUnit:string = "UNIT_WARRIOR";
    local bestCombat:number = 20;
    
    for i = #MELEE_UNITS, 1, -1 do
        local unitData = MELEE_UNITS[i];
        local canProduce:boolean = false;
        
        if unitData.Tech == nil then
            canProduce = true;
        else
            if GameInfo and GameInfo.Technologies then
                local techIndex = GameInfo.Technologies[unitData.Tech];
                if techIndex and pPlayerTechs:HasTech(techIndex.Index) then
                    canProduce = true;
                end
            end
        end
        
        if canProduce then
            bestUnit = unitData.Type;
            bestCombat = unitData.Combat;
            break;
        end
    end
    
    return bestUnit;
end

-- ===========================================================================
-- 获取玩家当前时代
-- ===========================================================================
function GetCurrentEra(pPlayer:table)
    if not pPlayer or not pPlayer.GetEras then
        return -1;
    end
    
    local pEras = pPlayer:GetEras();
    if not pEras or not pEras.GetCurrentEra then
        return -1;
    end
    
    return pEras:GetCurrentEra();
end

-- ===========================================================================
-- 获取玩家商路数量
-- ===========================================================================
function GetTradeRouteCount(pPlayer:table)
    if not pPlayer or not pPlayer.GetTrade then
        return 0;
    end
    
    local pTrade = pPlayer:GetTrade();
    if not pTrade or not pTrade.GetOutgoingRoutes then
        return 0;
    end
    
    local routes = pTrade:GetOutgoingRoutes();
    if not routes then
        return 0;
    end
    
    local count = 0;
    for _, route in ipairs(routes) do
        if route then
            count = count + 1;
        end
    end
    
    return count;
end

-- ===========================================================================
-- 在城市附近生成单位
-- ===========================================================================
function CreateUnitNearCity(pPlayer:table, pCity:table, unitType:string)
    if not pPlayer.GetID or not pCity.GetX or not pCity.GetY then
        return false;
    end
    
    local cityX:number = pCity:GetX();
    local cityY:number = pCity:GetY();
    
    if not GameInfo or not GameInfo.Units or not GameInfo.Units[unitType] then
        return false;
    end
    
    local unitIndex = GameInfo.Units[unitType].Index;
    
    if not pPlayer.GetUnits then
        return false;
    end
    
    local pPlayerUnits = pPlayer:GetUnits();
    if not pPlayerUnits or not pPlayerUnits.Create then
        return false;
    end
    
    local pUnit = pPlayerUnits:Create(unitIndex, cityX, cityY);
    
    if pUnit then
        return true;
    else
        local directions = {
            {0, 1}, {1, 0}, {1, -1}, {0, -1}, {-1, 0}, {-1, 1}
        };
        
        for _, dir in ipairs(directions) do
            local newX = cityX + dir[1];
            local newY = cityY + dir[2];
            
            pUnit = pPlayerUnits:Create(unitIndex, newX, newY);
            if pUnit then
                return true;
            end
        end
        
        return false;
    end
end

-- ===========================================================================
-- 通用辅助函数：获取玩家的符文选择（支持任意数量的阶段）
-- 这个函数会自动遍历所有可能的阶段，找到玩家选择的符文
-- ===========================================================================
function GetPlayerDedicationChoice(playerID:number, targetStage:number)
    -- 如果指定了阶段，只返回该阶段的选择
    if targetStage then
        local stageKey = "Turn2Dedication_Stage" .. targetStage .. "_P" .. playerID;
        local choice = Game.GetProperty(stageKey);
        if choice then
            return choice;
        end
        if g_PlayerDedications[playerID] and g_PlayerDedications[playerID][targetStage] then
            return g_PlayerDedications[playerID][targetStage];
        end
        return nil;
    end
    
    -- 未指定阶段时，返回所有阶段的选择列表（用于遍历检查）
    -- 1. 优先从 ExposedMembers 读取（多人游戏同步）
    if ExposedMembers and ExposedMembers.Turn2Dedication 
       and ExposedMembers.Turn2Dedication.PlayerChoices then
        local choice = ExposedMembers.Turn2Dedication.PlayerChoices[playerID];
        if choice then 
            return choice; 
        end
    end
    
    -- 2. 从激活符文读取（最快，推荐使用）
    local activeRune = Game.GetProperty("Turn2Dedication_ActiveRune_P" .. playerID);
    if activeRune then 
        return activeRune; 
    end
    
    -- 3. 遍历所有可能的阶段（兼容旧存档，最多支持10个阶段）
    for stage = 1, 10 do
        local stageKey = "Turn2Dedication_Stage" .. stage .. "_P" .. playerID;
        local choice = Game.GetProperty(stageKey);
        if choice then 
            return choice; 
        end
    end
    
    -- 4. 从 g_PlayerDedications 读取（备用）
    if g_PlayerDedications[playerID] then
        for stage = 1, 10 do
            local choice = g_PlayerDedications[playerID][stage];
            if choice then 
                return choice; 
            end
        end
    end
    
    return nil;
end

-- ===========================================================================
-- 检查玩家在任意阶段是否选择了指定符文
-- ===========================================================================
function PlayerHasDedication(playerID:number, dedicationID:number)
    local bonusKey = "Turn2Dedication_BonusRune_P" .. playerID .. "_R" .. dedicationID;
    if Game.GetProperty(bonusKey) ~= nil then
        return true;
    end

    local devKey = "Turn2Dedication_DevRune_P" .. playerID .. "_R" .. dedicationID;
    if Game.GetProperty(devKey) ~= nil then
        return true;
    end

    for stage = 1, 10 do
        local stageKey = "Turn2Dedication_Stage" .. stage .. "_P" .. playerID;
        local choice = Game.GetProperty(stageKey);
        if choice == dedicationID then
            return true;
        end
    end
    if g_PlayerDedications[playerID] then
        for stage = 1, 10 do
            if g_PlayerDedications[playerID][stage] == dedicationID then
                return true;
            end
        end
    end
    return false;
end

-- ===========================================================================
-- 阶段×稀有度 金币预算（rarityCode: 1白银/2黄金/3棱彩）。供一次性符文按预算缩放收益。
-- 与 UI/Turn2Dedication_RuneRegistry.lua 的 T2D_BUDGET 保持一致（两 VM 不共享，故各存一份）。
-- ===========================================================================
local T2D_TRIGGER_BUDGET = {
    [1] = {200,  600,  1200},   -- 白银
    [2] = {400,  1200, 2400},   -- 黄金
    [3] = {600,  1800, 3600},   -- 棱彩
};
function GetStageRarityBudget(stage:number, rarityCode:number)
    local row = T2D_TRIGGER_BUDGET[rarityCode or 1] or T2D_TRIGGER_BUDGET[1];
    return row[stage or 1] or row[1];
end

-- Gameplay 与 UI 位于不同 Lua VM，不能直接 include 注册表；这里仅镜像
-- “可作为网络选择传入”的 ID 边界。1-126 中 8/9/19/26 从未注册。
local T2D_UNREGISTERED_RUNE_IDS = { [8] = true, [9] = true, [19] = true, [26] = true };
-- 位掩码：1=阶段1、2=阶段2、4=阶段3。用于房主校验 UI 发来的 ID/阶段组合。
local T2D_RUNE_STAGE_MASK = {
    [1]=2, [2]=2, [3]=2, [4]=1, [5]=3, [6]=3, [7]=1, [10]=3, [11]=3, [12]=3, [13]=3, [14]=3,
    [15]=3, [16]=3, [17]=1, [18]=1, [20]=2, [21]=2, [22]=3, [23]=2, [24]=2, [25]=1, [27]=2, [28]=2,
    [29]=2, [30]=2, [31]=2, [32]=2, [33]=7, [34]=3, [35]=3, [36]=3, [37]=3, [38]=3, [39]=1, [40]=3,
    [41]=3, [42]=2, [43]=4, [44]=6, [45]=3, [46]=2, [47]=3, [48]=2, [49]=3, [50]=7, [51]=3, [52]=3,
    [53]=3, [54]=3, [55]=3, [56]=3, [57]=3, [58]=3, [59]=3, [60]=3, [61]=3, [62]=3, [63]=3, [64]=3,
    [65]=6, [66]=6, [67]=6, [68]=6, [69]=6, [70]=6, [71]=6, [72]=3, [73]=6, [74]=6, [75]=3, [76]=6,
    [77]=3, [78]=3, [79]=6, [80]=3, [81]=6, [82]=6,
    [83]=3, [84]=3, [85]=6, [86]=3, [87]=6, [88]=6, [89]=6, [90]=6, [91]=6, [92]=6,
    [93]=7, [94]=7, [95]=7, [96]=7, [97]=7, [98]=7, [99]=7, [100]=7, [101]=7,
    [102]=7, [103]=7, [104]=7, [105]=7, [106]=7, [107]=7, [108]=7, [109]=7,
    [110]=6, [111]=3, [112]=7, [113]=6, [114]=3, [115]=3, [116]=7, [117]=6,
    [118]=7, [119]=7, [120]=7, [121]=7, [122]=7, [123]=7, [124]=7, [125]=7, [126]=7,
    [127]=7, [128]=7, [129]=7, [130]=7, [131]=7, [132]=7, [133]=7, [134]=7,
    [135]=7, [136]=7, [137]=7, [138]=7, [139]=7, [140]=7, [141]=7,
    [142]=7, [143]=7, [144]=7, [145]=7,
};
-- 全量品质映射。阶段品质改为房主全局判定后，所有网络选择都必须同时
-- 匹配注册品质、消息品质和全局阶段品质，不能再对旧ID放宽校验。
local T2D_RUNE_RARITY_CODE = {
    [1]=1, [2]=1, [3]=1, [4]=1, [5]=1, [6]=1, [7]=1, [10]=1, [11]=2, [12]=3, [13]=1, [14]=1,
    [15]=1, [16]=1, [17]=1, [18]=1, [20]=1, [21]=3, [22]=3, [23]=1, [24]=2, [25]=1, [27]=1, [28]=1,
    [29]=1, [30]=2, [31]=2, [32]=2, [33]=1, [34]=2, [35]=2, [36]=2, [37]=2, [38]=1, [39]=1, [40]=2,
    [41]=2, [42]=2, [43]=2, [44]=2, [45]=2, [46]=2, [47]=3, [48]=2, [49]=3, [50]=2, [51]=2, [52]=1,
    [53]=1, [54]=1, [55]=1, [56]=1, [57]=1, [58]=1, [59]=1, [60]=1, [61]=1, [62]=1, [63]=1, [64]=1,
    [65]=1, [66]=1, [67]=1, [68]=1, [69]=1, [70]=2, [71]=2, [72]=2, [73]=2, [74]=2, [75]=2, [76]=2,
    [77]=2, [78]=2, [79]=2, [80]=2, [81]=2, [82]=2, [83]=2, [84]=2, [85]=2, [86]=2, [87]=2, [88]=2,
    [89]=2, [90]=2, [91]=2, [92]=2, [93]=1, [94]=1, [95]=1, [96]=1, [97]=1, [98]=1, [99]=1, [100]=1,
    [101]=1, [102]=1, [103]=1, [104]=1, [105]=1, [106]=1, [107]=1, [108]=1, [109]=1, [110]=2, [111]=2, [112]=2,
    [113]=2, [114]=2, [115]=2, [116]=2, [117]=2, [118]=3, [119]=3, [120]=3, [121]=3, [122]=3, [123]=3, [124]=3,
    [125]=3, [126]=3, [127]=3, [128]=3, [129]=3, [130]=3, [131]=3, [132]=3, [133]=3, [134]=3, [135]=3, [136]=3,
    [137]=3, [138]=3, [139]=3, [140]=3, [141]=3,
    [142]=1, [143]=2, [144]=3, [145]=2,
};
function T2D_IsValidRuneID(runeID)
    runeID = tonumber(runeID);
    return runeID ~= nil
        and runeID == math.floor(runeID)
        and runeID >= 1
        and runeID <= 145
        and not T2D_UNREGISTERED_RUNE_IDS[runeID];
end

local function T2D_IsRuneEligibleForStage(runeID, stage)
    local mask = T2D_RUNE_STAGE_MASK[tonumber(runeID)];
    local stageBit = stage and 2 ^ (stage - 1) or 0;
    return mask ~= nil and stageBit > 0 and math.floor(mask / stageBit) % 2 == 1;
end

local function T2D_IsRuneRarityCodeValid(runeID, rarityCode)
    local expectedCode = T2D_RUNE_RARITY_CODE[tonumber(runeID)];
    return expectedCode ~= nil and expectedCode == tonumber(rarityCode);
end

-- 精简池必须在 Gameplay 房主端再次校验，不能信任 UI 提交的 ID。
-- 完整池/全符文池目前均允许全部已注册符文。
local T2D_MODE1_RUNE_IDS = {
    1,2,3,4,5,7,10,11,13,14,15,16,17,18,22,23,24,25,28,33,38,39,
    52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,72,
    73,74,75,76,77,78,82,83,86,87,88,90,91,92,93,94,95,96,97,98,
    99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,
    115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,
    131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,
};
local T2D_MODE1_RUNE_SET = {};
for _, runeID in ipairs(T2D_MODE1_RUNE_IDS) do
    T2D_MODE1_RUNE_SET[runeID] = true;
end

local function T2D_IsRuneAllowedByConfiguredPool(runeID)
    local poolMode = 1;
    if GameConfiguration and GameConfiguration.GetValue then
        poolMode = tonumber(GameConfiguration.GetValue("TURN2_RUNE_POOL_MODE")) or 1;
    end
    if poolMode == 1 then return T2D_MODE1_RUNE_SET[tonumber(runeID)] == true; end
    return poolMode == 2 or poolMode == 3;
end

-- 间谍生产惩罚符文互斥：79(-60%)与85(-67%)不能同时获得。
-- 本表位于 Gameplay VM，不能依赖 UI 注册表中的 conflictGroup。
local T2D_RUNE_CONFLICTS = { [79] = 85, [85] = 79 };

function T2D_GetConflictingRune(playerID, runeID)
    local otherRuneID = T2D_RUNE_CONFLICTS[tonumber(runeID)];
    if otherRuneID and PlayerHasDedication(playerID, otherRuneID) then
        return otherRuneID;
    end
    return nil;
end

local function T2D_SetSelectionAck(playerID, stage, runeID, status)
    local ackKey = "Turn2Dedication_SelectionAck_P" .. tostring(playerID);
    Game.SetProperty(ackKey, tostring(stage or 0) .. ":" .. tostring(runeID)
        .. ":" .. tostring(status));
end

-- 所有会修改同步游戏状态的入口统一使用此门控。多人游戏只允许房主执行；
-- 单人游戏不依赖 Network 对象是否存在。
function T2D_IsAuthoritativeGameplay()
    local isMultiplayer = GameConfiguration and GameConfiguration.IsAnyMultiplayer
        and GameConfiguration.IsAnyMultiplayer();
    if not isMultiplayer then return true; end
    return Network and Network.IsGameHost and Network.IsGameHost() or false;
end

-- Game.GetProperty 在属性不存在时可能返回零个 Lua 返回值。先保存到局部变量，
-- 再做数值转换，避免 tonumber(Game.GetProperty(...)) 以零参数调用而抛错。
local function T2D_GetNumberGameProperty(propertyKey, defaultValue)
    local rawValue = Game.GetProperty(propertyKey);
    if rawValue == nil then return defaultValue; end
    local numberValue = tonumber(rawValue);
    if numberValue == nil then return defaultValue; end
    return numberValue;
end

-- 仅在缺少 PlayerTurnStartComplete 时启用；正常 Gathering Storm 游戏不会走此回退。
local g_T2DGold80UseTurnStartedFallback = false;

local function T2D_GetConfiguredSelectionTurn(stage)
    local defaults = { [1] = 2, [2] = 25, [3] = 41 };
    local keys = {
        [1] = "TURN2_STAGE1_TURN",
        [2] = "TURN2_STAGE2_TURN",
        [3] = "TURN2_STAGE3_TURN",
    };
    if not defaults[stage] then return nil; end

    local selectionTurn = defaults[stage];
    if GameConfiguration and GameConfiguration.GetValue then
        selectionTurn = tonumber(GameConfiguration.GetValue(keys[stage])) or selectionTurn;
    end
    if selectionTurn <= 0 then return nil; end
    return selectionTurn;
end

-- ===========================================================================
-- 房主权威的全局阶段品质
-- roll 使用 0-99 整数：3=棱彩、2=黄金、1=白银。
-- ===========================================================================
local T2D_STAGE_RARITY_WEIGHTS = {
    [1] = { prismatic = 25, gold = 35, silver = 40 },
    [2] = { prismatic = 15, gold = 25, silver = 60 },
    [3] = { prismatic = 20, gold = 30, silver = 50 },
};

local function T2D_GetGlobalRarityPropertyKey(stage)
    return "Turn2Dedication_GlobalRarity_Stage" .. tostring(stage);
end

local function T2D_GetStageRarityCodeFromRoll(stage, roll)
    local weights = T2D_STAGE_RARITY_WEIGHTS[stage];
    if not weights then return nil; end
    local normalizedRoll = math.max(0, math.min(99, math.floor(tonumber(roll) or 0)));
    if normalizedRoll < weights.prismatic then return 3; end
    if normalizedRoll < weights.prismatic + weights.gold then return 2; end
    return 1;
end

local function T2D_EnsureGlobalStageRarity(stage)
    local propertyKey = T2D_GetGlobalRarityPropertyKey(stage);
    local rawExistingCode = Game.GetProperty(propertyKey);
    if rawExistingCode ~= nil then
        local existingCode = tonumber(rawExistingCode);
        if existingCode and existingCode >= 1 and existingCode <= 3
            and existingCode == math.floor(existingCode) then
            return existingCode;
        end
        -- Property 一旦存在就绝不重掷；损坏值必须显式暴露，不能静默改变全局结果。
        print("Turn2DedicationTrigger: ❌ 阶段" .. tostring(stage)
            .. "已有无效的全局品质 Property：" .. tostring(rawExistingCode));
        return nil;
    end
    if not T2D_IsAuthoritativeGameplay() then return nil; end
    if not T2D_STAGE_RARITY_WEIGHTS[stage] or not Game or not Game.GetRandNum then
        print("Turn2DedicationTrigger: ❌ 无法生成阶段" .. tostring(stage)
            .. "全局品质：随机接口或阶段配置不可用");
        return nil;
    end

    local roll = Game.GetRandNum(100, "Turn2Dedication Global Rarity Stage " .. tostring(stage));
    local rarityCode = T2D_GetStageRarityCodeFromRoll(stage, roll);
    if not rarityCode then return nil; end
    Game.SetProperty(propertyKey, rarityCode);
    print("Turn2DedicationTrigger: 🎲 阶段" .. tostring(stage)
        .. "全局品质已确定：roll=" .. tostring(roll)
        .. " rarityCode=" .. tostring(rarityCode));
    return rarityCode;
end

local function T2D_EnsureGlobalRarityForCurrentTurn(currentTurn)
    for stage = 1, 3 do
        local selectionTurn = T2D_GetConfiguredSelectionTurn(stage);
        if selectionTurn and currentTurn == selectionTurn then
            local ok, result = pcall(T2D_EnsureGlobalStageRarity, stage);
            if not ok or not result then
                print("Turn2DedicationTrigger: ❌ 阶段" .. tostring(stage)
                    .. "全局品质初始化失败：" .. tostring(result));
            end
        end
    end
end

local function T2D_GetPendingSelectionStage(playerID, currentTurn)
    if playerID == nil or currentTurn == nil then return nil; end
    for stage = 1, 3 do
        local selectionTurn = T2D_GetConfiguredSelectionTurn(stage);
        local stageKey = "Turn2Dedication_Stage" .. tostring(stage) .. "_P" .. tostring(playerID);
        local missedKey = "Turn2Dedication_Stage" .. tostring(stage)
            .. "_Missed_P" .. tostring(playerID);
        if selectionTurn and currentTurn == selectionTurn
            and Game.GetProperty(stageKey) == nil
            and Game.GetProperty(missedKey) == nil then
            return stage;
        end
    end
    return nil;
end

local function T2D_MarkExpiredSelections(playerID, currentTurn)
    for stage = 1, 3 do
        local selectionTurn = T2D_GetConfiguredSelectionTurn(stage);
        local stageKey = "Turn2Dedication_Stage" .. tostring(stage) .. "_P" .. tostring(playerID);
        local missedKey = "Turn2Dedication_Stage" .. tostring(stage)
            .. "_Missed_P" .. tostring(playerID);
        if selectionTurn and currentTurn > selectionTurn
            and Game.GetProperty(stageKey) == nil
            and Game.GetProperty(missedKey) == nil then
            Game.SetProperty(missedKey, currentTurn);
            print("Turn2DedicationTrigger: ⏭ 玩家" .. tostring(playerID)
                .. "已错过阶段" .. tostring(stage) .. "符文选择");
        end
    end
end

local function T2D_GetRuneSelectionNotificationHash()
    local typeInfo = GameInfo and GameInfo.Types
        and GameInfo.Types["NOTIFICATION_T2D_RUNE_SELECTION"];
    return typeInfo and typeInfo.Hash or nil;
end

-- 未选择时保留一个与原版时代着力点相同用途的可点击通知。
local function T2D_ReconcileRuneSelectionNotification(playerID, currentTurn)
    if not T2D_IsAuthoritativeGameplay() then return; end
    local pPlayer = Players[playerID];
    if not pPlayer or not pPlayer:IsAlive() or not pPlayer:IsHuman() then return; end

    currentTurn = currentTurn or Game.GetCurrentGameTurn();
    T2D_MarkExpiredSelections(playerID, currentTurn);

    -- 阶段过期属于权威玩法状态，不能依赖通知接口是否可用。
    if not NotificationManager then return; end

    local notificationHash = T2D_GetRuneSelectionNotificationHash();
    if not notificationHash then
        print("Turn2DedicationTrigger: ⚠ 未找到 NOTIFICATION_T2D_RUNE_SELECTION");
        return;
    end

    local pendingStage = T2D_GetPendingSelectionStage(playerID, currentTurn);
    local existing = NotificationManager.FindType(notificationHash, playerID);
    if pendingStage then
        if not existing then
            NotificationManager.SendNotification(
                playerID,
                notificationHash,
                Locale.Lookup("LOC_NOTIFICATION_T2D_RUNE_SELECTION_MESSAGE"),
                Locale.Lookup("LOC_NOTIFICATION_T2D_RUNE_SELECTION_SUMMARY"));
        end
    elseif existing then
        NotificationManager.Dismiss(existing:GetPlayerID(), existing:GetID());
    end
end

-- ===========================================================================
-- 处理玩家确认的着力点选择（通过LuaEvents，如果可用）
-- ===========================================================================
function OnDedicationConfirmedLegacyUnused(dedicationType:number)
    print("╔════════════════════════════════════════════════════════");
    print("║ Turn2DedicationTrigger: OnDedicationConfirmed 被调用（单人游戏）");
    print("╚════════════════════════════════════════════════════════");
    print("  收到的符文类型: " .. tostring(dedicationType));
    
    if not T2D_IsAuthoritativeGameplay() or not T2D_IsValidRuneID(dedicationType) then
        print("Turn2DedicationTrigger: ❌ 忽略无权威或无效的本地符文确认");
        return;
    end

    local localPlayerID:number = Game.GetLocalPlayer();
    print("  本地玩家ID: " .. tostring(localPlayerID));
    
    if localPlayerID == PlayerTypes.NONE or localPlayerID == -1 then
        print("  ❌ 错误：无效的本地玩家ID");
        print("════════════════════════════════════════════════════════╝");
        return;
    end

    local conflictingRuneID = T2D_GetConflictingRune(localPlayerID, dedicationType);
    if conflictingRuneID then
        T2D_SetSelectionAck(localPlayerID, 0, dedicationType, "CONFLICT");
        print("Turn2DedicationTrigger: ❌ 拒绝本地符文确认：ID "
            .. tostring(dedicationType) .. " 与已拥有ID "
            .. tostring(conflictingRuneID) .. " 互斥");
        return;
    end
    
    -- 使用Game级别的Property（参考BBG mod的做法）
    local propertyKey = "Turn2Dedication_Choice_P" .. localPlayerID;
    print("  Property Key: " .. propertyKey);
    Game.SetProperty(propertyKey, dedicationType);
    T2D_SetSelectionAck(localPlayerID, 0, dedicationType, "ACCEPTED");
    print("  ✓ Game Property 已设置");
    
    -- 立即读取验证
    local readBack = Game.GetProperty(propertyKey);
    print("  ► 验证读取: " .. tostring(readBack));
    
    -- 注意：g_PlayerDedications 现在使用多阶段嵌套结构，此处不再直接设置
    -- 应该由 OnMultiplayerChatGameplay 统一处理
    -- g_PlayerDedications[localPlayerID] = dedicationType;
    print("  ✓ 选择已保存到 Game Property");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 【关键修复】Gameplay层直接监听聊天消息（多人游戏网络同步）
-- ===========================================================================
function OnMultiplayerChatGameplay(fromPlayer:number, toPlayer:number, text:string, eTargetType:number)
    -- 端口检查：只处理符文选择消息专用端口（655001）
    if toPlayer ~= 655001 then
        return;
    end
    if type(text) ~= "string" then return; end
    
    -- 解析消息格式：[T2D]playerID:runeID:stage:turn:rarityCode
    -- 第5段是客户端对全局品质 Property 的回显值；房主会再与注册品质和权威 Property 交叉校验。
    local marker, playerID, dedicationType, stage, turn, rarityCode =
        text:match("^(%[T2D%])(%d+):(%d+):(%d+):(%d+):(%d+)$");

    if not marker then
        print("Turn2DedicationTrigger: ❌ 无效的符文消息格式: " .. text);
        return;
    end

    playerID = tonumber(playerID);
    dedicationType = tonumber(dedicationType);
    stage = tonumber(stage);
    turn = tonumber(turn);
    rarityCode = tonumber(rarityCode);

    -- 选择消息会广播到所有客户端，但只有房主可以写同步 Property。
    if not T2D_IsAuthoritativeGameplay() then return; end

    -- 消息中的玩家必须就是网络发送者，避免其他客户端代选或覆盖选择。
    if tonumber(fromPlayer) ~= playerID then
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：发送者与玩家ID不一致");
        return;
    end
    if not T2D_IsValidRuneID(dedicationType) then
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：无效符文ID " .. tostring(dedicationType));
        return;
    end
    if stage == nil or stage ~= math.floor(stage) or stage < 1 or stage > 3 then
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：无效阶段 " .. tostring(stage));
        return;
    end
    if not T2D_IsRuneEligibleForStage(dedicationType, stage) then
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：符文不属于该阶段 ID="
            .. tostring(dedicationType) .. " stage=" .. tostring(stage));
        return;
    end
    local missedKey = "Turn2Dedication_Stage" .. tostring(stage)
        .. "_Missed_P" .. tostring(playerID);
    if Game.GetProperty(missedKey) ~= nil then
        T2D_SetSelectionAck(playerID, stage, dedicationType, "EXPIRED");
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：该阶段机会已经失效");
        return;
    end
    if not T2D_IsRuneAllowedByConfiguredPool(dedicationType) then
        T2D_SetSelectionAck(playerID, stage, dedicationType, "ERROR");
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：符文不属于当前配置池 ID="
            .. tostring(dedicationType));
        return;
    end
    if rarityCode == nil or rarityCode ~= math.floor(rarityCode) or rarityCode < 1 or rarityCode > 3 then
        T2D_SetSelectionAck(playerID, stage, dedicationType, "RARITY_MISMATCH");
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：无效稀有度 " .. tostring(rarityCode));
        return;
    end
    if not T2D_IsRuneRarityCodeValid(dedicationType, rarityCode) then
        T2D_SetSelectionAck(playerID, stage, dedicationType, "RARITY_MISMATCH");
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：符文稀有度不匹配 ID="
            .. tostring(dedicationType) .. " rarity=" .. tostring(rarityCode));
        return;
    end

    local expectedTurn = T2D_GetConfiguredSelectionTurn(stage);
    local currentTurn = Game.GetCurrentGameTurn();
    if not expectedTurn or currentTurn ~= expectedTurn or turn ~= currentTurn then
        T2D_SetSelectionAck(playerID, stage, dedicationType, "EXPIRED");
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：阶段/回合不匹配 stage="
            .. tostring(stage) .. " payloadTurn=" .. tostring(turn)
            .. " currentTurn=" .. tostring(currentTurn));
        return;
    end

    local globalRarityCode = T2D_EnsureGlobalStageRarity(stage);
    local registeredRarityCode = T2D_RUNE_RARITY_CODE[dedicationType];
    if not globalRarityCode or rarityCode ~= globalRarityCode
        or registeredRarityCode ~= globalRarityCode then
        T2D_SetSelectionAck(playerID, stage, dedicationType, "RARITY_MISMATCH");
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：不符合全局阶段品质 stage="
            .. tostring(stage) .. " global=" .. tostring(globalRarityCode)
            .. " payload=" .. tostring(rarityCode)
            .. " registered=" .. tostring(registeredRarityCode));
        return;
    end
    
    print("════════════════════════════════════════════════════════╗");
    print("║ Turn2DedicationTrigger: 接收到符文选择");
    print("  ► 玩家ID: " .. playerID);
    print("  ► 符文类型: " .. dedicationType);
    print("  ► 阶段: " .. stage);
    print("  ► 回合: " .. turn);
    print("  ► 全局品质: " .. tostring(globalRarityCode));
    
    local pPlayer = Players[playerID];
    if not pPlayer or not pPlayer:IsHuman() then
        print("  ❌ 无效的玩家ID");
        return;
    end

    local stageKey = "Turn2Dedication_Stage" .. stage .. "_P" .. playerID;
    local authoritativeStageRune = Game.GetProperty(stageKey);
    if authoritativeStageRune ~= nil then
        -- ACK 回显本次请求ID，确保等待中的Popup能匹配；UI随后读取stageKey中的权威值并关闭。
        T2D_SetSelectionAck(playerID, stage, dedicationType, "ALREADY_SELECTED");
        print("Turn2DedicationTrigger: ⓘ 阶段选择已存在，拒绝重复覆盖: " .. stageKey
            .. " authoritativeRune=" .. tostring(authoritativeStageRune)
            .. " requestedRune=" .. tostring(dedicationType));
        return;
    end

    if PlayerHasDedication(playerID, dedicationType) then
        T2D_SetSelectionAck(playerID, stage, dedicationType, "ALREADY_OWNED");
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：玩家已拥有ID "
            .. tostring(dedicationType));
        return;
    end

    local conflictingRuneID = T2D_GetConflictingRune(playerID, dedicationType);
    if conflictingRuneID then
        T2D_SetSelectionAck(playerID, stage, dedicationType, "CONFLICT");
        print("Turn2DedicationTrigger: ❌ 拒绝符文选择：ID "
            .. tostring(dedicationType) .. " 与已拥有ID "
            .. tostring(conflictingRuneID) .. " 互斥");
        return;
    end
    
    -- 保存阶段选择
    Game.SetProperty(stageKey, dedicationType);
    print("  ✓ 阶段状态已保存: " .. stageKey);
    
    -- 同时保存为激活符文（方便快速读取，支持任意阶段扩展）
    local activeRuneKey = "Turn2Dedication_ActiveRune_P" .. playerID;
    Game.SetProperty(activeRuneKey, dedicationType);
    print("  ✓ 激活符文已保存: " .. activeRuneKey);

    -- 保存稀有度编码（供应用时按阶段×稀有度缩放一次性符文）
    local rarityKey = "Turn2Dedication_Rarity_Stage" .. stage .. "_P" .. playerID;
    Game.SetProperty(rarityKey, globalRarityCode);
    print("  ✓ 稀有度已保存: " .. rarityKey .. " = " .. tostring(globalRarityCode));
    
    -- 保存到全局记录（用于查询）
    g_PlayerDedications[playerID] = g_PlayerDedications[playerID] or {};
    g_PlayerDedications[playerID][stage] = dedicationType;
    T2D_SetSelectionAck(playerID, stage, dedicationType, "ACCEPTED");
    local okNotification, notificationError = pcall(
        T2D_ReconcileRuneSelectionNotification, playerID, currentTurn);
    if not okNotification then
        print("Turn2DedicationTrigger: ⚠ 待选通知收尾失败：" .. tostring(notificationError));
    end
    
    -- 应用符文效果
    -- ApplyDedicationEffect(pPlayer, dedicationType); 删除重复应用
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 【奇观狂魔】Gameplay层监听奇观完成广播（隐藏聊天消息）
-- ===========================================================================
function OnWonderCompletedGameplay(fromPlayer:number, toPlayer:number, text:string, eTargetType:number)
    -- 检查是否是奇观完成消息（端口655002）
    if toPlayer ~= 655002 then
        return;
    end
    
    -- 检查消息格式: [T2D_WONDER]玩家ID:城市ID:奇观索引
    if not text or type(text) ~= "string" then
        return;
    end
    
    local prefix = "[T2D_WONDER]";
    if string.sub(text, 1, #prefix) ~= prefix then
        return;
    end
    
    -- 解析消息
    local data = string.sub(text, #prefix + 1);
    local parts = {};
    for part in string.gmatch(data, "[^:]+") do
        table.insert(parts, part);
    end
    
    if #parts ~= 3 then
        print("Turn2DedicationTrigger: ❌ 奇观消息格式错误: " .. text);
        return;
    end
    
    local playerID = tonumber(parts[1]);
    local cityID = tonumber(parts[2]);
    local buildingIndex = tonumber(parts[3]);
    
    if not playerID or not cityID or not buildingIndex then
        print("Turn2DedicationTrigger: ❌ 奇观消息解析失败: " .. text);
        return;
    end
    
    -- 只在非多人游戏或房主端执行游戏逻辑修改
    if not T2D_IsAuthoritativeGameplay() then return; end
    if tonumber(fromPlayer) ~= playerID then
        print("Turn2DedicationTrigger: ❌ 拒绝奇观完成消息：发送者与玩家ID不一致");
        return;
    end
    
    -- 验证玩家和城市
    local pPlayer = Players[playerID];
    if not pPlayer or not pPlayer:IsAlive() then
        print("Turn2DedicationTrigger: ❌ 玩家不存在或已淘汰");
        return;
    end
    
    local pCity = pPlayer:GetCities():FindID(cityID);
    if not pCity then
        print("Turn2DedicationTrigger: ❌ 城市不存在");
        return;
    end
    
    -- 验证奇观建筑
    local buildingInfo = GameInfo.Buildings[buildingIndex];
    if not buildingInfo or not buildingInfo.IsWonder then
        print("Turn2DedicationTrigger: ❌ 建筑不是奇观");
        return;
    end
    
    -- 检查是否选择了奇观狂魔符文（支持多阶段）
    if not PlayerHasDedication(playerID, 22) then
        return; -- 没选奇观狂魔，不处理
    end

    local rewardKey = "Turn2Dedication_WonderReward_P" .. tostring(playerID)
        .. "_B" .. tostring(buildingIndex);
    if Game.GetProperty(rewardKey) ~= nil then
        print("Turn2DedicationTrigger: ⓘ 该奇观奖励已经结算，跳过重复事件");
        return;
    end

    -- 奇观狂魔返还次数上限（避免无上限累积；配合下方0.6返还比例收敛到 prismatic 预算）
    local refundKey = "TURN2_WONDER_REFUND_COUNT_P" .. playerID;
    local refundCount = Game.GetProperty(refundKey) or 0;
    local REFUND_CAP = 6;
    if refundCount >= REFUND_CAP then
        print("Turn2DedicationTrigger: 奇观狂魔返还已达上限(" .. REFUND_CAP .. ")，本次不再返还");
        return;
    end
    
    local wonderName = Locale.Lookup(buildingInfo.Name);
    local cityName = Locale.Lookup(pCity:GetName());
    
    print("╔════════════════════════════════════════════════════════════════╗");
    print("║ 🎉 奇观狂魔 - 奇观完成奖励");
    print("╚════════════════════════════════════════════════════════════════╝");
    
    -- 获取游戏速度修正
    local gameSpeed = GameConfiguration.GetGameSpeedType();
    local speedMultiplier = 1;
    if gameSpeed and GameInfo.GameSpeeds[gameSpeed] then
        local costMultiplierPercent = GameInfo.GameSpeeds[gameSpeed].CostMultiplier or 100;
        speedMultiplier = costMultiplierPercent / 100;  -- 转换百分比为倍率（50% -> 0.5）
    end
    
    -- 获取奇观基础成本
    local baseCost = buildingInfo.Cost or 0;
    
    -- 计算实际成本（考虑游戏速度）
    local actualCost = math.floor(baseCost * speedMultiplier);
    
    -- 计算金币奖励（实际成本的60%，配合次数上限避免无上限累积）
    local goldReward = math.floor(actualCost * 0.6);
    
    print("  玩家: " .. playerID);
    print("  城市: " .. cityName);
    print("  奇观: " .. wonderName);
    print("  基础成本: " .. baseCost .. " 🔨");
    print("  游戏速度: " .. (GameInfo.GameSpeeds[gameSpeed] and Locale.Lookup(GameInfo.GameSpeeds[gameSpeed].Name) or "未知") .. " (" .. (speedMultiplier * 100) .. "%)");
    print("  实际成本: " .. actualCost .. " 🔨");
    print("  金币奖励: " .. goldReward .. " 💰 (实际成本的125%)");
    
    -- 发放金币奖励
    local pTreasury = pPlayer:GetTreasury();
    if pTreasury and pTreasury.ChangeGoldBalance then
        pTreasury:ChangeGoldBalance(goldReward);
        Game.SetProperty(refundKey, refundCount + 1);
        Game.SetProperty(rewardKey, 1);
        print("  ✅ 金币已发放！(第" .. (refundCount + 1) .. "/" .. REFUND_CAP .. "次)");
    else
        print("  ❌ 无法发放金币（API不可用）");
        return;
    end
    
    -- 记录该城市的奇观数量（用于统计）
    local cityKey = "CITY_" .. cityID;
    g_CityWonderCounts[cityKey] = (g_CityWonderCounts[cityKey] or 0) + 1;
    local currentCount = g_CityWonderCounts[cityKey];
    
    -- 持久化存储（用于重新加载游戏）
    Game.SetProperty("TURN2_WONDER_COUNT_C" .. cityID, currentCount);
    
    print("  ► 该城市奇观总数: " .. currentCount);
    print("════════════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 【探索先锋】Gameplay层监听自然奇观发现广播（隐藏聊天消息）
-- ===========================================================================
function OnNaturalWonderDiscoveredGameplay(fromPlayer:number, toPlayer:number, text:string, eTargetType:number)
    -- 检查是否是自然奇观发现消息（端口655003）
    if toPlayer ~= 655003 then
        return;
    end
    
    if type(text) ~= "string" or not T2D_IsAuthoritativeGameplay() then return; end

    -- 解析消息格式：[T2D_WONDER_NATURE]玩家ID:奇观ID
    local marker, playerID, featureID = text:match("^(%[T2D_WONDER_NATURE%])(%d+):(%d+)$");
    
    if not marker then
        print("Turn2DedicationTrigger: ❌ 无效的自然奇观消息格式: " .. text);
        return;
    end
    
    playerID = tonumber(playerID);
    featureID = tonumber(featureID);
    if tonumber(fromPlayer) ~= playerID then
        print("Turn2DedicationTrigger: ❌ 拒绝自然奇观消息：发送者与玩家ID不一致");
        return;
    end

    local pPlayer = Players[playerID];
    local featureInfo = GameInfo.Features[featureID];
    if not pPlayer or not pPlayer:IsAlive() or not pPlayer:IsHuman()
        or not PlayerHasDedication(playerID, 20)
        or not featureInfo or not featureInfo.NaturalWonder then
        print("Turn2DedicationTrigger: ❌ 拒绝无效的自然奇观发现消息");
        return;
    end

    local seenKey = "Turn2Dedication_NaturalWonderSeen_P" .. tostring(playerID)
        .. "_F" .. tostring(featureID);
    if Game.GetProperty(seenKey) ~= nil then
        print("Turn2DedicationTrigger: ⓘ 自然奇观发现已记录，跳过重复消息");
        return;
    end
    
    print("╔════════════════════════════════════════════════════════");
    print("║ 探索先锋 - Gameplay层接收自然奇观发现");
    print("╚════════════════════════════════════════════════════════");
    print("  玩家ID: " .. playerID);
    print("  奇观ID: " .. featureID);
    
    -- 获取奇观名称
    if featureInfo then
        print("  奇观名称: " .. Locale.Lookup(featureInfo.Name or "未知"));
    end
    
    -- 更新玩家发现的自然奇观数量（使用Game.Property，网络同步）
    local wonderCountKey = "Turn2Dedication_WonderCount_P" .. playerID;
    local wonderCount = Game.GetProperty(wonderCountKey) or 0;
    wonderCount = wonderCount + 1;
    Game.SetProperty(wonderCountKey, wonderCount);
    Game.SetProperty(seenKey, 1);
    
    print("  ✓ 玩家 " .. playerID .. " 已发现 " .. wonderCount .. " 个自然奇观");
    print("  ► 里程碑检查将在下回合执行");
    print("════════════════════════════════════════════════════════╝");
end

-- 只有这些已注册的任务型符文允许在没有即时 handler 时标记为 DEFERRED。
-- 其他合法 ID 若因脚本或数据缺失而没有 handler，必须保留未处理以便重试。
local T2D_DEFERRED_TASK_RUNE_IDS = { [12] = true, [20] = true, [24] = true };

-- ===========================================================================
-- 应用着力点效果（统一入口）
-- ===========================================================================
function ApplyDedicationEffect(pPlayer:table, dedicationType:number, stage:number, rarity:number)
    -- 权威应用入口的最后一道互斥保护；正式选择、图鉴和任何直接调用都不能绕过。
    if pPlayer and pPlayer.GetID then
        local playerID = pPlayer:GetID();
        local conflictingRuneID = T2D_GetConflictingRune(playerID, dedicationType);
        if conflictingRuneID then
            print("Turn2DedicationTrigger: ❌ 拒绝应用符文 " .. tostring(dedicationType)
                .. "：与已拥有符文 " .. tostring(conflictingRuneID) .. " 互斥");
            return "CONFLICT";
        end
    end

    -- 效果分发表（懒加载：首次调用时构建，此时所有 Apply* 全局函数已定义，规避前向引用）。
    -- handler 统一签名 (pPlayer, stage, rarity)；不需要 stage/rarity 的 handler 自动忽略多余参数。
    if not g_DedicationHandlers then
        g_DedicationHandlers = {
            [1]  = ApplyMilitaryDedication,           -- 实战训练
            [2]  = ApplyScienceDedication,            -- 知识下载
            [3]  = ApplyCultureDedication,            -- 鼓舞人心
            [4]  = ApplyEconomyDedication,            -- 贸易大亨
            [5]  = ApplyCultureAdvDedication,          -- 文化传承（ID5，已与战略资源门控对齐：战略储备=ID6）
            [6]  = ApplyStrategicDedication,           -- 战略储备（ID6）
            [7]  = ApplyPioneerDedication,            -- 探索者
            [10] = ApplyArchitectDedication,          -- 建筑大师
            [11] = ApplyDiplomaticDedication,         -- 外交联盟
            [13] = ApplyReligionDedication,           -- 宗教信仰
            [14] = ApplyAcademicDedication,           -- 学术精英
            [15] = ApplyTradeNetworkDedication,       -- 商贸网络
            [16] = ApplyAgricultureDedication,        -- 农业革新
            [17] = ApplyMilitarismDedication,         -- 军事主义
            [18] = ApplyFortificationDedication,      -- 防御工事
            [21] = ApplyRenaissanceDedication,        -- 文艺复兴
            [22] = ApplyWonderDedication,             -- 奇观狂魔
            [23] = ApplyTurtleFormationDedication,    -- 龟型阵
            [25] = ApplyMaritimeDedication,           -- 海上贸易
            [27] = ApplyCavalryAssaultDedication,     -- 骑兵突击
            [28] = ApplyGoldenTradeDedication,        -- 黄金贸易
            [29] = ApplyReligiousExpansionDedication, -- 宗教扩张
            [30] = ApplyFeudalBudDedication,          -- 封建萌芽
            [31] = ApplyCommercialMonopolyDedication, -- 商业垄断
            [32] = ApplyHarvestBlessingDedication,    -- 丰收祝福
            [33] = ApplyWealthFreedomDedication,      -- 财富自由
            [34] = ApplyWisdomLightDedication,        -- 智慧之光
            [35] = ApplyFirstDistrictDedication,      -- 快速扩张
            [36] = ApplyRuneSummoningDedication,      -- 符文召唤
            [37] = ApplyRangedMasteryDedication,      -- 远程精通
            [38] = ApplyTamarisSoulDedication,        -- 塔玛丽之魂
            [39] = ApplyFarSightDedication,           -- 千里眼（已补实现）
            [40] = ApplyStatecraftDedication,         -- 治国之才（已补实现）
            [41] = ApplyThousandHeartsDedication,     -- 千政之心
            [42] = ApplyTaxReformDedication,          -- 税收改革
            [43] = ApplyChivalryDedication,           -- 骑士精神
            [44] = ApplyNavalSupremacy,               -- 海权霸主
            [45] = ApplyHomelandBastion,              -- 本土壁垒
            [46] = ApplyVeterancy,                    -- 百战精兵
            [47] = ApplyEraGlory,                     -- 荣耀史诗
            [48] = ApplyIronRule,                     -- 铁腕统治
            [49] = ApplyTerrainMastery,               -- 山河形胜
            [50] = ApplyEurekaFlash,                  -- 灵光乍现
            [51] = ApplyFreeInfrastructure,           -- 百废俱兴
            [52] = ApplyWarOathSilverBlade,           -- 战誓银刃
            [53] = ApplyTriumphMemory,                -- 凯旋铭记
            [54] = ApplyRoyalInscription,             -- 王权铭文
            [55] = ApplyRiverValleyWorkshop,          -- 河谷工坊
            [56] = ApplyMountainTempleBell,           -- 山寺钟声
            [57] = ApplyTitheTradePact,                -- 什一商约
            [58] = ApplyMilitiaEpic,                  -- 民兵史诗
            [59] = ApplyAncestralEcho,                -- 祖制回响
            [60] = ApplyScholasticSilverRing,         -- 学派银环
            [61] = ApplyCartographyAcademy,           -- 测绘学院
            [62] = ApplySilverCableTradePact,         -- 银缆商约
            [63] = ApplyEmbassySilverTier,            -- 使馆银阶
            [64] = ApplyWoodlandAcademy,              -- 林地书院
            [65] = ApplyCivicSalon,                   -- 公民沙龙
            [66] = ApplyAllianceSilverCovenant,       -- 同盟银契
            [67] = ApplyWorkshopLectern,              -- 工坊讲席
            [68] = ApplySacredTextConcordance,        -- 圣卷互证
            [69] = ApplyOverseasCharter,              -- 海外宪章
            [70] = ApplyCabinetCouncil,               -- 内阁议会
            [71] = ApplyKnowledgeMission,             -- 求知使团
            [72] = ApplyEcologicalCorridor,           -- 生态廊道
            [73] = ApplyInternationalMediation,       -- 万国调停
            [74] = ApplyShadowCouncil,                -- 暗线议会
            [75] = ApplyItinerantOrder,               -- 行脚修会
            [76] = ApplyCulturalExchange,             -- 文化互访
            [77] = ApplySecondaryCenter,              -- 次级中心
            [78] = ApplyLandTransformation,           -- 土地改造
            [79] = ApplyMastermind,                    -- 幕后黑手
            [80] = ApplyExhaustThePond,                -- 竭泽而渔
            [81] = ApplyScorchedEarth,                 -- 焦土计划
            [82] = ApplySprintSprintSprint,            -- 冲刺冲刺冲刺
            [83] = ApplyGoldRune83,                    -- 合成作战
            [84] = ApplyGoldRune84,                    -- 军械标准化
            [85] = ApplyGoldRune85,                    -- 全域监听
            [86] = ApplyGoldRune86,                    -- 实证革命
            [87] = ApplyGoldRune87,                    -- 科研产业化
            [88] = ApplyGoldRune88,                    -- 国家策展
            [89] = ApplyGoldRune89,                    -- 全球巡演
            [90] = ApplyGoldRune90,                    -- 产业电网
            [91] = ApplyGoldRune91,                    -- 都会引擎
            [92] = ApplyGoldRune92,                    -- 制空权
            [93] = ApplySilverRune93,                  -- 地籍清丈
            [94] = ApplySilverRune94,                  -- 田野勘察
            [95] = ApplySilverRune95,                  -- 同行评议
            [96] = ApplySilverRune96,                  -- 公民节庆
            [97] = ApplySilverRune97,                  -- 奢品陈列
            [98] = ApplySilverRune98,                  -- 慈善教区
            [99] = ApplySilverRune99,                  -- 巡回讲坛
            [100] = ApplySilverRune100,                -- 外交先遣
            [101] = ApplySilverRune101,                -- 公共竞标
            [102] = ApplySilverRune102,                -- 博闻强识
            [103] = ApplySilverRune103,                -- 丰收折算
            [104] = ApplySilverRune104,                -- 京畿迁入
            [105] = ApplySilverRune105,                -- 丰育新政
            [106] = ApplySilverRune106,                -- 畜贸行会
            [107] = ApplySilverRune107,                -- 中央采办
            [108] = ApplySilverRune108,                -- 牧界拓殖
            [109] = ApplySilverRune109,                -- 星纹贡礼
            [110] = ApplyGoldRune110,                  -- 帝国战史
            [111] = ApplyGoldRune111,                  -- 帝国地籍
            [112] = ApplyGoldRune112,                  -- 国土资源院
            [113] = ApplyGoldRune113,                  -- 万国奢博
            [114] = ApplyGoldRune114,                  -- 济世圣会
            [115] = ApplyGoldRune115,                  -- 机械化采收
            [116] = ApplyGoldRune116,                  -- 都城大迁徙
            [117] = ApplyGoldRune117,                  -- 共同体条约
            [118] = ApplyPrismaticRune118,             -- 战争神话
            [119] = ApplyPrismaticRune119,             -- 无垠疆界
            [120] = ApplyPrismaticRune120,             -- 知识奇点
            [121] = ApplyPrismaticRune121,             -- 普世圣座
            [122] = ApplyPrismaticRune122,             -- 人类记忆宫
            [123] = ApplyPrismaticRune123,             -- 行政府矩阵
            [124] = ApplyPrismaticRune124,             -- 命运共同体
            [125] = ApplyPrismaticRune125,             -- 无定宪章
            [126] = ApplyPrismaticRune126,             -- 万城柱石
            [127] = ApplyPrismaticRune127,             -- 战略军团制
            [128] = ApplyPrismaticRune128,             -- 不间断指挥
            [129] = ApplyPrismaticRune129,             -- 群星议院
            [130] = ApplyPrismaticRune130,             -- 信仰即资本
            [131] = ApplyPrismaticRune131,             -- 城邦联邦
            [132] = ApplyPrismaticRune132,             -- 超额区划
            [133] = ApplyPrismaticRune133,             -- 帝国动脉
            [134] = ApplyPrismaticRune134,             -- 山岳都市
            [135] = ApplyPrismaticRune135,             -- 万工会典
            [136] = ApplyPrismaticRune136,             -- 百家圣约
            [137] = ApplyPrismaticRune137,             -- 战略自由
            [138] = ApplyPrismaticRune138,             -- 万军教范
            [139] = ApplyPrismaticRune139,             -- 山岳营造法
            [140] = ApplyPrismaticRune140,             -- 圣堂军制
            [141] = ApplyPrismaticRune141,             -- 天下归枢
            [142] = ApplySilverRune142,                -- 质变：黄金
            [143] = ApplyGoldRune143,                  -- 质变：棱彩
            [144] = ApplyPrismaticRune144,             -- 一使定邦
            [145] = ApplyGoldRune145,                  -- 使节贡赋
            -- 任务型符文(12开疆拓土/20探索先锋/24学术网络)无立即应用，
            -- 效果由 OnTurnBegin/Check* 状态机处理。
        };
    end

    local handler = g_DedicationHandlers[dedicationType];
    if handler then
        local handlerResult = handler(pPlayer, stage, rarity);
        if handlerResult == "DEFERRED" then
            return "DEFERRED";
        elseif handlerResult == "RETRY" then
            return "RETRY";
        end
        return "APPLIED";
    else
        if T2D_DEFERRED_TASK_RUNE_IDS[dedicationType] then
            print("Turn2DedicationTrigger: 符文 " .. tostring(dedicationType)
                .. " 为任务型，交由回合状态机处理");
            return "DEFERRED";
        end
        print("Turn2DedicationTrigger: ❌ 符文 " .. tostring(dedicationType)
            .. " 缺少应用 handler，保留未处理状态");
        return "RETRY";
    end
end

-- ===========================================================================
-- 应用军事着力点效果：获得2个最强近战单位 + 首都产出加成
-- ===========================================================================
function ApplyMilitaryDedication(pPlayer:table)
    if not pPlayer.GetCities then
        return;
    end
    
    local pPlayerCities = pPlayer:GetCities();
    if not pPlayerCities or not pPlayerCities.GetCapitalCity then
        return;
    end
    
    local pCapital = pPlayerCities:GetCapitalCity();
    if not pCapital then
        return;
    end
    
    ApplyCapitalBonuses(pPlayer);
    
    local unitType:string = GetStrongestMeleeUnit(pPlayer);
    
    -- 创建1个最强近战单位
        CreateUnitNearCity(pPlayer, pCapital, unitType);
end

-- ===========================================================================
-- 应用科技着力点效果
-- ===========================================================================
function ApplyScienceDedication(pPlayer:table)
    if not pPlayer.AttachModifierByID then
        return;
    end
    
    pPlayer:AttachModifierByID("MODIFIER_TURN2_SCIENCE_GREAT_SCIENTIST_POINTS");
    pPlayer:AttachModifierByID("MODIFIER_TURN2_SCIENCE_CAPITAL_SCIENCE");
end

-- ===========================================================================
-- 应用文化着力点效果
-- ===========================================================================
function ApplyCultureDedication(pPlayer:table)
    if not pPlayer.AttachModifierByID then
        return;
    end
    
    pPlayer:AttachModifierByID("MODIFIER_TURN2_CULTURE_GREAT_WRITER_POINTS");
    pPlayer:AttachModifierByID("MODIFIER_TURN2_CULTURE_CAPITAL_CULTURE");
end

-- ===========================================================================
-- 应用经济着力点效果
-- ===========================================================================
function ApplyEconomyDedication(pPlayer:table)
    if not pPlayer.AttachModifierByID then
        return;
    end
    
    pPlayer:AttachModifierByID("MODIFIER_TURN2_ECONOMY_CAPITAL_GOLD");
    
    -- 注意：g_PlayerDedications 现在使用多阶段嵌套结构，不应在此处直接设置
    -- 选择信息由 OnMultiplayerChatGameplay 统一管理
    -- local playerID = pPlayer:GetID();
    -- g_PlayerDedications[playerID] = 4;
end

-- ===========================================================================
-- 应用战略储备符文效果（只应用储备上限，资源由Lua每回合给予）
-- ===========================================================================
function ApplyStrategicDedication(pPlayer:table)
    print("┌─────────────────────────────────────────────┐");
    print("│ === 应用战略储备符文效果 ===");
    print("└─────────────────────────────────────────────┘");
    
    if not pPlayer.AttachModifierByID then
        print("❌ pPlayer.AttachModifierByID 方法不存在");
        return;
    end
    
    -- 储备上限
    pPlayer:AttachModifierByID("MODIFIER_TURN2_STRATEGIC_RESOURCE_CAP");
    print("  ✓ 战略资源储备上限 +20");
    print("  ► 战略资源将由Lua脚本每回合给予");
    
    print("└─────────────────────────────────────────────┘");
end

-- ===========================================================================
-- 每回合给予已解锁的战略资源（战略储备符文）
-- ===========================================================================
function GiveStrategicResources(playerID:number)
    local pPlayer = Players[playerID];
    if not pPlayer then
        return;
    end
    
    -- 战略资源与解锁科技对照表
    local strategicResources = {
        {Type = "RESOURCE_HORSES", Tech = "TECH_ANIMAL_HUSBANDRY", Name = "马"},
        {Type = "RESOURCE_IRON", Tech = "TECH_BRONZE_WORKING", Name = "铁"},
        {Type = "RESOURCE_NITER", Tech = "TECH_MILITARY_ENGINEERING", Name = "硝石"},
        {Type = "RESOURCE_COAL", Tech = "TECH_INDUSTRIALIZATION", Name = "煤"},
        {Type = "RESOURCE_OIL", Tech = "TECH_REFINING", Name = "石油"},
        {Type = "RESOURCE_ALUMINUM", Tech = "TECH_RADIO", Name = "铝"},
        {Type = "RESOURCE_URANIUM", Tech = "TECH_COMBINED_ARMS", Name = "铀"},
    };
    
    local pPlayerTechs = pPlayer:GetTechs();
    if not pPlayerTechs then
        print("  ❌ 无法获取科技管理器");
        return;
    end
    
    local pPlayerResources = pPlayer:GetResources();
    if not pPlayerResources then
        print("  ❌ 无法获取资源管理器");
        return;
    end
    
    print("  ► 战略储备符文：检查已解锁的战略资源...");
    local giveCount = 0;
    
    for _, resource in ipairs(strategicResources) do
        -- 检查是否已研究对应科技
        local hasTech = false;
        local techInfo = GameInfo.Technologies[resource.Tech];
        if techInfo then
            hasTech = pPlayerTechs:HasTech(techInfo.Index);
        end
        
        if hasTech then
            -- 已解锁，给予资源
            local resourceInfo = GameInfo.Resources[resource.Type];
            if resourceInfo then
                pPlayerResources:ChangeResourceAmount(resourceInfo.Index, 2);
                print("    ✓ " .. resource.Name .. " +2");
                giveCount = giveCount + 1;
            end
        else
            print("    × " .. resource.Name .. " (未解锁科技)");
        end
    end
    
    if giveCount > 0 then
        print("  ✓✓✓ 本回合共给予 " .. tostring(giveCount) .. " 种战略资源");
    else
        print("  ⚠ 本回合没有已解锁的战略资源");
    end
end

-- ===========================================================================
-- 应用文化传承符文效果
-- ===========================================================================
function ApplyCultureAdvDedication(pPlayer:table, stage:number, rarity:number)
    if not pPlayer.AttachModifierByID then
        return;
    end

    -- 一次性文化进度（混合型：按预算约 1/10 折算为文化，白银约 20/60/120）
    local cultureLump = math.floor(GetStageRarityBudget(stage, rarity) / 10);
    local pCulture = pPlayer:GetCulture();
    if pCulture and pCulture.ChangeCurrentCulturalProgress then
        pCulture:ChangeCurrentCulturalProgress(cultureLump);
        print("    ✓ 立即获得" .. cultureLump .. "点文化进度");
    else
        print("    ⚠ 无法获取文化API");
    end
    
    pPlayer:AttachModifierByID("MODIFIER_TURN2_CULTURE_ADV_CAPITAL");
    pPlayer:AttachModifierByID("MODIFIER_TURN2_CULTURE_ADV_THEATER");
end

-- ===========================================================================
-- 应用开拓者符文效果
-- ===========================================================================
function ApplyPioneerDedication(pPlayer:table)
    if not pPlayer.AttachModifierByID then
        return;
    end
    
    pPlayer:AttachModifierByID("MODIFIER_TURN2_PIONEER_SCOUT_MOVEMENT");
    pPlayer:AttachModifierByID("MODIFIER_TURN2_PIONEER_CAPITAL_HOUSING");
    
    local pPlayerCities = pPlayer:GetCities();
    if pPlayerCities then
        local pCapital = pPlayerCities:GetCapitalCity();
        if pCapital then
            CreateUnitNearCity(pPlayer, pCapital, "UNIT_SCOUT");
        end
    end
end

-- ===========================================================================
-- 应用千里眼符文效果（ID39）：1个侦察兵 + 侦察兵+1移动力 + 侦察兵经验+100%
-- 说明：玩家级"侦察兵+视野"无干净的引擎接口，故以"移动力+经验"落实文本意图（均为已验证的真实Modifier）。
-- ===========================================================================
function ApplyFarSightDedication(pPlayer:table, stage:number, rarity:number)
    if not pPlayer.AttachModifierByID then return; end
    pPlayer:AttachModifierByID("MODIFIER_TURN2_PIONEER_SCOUT_MOVEMENT");  -- 复用：侦察兵+1移动力
    pPlayer:AttachModifierByID("MODIFIER_TURN2_FARSIGHT_SCOUT_XP");        -- 新增：侦察兵经验+100%
    local pPlayerCities = pPlayer:GetCities();
    if pPlayerCities then
        local pCapital = pPlayerCities:GetCapitalCity();
        if pCapital then
            CreateUnitNearCity(pPlayer, pCapital, "UNIT_SCOUT");
        end
    end
    print("Turn2DedicationTrigger: ✓ 千里眼符文已应用（侦察兵+移动力+经验）");
end

-- ===========================================================================
-- 应用治国之才符文效果（ID40）：总督头衔+1 + 有总督的城市+2生产+2金币
-- 与 ID41 千政之心区分：ID40 为有总督城市的"定额"加成，ID41 为"按总督等级递增"加成。
-- ===========================================================================
function ApplyStatecraftDedication(pPlayer:table, stage:number, rarity:number)
    if not pPlayer.AttachModifierByID then return; end
    pPlayer:AttachModifierByID("MODIFIER_TURN2_STATECRAFT_GOVERNOR_TITLE");  -- 总督头衔+1
    pPlayer:AttachModifierByID("MODIFIER_TURN2_STATECRAFT_PRODUCTION");      -- 有总督城市+2生产
    pPlayer:AttachModifierByID("MODIFIER_TURN2_STATECRAFT_GOLD");            -- 有总督城市+2金币
    print("Turn2DedicationTrigger: ✓ 治国之才符文已应用（总督头衔+有总督城市产出）");
end

-- ===========================================================================
-- 应用建筑大师符文效果
-- ===========================================================================
function ApplyArchitectDedication(pPlayer:table)
    if not pPlayer.AttachModifierByID then
        return;
    end
    
    pPlayer:AttachModifierByID("MODIFIER_TURN2_ARCHITECT_WONDER_PRODUCTION");
end

-- ===========================================================================
-- 应用外交联盟符文效果
-- ===========================================================================
function ApplyDiplomaticDedication(pPlayer:table)
    if not pPlayer.AttachModifierByID then
        return;
    end
    
    pPlayer:AttachModifierByID("MODIFIER_TURN2_DIPLOMATIC_INFLUENCE_TOKEN");
end

-- ===========================================================================
-- 给首都添加产出加成（军事着力点）
-- ===========================================================================
function ApplyCapitalBonuses(pPlayer:table)
    if not pPlayer.AttachModifierByID then
        return;
    end
    
    pPlayer:AttachModifierByID("MODIFIER_TURN2_MILITARY_CAPITAL_PRODUCTION");
    pPlayer:AttachModifierByID("MODIFIER_TURN2_MILITARY_CAPITAL_GOLD");
end

-- ===========================================================================
-- 玩家回合开始事件
-- ===========================================================================
function OnPlayerTurnStarted(playerID:number, isFirstTimeGameTurn:boolean)
    local pPlayer = Players[playerID];
    if not pPlayer or not pPlayer:IsHuman() then
        return;
    end

    -- 所有 Property、Modifier、单位和资源变化都只由房主执行。
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    local currentTurn = Game.GetCurrentGameTurn();
    -- OnGameTurnStarted 正常会先建立全局品质；这里作为规则集/事件顺序差异的幂等兜底。
    T2D_EnsureGlobalRarityForCurrentTurn(currentTurn);
    local okPendingNotification, pendingNotificationError = pcall(
        T2D_ReconcileRuneSelectionNotification, playerID, currentTurn);
    if not okPendingNotification then
        print("Turn2DedicationTrigger: ⚠ 待选符文通知校准失败："
            .. tostring(pendingNotificationError));
    end

    -- 80 正常在 PlayerTurnStartComplete 结算，确保本回合的原生金币收益已经处理。
    -- 旧版/特殊规则集缺少该事件时才在这里回退；LastChargeTurn 仍会防止重复。
    if g_T2DGold80UseTurnStartedFallback and T2D_ProcessGold80Debt then
        local okGold80, gold80Error = pcall(T2D_ProcessGold80Debt, pPlayer, playerID, currentTurn);
        if not okGold80 then
            print("Turn2DedicationTrigger: ⚠ 竭泽而渔回退结算失败，其他回合逻辑继续: "
                .. tostring(gold80Error));
        end
    end
    if T2D_CheckGold71Unlocks then
        local okGold71, gold71Error = pcall(T2D_CheckGold71Unlocks, pPlayer, playerID);
        if not okGold71 then
            print("Turn2DedicationTrigger: ⚠ 求知使团状态检查失败，其他回合逻辑继续: "
                .. tostring(gold71Error));
        end
    end

    -- 应用回合=选择回合+1；使用 >= 允许数据库/脚本暂时失败后在后续玩家回合重试。
    local stageApplyTurns = {};
    for stage = 1, 3 do
        local selectionTurn = T2D_GetConfiguredSelectionTurn(stage);
        if selectionTurn then stageApplyTurns[stage] = selectionTurn + 1; end
    end

    for stage = 1, 3 do
        local applyTurn = stageApplyTurns[stage];
        if applyTurn and currentTurn >= applyTurn then
            local processedKey = "Turn2Dedication_Applied_Stage" .. stage .. "_P" .. playerID;
            if not Game.GetProperty(processedKey) then
                local stageKey = "Turn2Dedication_Stage" .. stage .. "_P" .. playerID;
                local dedicationType = T2D_GetNumberGameProperty(stageKey, nil);

                -- 错过配置回合的阶段直接结案；绝不回退 ActiveRune 或默认 ID 1。
                if not dedicationType then
                    local missedKey = "Turn2Dedication_Stage" .. tostring(stage)
                        .. "_Missed_P" .. tostring(playerID);
                    if Game.GetProperty(missedKey) ~= nil then
                        Game.SetProperty(processedKey, 1);
                        print("Turn2DedicationTrigger: ⏭ 阶段" .. stage
                            .. "选择已错过，本阶段不再应用符文");
                    else
                        print("Turn2DedicationTrigger: ⓘ 阶段" .. stage
                            .. "尚无权威选择，暂不处理");
                    end
                elseif not T2D_IsValidRuneID(dedicationType) then
                    print("Turn2DedicationTrigger: ❌ 阶段" .. stage
                        .. "包含无效符文ID，保留未处理状态: " .. tostring(dedicationType));
                else
                    local rarityCode = T2D_GetNumberGameProperty(
                        "Turn2Dedication_Rarity_Stage" .. stage .. "_P" .. playerID, 1);
                    if rarityCode < 1 or rarityCode > 3 or rarityCode ~= math.floor(rarityCode) then
                        rarityCode = 1;
                    end

                    local devKey = "Turn2Dedication_DevRune_P" .. playerID .. "_R" .. dedicationType;
                    -- 116允许跨阶段重复取得；即使曾由图鉴测试应用，也必须进入
                    -- 阶段幂等 handler，才能发放该阶段独立的2/4/6人口奖励。
                    if Game.GetProperty(devKey) ~= nil and dedicationType ~= 116 then
                        Game.SetProperty(processedKey, 1);
                        print("Turn2DedicationTrigger: ⓘ 阶段" .. stage .. "符文 "
                            .. dedicationType .. " 已由开发者模式应用，本阶段记录完成");
                    else
                        local okApply, result = pcall(function()
                            return ApplyDedicationEffect(pPlayer, dedicationType, stage, rarityCode);
                        end);
                        if okApply and (result == "APPLIED" or result == "DEFERRED") then
                            Game.SetProperty(processedKey, 1);
                            print("Turn2DedicationTrigger: ✅ 阶段" .. stage
                                .. "符文已应用并标记（" .. tostring(result) .. "）");
                        elseif okApply and result == "CONFLICT" then
                            T2D_SetSelectionAck(playerID, stage, dedicationType, "CONFLICT");
                            print("Turn2DedicationTrigger: ❌ 阶段" .. stage
                                .. "符文与已拥有符文互斥，未挂载且保留未处理状态");
                        elseif okApply and result == "RETRY" then
                            print("Turn2DedicationTrigger: ⓘ 阶段" .. stage
                                .. "符文等待前置条件，保留未处理状态供下回合重试");
                        elseif okApply then
                            print("Turn2DedicationTrigger: ❌ 阶段" .. stage
                                .. "返回未知状态，保留未处理以便重试: " .. tostring(result));
                        else
                            print("Turn2DedicationTrigger: ❌ 阶段" .. stage
                                .. "符文应用失败，保留未处理以便重试: " .. tostring(result));
                        end
                    end
                end
            end
        end
    end

    -- 棱彩机制状态机各自隔离：政策解锁或单城市奖励失败时，
    -- 不得阻断本回合其他符文与旧机制的处理。全局函数定义在 SafeAttach 辅助之后。
    if T2D_CheckPrismatic125LegacyPolicies then
        local ok125, error125 = pcall(T2D_CheckPrismatic125LegacyPolicies, pPlayer, playerID);
        if not ok125 then
            print("Turn2DedicationTrigger: ⚠ 无定宪章传承政策检查失败，其他回合逻辑继续: "
                .. tostring(error125));
        end
    end
    if T2D_CheckPrismatic126PendingCities then
        local ok126, error126 = pcall(T2D_CheckPrismatic126PendingCities, pPlayer, playerID);
        if not ok126 then
            print("Turn2DedicationTrigger: ⚠ 万城柱石新城奖励重试失败，其他回合逻辑继续: "
                .. tostring(error126));
        end
    end
    if T2D_CheckPrismatic131EraEnvoys then
        local ok131, error131 = pcall(T2D_CheckPrismatic131EraEnvoys, pPlayer, playerID);
        if not ok131 then
            print("Turn2DedicationTrigger: ⚠ 城邦联邦时代使者检查失败，其他回合逻辑继续: "
                .. tostring(error131));
        end
    end
    if T2D_ReconcilePrismatic138Fortification then
        local ok138, error138 = pcall(T2D_ReconcilePrismatic138Fortification, pPlayer, playerID);
        if not ok138 then
            print("Turn2DedicationTrigger: ⚠ 万军教范驻扎校准失败，其他回合逻辑继续: "
                .. tostring(error138));
        end
    end
    if T2D_ReconcilePrismatic139Player then
        local ok139, error139 = pcall(T2D_ReconcilePrismatic139Player, pPlayer, playerID);
        if not ok139 then
            print("Turn2DedicationTrigger: ⚠ 山岳营造法生产队列校准失败，其他回合逻辑继续: "
                .. tostring(error139));
        end
    end
    if T2D_CheckPrismatic140ProphetPoints then
        local ok140, error140 = pcall(T2D_CheckPrismatic140ProphetPoints, pPlayer, playerID);
        if not ok140 then
            print("Turn2DedicationTrigger: ⚠ 圣堂军制大预言家点数检查失败，其他回合逻辑继续: "
                .. tostring(error140));
        end
    end
    if T2D_EnsurePrismatic141Thresholds then
        local ok141, error141 = pcall(T2D_EnsurePrismatic141Thresholds, pPlayer, playerID);
        if not ok141 then
            print("Turn2DedicationTrigger: ⚠ 天下归枢城市阈值扩展失败，其他回合逻辑继续: "
                .. tostring(error141));
        end
    end
    if T2D_ReconcilePrismatic144 then
        local ok144, error144 = pcall(T2D_ReconcilePrismatic144, pPlayer, playerID);
        if not ok144 then
            print("Turn2DedicationTrigger: ⚠ 一使定邦补派检查失败，其他回合逻辑继续: "
                .. tostring(error144));
        end
    end
    
    if CheckSilverRuneTurnRewards then
        CheckSilverRuneTurnRewards(pPlayer, playerID);
    end

    -- 检查封建萌芽：时代变更时赠送工人
    if g_FeudalBudPlayers[playerID] then
        local feudalData = g_FeudalBudPlayers[playerID];
        local currentEra = GetCurrentEra(pPlayer);
        
        -- 如果时代前进了，赠送工人（每次时代变更都赠送）
        if currentEra > feudalData.currentEra then
            print("封建萌芽：玩家 " .. playerID .. " 进入新时代（" .. feudalData.currentEra .. " -> " .. currentEra .. "），赠送工人");
            
            local pPlayerCities = pPlayer:GetCities();
            if pPlayerCities then
                local pCapital = pPlayerCities:GetCapitalCity();
                if pCapital then
                    local success = CreateUnitNearCity(pPlayer, pCapital, "UNIT_BUILDER");
                    if success then
                        print("  ✓ 成功为首都赠送工人（时代变更奖励）");
                    else
                        print("  ❌ 赠送工人失败");
                    end
                end
            end
            -- 更新当前时代（允许下次时代变更再次触发）
            feudalData.currentEra = currentEra;
            Game.SetProperty("TURN2_FEUDAL_BUD_ERA_P" .. playerID, currentEra);
        end
    end
    
    -- 检查智慧之光：进入中世纪时升级效果
    if g_WisdomLightPlayers[playerID] then
        local wisdomData = g_WisdomLightPlayers[playerID];
        local currentEra = GetCurrentEra(pPlayer);
        
        -- ERA_MEDIEVAL 是中世纪，索引为2
        if currentEra >= 2 and not wisdomData.hasUpgraded then
            print("智慧之光：玩家 " .. playerID .. " 进入中世纪，升级效果");
            
            -- 应用第2阶段加成（所有城市 +2 科技 +2 文化）
            if pPlayer.AttachModifierByID then
                local success1 = pcall(function()
                    pPlayer:AttachModifierByID("MODIFIER_TURN2_WISDOM_LIGHT_SCIENCE_TIER2");
                end);
                local success2 = pcall(function()
                    pPlayer:AttachModifierByID("MODIFIER_TURN2_WISDOM_LIGHT_CULTURE_TIER2");
                end);
                
                if success1 and success2 then
                    print("  ✓✓✓ 成功应用：所有城市额外 +1 科技 +1 文化（叠加后总计+2）");
                    wisdomData.hasUpgraded = true;
                else
                    print("  ❌ 应用第2阶段修改器失败");
                end
            end
        end
    end
end


-- ===========================================================================
-- 游戏回合开始
-- ===========================================================================
function OnTurnBegin()
    local currentTurn = Game.GetCurrentGameTurn();
    print("╔══════════════════════════════════════════════╗");
    print("║ Gameplay: 回合开始 - 回合 " .. tostring(currentTurn));
    print("╚══════════════════════════════════════════════╝")
    
    -- 只在单人或多人房主端执行（与其他同步状态入口使用同一权威门控）。
    if not T2D_IsAuthoritativeGameplay() then return; end

    -- 在本阶段任何玩家打开选择面板前，只由房主掷一次全局品质。
    T2D_EnsureGlobalRarityForCurrentTurn(currentTurn);
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsAlive() and pPlayer:IsHuman() then
            local okPendingNotification, pendingNotificationError = pcall(
                T2D_ReconcileRuneSelectionNotification, playerID, currentTurn);
            if not okPendingNotification then
                print("Turn2DedicationTrigger: ⚠ 待选符文通知校准失败 P"
                    .. tostring(playerID) .. "：" .. tostring(pendingNotificationError));
            end
        end
    end
    
    -- 每回合给予战略储备符文玩家已解锁的战略资源
    if currentTurn >= 4 then
        for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
            local pPlayer = Players[playerID];
            if pPlayer and pPlayer:IsHuman() and pPlayer:IsAlive() then
                if PlayerHasDedication(playerID, 6) then  -- 战略储备=ID6（已与符文命名对齐）
                    GiveStrategicResources(playerID);
                end
            end
        end
    end
    
    -- 第15回合：给选择了经济着力点的玩家添加贸易路线
    if currentTurn == 15 then
        print("╔══════════════════════════════════════════════╗");
        print("║ 第15回合：检查经济着力点玩家");
        print("╚══════════════════════════════════════════════╝");
        
        -- 检查所有人类玩家
        for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
            local pPlayer = Players[playerID];
            if pPlayer and pPlayer:IsHuman() and pPlayer:IsAlive() then
                if PlayerHasDedication(playerID, 4) then
                    print("  ✓ 玩家 " .. tostring(playerID) .. " 选择了经济着力点");
                    print("  ► 给予贸易路线 +1...");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_ECONOMY_TRADE_ROUTE");
                        print("  ✓✓✓ 贸易路线 +1 已给予");
                    else
                        print("  ❌ AttachModifierByID 方法不存在");
                    end
                end
            end
        end
    end
    
    -- 每回合检查开疆拓土符文的条件
    CheckExpansionDedicationMilestones();
    
    -- 每回合检查征服之路符文的条件
    CheckConquestDedicationMilestones();
    
    -- 每回合检查探索先锋符文的条件
    CheckExplorationDedicationMilestones();
    
    -- 奇观狂魔符文（预留函数，实际奖励在奇观完成时发放）
    CheckWonderDedicationEffects();
    
    -- 每回合检查文艺复兴符文的条件
    CheckRenaissanceDedicationEffects();
    
    -- 每回合检查古典时代相关符文的条件
    CheckClassicalEraEffects();
    
    -- 每回合检查龟型阵符文的回合奖励
    CheckTurtleFormationRewards();
    
    -- 每回合检查骑兵突击符文的回合奖励
    CheckCavalryAssaultRewards();
end

-- ===========================================================================
-- 检查开疆拓土符文的城市数量里程碑
-- ===========================================================================
function CheckExpansionDedicationMilestones()
    -- 只在非多人游戏或房主端执行
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsHuman() and pPlayer:IsAlive() then
            -- 只处理选择了开疆拓土符文（12）的玩家（支持多阶段）
            if PlayerHasDedication(playerID, 12) then
                local pPlayerCities = pPlayer:GetCities();
                if not pPlayerCities then
                    return;
                end
                
                local cityCount = pPlayerCities:GetCount();
                local currentEraIndex = -1;
                
                -- 获取当前时代索引
                if Game and Game.GetEras then
                    local gameEras = Game.GetEras();
                    if gameEras and gameEras.GetCurrentEra then
                        currentEraIndex = gameEras:GetCurrentEra();
                    end
                end
                
                -- 获取已应用的最高层级
                local appliedTier = Game.GetProperty("TURN2_EXPANSION_TIER_P" .. playerID) or 0;
                
                -- 定义时代常量（参考原版）
                local ERA_ANCIENT = 0;
                local ERA_CLASSICAL = 1;
                local ERA_MEDIEVAL = 2;
                local ERA_RENAISSANCE = 3;
                local ERA_INDUSTRIAL = 4;
                
                -- 检查每个里程碑
                local newTier = appliedTier;
                
                -- 古典时代：6城
                if currentEraIndex >= ERA_CLASSICAL and cityCount >= 6 and appliedTier < 1 then
                    print("开疆拓土：玩家 " .. playerID .. " 达成古典时代里程碑（6城）");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPANSION_CLASSICAL_CULTURE");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPANSION_CLASSICAL_PRODUCTION");
                        print("  ✓ 已应用：所有城市+1文化+1生产力");
                    end
                    newTier = 1;
                end
                
                -- 中世纪：8城
                if currentEraIndex >= ERA_MEDIEVAL and cityCount >= 8 and appliedTier < 2 then
                    print("开疆拓土：玩家 " .. playerID .. " 达成中世纪里程碑（8城）");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPANSION_MEDIEVAL_SCIENCE");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPANSION_MEDIEVAL_PRODUCTION");
                        print("  ✓ 已应用：所有城市+1科技+1生产力");
                    end
                    newTier = 2;
                end
                
                -- 文艺复兴：11城
                if currentEraIndex >= ERA_RENAISSANCE and cityCount >= 11 and appliedTier < 3 then
                    print("开疆拓土：玩家 " .. playerID .. " 达成文艺复兴里程碑（11城）");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPANSION_RENAISSANCE_GOLD");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPANSION_RENAISSANCE_PRODUCTION");
                        print("  ✓ 已应用：所有城市+2金币+1生产力");
                    end
                    newTier = 3;
                end
                
                -- 工业时代层已移除（封顶）：开疆拓土按城市数线性放大，删去无限放大的尾段以贴合 prismatic 预算（约2000金）。
                
                -- 更新已应用的层级
                if newTier > appliedTier then
                    Game.SetProperty("TURN2_EXPANSION_TIER_P" .. playerID, newTier);
                end
            end
        end
    end
end

-- ===========================================================================
-- 宗教信仰符文效果：首都+2信仰，每回合+1大预言家点数
-- ===========================================================================
function ApplyReligionDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 宗教信仰符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 检查首都
    local pCapital = pPlayer:GetCities():GetCapitalCity();
    if pCapital then
        print("  ✓ 首都存在: " .. pCapital:GetName());
        print("    首都坐标: (" .. pCapital:GetX() .. ", " .. pCapital:GetY() .. ")");
    else
        print("  ❌ 错误：玩家没有首都！");
        return;
    end
    
    -- 首都 +2 信仰
    print("  ► 尝试应用修改器：MODIFIER_TURN2_RELIGION_CAPITAL_FAITH");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_RELIGION_CAPITAL_FAITH");
        end);
        if success then
            print("  ✓✓✓ 成功应用：首都+2信仰");
        else
            print("  ❌❌❌ 失败：无法应用首都+2信仰修改器");
        end
    else
        print("  ❌ 错误：AttachModifierByID 方法不存在");
    end
    
    -- 每回合 +1 大预言家点数
    print("  ► 尝试应用修改器：MODIFIER_TURN2_RELIGION_GREAT_PROPHET_POINTS");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_RELIGION_GREAT_PROPHET_POINTS");
        end);
        if success then
            print("  ✓✓✓ 成功应用：每回合+1大预言家点数");
        else
            print("  ❌❌❌ 失败：无法应用大预言家点数修改器");
        end
    end
    
    print("╚════════════════════════════════════════════════════════");
    print("  注：古典时代获得传教士在CheckClassicalEraEffects中处理");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 学术精英符文效果：学院+1科技，学院建造速度+25%
-- ===========================================================================
function ApplyAcademicDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 学术精英符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 学院 +1 科技
    print("  ► 尝试应用修改器：MODIFIER_TURN2_ACADEMIC_CAMPUS_SCIENCE");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_ACADEMIC_CAMPUS_SCIENCE");
        end);
        if success then
            print("  ✓✓✓ 成功应用：学院+1科技");
        else
            print("  ❌❌❌ 失败：无法应用学院科技修改器");
        end
    end
    
    -- 学院建造速度 +25%
    print("  ► 尝试应用修改器：MODIFIER_TURN2_ACADEMIC_CAMPUS_SPEED");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_ACADEMIC_CAMPUS_SPEED");
        end);
        if success then
            print("  ✓✓✓ 成功应用：学院建造速度+25%");
        else
            print("  ❌❌❌ 失败：无法应用学院建造速度修改器");
        end
    end
    
    print("╚════════════════════════════════════════════════════════");
    print("  注：原计划的古典时代图书馆奖励因技术限制已移除");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 商贸网络符文效果：每回合+1大商人点数，贸易路线加成
-- ===========================================================================
function ApplyTradeNetworkDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 商贸网络符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 每回合 +1 大商人点数
    print("  ► 尝试应用修改器：MODIFIER_TURN2_TRADE_GREAT_MERCHANT_POINTS");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_TRADE_GREAT_MERCHANT_POINTS");
        end);
        if success then
            print("  ✓✓✓ 成功应用：每回合+1大商人点数");
        else
            print("  ❌❌❌ 失败：无法应用大商人点数修改器");
        end
    end
    
    -- 贸易路线 +1 金币（贸易站）
    print("  ► 尝试应用修改器：MODIFIER_TURN2_TRADE_ROUTE_GOLD");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_TRADE_ROUTE_GOLD");
        end);
        if success then
            print("  ✓✓✓ 成功应用：贸易路线每贸易站+1金币");
        else
            print("  ❌❌❌ 失败：无法应用贸易路线金币修改器");
        end
    end
    
    -- 贸易路线 +1 生产力（贸易站）
    print("  ► 尝试应用修改器：MODIFIER_TURN2_TRADE_ROUTE_PRODUCTION");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_TRADE_ROUTE_PRODUCTION");
        end);
        if success then
            print("  ✓✓✓ 成功应用：贸易路线每贸易站+1生产力");
        else
            print("  ❌❌❌ 失败：无法应用贸易路线生产力修改器");
        end
    end
    
    print("╚════════════════════════════════════════════════════════");
    print("  注：古典时代获得商路容量+商人在CheckClassicalEraEffects中处理");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 农业革新符文效果：农场+1食物，粮仓/水磨建造速度+25%
-- ===========================================================================
function ApplyAgricultureDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 农业革新符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 农场 +1 食物
    print("  ► 尝试应用修改器：MODIFIER_TURN2_AGRICULTURE_FARM_FOOD");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_AGRICULTURE_FARM_FOOD");
        end);
        if success then
            print("  ✓✓✓ 成功应用：农场额外+1食物");
        else
            print("  ❌❌❌ 失败：无法应用农场食物修改器");
        end
    end
    
    -- 粮仓建造速度 +100%
    print("  ► 尝试应用修改器：MODIFIER_TURN2_AGRICULTURE_GRANARY_SPEED");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_AGRICULTURE_GRANARY_SPEED");
        end);
        if success then
            print("  ✓✓✓ 成功应用：粮仓建造速度+100%");
        else
            print("  ❌❌❌ 失败：无法应用粮仓建造速度修改器");
        end
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 军事主义符文效果：获得投石兵，军营建造速度+25%，每回合+1大将军点数
-- ===========================================================================
function ApplyMilitarismDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 军事主义符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 军营建造速度 +25%
    print("  ► 尝试应用修改器：MODIFIER_TURN2_MILITARISM_ENCAMPMENT_SPEED");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_MILITARISM_ENCAMPMENT_SPEED");
        end);
        if success then
            print("  ✓✓✓ 成功应用：军营建造速度+25%");
        else
            print("  ❌❌❌ 失败：无法应用军营建造速度修改器");
        end
    end
    
    -- 获得一个投石兵
    print("  ► 尝试创建投石兵单位");
    local pPlayerUnits = pPlayer:GetUnits();
    if pPlayerUnits then
        local pCapitalCity = pPlayer:GetCities():GetCapitalCity();
        if pCapitalCity then
            local iX = pCapitalCity:GetX();
            local iY = pCapitalCity:GetY();
            print("    首都坐标: (" .. iX .. ", " .. iY .. ")");
            local pUnit = pPlayerUnits:Create(GameInfo.Units["UNIT_SLINGER"].Index, iX, iY);
            if pUnit then
                print("  ✓✓✓ 成功创建：投石兵于首都");
            else
                print("  ❌❌❌ 失败：无法创建投石兵");
            end
        else
            print("  ❌ 错误：玩家没有首都");
        end
    else
        print("  ❌ 错误：无法获取玩家单位管理器");
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 防御工事符文效果：城墙生命值+15，远古城墙建造速度+50%
-- ===========================================================================
function ApplyFortificationDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 防御工事符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 远古城墙建造速度 +50%
    print("  ► 尝试应用修改器：MODIFIER_TURN2_FORTIFICATION_WALL_SPEED");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_FORTIFICATION_WALL_SPEED");
        end);
        if success then
            print("  ✓✓✓ 成功应用：远古城墙建造速度+50%");
        else
            print("  ❌❌❌ 失败：无法应用城墙建造速度修改器");
        end
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 文艺复兴符文效果：进入中世纪/文艺复兴时代后，除大将军外所有伟人点数+1.5
-- ===========================================================================
function ApplyRenaissanceDedication(pPlayer:table)
    print("Turn2DedicationTrigger: 应用文艺复兴符文效果");
    -- 检查当前时代，如果已经是中世纪或更晚，立即应用
    local currentEra = Game.GetEras():GetCurrentEra();
    local ERA_MEDIEVAL = GameInfo.Eras["ERA_MEDIEVAL"].Index or 2;
    
    if currentEra >= ERA_MEDIEVAL then
        ApplyRenaissanceGreatPersonBonus(pPlayer);
        print("  ✓ 当前时代满足条件，已立即应用伟人点数加成");
    else
        print("  ✓ 已记录：将在进入中世纪/文艺复兴时代时应用");
    end
end

-- ===========================================================================
-- 应用文艺复兴符文的伟人点数加成
-- ===========================================================================
function ApplyRenaissanceGreatPersonBonus(pPlayer:table)
    if pPlayer.AttachModifierByID then
        pPlayer:AttachModifierByID("MODIFIER_TURN2_RENAISSANCE_PROPHET_POINTS");
        pPlayer:AttachModifierByID("MODIFIER_TURN2_RENAISSANCE_MERCHANT_POINTS");
        pPlayer:AttachModifierByID("MODIFIER_TURN2_RENAISSANCE_SCIENTIST_POINTS");
        pPlayer:AttachModifierByID("MODIFIER_TURN2_RENAISSANCE_ARTIST_POINTS");
        pPlayer:AttachModifierByID("MODIFIER_TURN2_RENAISSANCE_ENGINEER_POINTS");
        pPlayer:AttachModifierByID("MODIFIER_TURN2_RENAISSANCE_WRITER_POINTS");
        pPlayer:AttachModifierByID("MODIFIER_TURN2_RENAISSANCE_MUSICIAN_POINTS");
        print("  ✓ 已应用：除大将军外所有伟人点数+1.5");
    end
end

-- ===========================================================================
-- 奇观狂魔符文效果：奇观建造速度+5%，每个奇观完成时获得125%实际成本的金币
-- ===========================================================================
function ApplyWonderDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 奇观狂魔符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 奇观建造速度 +5%
    print("  ► 尝试应用修改器：MODIFIER_TURN2_WONDER_BUILD_SPEED");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_WONDER_BUILD_SPEED");
        end);
        if success then
            print("  ✓✓✓ 成功应用：奇观建造速度+5%");
        else
            print("  ❌❌❌ 失败：无法应用奇观建造速度修改器");
        end
    end
    
    print("╚════════════════════════════════════════════════════════");
    print("  注：每个奇观完成时立即获得125%实际建造成本的金币");
    print("  注：实际成本 = 基础成本 × 游戏速度修正");
    print("  注：金币通过OnWonderCompletedGameplay函数发放");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 龟型阵符文效果：抗骑兵单位建造速度+15%，选择回合+15和+25回合后获得重装枪兵
-- ===========================================================================
function ApplyTurtleFormationDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 龟型阵符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 记录选择回合（用于计算15回合后和25回合后）
    local currentTurn = Game.GetCurrentGameTurn();
    Game.SetProperty("Turn2Dedication_ChoiceTurn_P" .. playerID .. "_D23", currentTurn);
    print("  ✓ 记录选择回合: " .. currentTurn);
    
    -- 应用抗骑兵单位建造速度修改器（所有时代）
    print("  ► 应用抗骑兵单位建造速度+15%（所有时代）");
    if pPlayer.AttachModifierByID then
        local modifiers = {
            "MODIFIER_TURN2_TURTLE_ANTICAV_ANCIENT",
            "MODIFIER_TURN2_TURTLE_ANTICAV_CLASSICAL",
            "MODIFIER_TURN2_TURTLE_ANTICAV_MEDIEVAL",
            "MODIFIER_TURN2_TURTLE_ANTICAV_RENAISSANCE",
            "MODIFIER_TURN2_TURTLE_ANTICAV_INDUSTRIAL",
            "MODIFIER_TURN2_TURTLE_ANTICAV_MODERN",
            "MODIFIER_TURN2_TURTLE_ANTICAV_ATOMIC",
            "MODIFIER_TURN2_TURTLE_ANTICAV_INFORMATION"
        };
        
        local successCount = 0;
        for _, modifierID in ipairs(modifiers) do
        local success = pcall(function()
                pPlayer:AttachModifierByID(modifierID);
        end);
        if success then
                successCount = successCount + 1;
        end
    end
    
        if successCount == 8 then
            print("  ✓✓✓ 成功应用：抗骑兵单位建造速度+15%（全时代）");
        elseif successCount > 0 then
            print("  ⚠️ 部分成功：应用了" .. successCount .. "/8个时代修改器");
        else
            print("  ❌❌❌ 失败：无法应用抗骑兵单位建造速度修改器");
        end
    end
    
    print("╚════════════════════════════════════════════════════════");
    print("  注：选择回合+15和+25回合后将获得重装枪兵");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 符文召唤效果：立即获得2个符文战士
-- ===========================================================================
function ApplyRuneSummoningDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 符文召唤 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 立即创建2个符文战士
    print("  ► 召唤符文战士...");
    CreateRuneWarrior(pPlayer, 2);
    
    print("╔════════════════════════════════════════════════════════");
    print("║ 符文召唤 - 应用完成");
    print("╚════════════════════════════════════════════════════════");
    print("  效果：立即获得2个符文战士（战斗力36，移动力3）");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 远程精通符文效果：获得弓箭手，远程单位建造+20%，平坦地形+1移动力
-- ===========================================================================
function ApplyRangedMasteryDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 远程精通 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    if not pPlayer.AttachModifierByID then
        print("  ❌ AttachModifierByID 方法不可用");
        return;
    end
    
    -- 1. 应用远程单位建造速度+20%（所有时代）
    print("  ► 应用远程单位建造速度+20%（所有时代）");
    local rangedModifiers = {
        "MODIFIER_TURN2_RANGED_ANCIENT",
        "MODIFIER_TURN2_RANGED_CLASSICAL",
        "MODIFIER_TURN2_RANGED_MEDIEVAL",
        "MODIFIER_TURN2_RANGED_RENAISSANCE",
        "MODIFIER_TURN2_RANGED_INDUSTRIAL",
        "MODIFIER_TURN2_RANGED_MODERN",
        "MODIFIER_TURN2_RANGED_ATOMIC",
        "MODIFIER_TURN2_RANGED_INFORMATION"
    };
    
    local successCount = 0;
    for _, modifierID in ipairs(rangedModifiers) do
        local success = pcall(function()
            pPlayer:AttachModifierByID(modifierID);
        end);
        if success then
            successCount = successCount + 1;
        end
    end
    print("  ✓ 远程建造速度修改器: " .. successCount .. "/8");
    
    -- 2. 授予远程单位平坦地形+1移动力能力
    print("  ► 应用平坦地形移动力能力");
    local success = pcall(function()
        pPlayer:AttachModifierByID("MODIFIER_TURN2_RANGED_GRANT_TERRAIN_ABILITY");
    end);
    if success then
        print("  ✓ 远程单位平坦地形+1移动力能力已授予");
    else
        print("  ❌ 能力授予失败");
    end
    
    -- 3. 在首都创建1个弓箭手
    print("  ► 创建弓箭手");
    local pPlayerCities = pPlayer:GetCities();
    if pPlayerCities then
        local pCapital = pPlayerCities:GetCapitalCity();
        if pCapital then
            local created = CreateUnitNearCity(pPlayer, pCapital, "UNIT_ARCHER");
            if created then
                print("  ✓ 弓箭手已创建于首都");
            else
                print("  ❌ 弓箭手创建失败");
            end
        end
    end
    
    print("╔════════════════════════════════════════════════════════");
    print("║ 远程精通 - 应用完成");
    print("╚════════════════════════════════════════════════════════");
end

-- ===========================================================================
-- 塔玛丽之魂：解锁砌砖术+首都城墙+城墙信仰
-- ===========================================================================
function ApplyTamarisSoulDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 塔玛丽之魂 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 1. 立即解锁砌砖术科技
    print("  ► 解锁砌砖术科技");
    local pPlayerTechs = pPlayer:GetTechs();
    if pPlayerTechs then
        local techInfo = GameInfo.Technologies["TECH_MASONRY"];
        if techInfo then
            if not pPlayerTechs:HasTech(techInfo.Index) then
                pPlayerTechs:SetResearchingTech(techInfo.Index);
                pPlayerTechs:SetResearchProgress(techInfo.Index, pPlayerTechs:GetResearchCost(techInfo.Index));
                print("  ✓ 砌砖术已解锁");
            else
                print("  ⓘ 砌砖术已研究过，跳过");
            end
        else
            print("  ❌ 找不到 TECH_MASONRY 定义");
        end
    else
        print("  ❌ 无法获取科技管理器");
    end
    
    -- 2. 首都获得远古城墙
    print("  ► 在首都建造远古城墙");
    local pPlayerCities = pPlayer:GetCities();
    if pPlayerCities then
        local pCapital = pPlayerCities:GetCapitalCity();
        if pCapital then
            local wallsInfo = GameInfo.Buildings["BUILDING_WALLS"];
            if wallsInfo then
                local pCityBuildQueue = pCapital:GetBuildQueue();
                if pCityBuildQueue then
                    pCityBuildQueue:CreateIncompleteBuilding(wallsInfo.Index, 100);
                    print("  ✓ 远古城墙已建造于首都");
                else
                    print("  ❌ 无法获取城市建造队列");
                end
            else
                print("  ❌ 找不到 BUILDING_WALLS 定义");
            end
        else
            print("  ❌ 玩家没有首都");
        end
    else
        print("  ❌ 无法获取城市列表");
    end
    
    -- 3. 附加城墙信仰修正器（所有级别城墙）
    print("  ► 附加城墙信仰修正器");
    if pPlayer.AttachModifierByID then
        local modifiers = {
            "MODIFIER_TURN2_TAMARIS_WALLS_FAITH",
            "MODIFIER_TURN2_TAMARIS_CASTLE_FAITH",
            "MODIFIER_TURN2_TAMARIS_STAR_FORT_FAITH",
        };
        local successCount = 0;
        for _, modID in ipairs(modifiers) do
            local success = pcall(function()
                pPlayer:AttachModifierByID(modID);
            end);
            if success then
                successCount = successCount + 1;
            end
        end
        print("  ✓ 城墙信仰修正器: " .. successCount .. "/3");
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    print("╔════════════════════════════════════════════════════════");
    print("║ 塔玛丽之魂 - 应用完成");
    print("╚════════════════════════════════════════════════════════");
end

-- ===========================================================================
-- 千政之心符文：+1总督头衔 + 有总督城市按等级获得产出
-- ===========================================================================
function ApplyThousandHeartsDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 千政之心 - 开始应用");
    print("╚════════════════════════════════════════════════════════");

    if not pPlayer.AttachModifierByID then
        print("  ❌ AttachModifierByID 方法不可用");
        return;
    end

    -- 1. 总督头衔 +1（RunOnce）
    print("  ► 附加总督头衔修正器");
    pPlayer:AttachModifierByID("MODIFIER_TURN2_THOUSAND_HEARTS_GOVERNOR_TITLE");

    -- 2. 分层城市产出修正器（共10个）
    local modifiers = {
        "MODIFIER_TURN2_THOUSAND_HEARTS_T1_PRODUCTION",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T1_GOLD",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T1_SCIENCE",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T2_PRODUCTION",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T2_GOLD",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T2_SCIENCE",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T3_PRODUCTION",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T3_GOLD",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T3_SCIENCE",
        "MODIFIER_TURN2_THOUSAND_HEARTS_T3_CULTURE",
    };

    print("  ► 附加城市产出修正器（10个）");
    local successCount = 0;
    for _, modID in ipairs(modifiers) do
        local success = pcall(function()
            pPlayer:AttachModifierByID(modID);
        end);
        if success then
            successCount = successCount + 1;
        end
    end
    print("  ✓ 城市产出修正器: " .. successCount .. "/10");

    print("╔════════════════════════════════════════════════════════");
    print("║ 千政之心 - 应用完成");
    print("╚════════════════════════════════════════════════════════");
end

-- ===========================================================================
-- 税收改革符文效果：每人口+1金币，10+人口城市每人口+2金币
-- ===========================================================================
function ApplyTaxReformDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 税收改革 - 开始应用");
    print("╚════════════════════════════════════════════════════════");

    if not pPlayer.AttachModifierByID then
        print("  ❌ AttachModifierByID 方法不可用");
        return;
    end

    -- 1. 基础层：所有城市每人口+1金币
    print("  ► 附加基础层修正器：每人口+1金币");
    local success1 = pcall(function()
        pPlayer:AttachModifierByID("MODIFIER_TURN2_TAX_REFORM_GOLD_PER_POP");
    end);
    if success1 then
        print("  ✓ 基础层已应用：所有城市每人口+1金币");
    else
        print("  ❌ 基础层应用失败");
    end

    -- 2. 奖励层：10+人口城市每人口额外+1金币（总计+2）
    print("  ► 附加奖励层修正器：10+人口城市每人口额外+1金币");
    local success2 = pcall(function()
        pPlayer:AttachModifierByID("MODIFIER_TURN2_TAX_REFORM_GOLD_PER_POP_BONUS");
    end);
    if success2 then
        print("  ✓ 奖励层已应用：10+人口城市每人口额外+1金币");
    else
        print("  ❌ 奖励层应用失败");
    end

    print("╔════════════════════════════════════════════════════════");
    print("║ 税收改革 - 应用完成");
    print("╚════════════════════════════════════════════════════════");
    print("  效果：每人口+1金币，10+人口城市每人口+2金币");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 骑士精神符文效果：获得2个骑士 + 重骑兵生产速度+10%
-- ===========================================================================
function ApplyChivalryDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 骑士精神 - 开始应用");
    print("╚════════════════════════════════════════════════════════");

    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));

    -- 1. 创建2个骑士
    print("  ► 创建2个骑士");
    local pPlayerCities = pPlayer:GetCities();
    if pPlayerCities then
        local pCapital = pPlayerCities:GetCapitalCity();
        if pCapital then
            local created1 = CreateUnitNearCity(pPlayer, pCapital, "UNIT_KNIGHT");
            local created2 = CreateUnitNearCity(pPlayer, pCapital, "UNIT_KNIGHT");
            if created1 and created2 then
                print("  ✓ 2个骑士已创建于首都");
            else
                print("  ⚠ 骑士创建部分失败: " .. tostring(created1) .. ", " .. tostring(created2));
            end
        else
            print("  ❌ 玩家没有首都");
        end
    else
        print("  ❌ 无法获取城市列表");
    end

    -- 2. 应用重骑兵建造速度+10%（全时代）
    if not pPlayer.AttachModifierByID then
        print("  ❌ AttachModifierByID 方法不可用");
        return;
    end

    print("  ► 应用重骑兵建造速度+10%（全时代）");
    local heavyCavModifiers = {
        "MODIFIER_TURN2_CHIVALRY_HEAVY_ANCIENT",
        "MODIFIER_TURN2_CHIVALRY_HEAVY_CLASSICAL",
        "MODIFIER_TURN2_CHIVALRY_HEAVY_MEDIEVAL",
        "MODIFIER_TURN2_CHIVALRY_HEAVY_RENAISSANCE",
        "MODIFIER_TURN2_CHIVALRY_HEAVY_INDUSTRIAL",
        "MODIFIER_TURN2_CHIVALRY_HEAVY_MODERN",
        "MODIFIER_TURN2_CHIVALRY_HEAVY_ATOMIC",
        "MODIFIER_TURN2_CHIVALRY_HEAVY_INFORMATION"
    };

    local successCount = 0;
    for _, modifierID in ipairs(heavyCavModifiers) do
        local success = pcall(function()
            pPlayer:AttachModifierByID(modifierID);
        end);
        if success then
            successCount = successCount + 1;
        end
    end
    print("  ✓ 重骑兵生产修正器: " .. successCount .. "/8");

    print("╔════════════════════════════════════════════════════════");
    print("║ 骑士精神 - 应用完成");
    print("╚════════════════════════════════════════════════════════");
    print("  效果：获得2个骑士，重骑兵生产速度+10%");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 创建移动力为1的重装枪兵（龟型阵符文专用）
-- ===========================================================================
function CreateSlowSpearman(pPlayer:table)
    local pPlayerUnits = pPlayer:GetUnits();
    if pPlayerUnits then
        local pCapitalCity = pPlayer:GetCities():GetCapitalCity();
        if pCapitalCity then
            local iX = pCapitalCity:GetX();
            local iY = pCapitalCity:GetY();
            print("    首都坐标: (" .. iX .. ", " .. iY .. ")");
            
            -- 创建自定义重装枪兵单位（移动力固定为1）
            local unitInfo = GameInfo.Units["UNIT_TURN2_SLOW_SPEARMAN"];
            if unitInfo then
                local pUnit = pPlayerUnits:Create(unitInfo.Index, iX, iY);
            
            if pUnit then
                    print("  ✓✓✓ 成功创建：重装枪兵（战斗力25，移动力1，反骑兵+10）");
                else
                    print("  ❌❌❌ 失败：无法创建重装枪兵单位");
                end
            else
                print("  ❌❌❌ 错误：找不到单位定义 UNIT_TURN2_SLOW_SPEARMAN");
                print("  提示：请确认SQL文件已在.modinfo中正确注册");
            end
        else
            print("  ❌ 错误：玩家没有首都");
        end
    else
        print("  ❌ 错误：无法获取玩家单位管理器");
    end
end

-- ===========================================================================
-- 创建符文战士（符文召唤专用）
-- ===========================================================================
function CreateRuneWarrior(pPlayer:table, count:number)
    count = count or 1;  -- 默认创建1个
    local pPlayerUnits = pPlayer:GetUnits();
    if pPlayerUnits then
        local pCapitalCity = pPlayer:GetCities():GetCapitalCity();
        if pCapitalCity then
            local iX = pCapitalCity:GetX();
            local iY = pCapitalCity:GetY();
            print("    首都坐标: (" .. iX .. ", " .. iY .. ")");
            
            -- 创建符文战士单位（战斗力36，移动力3）
            local unitInfo = GameInfo.Units["UNIT_TURN2_RUNE_WARRIOR"];
            if unitInfo then
                local successCount = 0;
                for i = 1, count do
                    local pUnit = pPlayerUnits:Create(unitInfo.Index, iX, iY);
                    if pUnit then
                        successCount = successCount + 1;
                    end
                end
                
                if successCount == count then
                    print(string.format("  ✓✓✓ 成功创建：%d个符文战士（战斗力36，移动力3）", successCount));
                elseif successCount > 0 then
                    print(string.format("  ⚠️ 部分成功：创建了%d/%d个符文战士", successCount, count));
                else
                    print("  ❌❌❌ 失败：无法创建符文战士单位");
                end
            else
                print("  ❌❌❌ 错误：找不到单位定义 UNIT_TURN2_RUNE_WARRIOR");
                print("  提示：请确认SQL文件已在.modinfo中正确注册");
            end
        else
            print("  ❌ 错误：玩家没有首都");
        end
    else
        print("  ❌ 错误：无法获取玩家单位管理器");
    end
end

-- ===========================================================================
-- 检查龟型阵符文的回合奖励
-- ===========================================================================
function CheckTurtleFormationRewards()
    -- 只在非多人游戏或房主端执行
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    local currentTurn = Game.GetCurrentGameTurn();
    
    -- 遍历所有玩家，检查是否到达奖励回合
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsAlive() then
            -- 检查是否选择了龟型阵符文（23）（支持多阶段）
            if PlayerHasDedication(playerID, 23) then
                -- 获取玩家选择龟型阵的回合
                local choiceTurn = Game.GetProperty("Turn2Dedication_ChoiceTurn_P" .. playerID .. "_D23");
                
                if choiceTurn then
                    -- 计算目标回合：选择回合 + 15 和 + 25
                    local targetTurn1 = choiceTurn + 15;
                    local targetTurn2 = choiceTurn + 25;
                    
                    -- 修复2：检查当前回合是否是奖励回合，并且奖励还未发放
                    if currentTurn == targetTurn1 then
                        local rewardKey1 = "Turn2Dedication_TurtleReward1_P" .. playerID;
                        if not Game.GetProperty(rewardKey1) then
                        print("╔════════════════════════════════════════════════════════");
                            print(string.format("║ 龟型阵 - 第%d回合奖励1（选择回合+15）", currentTurn));
                        print("╚════════════════════════════════════════════════════════");
                        print("  玩家: " .. playerID);
                        print("  选择回合: " .. choiceTurn);
                CreateSlowSpearman(pPlayer);
                            -- 标记第1次奖励已发放
                            Game.SetProperty(rewardKey1, 1);
                            print("════════════════════════════════════════════════════════╝");
                        end
                    elseif currentTurn == targetTurn2 then
                        local rewardKey2 = "Turn2Dedication_TurtleReward2_P" .. playerID;
                        if not Game.GetProperty(rewardKey2) then
                            print("╔════════════════════════════════════════════════════════");
                            print(string.format("║ 龟型阵 - 第%d回合奖励2（选择回合+25）", currentTurn));
                            print("╚════════════════════════════════════════════════════════");
                            print("  玩家: " .. playerID);
                            print("  选择回合: " .. choiceTurn);
                            CreateSlowSpearman(pPlayer);
                            -- 标记第2次奖励已发放
                            Game.SetProperty(rewardKey2, 1);
                            print("════════════════════════════════════════════════════════╝");
                        end
                    end
                end
            end
        end
    end
end

-- ===========================================================================
-- 检查骑兵突击符文的延迟奖励（3回合后给予2个骑手）
-- ===========================================================================
function CheckCavalryAssaultRewards()
    -- 只在非多人游戏或房主端执行
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    local currentTurn = Game.GetCurrentGameTurn();
    
    -- 遍历所有玩家，检查是否到达奖励回合
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsAlive() then
            -- 检查是否选择了骑兵突击符文（27）（支持多阶段）
            if PlayerHasDedication(playerID, 27) then
                -- 获取玩家选择骑兵突击的回合
                local choiceTurn = Game.GetProperty("Turn2Dedication_ChoiceTurn_P" .. playerID .. "_D27");
                
                if choiceTurn then
                    -- 计算目标回合：选择回合 + 3
                    local targetTurn = choiceTurn + 3;
                    
                    -- 检查当前回合是否是奖励回合，并且奖励还未发放
                    if currentTurn == targetTurn then
                        local rewardKey = "Turn2Dedication_CavalryReward_P" .. playerID;
                        if not Game.GetProperty(rewardKey) then
                            print("╔════════════════════════════════════════════════════════");
                            print(string.format("║ 骑兵突击 - 第%d回合奖励（选择回合+3）", currentTurn));
                            print("╚════════════════════════════════════════════════════════");
                            print("  玩家: " .. playerID);
                            print("  选择回合: " .. choiceTurn);
                            
                            -- 获取首都
                            if pPlayer.GetCities then
                                local pPlayerCities = pPlayer:GetCities();
                                if pPlayerCities and pPlayerCities.GetCapitalCity then
                                    local pCapital = pPlayerCities:GetCapitalCity();
                                    if pCapital then
                                        -- 创建2个骑手
                                        print("  ► 创建2个骑手");
                                        CreateUnitNearCity(pPlayer, pCapital, "UNIT_HORSEMAN");
                                        CreateUnitNearCity(pPlayer, pCapital, "UNIT_HORSEMAN");
                                        print("  ✓✓✓ 2个骑手已创建");
                                        
                                        -- 标记奖励已发放
                                        Game.SetProperty(rewardKey, 1);
                                    else
                                        print("  ❌ 无法获取首都");
                                    end
                                else
                                    print("  ❌ 无法获取城市列表");
                                end
                            else
                                print("  ❌ GetCities 方法不可用");
                            end
                            
                            print("════════════════════════════════════════════════════════╝");
                        end
                    end
                end
            end
        end
    end
end

-- ===========================================================================
-- 检查征服之路符文的占领城市里程碑
-- ===========================================================================
function CheckConquestDedicationMilestones()
    -- 只在非多人游戏或房主端执行
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    -- 遍历所有玩家
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsAlive() then
            -- 检查是否选择了征服之路符文（19）（支持多阶段）
            if PlayerHasDedication(playerID, 19) then
                -- 获取已应用的层级
                local appliedTier = Game.GetProperty("TURN2_CONQUEST_TIER_P" .. playerID) or 0;
                
                -- 获取玩家占领的城市数量（使用 OnCityAddedToMap 追踪的数据）
                local cityCount = 0;
                local capturedCitiesKey = "TURN2_CAPTURED_CITIES_P" .. playerID;
                local capturedCitiesStr = Game.GetProperty(capturedCitiesKey);
                if capturedCitiesStr then
                    for _ in string.gmatch(capturedCitiesStr, "([^,]+)") do
                        cityCount = cityCount + 1;
                    end
                end
                
                local newTier = appliedTier;
                
                -- 第2城：军事单位+2战斗力，掠夺+15%
                if cityCount >= 2 and appliedTier < 1 then
                    print("征服之路：玩家 " .. playerID .. " 占领第2城");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_CONQUEST_COMBAT_TIER1");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_CONQUEST_PILLAGE_TIER1");
                        print("  ✓ 已应用：军事单位+2战斗力，掠夺+15%");
                    end
                    newTier = 1;
                end
                
                -- 第4城：生产军事单位+25%，掠夺+15%
                if cityCount >= 4 and appliedTier < 2 then
                    print("征服之路：玩家 " .. playerID .. " 占领第4城");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_CONQUEST_UNIT_PRODUCTION_TIER2");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_CONQUEST_PILLAGE_TIER2");
                        print("  ✓ 已应用：生产军事单位+25%，掠夺+15%");
                    end
                    newTier = 2;
                end
                
                -- 第6城：军事单位+1移动力，掠夺+15%
                if cityCount >= 6 and appliedTier < 3 then
                    print("征服之路：玩家 " .. playerID .. " 占领第6城");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_CONQUEST_MOVEMENT_TIER3");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_CONQUEST_PILLAGE_TIER3");
                        print("  ✓ 已应用：军事单位+1移动力，掠夺+15%");
                    end
                    newTier = 3;
                end
                
                -- 第10城：军事单位+3战斗力，+1外交能见度
                if cityCount >= 10 and appliedTier < 4 then
                    print("征服之路：玩家 " .. playerID .. " 占领第10城");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_CONQUEST_COMBAT_TIER4");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_CONQUEST_VISIBILITY_TIER4");
                        print("  ✓ 已应用：军事单位+3战斗力，+1外交能见度");
                    end
                    newTier = 4;
                end
                
                -- 更新已应用的层级
                if newTier > appliedTier then
                    Game.SetProperty("TURN2_CONQUEST_TIER_P" .. playerID, newTier);
                end
            end
        end
    end
end

-- ===========================================================================
-- 检查探索先锋符文的奇观发现里程碑
-- ===========================================================================
function CheckExplorationDedicationMilestones()
    -- 只在非多人游戏或房主端执行
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    -- 遍历所有玩家
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsAlive() then
            -- 检查是否选择了探索先锋符文（20）（支持多阶段）
            if PlayerHasDedication(playerID, 20) then
                -- 获取已应用的层级
                local appliedTier = Game.GetProperty("TURN2_EXPLORATION_TIER_P" .. playerID) or 0;
                
                -- 获取玩家发现的自然奇观数量（从Game.Property读取，网络同步）
                local wonderCountKey = "Turn2Dedication_WonderCount_P" .. playerID;
                local wonderCount = Game.GetProperty(wonderCountKey) or 0;
                
                    print("探索先锋检查：玩家 " .. playerID .. " 当前奇观数: " .. wonderCount .. ", 已应用层级: " .. appliedTier);
                
                local newTier = appliedTier;
                
                -- 第1个：首都+1金币+1科技+1生产力
                if wonderCount >= 1 and appliedTier < 1 then
                    print("╔════════════════════════════════════════════════════════");
                    print("║ 探索先锋：玩家 " .. playerID .. " 发现第1个自然奇观");
                    print("╚════════════════════════════════════════════════════════");
                    print("  奇观数量: " .. wonderCount);
                    print("  已应用层级: " .. appliedTier);
                    
                    if pPlayer.AttachModifierByID then
                        print("  ► 应用修改器: MODIFIER_TURN2_EXPLORATION_CAPITAL_GOLD_TIER1");
                        local success1 = pcall(function()
                            pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPLORATION_CAPITAL_GOLD_TIER1");
                        end);
                        print("    " .. (success1 and "✓" or "❌") .. " 金币修改器");
                        
                        print("  ► 应用修改器: MODIFIER_TURN2_EXPLORATION_CAPITAL_SCIENCE_TIER1");
                        local success2 = pcall(function()
                            pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPLORATION_CAPITAL_SCIENCE_TIER1");
                        end);
                        print("    " .. (success2 and "✓" or "❌") .. " 科技修改器");
                        
                        print("  ► 应用修改器: MODIFIER_TURN2_EXPLORATION_CAPITAL_PRODUCTION_TIER1");
                        local success3 = pcall(function()
                            pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPLORATION_CAPITAL_PRODUCTION_TIER1");
                        end);
                        print("    " .. (success3 and "✓" or "❌") .. " 生产力修改器");
                        
                        if success1 and success2 and success3 then
                            print("  ✓✓✓ 所有修改器应用成功：首都+1金币+1科技+1生产力");
                        else
                            print("  ❌ 部分修改器应用失败");
                        end
                    else
                        print("  ❌ 错误：AttachModifierByID 方法不存在");
                    end
                    newTier = 1;
                    print("════════════════════════════════════════════════════════╝");
                end
                
                -- 第3个：首都+10%金币+10%文化+10%生产力
                if wonderCount >= 3 and appliedTier < 2 then
                    print("探索先锋：玩家 " .. playerID .. " 发现第3个自然奇观");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPLORATION_CAPITAL_GOLD_PERCENT_TIER2");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPLORATION_CAPITAL_CULTURE_PERCENT_TIER2");
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPLORATION_CAPITAL_PRODUCTION_PERCENT_TIER2");
                        print("  ✓ 已应用：首都+10%金币+10%文化+10%生产力");
                    end
                    newTier = 2;
                end
                
                -- 第5个：首都+3宜居度
                if wonderCount >= 5 and appliedTier < 3 then
                    print("探索先锋：玩家 " .. playerID .. " 发现第5个自然奇观");
                    if pPlayer.AttachModifierByID then
                        pPlayer:AttachModifierByID("MODIFIER_TURN2_EXPLORATION_CAPITAL_AMENITY_TIER3");
                        print("  ✓ 已应用：首都+3宜居度");
                    end
                    newTier = 3;
                end
                
                -- 更新已应用的层级
                if newTier > appliedTier then
                    Game.SetProperty("TURN2_EXPLORATION_TIER_P" .. playerID, newTier);
                end
            end
        end
    end
end

-- ===========================================================================
-- 奇观狂魔：符文效果检查（预留函数）
-- 注：奖励已改为一次性金币奖励（125%实际建造成本，考虑游戏速度）
-- 注：实际发放在OnWonderCompletedGameplay函数中完成，不需要每回合计算
-- 保留此函数仅用于未来可能的扩展
-- ===========================================================================
function CheckWonderDedicationEffects()
    -- 奇观狂魔现在使用一次性金币奖励（在奇观完成时通过隐藏聊天消息触发）
    -- 不需要每回合计算产出
end

-- ===========================================================================
-- 检查文艺复兴符文的时代条件
-- ===========================================================================
function CheckRenaissanceDedicationEffects()
    -- 只在非多人游戏或房主端执行
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    -- 遍历所有玩家
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsAlive() then
            -- 检查是否选择了文艺复兴符文（21）（支持多阶段）
            if PlayerHasDedication(playerID, 21) then
                -- 检查是否已经应用过
                local alreadyApplied = Game.GetProperty("TURN2_RENAISSANCE_APPLIED_P" .. playerID);
                if not alreadyApplied then
                    -- 检查当前时代
                    local currentEra = Game.GetEras():GetCurrentEra();
                    local ERA_MEDIEVAL = GameInfo.Eras["ERA_MEDIEVAL"].Index or 2;
                    
                    if currentEra >= ERA_MEDIEVAL then
                        print("文艺复兴：玩家 " .. playerID .. " 进入中世纪/文艺复兴时代");
                        ApplyRenaissanceGreatPersonBonus(pPlayer);
                        Game.SetProperty("TURN2_RENAISSANCE_APPLIED_P" .. playerID, 1);
                    end
                end
            end
        end
    end
end

-- ===========================================================================
-- 检查古典时代相关符文效果（学术精英、商贸网络）
-- ===========================================================================
function CheckClassicalEraEffects()
    -- 只在非多人游戏或房主端执行
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    -- 获取当前时代
    local currentEra = Game.GetEras():GetCurrentEra();
    local ERA_CLASSICAL = GameInfo.Eras["ERA_CLASSICAL"].Index or 1;
    
    -- 只有在古典时代或更晚才处理
    if currentEra < ERA_CLASSICAL then
        return;
    end
    
    -- 遍历所有玩家
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsAlive() then
            -- 学术精英（14）：古典时代额外奖励已由基础效果提供
            -- 注：原计划"古典时代学院获得图书馆"功能因技术限制无法实现
            
            -- 宗教信仰（13）：古典时代获得传教士（支持多阶段）
            if PlayerHasDedication(playerID, 13) then
                local alreadyApplied = Game.GetProperty("TURN2_RELIGION_MISSIONARY_P" .. playerID);
                if not alreadyApplied then
                    local missionaryRetry = false;  -- 尚未创立宗教时置true：不标记完成、下回合重试
                    print("╔════════════════════════════════════════════════════════");
                    print("║ 宗教信仰 - 古典时代奖励");
                    print("╚════════════════════════════════════════════════════════");
                    print("  玩家 " .. playerID .. " 进入古典时代");
                    
                    -- 创建传教士单位
                    print("  ► 尝试创建传教士单位");
                    local pPlayerUnits = pPlayer:GetUnits();
                    if pPlayerUnits then
                        local pCapitalCity = pPlayer:GetCities():GetCapitalCity();
                        if pCapitalCity then
                            local iX = pCapitalCity:GetX();
                            local iY = pCapitalCity:GetY();
                            print("    首都坐标: (" .. iX .. ", " .. iY .. ")");
                            
                            -- 检查玩家是否有宗教
                            local pPlayerReligion = pPlayer:GetReligion();
                            if pPlayerReligion then
                                local religionType = pPlayerReligion:GetReligionTypeCreated();
                                print("    玩家宗教类型: " .. tostring(religionType));
                                
                                if religionType and religionType >= 0 then
                                    -- 玩家已创建宗教，可以创建传教士
                                    local pUnit = pPlayerUnits:Create(GameInfo.Units["UNIT_MISSIONARY"].Index, iX, iY);
                                    if pUnit then
                                        print("  ✓✓✓ 成功创建：传教士单位于首都");
                                    else
                                        print("  ❌❌❌ 失败：无法创建传教士单位");
                                    end
                                else
                                    print("  ⓘ 玩家尚未创立宗教，创立后将在后续回合获得传教士");
                                    -- 仅标记本玩家待重试；不再 return，避免中断同回合其他玩家的古典奖励处理
                                    missionaryRetry = true;
                                end
                            else
                                print("  ❌ 错误：无法获取玩家宗教信息");
                            end
                        else
                            print("  ❌ 错误：玩家没有首都");
                        end
                    else
                        print("  ❌ 错误：无法获取玩家单位管理器");
                    end
                    
                    if not missionaryRetry then
                        Game.SetProperty("TURN2_RELIGION_MISSIONARY_P" .. playerID, 1);
                    end
                    print("════════════════════════════════════════════════════════╝");
                end
            end
            
            -- 商贸网络（15）：古典时代获得商路容量+商人（支持多阶段）
            if PlayerHasDedication(playerID, 15) then
                local alreadyApplied = Game.GetProperty("TURN2_TRADE_TRADER_P" .. playerID);
                if not alreadyApplied then
                    print("╔════════════════════════════════════════════════════════");
                    print("║ 商贸网络 - 古典时代奖励");
                    print("╚════════════════════════════════════════════════════════");
                    print("  玩家 " .. playerID .. " 进入古典时代");
                    
                    -- 增加商路容量
                    print("  ► 尝试应用修改器：MODIFIER_TURN2_TRADE_ROUTE_CAPACITY");
                    if pPlayer.AttachModifierByID then
                        local success = pcall(function()
                            pPlayer:AttachModifierByID("MODIFIER_TURN2_TRADE_ROUTE_CAPACITY");
                        end);
                        if success then
                            print("  ✓✓✓ 成功应用：商路容量+1");
                        else
                            print("  ❌❌❌ 失败：无法应用商路容量修改器");
                        end
                    end
                    
                    -- 创建商人单位
                    print("  ► 尝试创建商人单位");
                    local pPlayerUnits = pPlayer:GetUnits();
                    if pPlayerUnits then
                        local pCapitalCity = pPlayer:GetCities():GetCapitalCity();
                        if pCapitalCity then
                            local iX = pCapitalCity:GetX();
                            local iY = pCapitalCity:GetY();
                            print("    首都坐标: (" .. iX .. ", " .. iY .. ")");
                            local pUnit = pPlayerUnits:Create(GameInfo.Units["UNIT_TRADER"].Index, iX, iY);
                            if pUnit then
                                print("  ✓✓✓ 成功创建：商人单位于首都");
                            else
                                print("  ❌❌❌ 失败：无法创建商人单位");
                            end
                        else
                            print("  ❌ 错误：玩家没有首都");
                        end
                    else
                        print("  ❌ 错误：无法获取玩家单位管理器");
                    end
                    
                    Game.SetProperty("TURN2_TRADE_TRADER_P" .. playerID, 1);
                    print("════════════════════════════════════════════════════════╝");
                end
            end
        end
    end
end

-- ===========================================================================
-- 自然奇观发现事件处理（探索先锋符文）
-- 注：此事件现在在UI脚本（Turn2NaturalWonderListener.lua）中处理
-- ===========================================================================

-- ===========================================================================
-- 奇观建造完成事件处理（奇观狂魔符文）
-- 注：已实现，通过OnWonderCompletedGameplay函数监听隐藏聊天消息（端口655002）
-- 注：发放125%实际建造成本的金币奖励（考虑游戏速度修正）
-- ===========================================================================

-- ===========================================================================
-- 城市占领检测（用于追踪玩家占领的城市数量）
-- ===========================================================================
function OnCityAddedToMap(playerID:number, cityID:number, x:number, y:number)
    -- 只在非多人游戏或房主端执行
    if not T2D_IsAuthoritativeGameplay() then return; end
    
    local pPlayer = Players[playerID];
    if not pPlayer then
        return;
    end
    
    local pCity = pPlayer:GetCities():FindID(cityID);
    if not pCity then
        return;
    end

    if T2D_ReconcilePrismatic139City then
        local ok139, error139 = pcall(T2D_ReconcilePrismatic139City, pPlayer, playerID, pCity);
        if not ok139 then
            print("Turn2DedicationTrigger: ⚠ 山岳营造法城市事件校准失败: " .. tostring(error139));
        end
    end
    if T2D_EnsurePrismatic141Thresholds then
        local ok141, error141 = pcall(T2D_EnsurePrismatic141Thresholds, pPlayer, playerID);
        if not ok141 then
            print("Turn2DedicationTrigger: ⚠ 天下归枢城市事件扩展失败: " .. tostring(error141));
        end
    end
    
    -- 获取城市的原始拥有者
    local originalOwner = pCity:GetOriginalOwner();

    -- 该事件位于 SafeAttachCity 的局部声明之前，只调用稍后定义的全局入口。
    -- 入口会为所有城市记录“已出现”标记，以区分真正新建城市与占领/解放。
    if T2D_HandlePrismatic126NewCity then
        local ok126, error126 = pcall(
            T2D_HandlePrismatic126NewCity, pPlayer, playerID, pCity, originalOwner);
        if not ok126 then
            print("Turn2DedicationTrigger: ⚠ 万城柱石城市事件失败，原有城市逻辑继续: "
                .. tostring(error126));
        end
    end

    -- 测绘学院只奖励玩家亲自建立的新城；占领城市继续走下方原有统计逻辑。
    if originalOwner == playerID and PlayerHasDedication(playerID, 61) and T2D_HandleCartographyCityReward then
        T2D_HandleCartographyCityReward(pPlayer, playerID, pCity);
    end
    
    -- 如果原始拥有者不是当前玩家，说明这个城市是被占领的
    if originalOwner and originalOwner ~= playerID then
        print("╔════════════════════════════════════════════════════════");
        print("║ 城市占领检测");
        print("╚════════════════════════════════════════════════════════");
        print("  玩家 " .. playerID .. " 占领了城市：" .. Locale.Lookup(pCity:GetName()));
        print("  城市ID: " .. cityID);
        print("  原始拥有者: " .. originalOwner);
        print("  城市坐标: (" .. x .. ", " .. y .. ")");
        
        -- 获取玩家已占领的城市列表（存储为城市ID的组合字符串）
        local capturedCitiesKey = "TURN2_CAPTURED_CITIES_P" .. playerID;
        local capturedCitiesStr = Game.GetProperty(capturedCitiesKey);
        
        -- 城市ID列表（用逗号分隔）
        local capturedCities = {};
        if capturedCitiesStr then
            for cityIDStr in string.gmatch(capturedCitiesStr, "([^,]+)") do
                capturedCities[tonumber(cityIDStr)] = true;
            end
        end
        
        -- 检查这个城市是否已经被记录过
        if not capturedCities[cityID] then
            -- 添加新占领的城市
            capturedCities[cityID] = true;
            
            -- 重新组合字符串
            local newCitiesStr = "";
            local count = 0;
            for cID, _ in pairs(capturedCities) do
                if newCitiesStr ~= "" then
                    newCitiesStr = newCitiesStr .. ",";
                end
                newCitiesStr = newCitiesStr .. tostring(cID);
                count = count + 1;
            end
            
            -- 保存更新后的列表
            Game.SetProperty(capturedCitiesKey, newCitiesStr);
            
            print("  ► 这是玩家 " .. playerID .. " 占领的第 " .. count .. " 个城市（不重复计算）");
            print("  ► 已占领的城市ID列表: " .. newCitiesStr);
        else
            -- 计算总数
            local count = 0;
            for _, _ in pairs(capturedCities) do
                count = count + 1;
            end
            print("  ⓘ 这个城市已被占领过，不重复计算");
            print("  ► 玩家 " .. playerID .. " 当前占领城市总数: " .. count);
        end
        
        print("════════════════════════════════════════════════════════╝");
    end
    
    -- 【快速扩张符文】
    -- 注：SQL引擎会自动处理新城市的区域检测，无需Lua追踪
end

-- ===========================================================================
-- 区域建造进度监听（用于学术网络、文化遗产等符文）
-- ===========================================================================
function OnDistrictBuildProgressChanged(playerID, districtID, cityID, x, y, districtType, era, civilization, percentComplete, appeal, isPillaged)
    if not T2D_IsAuthoritativeGameplay() then return; end
    local pPlayer = Players[playerID];
    local pCity = pPlayer and pPlayer:GetCities():FindID(cityID) or nil;

    -- 139 also needs incomplete progress notifications because they can follow
    -- a queue switch. Reconcile before the legacy completion-only early return.
    if pPlayer and pCity and T2D_ReconcilePrismatic139City then
        local ok139, error139 = pcall(T2D_ReconcilePrismatic139City, pPlayer, playerID, pCity);
        if not ok139 then
            print("Turn2DedicationTrigger: ⚠ 山岳营造法区域事件校准失败: " .. tostring(error139));
        end
    end

    -- 只检测完成的区域
    if percentComplete < 100 then
        return;
    end
    
    -- 获取区域信息
    local districtInfo = GameInfo.Districts[districtType];
    if not districtInfo then
        return;
    end
    
    local districtTypeName = districtInfo.DistrictType;
    local districtName = Locale.Lookup(districtInfo.Name);
    
    -- 获取玩家信息
    if not pPlayer then
        return;
    end
    
    -- 获取城市信息
    local cityName = pCity and pCity:GetName() or "未知城市";

    if T2D_HandlePrismatic140DistrictCompleted then
        local ok140, error140 = pcall(
            T2D_HandlePrismatic140DistrictCompleted,
            pPlayer, playerID, districtTypeName, percentComplete);
        if not ok140 then
            print("Turn2DedicationTrigger: ⚠ 圣堂军制首座圣地检查失败: " .. tostring(error140));
        end
    end
    
    -- ★★★ 防重复触发：使用区域ID+城市ID作为唯一标识 ★★★
    local districtKey = string.format("TURN2_DISTRICT_COMPLETED_%d_%d_%d", playerID, cityID, districtID);
    if Game.GetProperty(districtKey) then
        -- 该区域已经被计数过，跳过
        return;
    end
    
    -- 标记该区域已完成（防止重复触发）
    Game.SetProperty(districtKey, 1);
    
    -- 打印基础日志
    print("╔════════════════════════════════════════════════════════");
    print("║ 区域建造完成检测");
    print("╚════════════════════════════════════════════════════════");
    print(string.format("  玩家ID: %d", playerID));
    print(string.format("  城市: %s (ID=%d)", cityName, cityID));
    print(string.format("  区域类型: %s (%s)", districtTypeName, districtName));
    print(string.format("  区域ID: %d ★去重标记已设置", districtID));
    print(string.format("  坐标: (%d, %d)", x, y));
    
    -- 检查是否为学院区域
    if districtTypeName == "DISTRICT_CAMPUS" then
        -- 检查是否选择了学术网络符文（支持多阶段）
        if PlayerHasDedication(playerID, 24) then
            -- 获取并更新学院完成数量
            local campusCountKey = "TURN2_ACADEMIC_CAMPUS_COUNT_P" .. playerID;
            local currentCount = Game.GetProperty(campusCountKey) or 0;
            local newCount = currentCount + 1;
            Game.SetProperty(campusCountKey, newCount);
            
            print(string.format("  >>> 🎓 学术网络符文：玩家已完成 %d 个学院", newCount));
            
            -- 检查里程碑
            CheckAcademicNetworkMilestones(pPlayer, playerID, newCount);
        end
    end
    
    -- 【快速扩张符文】
    -- 注：SQL引擎会自动检测城市区域数量并控制加成失效，无需Lua追踪
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 学术网络符文 - 里程碑检查
-- ===========================================================================
function CheckAcademicNetworkMilestones(pPlayer, playerID, campusCount)
    print("  ► 检查学术网络里程碑...");
    
    -- 第一阶梯：完成2个学院，+2 大科学家点数/回合
    if campusCount == 2 then
        local tier1Key = "TURN2_ACADEMIC_TIER1_P" .. playerID;
        if not Game.GetProperty(tier1Key) then
            pPlayer:AttachModifierByID("MODIFIER_TURN2_ACADEMIC_NETWORK_TIER1_GPP");
            Game.SetProperty(tier1Key, 1);
            print("  >>> 🎉 第一阶梯达成！+2 大科学家点数/回合");
        end
    end
    
    -- 第二阶梯：完成4个学院，学院建筑建造速度 +25%
    if campusCount == 4 then
        local tier2Key = "TURN2_ACADEMIC_TIER2_P" .. playerID;
        if not Game.GetProperty(tier2Key) then
            pPlayer:AttachModifierByID("MODIFIER_TURN2_ACADEMIC_NETWORK_TIER2_BUILDING_SPEED");
            Game.SetProperty(tier2Key, 1);
            print("  >>> 🎉 第二阶梯达成！学院建筑建造速度 +25%");
        end
    end
    
    -- 第三阶梯：完成6个学院，根据时代给予大科学家点数
    if campusCount == 6 then
        local tier3Key = "TURN2_ACADEMIC_TIER3_P" .. playerID;
        if not Game.GetProperty(tier3Key) then
            -- 获取当前时代
            local currentEra = Game.GetEras():GetCurrentEra();
            local modifierID = "MODIFIER_TURN2_ACADEMIC_NETWORK_TIER3_ERA" .. currentEra;
            local points = 100 + 40 * currentEra;
            
            pPlayer:AttachModifierByID(modifierID);
            Game.SetProperty(tier3Key, 1);
            print(string.format("  >>> 🎉 第三阶梯达成！获得 %d 点大科学家点数（时代 %d）", points, currentEra));
        end
    end
    
    -- 第四阶梯：完成10个学院，获得随机6个工业+现代科技尤里卡
    if campusCount == 10 then
        local tier4Key = "TURN2_ACADEMIC_TIER4_P" .. playerID;
        if not Game.GetProperty(tier4Key) then
            -- 附加2个随机尤里卡修改器（工业3个+现代3个）
            pPlayer:AttachModifierByID("MODIFIER_TURN2_ACADEMIC_NETWORK_TIER4_INDUSTRIAL_BOOST");
            pPlayer:AttachModifierByID("MODIFIER_TURN2_ACADEMIC_NETWORK_TIER4_MODERN_BOOST");
            Game.SetProperty(tier4Key, 1);
            print("  >>> 🎉 第四阶梯达成！获得随机6个工业+现代科技尤里卡");
        end
    end
end

-- ===========================================================================
-- 海上贸易符文效果：首都+2金币，港口+1金币
-- ===========================================================================
function ApplyMaritimeDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ 海上贸易符文 - 开始应用");
    print("╚════════════════════════════════════════════════════════");
    
    if not pPlayer.AttachModifierByID then
        print("  ❌ AttachModifierByID 方法不可用");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 首都 +2 金币
    print("  ► 尝试应用修改器：MODIFIER_TURN2_MARITIME_CAPITAL_GOLD");
    local success1 = pcall(function()
        pPlayer:AttachModifierByID("MODIFIER_TURN2_MARITIME_CAPITAL_GOLD");
    end);
    if success1 then
        print("  ✓✓✓ 成功应用：首都 +2 金币");
    else
        print("  ❌❌❌ 失败：无法应用首都金币修改器");
    end
    
    -- 港口 +1 金币（包括所有特色港口）
    print("  ► 尝试应用修改器：MODIFIER_TURN2_MARITIME_HARBOR_GOLD");
    local success2 = pcall(function()
        pPlayer:AttachModifierByID("MODIFIER_TURN2_MARITIME_HARBOR_GOLD");
    end);
    if success2 then
        print("  ✓✓✓ 成功应用：所有港口 +1 金币（包括特色港口）");
    else
        print("  ❌❌❌ 失败：无法应用港口金币修改器");
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用骑兵突击符文效果
-- ===========================================================================
function ApplyCavalryAssaultDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyCavalryAssaultDedication: 应用骑兵突击符文效果");
    print("╚════════════════════════════════════════════════════════");
    
    if not pPlayer.AttachModifierByID then
        print("  ❌ AttachModifierByID 方法不可用");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    local playerID = pPlayer:GetID();
    local currentTurn = Game.GetCurrentGameTurn();
    print("  玩家ID: " .. tostring(playerID));
    print("  当前回合: " .. tostring(currentTurn));
    
    -- 记录选择回合（用于延迟奖励）
    local propertyKey = "Turn2Dedication_ChoiceTurn_P" .. playerID .. "_D27";
    Game.SetProperty(propertyKey, currentTurn);
    print("  ✓ 已记录选择回合: " .. propertyKey);
    
    -- 1. 应用轻骑兵建造速度加成（所有时代）
    print("  ► 应用轻骑兵建造速度加成（所有时代）");
    local lightCavModifiers = {
        "MODIFIER_TURN2_CAVALRY_LIGHT_ANCIENT",
        "MODIFIER_TURN2_CAVALRY_LIGHT_CLASSICAL",
        "MODIFIER_TURN2_CAVALRY_LIGHT_MEDIEVAL",
        "MODIFIER_TURN2_CAVALRY_LIGHT_RENAISSANCE",
        "MODIFIER_TURN2_CAVALRY_LIGHT_INDUSTRIAL",
        "MODIFIER_TURN2_CAVALRY_LIGHT_MODERN",
        "MODIFIER_TURN2_CAVALRY_LIGHT_ATOMIC",
        "MODIFIER_TURN2_CAVALRY_LIGHT_INFORMATION"
    };
    
    for _, modifierId in ipairs(lightCavModifiers) do
        local success = pcall(function()
            pPlayer:AttachModifierByID(modifierId);
        end);
        if success then
            print("  ✓ " .. modifierId);
        else
            print("  ❌ " .. modifierId);
        end
    end
    
    -- 2. 应用重骑兵建造速度加成（所有时代）
    print("  ► 应用重骑兵建造速度加成（所有时代）");
    local heavyCavModifiers = {
        "MODIFIER_TURN2_CAVALRY_HEAVY_ANCIENT",
        "MODIFIER_TURN2_CAVALRY_HEAVY_CLASSICAL",
        "MODIFIER_TURN2_CAVALRY_HEAVY_MEDIEVAL",
        "MODIFIER_TURN2_CAVALRY_HEAVY_RENAISSANCE",
        "MODIFIER_TURN2_CAVALRY_HEAVY_INDUSTRIAL",
        "MODIFIER_TURN2_CAVALRY_HEAVY_MODERN",
        "MODIFIER_TURN2_CAVALRY_HEAVY_ATOMIC",
        "MODIFIER_TURN2_CAVALRY_HEAVY_INFORMATION"
    };
    
    for _, modifierId in ipairs(heavyCavModifiers) do
        local success = pcall(function()
            pPlayer:AttachModifierByID(modifierId);
        end);
        if success then
            print("  ✓ " .. modifierId);
        else
            print("  ❌ " .. modifierId);
        end
    end
    
    print("  ✓✓✓ 轻重骑兵建造速度 +20% 已应用");
    print("  ⓘ 注意：2个骑手将在3回合后（第" .. (currentTurn + 3) .. "回合）给予");
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用黄金贸易符文效果
-- ===========================================================================
function ApplyGoldenTradeDedication(pPlayer:table, stage:number, rarity:number)
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyGoldenTradeDedication: 应用黄金贸易符文效果");
    print("╚════════════════════════════════════════════════════════");

    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));

    -- 1. 一次性金币（混合型：约占预算一半，其余价值来自下方持续商路加成）
    local goldLump = math.floor(GetStageRarityBudget(stage, rarity) * 0.5);
    print("  ► 给予金币: " .. goldLump);
    if pPlayer.GetTreasury then
        local pTreasury = pPlayer:GetTreasury();
        if pTreasury and pTreasury.ChangeGoldBalance then
            pTreasury:ChangeGoldBalance(goldLump);
            print("  ✓✓✓ 成功给予：" .. goldLump .. " 金币");
        else
            print("  ❌ ChangeGoldBalance 方法不可用");
        end
    else
        print("  ❌ GetTreasury 方法不可用");
    end
    
    -- 2. 应用国际商路加成
    if pPlayer.AttachModifierByID then
        -- 国际商路 +2 金币
        print("  ► 尝试应用修改器：MODIFIER_TURN2_GOLDEN_TRADE_GOLD");
        local success1 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_GOLDEN_TRADE_GOLD");
        end);
        if success1 then
            print("  ✓✓✓ 成功应用：国际商路 +2 金币");
        else
            print("  ❌❌❌ 失败：无法应用国际商路金币修改器");
        end
        
        -- 国际商路 +1 科技
        print("  ► 尝试应用修改器：MODIFIER_TURN2_GOLDEN_TRADE_SCIENCE");
        local success2 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_GOLDEN_TRADE_SCIENCE");
        end);
        if success2 then
            print("  ✓✓✓ 成功应用：国际商路 +1 科技");
        else
            print("  ❌❌❌ 失败：无法应用国际商路科技修改器");
        end
        
        -- 商路容量 +1
        print("  ► 尝试应用修改器：MODIFIER_TURN2_GOLDEN_TRADE_CAPACITY");
        local success3 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_GOLDEN_TRADE_CAPACITY");
        end);
        if success3 then
            print("  ✓✓✓ 成功应用：商路容量 +1");
        else
            print("  ❌❌❌ 失败：无法应用商路容量修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用宗教扩张符文效果
-- ===========================================================================
function ApplyReligiousExpansionDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyReligiousExpansionDedication: 应用宗教扩张符文效果");
    print("╚════════════════════════════════════════════════════════");
    
    if not pPlayer.GetCities then
        print("  ❌ GetCities 方法不可用");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    local pPlayerCities = pPlayer:GetCities();
    if not pPlayerCities or not pPlayerCities.GetCapitalCity then
        print("  ❌ GetCapitalCity 方法不可用");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    local pCapital = pPlayerCities:GetCapitalCity();
    if not pCapital then
        print("  ❌ 无法获取首都");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 1. 创建使徒
    print("  ► 创建使徒");
    local success = CreateUnitNearCity(pPlayer, pCapital, "UNIT_APOSTLE");
    if success then
        print("  ✓✓✓ 使徒已创建");
    else
        print("  ❌ 使徒创建失败");
    end
    
    -- 2. 应用修改器
    if pPlayer.AttachModifierByID then
        -- 所有城市 +1 信仰
        print("  ► 尝试应用修改器：MODIFIER_TURN2_RELIGIOUS_EXPANSION_FAITH");
        local success1 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_RELIGIOUS_EXPANSION_FAITH");
        end);
        if success1 then
            print("  ✓✓✓ 成功应用：所有城市 +1 信仰");
        else
            print("  ❌❌❌ 失败：无法应用城市信仰修改器");
        end
        
        -- 传教士费用 -25%
        print("  ► 尝试应用修改器：MODIFIER_TURN2_RELIGIOUS_EXPANSION_MISSIONARY_COST");
        local success2 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_RELIGIOUS_EXPANSION_MISSIONARY_COST");
        end);
        if success2 then
            print("  ✓✓✓ 成功应用：传教士购买费用 -25%");
        else
            print("  ❌❌❌ 失败：无法应用传教士费用修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用封建萌芽符文效果
-- ===========================================================================
function ApplyFeudalBudDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyFeudalBudDedication: 应用封建萌芽符文效果");
    print("╚════════════════════════════════════════════════════════");
    
    if not pPlayer.GetCities then
        print("  ❌ GetCities 方法不可用");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    local pPlayerCities = pPlayer:GetCities();
    if not pPlayerCities or not pPlayerCities.GetCapitalCity then
        print("  ❌ GetCapitalCity 方法不可用");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    local pCapital = pPlayerCities:GetCapitalCity();
    if not pCapital then
        print("  ❌ 无法获取首都");
        print("════════════════════════════════════════════════════════╝");
        return;
    end
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 1. 给首都创建一个工人
    print("  ► 给首都创建工人");
    local success = CreateUnitNearCity(pPlayer, pCapital, "UNIT_BUILDER");
    if success then
        print("  ✓✓✓ 成功创建工人");
    else
        print("  ❌❌❌ 失败：无法创建工人");
    end
    
    -- 2. 应用生产工人速度 +15% 修改器
    print("  ► 应用生产工人速度修改器");
    if pPlayer.AttachModifierByID then
        local success2 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_FEUDAL_BUD_BUILDER_SPEED");
        end);
        if success2 then
            print("  ✓✓✓ 成功应用：生产工人速度 +15%");
        else
            print("  ❌❌❌ 失败：无法应用生产工人速度修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    -- 3. 记录玩家选择了封建萌芽符文（用于时代变更时赠送工人）
    print("  ► 记录玩家选择封建萌芽符文");
    local currentEra = GetCurrentEra(pPlayer);
    g_FeudalBudPlayers[playerID] = {
        currentEra = currentEra,
    };
    -- 持久化到 Game.SetProperty（存档兼容）
    Game.SetProperty("TURN2_FEUDAL_BUD_ERA_P" .. playerID, currentEra);
    print("  ✓ 已记录玩家ID: " .. tostring(playerID) .. "，当前时代: " .. tostring(currentEra));
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用商业垄断符文效果
-- ===========================================================================
function ApplyCommercialMonopolyDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyCommercialMonopolyDedication: 应用商业垄断符文效果");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 1. 应用国际商路加成修改器
    print("  ► 应用国际商路加成修改器");
    if pPlayer.AttachModifierByID then
        local success1 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_COMMERCIAL_MONOPOLY_INTERNATIONAL_GOLD");
        end);
        local success2 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_COMMERCIAL_MONOPOLY_INTERNATIONAL_PRODUCTION");
        end);
        
        if success1 and success2 then
            print("  ✓✓✓ 成功应用：国际商路 +2 金币 +2 生产力");
        else
            print("  ❌❌❌ 失败：无法应用国际商路修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    -- 2. 应用国内商路加成修改器
    print("  ► 应用国内商路加成修改器");
    if pPlayer.AttachModifierByID then
        local success1 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_COMMERCIAL_MONOPOLY_DOMESTIC_FOOD");
        end);
        local success2 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_COMMERCIAL_MONOPOLY_DOMESTIC_CULTURE");
        end);
        local success3 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_COMMERCIAL_MONOPOLY_DOMESTIC_PRODUCTION");
        end);
        
        if success1 and success2 and success3 then
            print("  ✓✓✓ 成功应用：国内商路 +1 食物 +1 文化 +1 生产力");
        else
            print("  ❌❌❌ 失败：无法应用国内商路修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    -- 3. 应用首都金币加成修改器
    print("  ► 应用首都金币加成修改器");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_COMMERCIAL_MONOPOLY_CAPITAL_GOLD_PER_ROUTE");
        end);
        
        if success then
            print("  ✓✓✓ 成功应用：首都 +5 金币");
        else
            print("  ❌❌❌ 失败：无法应用首都金币修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    -- 4. 记录玩家选择了商业垄断符文
    print("  ► 记录玩家选择商业垄断符文");
    g_CommercialMonopolyPlayers[playerID] = true;
    print("  ✓ 已记录玩家ID: " .. tostring(playerID));
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用丰收祝福符文效果
-- ===========================================================================
function ApplyHarvestBlessingDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyHarvestBlessingDedication: 应用丰收祝福符文效果");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 1. 应用市中心食物加成修改器
    print("  ► 应用市中心食物加成修改器");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_HARVEST_BLESSING_CITY_CENTER_FOOD");
        end);
        
        if success then
            print("  ✓✓✓ 成功应用：所有城市市中心 +3 食物");
        else
            print("  ❌❌❌ 失败：无法应用市中心食物修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    -- 2. 应用住房加成修改器
    print("  ► 应用住房加成修改器");
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_HARVEST_BLESSING_HOUSING");
        end);
        
        if success then
            print("  ✓✓✓ 成功应用：所有城市 +2 住房");
        else
            print("  ❌❌❌ 失败：无法应用住房修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用财富自由符文效果
-- ===========================================================================
function ApplyWealthFreedomDedication(pPlayer:table, stage:number, rarity:number)
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyWealthFreedomDedication: 应用财富自由符文效果");
    print("╚════════════════════════════════════════════════════════");

    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));

    -- 一次性符文：payout = 预算[阶段][稀有度]（白银 200/600/1200，黄金/棱彩按倍数）
    local gold = GetStageRarityBudget(stage, rarity);
    print("  ► 赠送金币（阶段" .. tostring(stage) .. " 稀有度" .. tostring(rarity) .. " => " .. gold .. "）");
    if pPlayer.GetTreasury then
        local pTreasury = pPlayer:GetTreasury();
        if pTreasury and pTreasury.ChangeGoldBalance then
            pTreasury:ChangeGoldBalance(gold);
            print("  ✓✓✓ 成功赠送 " .. gold .. " 金币");
        else
            print("  ❌ ChangeGoldBalance 方法不可用");
        end
    else
        print("  ❌ GetTreasury 方法不可用");
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用快速扩张符文效果（区域建造加速测试版）
-- 测试版本：所有区域建造速度+900%，无条件限制
-- ===========================================================================
function ApplyFirstDistrictDedication(pPlayer:table)
    local playerID = pPlayer:GetID();
    
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyFirstDistrictDedication: 应用快速扩张符文（测试版）");
    print("╚════════════════════════════════════════════════════════");
    print("  玩家ID: " .. playerID);
    
    -- 应用Modifier到玩家
    if pPlayer.AttachModifierByID then
        local success = pcall(function()
            pPlayer:AttachModifierByID("TURN2_FIRST_DISTRICT_SPEED_BOOST");
        end);
        if success then
            print("  ✓ Modifier已绑定到玩家");
            print("  ► 玩家城市在尚无专业区域时，第一个区域建造速度+900%");
            print("  ► 其他玩家城市不会获得该效果");
        else
            print("  ❌ Modifier绑定失败 - 请检查SQL定义");
        end
    else
        print("  ❌ AttachModifierByID方法不可用");
    end
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 应用智慧之光符文效果
-- ===========================================================================
function ApplyWisdomLightDedication(pPlayer:table)
    print("╔════════════════════════════════════════════════════════");
    print("║ ApplyWisdomLightDedication: 应用智慧之光符文效果");
    print("╚════════════════════════════════════════════════════════");
    
    local playerID = pPlayer:GetID();
    print("  玩家ID: " .. tostring(playerID));
    
    -- 应用第1阶段加成（所有城市 +1 科技 +1 文化）
    print("  ► 应用第1阶段加成（所有城市 +1 科技 +1 文化）");
    if pPlayer.AttachModifierByID then
        local success1 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_WISDOM_LIGHT_SCIENCE_TIER1");
        end);
        local success2 = pcall(function()
            pPlayer:AttachModifierByID("MODIFIER_TURN2_WISDOM_LIGHT_CULTURE_TIER1");
        end);
        
        if success1 and success2 then
            print("  ✓✓✓ 成功应用：所有城市 +1 科技 +1 文化");
        else
            print("  ❌❌❌ 失败：无法应用第1阶段修改器");
        end
    else
        print("  ❌ AttachModifierByID 方法不可用");
    end
    
    -- 记录玩家选择了智慧之光符文
    print("  ► 记录玩家选择智慧之光符文");
    local currentEra = GetCurrentEra(pPlayer);
    g_WisdomLightPlayers[playerID] = {
        currentEra = currentEra,
        hasUpgraded = false
    };
    -- 持久化到 Game.SetProperty（存档兼容）
    Game.SetProperty("TURN2_WISDOM_LIGHT_P" .. playerID, 1);
    print("  ✓ 已记录玩家ID: " .. tostring(playerID) .. "，当前时代: " .. tostring(currentEra));
    
    print("════════════════════════════════════════════════════════╝");
end

-- ===========================================================================
-- 初始化函数
-- ===========================================================================
function Initialize()
    print("Turn2DedicationTrigger: ========================================");
    print("Turn2DedicationTrigger: 初始化事件监听");
    print("Turn2DedicationTrigger: ========================================");
    
    if GameEvents and GameEvents.PlayerTurnStarted then
        GameEvents.PlayerTurnStarted.Add(OnPlayerTurnStarted);
        print("Turn2DedicationTrigger: ✓ 已注册 GameEvents.PlayerTurnStarted");
    elseif Events and Events.PlayerTurnStarted then
        Events.PlayerTurnStarted.Add(OnPlayerTurnStarted);
        print("Turn2DedicationTrigger: ✓ 已注册 Events.PlayerTurnStarted");
    end
    
    if GameEvents and GameEvents.OnGameTurnStarted then
        GameEvents.OnGameTurnStarted.Add(OnTurnBegin);
        print("Turn2DedicationTrigger: ✓ 已注册 GameEvents.OnGameTurnStarted");
    elseif Events and Events.TurnBegin then
        Events.TurnBegin.Add(OnTurnBegin);
        print("Turn2DedicationTrigger: ✓ 已注册 Events.TurnBegin");
    end
    
    -- 【关键修复】Gameplay层直接监听聊天消息（多人游戏网络同步）
    if Events and Events.MultiplayerChat then
        Events.MultiplayerChat.Add(OnMultiplayerChatGameplay);
        Events.MultiplayerChat.Add(OnNaturalWonderDiscoveredGameplay);
        print("Turn2DedicationTrigger: ✓ 已注册 Events.MultiplayerChat（Gameplay层多人游戏同步）");
        print("Turn2DedicationTrigger: ✓ 已注册符文选择监听（端口655001）");
        print("Turn2DedicationTrigger: ✓ 已注册自然奇观发现监听（端口655003）");
    end
    
    -- 注册城市占领检测事件
    if GameEvents and GameEvents.CityAddedToMap then
        GameEvents.CityAddedToMap.Add(OnCityAddedToMap);
        print("Turn2DedicationTrigger: ✓ 已注册 GameEvents.CityAddedToMap（城市占领检测）");
    end
    
    -- 注册区域建造进度监听事件
    if Events and Events.DistrictBuildProgressChanged then
        Events.DistrictBuildProgressChanged.Add(OnDistrictBuildProgressChanged);
        print("Turn2DedicationTrigger: ✓ 已注册 Events.DistrictBuildProgressChanged（区域建造监听）");
    end
    
    -- 注：自然奇观发现事件在UI脚本（Turn2NaturalWonderListener.lua）中处理
    print("Turn2DedicationTrigger: ⓘ 自然奇观发现监听由UI脚本处理");
    
    -- 注：奇观建造完成事件在UI脚本（Turn2WonderListener.lua）中处理
    print("Turn2DedicationTrigger: ⓘ 奇观完成监听由UI脚本通过隐藏聊天广播");
    
    -- 从 Game.SetProperty 恢复持久化状态（存读档兼容）
    print("Turn2DedicationTrigger: ► 恢复持久化状态...");
    for playerID = 0, PlayerManager.GetWasEverAliveCount() - 1 do
        local pPlayer = Players[playerID];
        if pPlayer and pPlayer:IsAlive() then
            -- 恢复封建萌芽状态
            local feudalEra = Game.GetProperty("TURN2_FEUDAL_BUD_ERA_P" .. playerID);
            if feudalEra then
                g_FeudalBudPlayers[playerID] = {
                    currentEra = feudalEra,
                };
                print("  ✓ 恢复封建萌芽状态：玩家 " .. playerID .. "，时代 " .. feudalEra);
            end
            
            -- 恢复智慧之光状态
            local wisdomLight = Game.GetProperty("TURN2_WISDOM_LIGHT_P" .. playerID);
            if wisdomLight then
                local currentEra = GetCurrentEra(pPlayer);
                local ERA_MEDIEVAL = 2;
                g_WisdomLightPlayers[playerID] = {
                    currentEra = currentEra,
                    hasUpgraded = (currentEra >= ERA_MEDIEVAL)
                };
                print("  ✓ 恢复智慧之光状态：玩家 " .. playerID .. "，已升级=" .. tostring(currentEra >= ERA_MEDIEVAL));
            end
        end
    end
    
    print("Turn2DedicationTrigger: ========================================");
end

Initialize();

-- ===========================================================================
-- 第四轮新符文(44-51) 处理函数与辅助
-- ===========================================================================

-- 安全且幂等地挂载玩家修改器。失败不写标记，允许后续回合重试。
local function T2D_SafeAttach(pPlayer, modID)
    if not pPlayer or not pPlayer.AttachModifierByID then return false; end
    if not modID or not GameInfo or not GameInfo.Modifiers or not GameInfo.Modifiers[modID] then
        print("Turn2DedicationTrigger: ⚠ 修改器未加载 " .. tostring(modID));
        return false;
    end

    local okPlayerID, playerID = pcall(function() return pPlayer:GetID(); end);
    if not okPlayerID or playerID == nil then return false; end
    local attachedKey = "Turn2Dedication_Attached_P" .. playerID .. "_" .. modID;
    if Game.GetProperty(attachedKey) then
        return true;
    end

    local ok, err = pcall(function() pPlayer:AttachModifierByID(modID); end);
    if not ok then
        print("Turn2DedicationTrigger: ⚠ 挂载修改器失败 " .. tostring(modID) .. ": " .. tostring(err));
        return false;
    end
    Game.SetProperty(attachedKey, 1);
    return ok;
end

-- 城市级修改器会随城市保存与转移；去重标记也放在城市 Property 上。
-- dedupeScope 可用于区分不同来源玩家的一次性效果，避免城市易主后错误共用标记。
local function T2D_SafeAttachCity(pCity, modID, dedupeScope)
    if not pCity or not pCity.AttachModifierByID or not pCity.GetProperty or not pCity.SetProperty then
        return false;
    end
    if not modID or not GameInfo or not GameInfo.Modifiers or not GameInfo.Modifiers[modID] then
        print("Turn2DedicationTrigger: ⚠ 城市修改器未加载 " .. tostring(modID));
        return false;
    end

    local attachedKey = "Turn2Dedication_Attached_"
        .. (dedupeScope and (tostring(dedupeScope) .. "_") or "") .. modID;
    local okProperty, attached = pcall(function() return pCity:GetProperty(attachedKey); end);
    if okProperty and attached then return true; end

    local okAttach, attachErr = pcall(function() pCity:AttachModifierByID(modID); end);
    if not okAttach then
        print("Turn2DedicationTrigger: ⚠ 城市修改器挂载失败 " .. tostring(modID) .. ": " .. tostring(attachErr));
        return false;
    end
    local okMark, markErr = pcall(function() pCity:SetProperty(attachedKey, 1); end);
    if not okMark then
        print("Turn2DedicationTrigger: ⚠ 城市修改器去重标记失败 " .. tostring(modID) .. ": " .. tostring(markErr));
        return false;
    end
    return true;
end

local function T2D_AttachRequiredModifiers(pPlayer, runeName, modifierIDs)
    for _, modifierID in ipairs(modifierIDs) do
        if not T2D_SafeAttach(pPlayer, modifierID) then
            error(tostring(runeName) .. "修改器挂载失败: " .. tostring(modifierID));
        end
    end
end

local T2D_ERA_SUFFIXES = {"ANCIENT","CLASSICAL","MEDIEVAL","RENAISSANCE","INDUSTRIAL","MODERN","ATOMIC","INFORMATION"};

local function T2D_CityHasBuilding(pCity, buildingType)
    if not pCity or not buildingType then return false; end
    local buildingInfo = GameInfo.Buildings[buildingType];
    if not buildingInfo then return false; end
    local okBuildings, pBuildings = pcall(function() return pCity:GetBuildings(); end);
    if not okBuildings or not pBuildings or not pBuildings.HasBuilding then return false; end
    local okHas, hasBuilding = pcall(function() return pBuildings:HasBuilding(buildingInfo.Index); end);
    return okHas and hasBuilding == true;
end

local function T2D_BuildingIsOrReplaces(buildingType, baseBuildingType)
    if not buildingType or not baseBuildingType then return false; end
    if buildingType == baseBuildingType then return true; end
    if not GameInfo or not GameInfo.BuildingReplaces then return false; end
    for replacement in GameInfo.BuildingReplaces() do
        if replacement.ReplacesBuildingType == baseBuildingType and replacement.CivUniqueBuildingType == buildingType then
            return true;
        end
    end
    return false;
end

local function T2D_CityHasBuildingOrReplacement(pCity, baseBuildingType)
    if T2D_CityHasBuilding(pCity, baseBuildingType) then return true; end
    if not GameInfo or not GameInfo.BuildingReplaces then return false; end
    for replacement in GameInfo.BuildingReplaces() do
        if replacement.ReplacesBuildingType == baseBuildingType
            and T2D_CityHasBuilding(pCity, replacement.CivUniqueBuildingType) then
            return true;
        end
    end
    return false;
end

local function T2D_CityHasDistrict(pCity, districtType)
    if not pCity or not districtType then return false; end
    local districtInfo = GameInfo.Districts[districtType];
    if not districtInfo then return false; end
    local okDistricts, pDistricts = pcall(function() return pCity:GetDistricts(); end);
    if not okDistricts or not pDistricts or not pDistricts.HasDistrict then return false; end
    local okHas, hasDistrict = pcall(function() return pDistricts:HasDistrict(districtInfo.Index, true); end);
    if okHas then return hasDistrict == true; end
    okHas, hasDistrict = pcall(function() return pDistricts:HasDistrict(districtInfo.Index); end);
    return okHas and hasDistrict == true;
end

local function T2D_GetCityDistrictPlot(pCity, districtType)
    if not pCity or not districtType then return nil; end
    local districtInfo = GameInfo.Districts[districtType];
    if not districtInfo then return nil; end
    local okDistricts, pDistricts = pcall(function() return pCity:GetDistricts(); end);
    if not okDistricts or not pDistricts or not pDistricts.GetDistrictLocation then return nil; end
    local okLocation, x, y = pcall(function() return pDistricts:GetDistrictLocation(districtInfo.Index); end);
    if not okLocation or not x or not y or x < 0 or y < 0 then return nil; end
    return Map.GetPlot(x, y);
end

local function T2D_DistrictAdjacentToMountain(pCity, districtType)
    if not T2D_CityHasDistrict(pCity, districtType) then return false; end
    local pPlot = T2D_GetCityDistrictPlot(pCity, districtType);
    if not pPlot then return false; end
    local x = pPlot:GetX();
    local y = pPlot:GetY();
    for direction = 0, 5 do
        local pAdjacent = Map.GetAdjacentPlot(x, y, direction);
        if pAdjacent then
            local okMountain, isMountain = pcall(function() return pAdjacent:IsMountain(); end);
            if okMountain and isMountain then
                return true;
            end
        end
    end
    return false;
end

local function T2D_PlayerHasMountainTempleCampusCombo(pPlayer)
    if not pPlayer or not pPlayer.GetCities then return false; end
    local pCities = pPlayer:GetCities();
    if not pCities then return false; end
    for _, pCity in pCities:Members() do
        if T2D_CityHasDistrict(pCity, "DISTRICT_CAMPUS") and T2D_DistrictAdjacentToMountain(pCity, "DISTRICT_HOLY_SITE") then
            return true;
        end
    end
    return false;
end

local function T2D_PlayerHasAncientWalls(pPlayer)
    if not pPlayer or not pPlayer.GetCities then return false; end
    local pCities = pPlayer:GetCities();
    if not pCities then return false; end
    for _, pCity in pCities:Members() do
        if T2D_CityHasBuilding(pCity, "BUILDING_WALLS") then
            return true;
        end
    end
    return false;
end

local function T2D_CountDomesticRoutesToHolySite(pPlayer, playerID)
    if not pPlayer or not pPlayer.GetTrade then return 0; end
    local okTrade, pTrade = pcall(function() return pPlayer:GetTrade(); end);
    if not okTrade or not pTrade or not pTrade.GetOutgoingRoutes then return 0; end
    local okRoutes, routes = pcall(function() return pTrade:GetOutgoingRoutes(); end);
    if not okRoutes or not routes then return 0; end

    local count = 0;
    for _, route in ipairs(routes) do
        if route and route.OriginCityPlayer == playerID and route.DestinationCityPlayer == playerID and route.DestinationCityID then
            local pDestinationPlayer = Players[route.DestinationCityPlayer];
            local pDestinationCities = pDestinationPlayer and pDestinationPlayer:GetCities();
            local pDestinationCity = pDestinationCities and pDestinationCities:FindID(route.DestinationCityID);
            if T2D_CityHasDistrict(pDestinationCity, "DISTRICT_HOLY_SITE") then
                count = count + 1;
            end
        end
    end
    return count;
end

local function T2D_AttachTitheBuildingYieldModifiers(pPlayer)
    if not pPlayer or not GameInfo or not GameInfo.Buildings then return; end
    for building in GameInfo.Buildings() do
        if building.PrereqDistrict == "DISTRICT_HOLY_SITE" then
            T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TITHE_HOLY_BUILDING_GOLD_" .. building.BuildingType);
        elseif building.PrereqDistrict == "DISTRICT_COMMERCIAL_HUB" then
            T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TITHE_COMMERCIAL_BUILDING_FAITH_" .. building.BuildingType);
        end
    end
end

local function T2D_AttachModifiersByPrefix(pPlayer, prefix)
    if not pPlayer or not prefix or not GameInfo or not GameInfo.Modifiers then return 0; end
    local count = 0;
    for modifier in GameInfo.Modifiers() do
        local modifierID = modifier and modifier.ModifierId;
        if modifierID and string.sub(modifierID, 1, string.len(prefix)) == prefix then
            if T2D_SafeAttach(pPlayer, modifierID) then
                count = count + 1;
            end
        end
    end
    return count;
end

local function T2D_CityCenterAdjacentToMountain(pCity)
    if not pCity then return false; end
    local x, y = pCity:GetX(), pCity:GetY();
    for direction = 0, 5 do
        local pAdjacent = Map.GetAdjacentPlot(x, y, direction);
        if pAdjacent then
            local okMountain, isMountain = pcall(function() return pAdjacent:IsMountain(); end);
            if okMountain and isMountain then return true; end
        end
    end
    return false;
end

local function T2D_GetCartographyCityKey(playerID, pCity)
    if not pCity then return nil; end
    local pPlot = Map.GetPlot(pCity:GetX(), pCity:GetY());
    if not pPlot then return nil; end
    return "Turn2Dedication_CartographySeenCity_P" .. playerID .. "_Plot" .. pPlot:GetIndex();
end

local function T2D_MarkExistingCartographyCities(pPlayer, playerID)
    local pCities = pPlayer and pPlayer:GetCities();
    if not pCities then return; end
    for _, pCity in pCities:Members() do
        local key = T2D_GetCartographyCityKey(playerID, pCity);
        if key then Game.SetProperty(key, 1); end
    end
    Game.SetProperty("Turn2Dedication_CartographyBaseline_P" .. playerID, 1);
end

T2D_HandleCartographyCityReward = function(pPlayer, playerID, pCity)
    if not pPlayer or playerID == nil or not pCity then return false; end
    local cityKey = T2D_GetCartographyCityKey(playerID, pCity);
    if not cityKey or Game.GetProperty(cityKey) then return false; end

    local triggerKey = "Turn2Dedication_CartographyMountainCount_P" .. playerID;
    local storedCount = Game.GetProperty(triggerKey);
    local triggerCount = tonumber(storedCount) or 0;
    if triggerCount < 2 and T2D_CityCenterAdjacentToMountain(pCity) then
        local nextCount = triggerCount + 1;
        if not T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_CARTOGRAPHY_MOUNTAIN_EUREKA_" .. nextCount) then
            return false;
        end
        triggerCount = nextCount;
        Game.SetProperty(triggerKey, triggerCount);
        print("Turn2DedicationTrigger: ✓ 测绘学院 邻山新城尤里卡 " .. triggerCount .. "/2");
    end

    Game.SetProperty(cityKey, 1);
    return true;
end

local function T2D_CheckCartographyCityRewards(pPlayer, playerID)
    local pCities = pPlayer and pPlayer:GetCities();
    if not pCities then return; end
    for _, pCity in pCities:Members() do
        T2D_HandleCartographyCityReward(pPlayer, playerID, pCity);
    end
end

local T2D_EMBASSY_REWARDS = {
    LEADER_MINOR_CIV_SCIENTIFIC = { key = "SCIENTIFIC", modifier = "MODIFIER_TURN2_EMBASSY_SCIENCE" },
    LEADER_MINOR_CIV_CULTURAL = { key = "CULTURAL", modifier = "MODIFIER_TURN2_EMBASSY_CULTURE" },
    LEADER_MINOR_CIV_TRADE = { key = "TRADE", modifier = "MODIFIER_TURN2_EMBASSY_GOLD" },
    LEADER_MINOR_CIV_RELIGIOUS = { key = "RELIGIOUS", modifier = "MODIFIER_TURN2_EMBASSY_FAITH" },
    LEADER_MINOR_CIV_MILITARISTIC = { key = "MILITARISTIC", modifier = "MODIFIER_TURN2_EMBASSY_MILITARY" },
    LEADER_MINOR_CIV_INDUSTRIAL = { key = "INDUSTRIAL", modifier = "MODIFIER_TURN2_EMBASSY_INDUSTRIAL" },
};

local function T2D_GetCityStateReward(pMinor)
    if not pMinor or not PlayerConfigurations or not GameInfo or not GameInfo.Leaders then return nil; end
    local pConfig = PlayerConfigurations[pMinor:GetID()];
    local leaderType = pConfig and pConfig:GetLeaderTypeName();
    local visited = {};
    while leaderType and not visited[leaderType] do
        visited[leaderType] = true;
        if T2D_EMBASSY_REWARDS[leaderType] then return T2D_EMBASSY_REWARDS[leaderType]; end
        local leader = GameInfo.Leaders[leaderType];
        leaderType = leader and leader.InheritFrom;
    end
    return nil;
end

local function T2D_CheckEmbassySilverRewards(pPlayer, playerID)
    if not PlayerManager or not PlayerManager.GetAliveMinors then return; end
    for _, pMinor in ipairs(PlayerManager.GetAliveMinors()) do
        local reward = T2D_GetCityStateReward(pMinor);
        local pInfluence = pMinor and pMinor:GetInfluence();
        local tokens = 0;
        if pInfluence and pInfluence.GetTokensReceived then
            local okTokens, value = pcall(function() return pInfluence:GetTokensReceived(playerID); end);
            if okTokens then tokens = tonumber(value) or 0; end
        end
        if reward and tokens >= 3 then
            local key = "Turn2Dedication_EmbassySilver_" .. reward.key .. "_P" .. playerID;
            if not Game.GetProperty(key) then
                if T2D_SafeAttach(pPlayer, reward.modifier) then
                    Game.SetProperty(key, 1);
                    print("Turn2DedicationTrigger: ✓ 使馆银阶 解锁 " .. reward.key);
                end
            end
        end
    end
end

local function T2D_GetLumberMillIndex()
    local improvement = GameInfo and GameInfo.Improvements and GameInfo.Improvements["IMPROVEMENT_LUMBER_MILL"];
    return improvement and improvement.Index or nil;
end

local function T2D_GetLumberMillPlotKey(playerID, plotIndex)
    return "Turn2Dedication_WoodlandSeenLumber_P" .. playerID .. "_Plot" .. plotIndex;
end

local function T2D_MarkExistingLumberMills(playerID)
    local lumberMillIndex = T2D_GetLumberMillIndex();
    if not lumberMillIndex or not Map.GetPlotCount then return; end
    for plotIndex = 0, Map.GetPlotCount() - 1 do
        local pPlot = Map.GetPlotByIndex(plotIndex);
        if pPlot and pPlot:GetImprovementType() == lumberMillIndex then
            Game.SetProperty(T2D_GetLumberMillPlotKey(playerID, plotIndex), 1);
        end
    end
    Game.SetProperty("Turn2Dedication_WoodlandLumberBaseline_P" .. playerID, 1);
end

local function T2D_GrantWoodlandLumberReward(pPlayer, playerID, plotIndex)
    local lumberMillIndex = T2D_GetLumberMillIndex();
    if not lumberMillIndex then return false; end
    local triggerKey = "Turn2Dedication_WoodlandLumberCount_P" .. playerID;
    local storedCount = Game.GetProperty(triggerKey);
    local triggerCount = tonumber(storedCount) or 0;
    if triggerCount >= 3 then return false; end

    local pPlot = Map.GetPlotByIndex(plotIndex);
    if not pPlot or pPlot:GetImprovementType() ~= lumberMillIndex or pPlot:GetOwner() ~= playerID then
        return false;
    end

    local plotKey = T2D_GetLumberMillPlotKey(playerID, plotIndex);
    if Game.GetProperty(plotKey) then return false; end
    local pCulture = pPlayer and pPlayer:GetCulture();
    if not pCulture or not pCulture.ChangeCurrentCulturalProgress then return false; end

    local okCulture, err = pcall(function() pCulture:ChangeCurrentCulturalProgress(10); end);
    if not okCulture then
        print("Turn2DedicationTrigger: ⚠ 林地书院文化发放失败: " .. tostring(err));
        return false;
    end

    triggerCount = triggerCount + 1;
    Game.SetProperty(plotKey, 1);
    Game.SetProperty(triggerKey, triggerCount);
    print("Turn2DedicationTrigger: ✓ 林地书院 新伐木场文化 +10 (" .. triggerCount .. "/3)");
    return true;
end

local function T2D_CheckWoodlandLumberRewards(pPlayer, playerID)
    local lumberMillIndex = T2D_GetLumberMillIndex();
    if not lumberMillIndex or not Map.GetPlotCount then return; end

    for plotIndex = 0, Map.GetPlotCount() - 1 do
        local pPlot = Map.GetPlotByIndex(plotIndex);
        if pPlot and pPlot:GetImprovementType() == lumberMillIndex then
            local key = T2D_GetLumberMillPlotKey(playerID, plotIndex);
            if pPlot:GetOwner() == playerID then
                T2D_GrantWoodlandLumberReward(pPlayer, playerID, plotIndex);
            elseif not Game.GetProperty(key) then
                -- 在其他玩家建成时记录，避免日后占领该地块被误算为“新建”。
                Game.SetProperty(key, 1);
            end
        end
    end
end

function OnWoodlandLumberAddedGameplay(fromPlayer:number, toPlayer:number, text:string, eTargetType:number)
    if toPlayer ~= 655012 or type(text) ~= "string" then return; end
    local playerID, plotIndex = text:match("^%[T2D_LUMBER%](%d+):(%d+)$");
    playerID = tonumber(playerID);
    plotIndex = tonumber(plotIndex);
    if playerID == nil or plotIndex == nil then return; end

    if not T2D_IsAuthoritativeGameplay() then return; end
    local pPlayer = Players[playerID];
    if not pPlayer or not PlayerHasDedication(playerID, 64) then return; end
    T2D_GrantWoodlandLumberReward(pPlayer, playerID, plotIndex);
end

local T2D_WORKSHOP_LECTERN_MODIFIERS = {
    "MODIFIER_TURN2_WORKSHOP_LECTERN_CITY_SCIENCE",
    "MODIFIER_TURN2_WORKSHOP_LECTERN_CITY_PRODUCTION",
    "MODIFIER_TURN2_WORKSHOP_LECTERN_SCIENTIST_POINTS",
    "MODIFIER_TURN2_WORKSHOP_LECTERN_ENGINEER_POINTS",
};

local function T2D_CityQualifiesForWorkshopLectern(pCity)
    return T2D_CityHasBuildingOrReplacement(pCity, "BUILDING_UNIVERSITY")
        and T2D_CityHasBuildingOrReplacement(pCity, "BUILDING_WORKSHOP");
end

local function T2D_FindWorkshopLecternCity(pPlayer)
    local pCities = pPlayer and pPlayer:GetCities();
    if not pCities then return nil; end

    local selectedCity = nil;
    local selectedCityID = nil;
    for _, pCity in pCities:Members() do
        if T2D_CityQualifiesForWorkshopLectern(pCity) then
            local okCityID, cityID = pcall(function() return pCity:GetID(); end);
            if okCityID and cityID ~= nil and (selectedCityID == nil or cityID < selectedCityID) then
                selectedCity = pCity;
                selectedCityID = cityID;
            end
        end
    end
    return selectedCity, selectedCityID;
end

local function T2D_TryUnlockWorkshopLectern(pPlayer, playerID)
    if not pPlayer or playerID == nil or not PlayerHasDedication(playerID, 67) then return false; end
    local unlockKey = "Turn2Dedication_WorkshopLecternCity_P" .. playerID;
    if Game.GetProperty(unlockKey) ~= nil then return true; end

    local pCity, cityID = T2D_FindWorkshopLecternCity(pPlayer);
    if not pCity or cityID == nil then return false; end

    local allAttached = true;
    for _, modifierID in ipairs(T2D_WORKSHOP_LECTERN_MODIFIERS) do
        if not T2D_SafeAttachCity(pCity, modifierID) then
            allAttached = false;
        end
    end
    if not allAttached then return false; end

    Game.SetProperty(unlockKey, cityID);
    print("Turn2DedicationTrigger: ✓ 工坊讲席 城市 " .. tostring(cityID) .. " 已永久强化");
    return true;
end

function OnWorkshopLecternBuildingConstructed(playerID:number, cityID:number, buildingID:number, plotIndex:number, originalConstruction:boolean)
    if not T2D_IsAuthoritativeGameplay() then return; end
    if playerID == nil or cityID == nil or buildingID == nil then return; end

    -- 奇观奖励直接使用权威 Gameplay 建筑事件，不再由 UI 聊天桥接。
    local constructedInfo = GameInfo and GameInfo.Buildings and GameInfo.Buildings[buildingID];
    if originalConstruction == true and constructedInfo and constructedInfo.IsWonder then
        local wonderMessage = "[T2D_WONDER]" .. tostring(playerID) .. ":"
            .. tostring(cityID) .. ":" .. tostring(buildingID);
        local okWonder, wonderError = pcall(
            OnWonderCompletedGameplay, playerID, 655002, wonderMessage, 0);
        if not okWonder then
            print("Turn2DedicationTrigger: ⚠ 奇观狂魔建筑事件失败：" .. tostring(wonderError));
        end
    end

    -- 共用既有 BuildingConstructed 监听；棱彩处理入口稍后定义，且内部自行执行房主门控。
    if T2D_HandlePrismatic125BuildingConstructed then
        local ok125, error125 = pcall(
            T2D_HandlePrismatic125BuildingConstructed,
            playerID, cityID, buildingID, plotIndex, originalConstruction);
        if not ok125 then
            print("Turn2DedicationTrigger: ⚠ 无定宪章建筑事件失败，工坊讲席逻辑继续: "
                .. tostring(error125));
        end
    end

    if not PlayerHasDedication(playerID, 67) then return; end
    if Game.GetProperty("Turn2Dedication_WorkshopLecternCity_P" .. playerID) ~= nil then return; end

    local buildingInfo = GameInfo and GameInfo.Buildings and GameInfo.Buildings[buildingID];
    local buildingType = buildingInfo and buildingInfo.BuildingType;
    if not T2D_BuildingIsOrReplaces(buildingType, "BUILDING_UNIVERSITY")
        and not T2D_BuildingIsOrReplaces(buildingType, "BUILDING_WORKSHOP") then
        return;
    end

    local pPlayer = Players[playerID];
    local pCities = pPlayer and pPlayer:GetCities();
    local pCity = pCities and pCities:FindID(cityID);
    if pCity and T2D_CityQualifiesForWorkshopLectern(pCity) then
        T2D_TryUnlockWorkshopLectern(pPlayer, playerID);
    end
end

function CheckSilverRuneTurnRewards(pPlayer, playerID)
    if not pPlayer or playerID == nil then return; end

    if PlayerHasDedication(playerID, 56) then
        local key = "Turn2Dedication_MountainTempleGSP_P" .. playerID;
        if not Game.GetProperty(key) and T2D_PlayerHasMountainTempleCampusCombo(pPlayer) then
            T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_MOUNTAIN_TEMPLE_GSP");
            Game.SetProperty(key, 1);
            print("Turn2DedicationTrigger: ✓ 山寺钟声 大科学家点数已激活");
        end
    end

    if PlayerHasDedication(playerID, 57) then
        local currentTurn = Game.GetCurrentGameTurn();
        local key = "Turn2Dedication_TitheTradeGold_LastTurn_P" .. playerID;
        if Game.GetProperty(key) ~= currentTurn then
            local gold = T2D_CountDomesticRoutesToHolySite(pPlayer, playerID);
            if gold > 0 then
                local pTreasury = pPlayer:GetTreasury();
                if pTreasury and pTreasury.ChangeGoldBalance then
                    pTreasury:ChangeGoldBalance(gold);
                end
                print("Turn2DedicationTrigger: ✓ 什一商约 国内圣地终点商路金币 +" .. tostring(gold));
            end
            Game.SetProperty(key, currentTurn);
        end
    end

    if PlayerHasDedication(playerID, 58) then
        local key = "Turn2Dedication_MilitiaWallBoost_P" .. playerID;
        if not Game.GetProperty(key) and T2D_PlayerHasAncientWalls(pPlayer) then
            T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_MILITIA_WALL_CIVIC_BOOST");
            Game.SetProperty(key, 1);
            print("Turn2DedicationTrigger: ✓ 民兵史诗 城墙市政鼓舞已触发");
        end
    end

    if PlayerHasDedication(playerID, 61) then
        T2D_CheckCartographyCityRewards(pPlayer, playerID);
    end

    if PlayerHasDedication(playerID, 63) then
        T2D_CheckEmbassySilverRewards(pPlayer, playerID);
    end

    if PlayerHasDedication(playerID, 64) then
        T2D_CheckWoodlandLumberRewards(pPlayer, playerID);
    end

    if PlayerHasDedication(playerID, 67) then
        T2D_TryUnlockWorkshopLectern(pPlayer, playerID);
    end
end

-- 各时代最强海军近战单位（按已研究科技，仿 GetStrongestMeleeUnit）
local NAVAL_MELEE_UNITS = {
    { unit = "UNIT_DESTROYER", tech = "TECH_COMBINED_ARMS" },
    { unit = "UNIT_IRONCLAD",  tech = "TECH_STEAM_POWER" },
    { unit = "UNIT_CARAVEL",   tech = "TECH_CARTOGRAPHY" },
    { unit = "UNIT_GALLEY",    tech = "TECH_SAILING" },
};
function GetStrongestNavalUnit(pPlayer)
    local pTechs = pPlayer:GetTechs();
    if pTechs then
        for _, e in ipairs(NAVAL_MELEE_UNITS) do
            local t = GameInfo.Technologies[e.tech];
            if t and pTechs:HasTech(t.Index) then
                return e.unit;
            end
        end
    end
    return "UNIT_GALLEY";
end

-- 找沿海城市旁的空水域格（放置海军单位）；找不到返回 nil
function FindNavalPlot(pPlayer)
    local found = nil;
    pcall(function()
        local pCities = pPlayer:GetCities();
        if not pCities then return; end
        for _, pCity in pCities:Members() do
            local cx, cy = pCity:GetX(), pCity:GetY();
            for dir = 0, 5 do
                local adj = Map.GetAdjacentPlot(cx, cy, dir);
                if adj and adj:IsWater() and (not adj:IsLake()) and adj:GetUnitCount() == 0 and (not adj:IsImpassable()) then
                    found = { adj:GetX(), adj:GetY() };
                    return;
                end
            end
        end
    end);
    if found then return found[1], found[2]; end
    return nil;
end

-- 44 海权霸主：全时代海军近战建造加速 + 最强战舰
function ApplyNavalSupremacy(pPlayer, stage, rarity)
    local eras = {"ANCIENT","CLASSICAL","MEDIEVAL","RENAISSANCE","INDUSTRIAL","MODERN","ATOMIC","INFORMATION"};
    for _, era in ipairs(eras) do
        T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_NAVAL_MELEE_" .. era);
    end
    local x, y = FindNavalPlot(pPlayer);
    if x then
        local unitType = GetStrongestNavalUnit(pPlayer);
        local info = GameInfo.Units[unitType];
        if info then
            pcall(function() pPlayer:GetUnits():Create(info.Index, x, y); end);
            print("Turn2DedicationTrigger: ✓ 海权霸主 生成战舰 " .. unitType);
        end
    else
        local pT = pPlayer:GetTreasury();
        if pT and pT.ChangeGoldBalance then
            pT:ChangeGoldBalance(math.floor(GetStageRarityBudget(stage, rarity) * 0.4));
        end
        print("Turn2DedicationTrigger: 海权霸主 无可用沿海水域，改发金币兜底");
    end
end

-- 45 本土壁垒：友方领土战斗+城防+治疗
function ApplyHomelandBastion(pPlayer, stage, rarity)
    -- 战斗力经 GRANT_ABILITY 下发到单位（单位级 modifier 不能直接挂 player）
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_BASTION_GRANT_COMBAT");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_BASTION_OUTER_DEFENSE");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_BASTION_INNER_DEFENSE");
    -- 治疗按领土类型拆 3 条（HEAL_PER_TURN 需 Type 参数）
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_BASTION_HEAL_FRIENDLY");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_BASTION_HEAL_NEUTRAL");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_BASTION_HEAL_ENEMY");
    print("Turn2DedicationTrigger: ✓ 本土壁垒");
end

-- 46 百战精兵：训练单位经验 + 经验倍数
function ApplyVeterancy(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_VETERANCY_TRAINED_XP");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_VETERANCY_XP_MODIFIER");
    print("Turn2DedicationTrigger: ✓ 百战精兵");
end

-- 47 荣耀史诗：多源时代得分
function ApplyEraGlory(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_ERAGLORY_DISTRICT");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_ERAGLORY_GREATPERSON");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_ERAGLORY_TRADEROUTE");
    print("Turn2DedicationTrigger: ✓ 荣耀史诗");
end

-- 48 铁腕统治：削弱敌城忠诚 + 己方城市一次性+忠诚
function ApplyIronRule(pPlayer, stage, rarity)
    if not T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_IRONRULE_POSTCOMBAT") then
        error("铁腕统治攻击忠诚修改器挂载失败");
    end

    local okPlayerID, playerID = pcall(function() return pPlayer:GetID(); end);
    local pCities = pPlayer.GetCities and pPlayer:GetCities() or nil;
    if not okPlayerID or playerID == nil or not pCities then
        error("铁腕统治无法读取玩家城市");
    end

    local grantedCities = 0;
    for _, pCity in pCities:Members() do
        if not T2D_SafeAttachCity(
            pCity, "MODIFIER_TURN2_IRONRULE_GRANTLOYALTY", "IRONRULE_P" .. playerID) then
            error("铁腕统治城市忠诚奖励挂载失败");
        end
        grantedCities = grantedCities + 1;
    end
    print("Turn2DedicationTrigger: ✓ 铁腕统治（己方现有城市+25忠诚："
        .. tostring(grantedCities) .. "座）");
end

-- 49 山河形胜：区域相邻加成镜像为金币
function ApplyTerrainMastery(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TERRAIN_ADJ_SCIENCE");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TERRAIN_ADJ_CULTURE");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TERRAIN_ADJ_FAITH");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TERRAIN_ADJ_PRODUCTION");
    print("Turn2DedicationTrigger: ✓ 山河形胜");
end

-- 50 灵光乍现：随机尤里卡/鼓舞（按阶段挂对应数量变体）
function ApplyEurekaFlash(pPlayer, stage, rarity)
    local s = stage or 1;
    if s < 1 then s = 1; elseif s > 3 then s = 3; end
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_EUREKA_TECH_S" .. s);
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_EUREKA_CIVIC_S" .. s);
    print("Turn2DedicationTrigger: ✓ 灵光乍现 阶段" .. tostring(s));
end

-- 51 百废俱兴：免费关键建筑（市政中心建筑，无需前置区域）
local FREE_BUILDINGS = { "BUILDING_MONUMENT", "BUILDING_GRANARY", "BUILDING_WALLS" };
local function GrantFreeBuildings(pCity)
    if not pCity then return; end
    local ok, bq = pcall(function() return pCity:GetBuildQueue(); end);
    if not ok or not bq then return; end
    for _, bt in ipairs(FREE_BUILDINGS) do
        local info = GameInfo.Buildings[bt];
        if info then
            pcall(function() bq:CreateIncompleteBuilding(info.Index, 100); end);
        end
    end
end
function ApplyFreeInfrastructure(pPlayer, stage, rarity)
    local pCities = pPlayer:GetCities();
    if not pCities then return; end
    local pCapital = pCities:GetCapitalCity();
    GrantFreeBuildings(pCapital);
    if (stage or 1) >= 2 then
        local n = 0;
        pcall(function()
            for _, pCity in pCities:Members() do
                if pCity ~= pCapital then
                    GrantFreeBuildings(pCity);
                    n = n + 1;
                    if n >= 2 then return; end
                end
            end
        end);
    end
    print("Turn2DedicationTrigger: ✓ 百废俱兴");
end

-- 52 战誓银刃：特色单位 +1 战斗力；己方领土内全战斗单位 +2 战斗力
function ApplyWarOathSilverBlade(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_WAROATH_GRANT_UNIQUE_COMBAT");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_WAROATH_GRANT_HOME_COMBAT");
    print("Turn2DedicationTrigger: ✓ 战誓银刃");
end

-- 53 凯旋铭记：击杀奖励金币与文化（按被击杀单位基础战斗力百分比）
function ApplyTriumphMemory(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TRIUMPH_GOLD_KILLS");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TRIUMPH_CULTURE_KILLS");
    print("Turn2DedicationTrigger: ✓ 凯旋铭记");
end

-- 54 王权铭文：总督城市文化；满忠诚总督城市金币
function ApplyRoyalInscription(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_ROYAL_GOVERNOR_CULTURE");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_ROYAL_GOVERNOR_FULL_LOYALTY_GOLD");
    print("Turn2DedicationTrigger: ✓ 王权铭文");
end

-- 55 河谷工坊：邻河城市住房；邻河且有工业区/商业中心城市生产力
function ApplyRiverValleyWorkshop(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_RIVERVALLEY_RIVER_HOUSING");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_RIVERVALLEY_RIVER_INDUSTRIAL_PRODUCTION");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_RIVERVALLEY_RIVER_COMMERCIAL_PRODUCTION");
    print("Turn2DedicationTrigger: ✓ 河谷工坊");
end

-- 56 山寺钟声：山脉圣地收益；组合城市激活玩家级大科学家点
function ApplyMountainTempleBell(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_MOUNTAIN_TEMPLE_FAITH");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_MOUNTAIN_TEMPLE_SCIENCE");
    if pPlayer and pPlayer.GetID then
        CheckSilverRuneTurnRewards(pPlayer, pPlayer:GetID());
    end
    print("Turn2DedicationTrigger: ✓ 山寺钟声");
end

-- 57 什一商约：圣地/商业中心互补收益；国内圣地终点商路由回合扫描发钱
function ApplyTitheTradePact(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TITHE_HOLY_SITE_GOLD");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_TITHE_COMMERCIAL_FAITH");
    T2D_AttachTitheBuildingYieldModifiers(pPlayer);
    if pPlayer and pPlayer.GetID then
        CheckSilverRuneTurnRewards(pPlayer, pPlayer:GetID());
    end
    print("Turn2DedicationTrigger: ✓ 什一商约");
end

-- 58 民兵史诗：纪念碑城市训练远程/抗骑兵加速；首次拥有远古城墙给市政鼓舞
function ApplyMilitiaEpic(pPlayer, stage, rarity)
    for _, era in ipairs(T2D_ERA_SUFFIXES) do
        T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_MILITIA_RANGED_" .. era);
        T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_MILITIA_ANTICAV_" .. era);
    end
    if pPlayer and pPlayer.GetID then
        CheckSilverRuneTurnRewards(pPlayer, pPlayer:GetID());
    end
    print("Turn2DedicationTrigger: ✓ 民兵史诗");
end

-- 59 祖制回响：所有已加载的特色区域/建筑/改良设施 +1 文化、金币、生产力
function ApplyAncestralEcho(pPlayer, stage, rarity)
    local count = T2D_AttachModifiersByPrefix(pPlayer, "MODIFIER_TURN2_ANCESTRAL_");
    print("Turn2DedicationTrigger: ✓ 祖制回响 挂载特色元素修改器=" .. tostring(count));
end

-- 60 学派银环：所有已加载的特色区域/建筑/改良设施 +1 科技、金币、生产力
function ApplyScholasticSilverRing(pPlayer, stage, rarity)
    local count = T2D_AttachModifiersByPrefix(pPlayer, "MODIFIER_TURN2_SCHOLASTIC_");
    print("Turn2DedicationTrigger: ✓ 学派银环 挂载特色元素修改器=" .. tostring(count));
end

-- 61 测绘学院：侦察类 +1 视野；新建邻山城市最多触发 2 次尤里卡
function ApplyCartographyAcademy(pPlayer, stage, rarity)
    if not T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_CARTOGRAPHY_RECON_SIGHT") then
        error("测绘学院侦察视野修改器挂载失败");
    end
    if pPlayer and pPlayer.GetID then
        local playerID = pPlayer:GetID();
        local baselineKey = "Turn2Dedication_CartographyBaseline_P" .. playerID;
        if not Game.GetProperty(baselineKey) then
            T2D_MarkExistingCartographyCities(pPlayer, playerID);
        end
        CheckSilverRuneTurnRewards(pPlayer, playerID);
    end
    print("Turn2DedicationTrigger: ✓ 测绘学院");
end

-- 62 银缆商约：城邦商路金币/文化；宗主城邦额外金币
function ApplySilverCableTradePact(pPlayer, stage, rarity)
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_SILVER_CABLE_CITYSTATE_GOLD");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_SILVER_CABLE_CITYSTATE_CULTURE");
    T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_SILVER_CABLE_SUZERAIN_GOLD");
    print("Turn2DedicationTrigger: ✓ 银缆商约");
end

-- 63 使馆银阶：每类城邦首次达到 3 使者时解锁永久首都收益
function ApplyEmbassySilverTier(pPlayer, stage, rarity)
    if pPlayer and pPlayer.GetID then
        CheckSilverRuneTurnRewards(pPlayer, pPlayer:GetID());
    end
    print("Turn2DedicationTrigger: ✓ 使馆银阶");
end

-- 64 林地书院：林地相邻区域互补收益；新建伐木场最多 3 次文化奖励
function ApplyWoodlandAcademy(pPlayer, stage, rarity)
    local modifierIDs = {
        "MODIFIER_TURN2_WOODLAND_CAMPUS_FOREST_CULTURE",
        "MODIFIER_TURN2_WOODLAND_CAMPUS_JUNGLE_CULTURE",
        "MODIFIER_TURN2_WOODLAND_THEATER_FOREST_SCIENCE",
        "MODIFIER_TURN2_WOODLAND_THEATER_JUNGLE_SCIENCE",
    };
    for _, modifierID in ipairs(modifierIDs) do
        if not T2D_SafeAttach(pPlayer, modifierID) then
            error("林地书院修改器挂载失败: " .. modifierID);
        end
    end
    if pPlayer and pPlayer.GetID then
        local playerID = pPlayer:GetID();
        local baselineKey = "Turn2Dedication_WoodlandLumberBaseline_P" .. playerID;
        if not Game.GetProperty(baselineKey) then
            T2D_MarkExistingLumberMills(playerID);
        end
        CheckSilverRuneTurnRewards(pPlayer, playerID);
    end
    print("Turn2DedicationTrigger: ✓ 林地书院");
end

-- 65 公民沙龙：快乐/欣喜若狂城市的科技与文化百分比加成
function ApplyCivicSalon(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "公民沙龙", {
        "MODIFIER_TURN2_CIVIC_SALON_HAPPY_SCIENCE",
        "MODIFIER_TURN2_CIVIC_SALON_HAPPY_CULTURE",
        "MODIFIER_TURN2_CIVIC_SALON_ECSTATIC_SCIENCE",
        "MODIFIER_TURN2_CIVIC_SALON_ECSTATIC_CULTURE",
    });
    print("Turn2DedicationTrigger: ✓ 公民沙龙");
end

-- 66 同盟银契：有效同盟提供外交支持，盟友商路提供复合产出
function ApplyAllianceSilverCovenant(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "同盟银契", {
        "MODIFIER_TURN2_ALLIANCE_COVENANT_FAVOR",
        "MODIFIER_TURN2_ALLIANCE_COVENANT_GOLD",
        "MODIFIER_TURN2_ALLIANCE_COVENANT_SCIENCE",
        "MODIFIER_TURN2_ALLIANCE_COVENANT_CULTURE",
    });
    print("Turn2DedicationTrigger: ✓ 同盟银契");
end

-- 67 工坊讲席：首座同时拥有大学和工作坊的城市永久强化
function ApplyWorkshopLectern(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then
        error("工坊讲席缺少有效玩家");
    end
    local playerID = pPlayer:GetID();
    if T2D_TryUnlockWorkshopLectern(pPlayer, playerID) then
        print("Turn2DedicationTrigger: ✓ 工坊讲席");
        return "APPLIED";
    end
    print("Turn2DedicationTrigger: ⓘ 工坊讲席已获得，等待大学+工作坊城市");
    return "DEFERRED";
end

-- 68 圣卷互证：著作与遗物提供文化、食物和生产力
function ApplySacredTextConcordance(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "圣卷互证", {
        "MODIFIER_TURN2_SACRED_TEXT_WRITING_CULTURE",
        "MODIFIER_TURN2_SACRED_TEXT_WRITING_FOOD",
        "MODIFIER_TURN2_SACRED_TEXT_WRITING_PRODUCTION",
        "MODIFIER_TURN2_SACRED_TEXT_RELIC_CULTURE",
        "MODIFIER_TURN2_SACRED_TEXT_RELIC_FOOD",
        "MODIFIER_TURN2_SACRED_TEXT_RELIC_PRODUCTION",
    });
    print("Turn2DedicationTrigger: ✓ 圣卷互证");
end

-- 69 海外宪章：异大陆城市生产力与忠诚度
function ApplyOverseasCharter(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "海外宪章", {
        "MODIFIER_TURN2_OVERSEAS_CHARTER_PRODUCTION",
        "MODIFIER_TURN2_OVERSEAS_CHARTER_LOYALTY",
    });
    print("Turn2DedicationTrigger: ✓ 海外宪章");
end

-- ===========================================================================
-- 第五轮黄金符文（70-82）
-- ===========================================================================

-- SQL 生成的建筑/区域替代项需要全部成功挂载；部分成功不能把符文标记为已应用。
local function T2D_AttachRequiredModifierPrefix(pPlayer, runeName, prefix)
    if not pPlayer or not prefix or not GameInfo or not GameInfo.Modifiers then
        error(tostring(runeName) .. "无法枚举修改器前缀: " .. tostring(prefix));
    end
    local found = 0;
    for modifier in GameInfo.Modifiers() do
        local modifierID = modifier and modifier.ModifierId;
        if modifierID and string.sub(modifierID, 1, string.len(prefix)) == prefix then
            found = found + 1;
            if not T2D_SafeAttach(pPlayer, modifierID) then
                error(tostring(runeName) .. "修改器挂载失败: " .. tostring(modifierID));
            end
        end
    end
    if found == 0 then
        error(tostring(runeName) .. "未找到修改器前缀: " .. tostring(prefix));
    end
    return found;
end

-- 70 内阁议会
function ApplyCabinetCouncil(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "内阁议会", {
        "MODIFIER_TURN2_GOLD70_CABINET_LOYALTY",
        "MODIFIER_TURN2_GOLD70_CABINET_FOOD",
        "MODIFIER_TURN2_GOLD70_CABINET_AMENITY",
    });
    T2D_AttachRequiredModifierPrefix(pPlayer, "内阁议会", "MODIFIER_TURN2_GOLD70_BUILDING_PRODUCTION_");
    print("Turn2DedicationTrigger: ✓ 内阁议会");
end

-- 71 求知使团：6 使者永久解锁该城邦的特色宗主奖励。
-- 数据层把每个城邦 Trait 映射到一个或多个可直接挂在玩家上的克隆修改器。
-- 克隆的 OwnerRequirementSet 使用特定城邦 LeaderType 的反向宗主条件，成为/失去宗主时动态停启。
local function T2D_GetGold71MinorTraits(minorID)
    local traits = {};
    local pConfig = PlayerConfigurations and PlayerConfigurations[minorID];
    local leaderType = pConfig and pConfig.GetLeaderTypeName and pConfig:GetLeaderTypeName();
    if not leaderType or not GameInfo or not GameInfo.LeaderTraits then return traits; end

    for row in GameInfo.LeaderTraits() do
        local traitType = row and row.TraitType;
        if row and row.LeaderType == leaderType and traitType
            and string.sub(traitType, 1, 10) == "MINOR_CIV_"
            and traitType ~= "MINOR_CIV_DEFAULT_TRAIT"
            and traitType ~= "MINOR_CIV_SCIENTIFIC_TRAIT"
            and traitType ~= "MINOR_CIV_RELIGIOUS_TRAIT"
            and traitType ~= "MINOR_CIV_TRADE_TRAIT"
            and traitType ~= "MINOR_CIV_CULTURAL_TRAIT"
            and traitType ~= "MINOR_CIV_MILITARISTIC_TRAIT"
            and traitType ~= "MINOR_CIV_INDUSTRIAL_TRAIT" then
            traits[traitType] = true;
        end
    end
    return traits;
end

local function T2D_TryUnlockGold71ForMinor(pPlayer, playerID, pMinor)
    if not pPlayer or playerID == nil or not pMinor or not pMinor.GetID then return false; end
    local minorID = pMinor:GetID();
    local unlockKey = "Turn2Dedication_Gold71_Unlocked_P" .. playerID .. "_M" .. minorID;
    if Game.GetProperty(unlockKey) then return true; end

    local pInfluence = pMinor.GetInfluence and pMinor:GetInfluence();
    if not pInfluence or not pInfluence.GetTokensReceived then return false; end
    local okTokens, tokens = pcall(function() return pInfluence:GetTokensReceived(playerID); end);
    if not okTokens or (tonumber(tokens) or 0) < 6 then return false; end

    if not GameInfo or not GameInfo.T2D_Gold71Modifiers then
        print("Turn2DedicationTrigger: ⚠ 求知使团映射表 T2D_Gold71Modifiers 未加载");
        return false;
    end

    local minorTraits = T2D_GetGold71MinorTraits(minorID);
    local matched = 0;
    local allAttached = true;
    for mapping in GameInfo.T2D_Gold71Modifiers() do
        if mapping and mapping.TraitType and minorTraits[mapping.TraitType] then
            matched = matched + 1;
            if not T2D_SafeAttach(pPlayer, mapping.ModifierId) then
                allAttached = false;
            end
        end
    end

    if matched == 0 then
        local warningKey = "Turn2Dedication_Gold71_Unsupported_M" .. minorID;
        if not Game.GetProperty(warningKey) then
            Game.SetProperty(warningKey, 1);
            print("Turn2DedicationTrigger: ⚠ 求知使团无法识别城邦 " .. tostring(minorID) .. " 的特色能力，已跳过");
        end
        return false;
    end
    if not allAttached then return false; end

    Game.SetProperty(unlockKey, 1);
    print("Turn2DedicationTrigger: ✓ 求知使团 玩家 " .. tostring(playerID)
        .. " 永久解锁城邦 " .. tostring(minorID) .. " 的特色宗主奖励（" .. tostring(matched) .. "项）");
    return true;
end

function T2D_CheckGold71Unlocks(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return; end
    if not PlayerHasDedication(playerID, 71) then return; end
    if not PlayerManager or not PlayerManager.GetAliveMinors then return; end
    for _, pMinor in ipairs(PlayerManager.GetAliveMinors()) do
        T2D_TryUnlockGold71ForMinor(pPlayer, playerID, pMinor);
    end
end

function OnGold71InfluenceToken(majorID:number, minorID:number, amount:number)
    if not T2D_IsAuthoritativeGameplay() then return; end
    if majorID == nil or minorID == nil or not PlayerHasDedication(majorID, 71) then return; end
    local pPlayer = Players[majorID];
    local pMinor = Players[minorID];
    if pPlayer and pMinor then
        T2D_TryUnlockGold71ForMinor(pPlayer, majorID, pMinor);
    end
end

function ApplyKnowledgeMission(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("求知使团缺少有效玩家"); end
    if not GameInfo or not GameInfo.T2D_Gold71Modifiers then
        error("求知使团映射表 T2D_Gold71Modifiers 未加载");
    end
    local mappingCount = 0;
    for _ in GameInfo.T2D_Gold71Modifiers() do mappingCount = mappingCount + 1; end
    if mappingCount == 0 then error("求知使团映射表为空"); end
    T2D_CheckGold71Unlocks(pPlayer, pPlayer:GetID());
    print("Turn2DedicationTrigger: ✓ 求知使团（" .. tostring(mappingCount)
        .. "项城邦能力映射，等待或已处理6使者城邦）");
end

-- 72 生态廊道
function ApplyEcologicalCorridor(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "生态廊道", {
        "MODIFIER_TURN2_GOLD72_ECOLOGY_SCIENCE",
        "MODIFIER_TURN2_GOLD72_ECOLOGY_CULTURE",
    });
    print("Turn2DedicationTrigger: ✓ 生态廊道");
end

-- 73 万国调停
function ApplyInternationalMediation(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "万国调停", {
        "MODIFIER_TURN2_GOLD73_INFLUENCE",
        "MODIFIER_TURN2_GOLD73_FAVOR",
    });
    print("Turn2DedicationTrigger: ✓ 万国调停");
end

-- 74 暗线议会
function ApplyShadowCouncil(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "暗线议会", {
        "MODIFIER_TURN2_GOLD74_ESTABLISH_TIME",
        "MODIFIER_TURN2_GOLD74_COUNTERSPY",
        "MODIFIER_TURN2_GOLD74_SPY_PROMOTION",
    });
    print("Turn2DedicationTrigger: ✓ 暗线议会");
end

-- 75 行脚修会
function ApplyItinerantOrder(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "行脚修会", {
        "MODIFIER_TURN2_GOLD75_MISSIONARY_SPREAD",
        "MODIFIER_TURN2_GOLD75_GRANT_FOREIGN_MOVEMENT",
    });
    T2D_AttachRequiredModifierPrefix(pPlayer, "行脚修会", "MODIFIER_TURN2_GOLD75_HOLY_SITE_PRODUCTION_");
    print("Turn2DedicationTrigger: ✓ 行脚修会");
end

-- 76 文化互访
function ApplyCulturalExchange(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "文化互访", {
        "MODIFIER_TURN2_GOLD76_TRADE_CAPACITY",
        "MODIFIER_TURN2_GOLD76_INTERNATIONAL_CULTURE",
        "MODIFIER_TURN2_GOLD76_INTERNATIONAL_GOLD",
        "MODIFIER_TURN2_GOLD76_INTERNATIONAL_PRODUCTION",
        "MODIFIER_TURN2_GOLD76_TOURISM",
    });
    print("Turn2DedicationTrigger: ✓ 文化互访");
end

-- 77 次级中心
function ApplySecondaryCenter(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "次级中心", {
        "MODIFIER_TURN2_GOLD77_DISTRICT_PRODUCTION",
        "MODIFIER_TURN2_GOLD77_GROWTH",
    });
    print("Turn2DedicationTrigger: ✓ 次级中心");
end

-- 78 土地改造
function ApplyLandTransformation(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "土地改造", {
        "MODIFIER_TURN2_GOLD78_MINE_GOLD",
        "MODIFIER_TURN2_GOLD78_MINE_FOOD",
    });
    print("Turn2DedicationTrigger: ✓ 土地改造");
end

-- 79 幕后黑手
function ApplyMastermind(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "幕后黑手", {
        "MODIFIER_TURN2_GOLD79_SPY_OFFENSE",
        "MODIFIER_TURN2_GOLD79_SPY_DEFENSE",
        "MODIFIER_TURN2_GOLD79_SPY_PRODUCTION",
    });
    print("Turn2DedicationTrigger: ✓ 幕后黑手");
end

-- 80 竭泽而渔：即时奖励由 RunOnce 修改器发放；-50 金币使用原生回合收益
-- 修改器，以便顶部面板与原版破产逻辑都能正确识别。30期后挂载 +50 修改器抵消。
local T2D_GOLD80_DEBT_VERSION = 2;
local T2D_GOLD80_DEBT_MODIFIER = "MODIFIER_TURN2_GOLD80_DEBT_GOLD";
local T2D_GOLD80_SETTLEMENT_MODIFIER = "MODIFIER_TURN2_GOLD80_SETTLEMENT_GOLD";

local function T2D_GetGold80PropertyKeys(playerID)
    local suffix = "_P" .. tostring(playerID);
    return {
        startTurn = "Turn2Dedication_Gold80_StartTurn" .. suffix,
        remaining = "Turn2Dedication_Gold80_Remaining" .. suffix,
        lastTurn = "Turn2Dedication_Gold80_LastChargeTurn" .. suffix,
        version = "Turn2Dedication_Gold80_DebtVersion" .. suffix,
        settled = "Turn2Dedication_Gold80_Settled" .. suffix,
    };
end

function ApplyExhaustThePond(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("竭泽而渔缺少有效玩家"); end
    T2D_AttachRequiredModifiers(pPlayer, "竭泽而渔", {
        "MODIFIER_TURN2_GOLD80_GRANT_GOLD",
        "MODIFIER_TURN2_GOLD80_GRANT_FAITH",
        T2D_GOLD80_DEBT_MODIFIER,
    });

    local playerID = pPlayer:GetID();
    local keys = T2D_GetGold80PropertyKeys(playerID);
    if Game.GetProperty(keys.startTurn) == nil then
        Game.SetProperty(keys.startTurn, Game.GetCurrentGameTurn() + 1);
        Game.SetProperty(keys.remaining, 30);
        Game.SetProperty(keys.lastTurn, nil);
    end
    Game.SetProperty(keys.version, T2D_GOLD80_DEBT_VERSION);
    Game.SetProperty(keys.settled, nil);
    print("Turn2DedicationTrigger: ✓ 竭泽而渔（原生-50金币，债务从下一玩家回合开始）");
end

function T2D_ProcessGold80Debt(pPlayer, playerID, currentTurn)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return; end
    currentTurn = tonumber(currentTurn) or Game.GetCurrentGameTurn();

    local keys = T2D_GetGold80PropertyKeys(playerID);
    local rawStartTurn = Game.GetProperty(keys.startTurn);
    local rawRemaining = Game.GetProperty(keys.remaining);
    local version = T2D_GetNumberGameProperty(keys.version, 0);
    local remaining = T2D_GetNumberGameProperty(keys.remaining, 0);

    -- 只有已经由旧版 ApplyExhaustThePond 初始化过债务属性的存档才迁移。
    -- 单纯在本回合选择80、但尚未到应用回合的玩家不会被提前挂载惩罚。
    if version < T2D_GOLD80_DEBT_VERSION then
        if rawStartTurn == nil and rawRemaining == nil then return; end
        if remaining <= 0 then return; end
        if not T2D_SafeAttach(pPlayer, T2D_GOLD80_DEBT_MODIFIER) then
            error("竭泽而渔旧存档迁移：-50金币修改器挂载失败");
        end
        Game.SetProperty(keys.version, T2D_GOLD80_DEBT_VERSION);
        Game.SetProperty(keys.startTurn, currentTurn + 1);
        Game.SetProperty(keys.lastTurn, currentTurn);
        Game.SetProperty(keys.settled, nil);
        print("Turn2DedicationTrigger: ✓ 竭泽而渔旧存档已迁移；保留 "
            .. tostring(remaining) .. " 期，从下一玩家回合开始");
        return;
    end

    if remaining <= 0 then return; end
    local startTurn = T2D_GetNumberGameProperty(keys.startTurn, nil);
    if not startTurn or currentTurn < startTurn then return; end
    if T2D_GetNumberGameProperty(keys.lastTurn, nil) == currentTurn then return; end

    -- PlayerTurnStartComplete 在本回合原生金币收益结算后触发。因此 remaining==1
    -- 时本回合已经完成第30次-50结算，此时挂载+50只影响后续回合。
    if remaining == 1 then
        if T2D_GetNumberGameProperty(keys.settled, 0) ~= 1 then
            if not T2D_SafeAttach(pPlayer, T2D_GOLD80_SETTLEMENT_MODIFIER) then
                error("竭泽而渔偿清：+50金币抵消修改器挂载失败");
            end
            Game.SetProperty(keys.settled, 1);
        end
        remaining = 0;
    else
        remaining = remaining - 1;
    end

    Game.SetProperty(keys.remaining, remaining);
    Game.SetProperty(keys.lastTurn, currentTurn);
    print("Turn2DedicationTrigger: ✓ 竭泽而渔 玩家 " .. tostring(playerID)
        .. " 完成一期原生-50金币结算，剩余 " .. tostring(remaining) .. " 期");
end

function OnGold80PlayerTurnStartComplete(playerID:number)
    local pPlayer = Players[playerID];
    if not pPlayer or not pPlayer:IsHuman() or not T2D_IsAuthoritativeGameplay() then return; end
    local okGold80, gold80Error = pcall(
        T2D_ProcessGold80Debt, pPlayer, playerID, Game.GetCurrentGameTurn());
    if not okGold80 then
        print("Turn2DedicationTrigger: ⚠ 竭泽而渔结算失败，其他回合逻辑不受影响: "
            .. tostring(gold80Error));
    end
end

-- 81 焦土计划
function ApplyScorchedEarth(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "焦土计划", {
        "MODIFIER_TURN2_GOLD81_IMPROVEMENT_PILLAGE",
        "MODIFIER_TURN2_GOLD81_DISTRICT_PILLAGE",
        "MODIFIER_TURN2_GOLD81_MINE_SCIENCE",
        "MODIFIER_TURN2_GOLD81_QUARRY_CULTURE",
        "MODIFIER_TURN2_GOLD81_PLANTATION_CULTURE",
        "MODIFIER_TURN2_GOLD81_PASTURE_CULTURE",
        "MODIFIER_TURN2_GOLD81_CAMP_CULTURE",
        "MODIFIER_TURN2_GOLD81_UNIT_MAINTENANCE",
    });
    print("Turn2DedicationTrigger: ✓ 焦土计划");
end

-- 82 冲刺冲刺冲刺
function ApplySprintSprintSprint(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "冲刺冲刺冲刺", {
        "MODIFIER_TURN2_GOLD82_LEVEL_UP_UNITS",
    });
    T2D_AttachRequiredModifierPrefix(pPlayer, "冲刺冲刺冲刺", "MODIFIER_TURN2_GOLD82_NON_CIVILIAN_PRODUCTION_");
    print("Turn2DedicationTrigger: ✓ 冲刺冲刺冲刺");
end

-- ===========================================================================
-- 第六轮黄金符文（83-92）
-- ===========================================================================

-- 83 合成作战
function ApplyGoldRune83(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "合成作战", {
        "MODIFIER_TURN2_GOLD83_FLANKING_BONUS",
        "MODIFIER_TURN2_GOLD83_SUPPORT_BONUS",
    });
    print("Turn2DedicationTrigger: ✓ 合成作战");
end

-- 84 军械标准化
function ApplyGoldRune84(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "军械标准化", {
        "MODIFIER_TURN2_GOLD84_UPGRADE_GOLD_DISCOUNT",
        "MODIFIER_TURN2_GOLD84_UPGRADE_RESOURCE_DISCOUNT",
        "MODIFIER_TURN2_GOLD84_CIVILIAN_PRODUCTION",
    });
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "军械标准化", "MODIFIER_TURN2_GOLD84_NON_CIVILIAN_PRODUCTION_");
    print("Turn2DedicationTrigger: ✓ 军械标准化");
end

-- 85 全域监听（79/85互斥由统一应用入口在任何挂载前校验）。
-- 可见度数据直接复刻黑皇后凯瑟琳的原生 SOURCE_TRAIT 能力链。
function ApplyGoldRune85(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "全域监听", {
        "MODIFIER_TURN2_GOLD85_VISIBILITY",
        "MODIFIER_TURN2_GOLD85_COMBAT_PER_VISIBILITY",
        "MODIFIER_TURN2_GOLD85_SPY_PRODUCTION",
    });
    print("Turn2DedicationTrigger: ✓ 全域监听");
end

-- 86 实证革命；两项随机奖励由数据层 RunOnce 修改器保证只执行一次。
function ApplyGoldRune86(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "实证革命", {
        "MODIFIER_TURN2_GOLD86_TECH_BOOST_PROGRESS",
        "MODIFIER_TURN2_GOLD86_CIVIC_BOOST_PROGRESS",
        "MODIFIER_TURN2_GOLD86_GRANT_TECH_BOOSTS",
        "MODIFIER_TURN2_GOLD86_GRANT_CIVIC_BOOSTS",
    });
    print("Turn2DedicationTrigger: ✓ 实证革命");
end

-- 87 科研产业化
function ApplyGoldRune87(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "科研产业化", {
        "MODIFIER_TURN2_GOLD87_CAMPUS_ADJACENCY_PRODUCTION",
        "MODIFIER_TURN2_GOLD87_SPACE_RACE_PRODUCTION",
    });
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "科研产业化", "MODIFIER_TURN2_GOLD87_UNIVERSITY_PRODUCTION_");
    print("Turn2DedicationTrigger: ✓ 科研产业化");
end

-- 88 国家策展
function ApplyGoldRune88(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "国家策展", {
        "MODIFIER_TURN2_GOLD88_AUTO_THEME",
        "MODIFIER_TURN2_GOLD88_THEMED_YIELD",
        "MODIFIER_TURN2_GOLD88_THEMED_TOURISM",
    });
    print("Turn2DedicationTrigger: ✓ 国家策展");
end

-- 89 全球巡演
function ApplyGoldRune89(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "全球巡演", {
        "MODIFIER_TURN2_GOLD89_ROCK_BAND_PROMOTIONS",
        "MODIFIER_TURN2_GOLD89_ROCK_BAND_TOURISM",
        "MODIFIER_TURN2_GOLD89_ROCK_BAND_FAITH_COST",
    });
    print("Turn2DedicationTrigger: ✓ 全球巡演");
end

-- 90 产业电网
function ApplyGoldRune90(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "产业电网", {
        "MODIFIER_TURN2_GOLD90_POWERED_BUILDING_PRODUCTION",
        "MODIFIER_TURN2_GOLD90_POWERED_BUILDING_GOLD",
    });
    print("Turn2DedicationTrigger: ✓ 产业电网");
end

-- 91 都会引擎
function ApplyGoldRune91(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "都会引擎", {
        "MODIFIER_TURN2_GOLD91_THREE_DISTRICT_PRODUCTION",
        "MODIFIER_TURN2_GOLD91_THREE_DISTRICT_GOLD",
        "MODIFIER_TURN2_GOLD91_THREE_DISTRICT_AMENITY",
        "MODIFIER_TURN2_GOLD91_FIVE_DISTRICT_SCIENCE",
        "MODIFIER_TURN2_GOLD91_FIVE_DISTRICT_CULTURE",
    });
    print("Turn2DedicationTrigger: ✓ 都会引擎");
end

-- 92 制空权
function ApplyGoldRune92(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "制空权", {
        "MODIFIER_TURN2_GOLD92_AIR_PRODUCTION",
        "MODIFIER_TURN2_GOLD92_GRANT_AIR_COMBAT",
        "MODIFIER_TURN2_GOLD92_GRANT_AIR_RANGE",
    });
    print("Turn2DedicationTrigger: ✓ 制空权");
end

-- ===========================================================================
-- 白银符文第五、六批（93-109）
-- 所有玩家级效果均由 COLLECTION_OWNER / COLLECTION_PLAYER_* 数据作用域约束。
-- SQL 动态生成的替代项通过前缀枚举并逐项安全挂载，任一项失败均不写 Applied。
-- ===========================================================================

-- 93 地籍清丈
function ApplySilverRune93(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "地籍清丈", {
        "MODIFIER_TURN2_SILVER93_LAND_SURVEY_PLOT_PURCHASE",
        "MODIFIER_TURN2_SILVER93_LAND_SURVEY_CITY_TILES",
    });
    print("Turn2DedicationTrigger: ✓ 地籍清丈");
end

-- 94 田野勘察
function ApplySilverRune94(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "田野勘察", {
        "MODIFIER_TURN2_SILVER94_FIELD_SURVEY_QUARRY_SCIENCE",
        "MODIFIER_TURN2_SILVER94_FIELD_SURVEY_CAMP_SCIENCE",
    });
    print("Turn2DedicationTrigger: ✓ 田野勘察");
end

-- 95 同行评议
function ApplySilverRune95(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "同行评议", "MODIFIER_TURN2_SILVER95_PEER_REVIEW_PROJECT_");
    print("Turn2DedicationTrigger: ✓ 同行评议");
end

-- 96 公民节庆
function ApplySilverRune96(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "公民节庆", "MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_DISTRICT_");
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "公民节庆", "MODIFIER_TURN2_SILVER96_CIVIC_FESTIVAL_BUILDING_");
    print("Turn2DedicationTrigger: ✓ 公民节庆");
end

-- 97 奢品陈列
function ApplySilverRune97(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "奢品陈列", {
        "MODIFIER_TURN2_SILVER97_LUXURY_DISPLAY_CULTURE",
        "MODIFIER_TURN2_SILVER97_LUXURY_DISPLAY_GOLD",
    });
    print("Turn2DedicationTrigger: ✓ 奢品陈列");
end

-- 98 慈善教区
function ApplySilverRune98(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "慈善教区", "MODIFIER_TURN2_SILVER98_CHARITY_PARISH_FOOD_");
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "慈善教区", "MODIFIER_TURN2_SILVER98_TEMPLE_HOUSING_");
    print("Turn2DedicationTrigger: ✓ 慈善教区");
end

-- 99 巡回讲坛
function ApplySilverRune99(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "巡回讲坛", {
        "MODIFIER_TURN2_SILVER99_ITINERANT_PULPIT_DISTANCE",
        "MODIFIER_TURN2_SILVER99_ITINERANT_PULPIT_PRESSURE",
    });
    print("Turn2DedicationTrigger: ✓ 巡回讲坛");
end

-- 100 外交先遣
function ApplySilverRune100(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "外交先遣", {
        "MODIFIER_TURN2_SILVER100_DIPLOMATIC_VANGUARD_FIRST_ENVOY",
    });
    print("Turn2DedicationTrigger: ✓ 外交先遣");
end

-- 101 公共竞标
function ApplySilverRune101(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "公共竞标", "MODIFIER_TURN2_SILVER101_PUBLIC_TENDER_PROJECT_");
    print("Turn2DedicationTrigger: ✓ 公共竞标");
end

-- 102 博闻强识
function ApplySilverRune102(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "博闻强识", {
        "MODIFIER_TURN2_SILVER102_LEARNED_TECH_BOOST",
        "MODIFIER_TURN2_SILVER102_LEARNED_CIVIC_BOOST",
    });
    print("Turn2DedicationTrigger: ✓ 博闻强识");
end

-- 103 丰收折算
function ApplySilverRune103(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "丰收折算", {
        "MODIFIER_TURN2_SILVER103_HARVEST_ACCOUNTING",
    });
    print("Turn2DedicationTrigger: ✓ 丰收折算");
end

-- 104 京畿迁入：城市级 RunOnce 修改器只挂当前首都；没有首都时保留待应用状态。
function ApplySilverRune104(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID or not pPlayer.GetCities then
        error("京畿迁入缺少有效玩家");
    end
    stage = tonumber(stage);
    if not stage or stage ~= math.floor(stage) or stage < 1 or stage > 3 then
        error("京畿迁入收到无效阶段: " .. tostring(stage));
    end

    local pCities = pPlayer:GetCities();
    if not pCities or not pCities.GetCapitalCity then
        print("Turn2DedicationTrigger: ⓘ 京畿迁入等待有效首都");
        return "RETRY";
    end
    local pCapital = pCities:GetCapitalCity();
    if not pCapital then
        print("Turn2DedicationTrigger: ⓘ 京畿迁入等待有效首都");
        return "RETRY";
    end

    local modifierID = "MODIFIER_TURN2_SILVER104_CAPITAL_MIGRATION_STAGE" .. tostring(stage);
    local dedupeScope = "Silver104_P" .. tostring(pPlayer:GetID()) .. "_S" .. tostring(stage);
    if not T2D_SafeAttachCity(pCapital, modifierID, dedupeScope) then
        error("京畿迁入修改器挂载失败: " .. modifierID);
    end
    print("Turn2DedicationTrigger: ✓ 京畿迁入（阶段" .. tostring(stage) .. "）");
    return "APPLIED";
end

-- 105 丰育新政
function ApplySilverRune105(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "丰育新政", {
        "MODIFIER_TURN2_SILVER105_GROWTH_POLICY",
    });
    print("Turn2DedicationTrigger: ✓ 丰育新政");
end

-- 106 畜贸行会
function ApplySilverRune106(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "畜贸行会", {
        "MODIFIER_TURN2_SILVER106_LIVESTOCK_GUILD_BASE",
        "MODIFIER_TURN2_SILVER106_LIVESTOCK_GUILD_MERCANTILISM",
    });
    print("Turn2DedicationTrigger: ✓ 畜贸行会");
end

-- 107 中央采办
function ApplySilverRune107(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "中央采办", "MODIFIER_TURN2_SILVER107_CENTRAL_PROCUREMENT_");
    print("Turn2DedicationTrigger: ✓ 中央采办");
end

-- 108 牧界拓殖
function ApplySilverRune108(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "牧界拓殖", {
        "MODIFIER_TURN2_SILVER108_PASTURE_CULTURE_BOMB",
    });
    print("Turn2DedicationTrigger: ✓ 牧界拓殖");
end

-- 109 星纹贡礼
function ApplySilverRune109(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "星纹贡礼", {
        "MODIFIER_TURN2_SILVER109_STARWEAVE_RESOURCE",
    });
    print("Turn2DedicationTrigger: ✓ 星纹贡礼");
end

-- ===========================================================================
-- 黄金符文第七批（110-117）
-- 这些符文均为独立效果，可按原生规则与其他符文叠加。
-- ===========================================================================

-- 110 帝国战史
function ApplyGoldRune110(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "帝国战史", {
        "MODIFIER_TURN2_GOLD110_IMPERIAL_WAR_HISTORY_GOLD",
        "MODIFIER_TURN2_GOLD110_IMPERIAL_WAR_HISTORY_CULTURE",
        "MODIFIER_TURN2_GOLD110_IMPERIAL_WAR_HISTORY_SCIENCE",
    });
    print("Turn2DedicationTrigger: ✓ 帝国战史");
end

-- 111 帝国地籍；边界扩张使用 COLLECTION_PLAYER_CITIES 自定义作用域。
function ApplyGoldRune111(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "帝国地籍", {
        "MODIFIER_TURN2_GOLD111_IMPERIAL_CADASTRE_PLOT_PURCHASE",
        "MODIFIER_TURN2_GOLD111_IMPERIAL_CADASTRE_CITY_TILES",
        "MODIFIER_TURN2_GOLD111_IMPERIAL_CADASTRE_BORDER_EXPANSION",
    });
    print("Turn2DedicationTrigger: ✓ 帝国地籍");
end

-- 112 国土资源院
function ApplyGoldRune112(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "国土资源院", {
        "MODIFIER_TURN2_GOLD112_QUARRY_SCIENCE",
        "MODIFIER_TURN2_GOLD112_QUARRY_PRODUCTION",
        "MODIFIER_TURN2_GOLD112_CAMP_SCIENCE",
        "MODIFIER_TURN2_GOLD112_CAMP_PRODUCTION",
    });
    print("Turn2DedicationTrigger: ✓ 国土资源院");
end

-- 113 万国奢博
function ApplyGoldRune113(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "万国奢博", {
        "MODIFIER_TURN2_GOLD113_LUXURY_CULTURE",
        "MODIFIER_TURN2_GOLD113_LUXURY_GOLD",
        "MODIFIER_TURN2_GOLD113_LUXURY_EXTRA_AMENITIES",
    });
    print("Turn2DedicationTrigger: ✓ 万国奢博");
end

-- 114 济世圣会；圣地建筑清单由 SQL 动态展开。
function ApplyGoldRune114(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "济世圣会", "MODIFIER_TURN2_GOLD114_HOLY_BUILDING_FOOD_");
    T2D_AttachRequiredModifiers(pPlayer, "济世圣会", {
        "MODIFIER_TURN2_GOLD114_TEMPLE_HOUSING",
        "MODIFIER_TURN2_GOLD114_TEMPLE_AMENITY",
    });
    print("Turn2DedicationTrigger: ✓ 济世圣会");
end

-- 115 机械化采收；后续建造者次数由原版公共工程同款永久训练单位 Modifier 提供。
function ApplyGoldRune115(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "机械化采收", {
        "MODIFIER_TURN2_GOLD115_HARVEST_BONUS",
        "MODIFIER_TURN2_GOLD115_FUTURE_BUILDER_CHARGE",
    });
    print("Turn2DedicationTrigger: ✓ 机械化采收");
end

-- 116 都城大迁徙：人口奖励按玩家+阶段去重；首都长期加成使用玩家级 Modifier，迁都后自动转移。
function ApplyGoldRune116(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID or not pPlayer.GetCities then
        error("都城大迁徙缺少有效玩家");
    end
    stage = tonumber(stage);
    if not stage or stage ~= math.floor(stage) or stage < 1 or stage > 3 then
        error("都城大迁徙收到无效阶段: " .. tostring(stage));
    end

    local pCities = pPlayer:GetCities();
    local pCapital = pCities and pCities.GetCapitalCity and pCities:GetCapitalCity() or nil;
    if not pCapital then
        print("Turn2DedicationTrigger: ⓘ 都城大迁徙等待有效首都");
        return "RETRY";
    end

    T2D_AttachRequiredModifiers(pPlayer, "都城大迁徙", {
        "MODIFIER_TURN2_GOLD116_CAPITAL_HOUSING",
        "MODIFIER_TURN2_GOLD116_CAPITAL_AMENITY",
    });

    local playerID = pPlayer:GetID();
    local populationKey = "Turn2Dedication_Gold116Population_P"
        .. tostring(playerID) .. "_S" .. tostring(stage);
    if not Game.GetProperty(populationKey) then
        local modifierID = "MODIFIER_TURN2_GOLD116_CAPITAL_POPULATION_STAGE" .. tostring(stage);
        local dedupeScope = "Gold116_P" .. tostring(playerID) .. "_S" .. tostring(stage);
        if not T2D_SafeAttachCity(pCapital, modifierID, dedupeScope) then
            error("都城大迁徙人口修改器挂载失败: " .. modifierID);
        end
        Game.SetProperty(populationKey, 1);
    end

    print("Turn2DedicationTrigger: ✓ 都城大迁徙（阶段" .. tostring(stage) .. "）");
    return "APPLIED";
end

-- 117 共同体条约
function ApplyGoldRune117(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "共同体条约", {
        "MODIFIER_TURN2_GOLD117_ALLIANCE_FAVOR",
        "MODIFIER_TURN2_GOLD117_ALLIANCE_POINTS",
        "MODIFIER_TURN2_GOLD117_ALLY_ROUTE_GOLD",
        "MODIFIER_TURN2_GOLD117_ALLY_ROUTE_PRODUCTION",
    });
    print("Turn2DedicationTrigger: ✓ 共同体条约");
end

-- ===========================================================================
-- 棱彩符文第一批（118-126）
-- ===========================================================================

-- 118 战争神话
function ApplyPrismaticRune118(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "战争神话", {
        "MODIFIER_TURN2_PRISMATIC118_DEFEAT_GOLD",
        "MODIFIER_TURN2_PRISMATIC118_DEFEAT_CULTURE",
        "MODIFIER_TURN2_PRISMATIC118_DEFEAT_SCIENCE",
        "MODIFIER_TURN2_PRISMATIC118_HEAL_FROM_COMBAT",
    });
    print("Turn2DedicationTrigger: ✓ 战争神话");
end

-- 119 无垠疆界
function ApplyPrismaticRune119(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "无垠疆界", {
        "MODIFIER_TURN2_PRISMATIC119_NEW_CITY_TILES",
        "MODIFIER_TURN2_PRISMATIC119_BORDER_EXPANSION",
        "MODIFIER_TURN2_PRISMATIC119_CAPITAL_SETTLER_NO_POPULATION",
    });
    print("Turn2DedicationTrigger: ✓ 无垠疆界");
end

-- 120 知识奇点：先挂载长期进度增幅，再执行两个一次性随机奖励。
function ApplyPrismaticRune120(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "知识奇点", {
        "MODIFIER_TURN2_PRISMATIC120_TECH_BOOST_PROGRESS",
        "MODIFIER_TURN2_PRISMATIC120_CIVIC_BOOST_PROGRESS",
    });
    if not T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_PRISMATIC120_GRANT_TECH_BOOSTS") then
        error("知识奇点尤里卡一次性修改器挂载失败");
    end
    if not T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_PRISMATIC120_GRANT_CIVIC_BOOSTS") then
        error("知识奇点鼓舞一次性修改器挂载失败");
    end
    print("Turn2DedicationTrigger: ✓ 知识奇点");
end

-- 121 普世圣座：圣地建筑及特色替代链由 SQL 生成。
function ApplyPrismaticRune121(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "普世圣座", "MODIFIER_TURN2_PRISMATIC121_HOLY_BUILDING_");
    T2D_AttachRequiredModifiers(pPlayer, "普世圣座", {
        "MODIFIER_TURN2_PRISMATIC121_TEMPLE_HOUSING",
        "MODIFIER_TURN2_PRISMATIC121_TEMPLE_AMENITY",
        "MODIFIER_TURN2_PRISMATIC121_RELIGIOUS_SPREAD_CHARGE",
    });
    print("Turn2DedicationTrigger: ✓ 普世圣座");
end

-- 122 人类记忆宫：各类巨作的产出修改器由 SQL 动态生成。
function ApplyPrismaticRune122(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "人类记忆宫", "MODIFIER_TURN2_PRISMATIC122_GREATWORK_");
    T2D_AttachRequiredModifiers(pPlayer, "人类记忆宫", {
        "MODIFIER_TURN2_PRISMATIC122_AUTO_THEME",
        "MODIFIER_TURN2_PRISMATIC122_THEMED_YIELD",
        "MODIFIER_TURN2_PRISMATIC122_THEMED_TOURISM",
    });
    print("Turn2DedicationTrigger: ✓ 人类记忆宫");
end

-- 123 行政府矩阵：先挂载四项长期产出，最后发放一次性总督头衔。
function ApplyPrismaticRune123(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "行政府矩阵", {
        "MODIFIER_TURN2_PRISMATIC123_GOVERNOR_SCIENCE",
        "MODIFIER_TURN2_PRISMATIC123_GOVERNOR_CULTURE",
        "MODIFIER_TURN2_PRISMATIC123_GOVERNOR_GOLD",
        "MODIFIER_TURN2_PRISMATIC123_GOVERNOR_PRODUCTION",
    });
    if not T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_PRISMATIC123_GOVERNOR_TITLES") then
        error("行政府矩阵总督头衔修改器挂载失败");
    end
    print("Turn2DedicationTrigger: ✓ 行政府矩阵");
end

-- 124 命运共同体
function ApplyPrismaticRune124(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "命运共同体", {
        "MODIFIER_TURN2_PRISMATIC124_ALLIANCE_FAVOR",
        "MODIFIER_TURN2_PRISMATIC124_ALLIANCE_POINTS",
        "MODIFIER_TURN2_PRISMATIC124_ALLY_ROUTE_GOLD",
        "MODIFIER_TURN2_PRISMATIC124_ALLY_ROUTE_PRODUCTION",
        "MODIFIER_TURN2_PRISMATIC124_ALLY_ROUTE_SCIENCE",
        "MODIFIER_TURN2_PRISMATIC124_ALLY_ROUTE_CULTURE",
        "MODIFIER_TURN2_PRISMATIC124_SHARED_VISIBILITY",
    });
    print("Turn2DedicationTrigger: ✓ 命运共同体");
end

local T2D_PRISMATIC125_LEGACY_POLICY_TYPES = {
    "POLICY_GOV_AUTOCRACY",
    "POLICY_GOV_OLIGARCHY",
    "POLICY_GOV_CLASSICAL_REPUBLIC",
};

local function T2D_IsPrismatic125TierOneGovernmentBuilding(buildingInfo)
    if not buildingInfo or buildingInfo.GovernmentTierRequirement ~= "Tier1" then return false; end
    local unlocksPolicy = buildingInfo.UnlocksGovernmentPolicy;
    local textValue = string.lower(tostring(unlocksPolicy));
    return unlocksPolicy == true or unlocksPolicy == 1 or textValue == "1" or textValue == "true";
end

local function T2D_Prismatic125PlayerHasTierOneGovernmentBuilding(pPlayer)
    local pCities = pPlayer and pPlayer.GetCities and pPlayer:GetCities() or nil;
    if not pCities or not GameInfo or not GameInfo.Buildings then return false; end
    for _, pCity in pCities:Members() do
        for buildingInfo in GameInfo.Buildings() do
            if T2D_IsPrismatic125TierOneGovernmentBuilding(buildingInfo)
                and T2D_CityHasBuilding(pCity, buildingInfo.BuildingType) then
                return true;
            end
        end
    end
    return false;
end

-- 125 传承卡解锁入口：UnlockPolicy 使用 Index，状态查询使用 Hash。
function T2D_CheckPrismatic125LegacyPolicies(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return false; end
    local armedKey = "Turn2Dedication_Prismatic125_Armed_P" .. tostring(playerID);
    local unlockedKey = "Turn2Dedication_Prismatic125_LegacyPolicies_P" .. tostring(playerID);
    if Game.GetProperty(unlockedKey) then return true; end
    if not Game.GetProperty(armedKey) or not PlayerHasDedication(playerID, 125) then return false; end
    if not T2D_Prismatic125PlayerHasTierOneGovernmentBuilding(pPlayer) then return false; end

    local pCulture = pPlayer.GetCulture and pPlayer:GetCulture() or nil;
    if not pCulture or not pCulture.UnlockPolicy or not pCulture.IsPolicyUnlocked then
        error("无定宪章无法访问 PlayerCulture 政策接口");
    end

    local unlockedAny = false;
    for _, policyType in ipairs(T2D_PRISMATIC125_LEGACY_POLICY_TYPES) do
        local policyInfo = GameInfo and GameInfo.Policies and GameInfo.Policies[policyType];
        if not policyInfo then
            error("无定宪章缺少传承政策数据: " .. tostring(policyType));
        end

        local okKnown, isUnlocked = pcall(function()
            return pCulture:IsPolicyUnlocked(policyInfo.Hash);
        end);
        if not okKnown then
            error("无定宪章政策状态查询失败: " .. tostring(policyType));
        end
        if not isUnlocked then
            local okUnlock, unlockError = pcall(function()
                pCulture:UnlockPolicy(policyInfo.Index);
            end);
            if not okUnlock then
                error("无定宪章政策解锁失败 " .. tostring(policyType)
                    .. ": " .. tostring(unlockError));
            end
            unlockedAny = true;
        end
    end

    -- 原版剧本在 UnlockPolicy 后设置该标志，令政府界面于本回合刷新可用政策。
    if unlockedAny and pCulture.SetCivicCompletedThisTurn then
        local okRefresh, refreshError = pcall(function()
            pCulture:SetCivicCompletedThisTurn(true);
        end);
        if not okRefresh then
            print("Turn2DedicationTrigger: ⚠ 无定宪章政府界面刷新标志设置失败: "
                .. tostring(refreshError));
        end
    end

    -- 再次校验三张卡；任一张尚未生效时不写完成标记，下回合继续重试。
    for _, policyType in ipairs(T2D_PRISMATIC125_LEGACY_POLICY_TYPES) do
        local policyInfo = GameInfo.Policies[policyType];
        local okVerify, isUnlocked = pcall(function()
            return pCulture:IsPolicyUnlocked(policyInfo.Hash);
        end);
        if not okVerify or not isUnlocked then return false; end
    end

    Game.SetProperty(unlockedKey, 1);
    print("Turn2DedicationTrigger: ✓ 无定宪章已解锁独裁、寡头与共和传承政策");
    return true;
end

-- 共用建筑完成事件；只认玩家原始建造完成的一级政府广场建筑。
function T2D_HandlePrismatic125BuildingConstructed(
    playerID, cityID, buildingID, plotIndex, originalConstruction)
    if not T2D_IsAuthoritativeGameplay() or originalConstruction ~= true then return; end
    if not PlayerHasDedication(playerID, 125)
        or not Game.GetProperty("Turn2Dedication_Prismatic125_Armed_P" .. tostring(playerID)) then
        return;
    end
    local buildingInfo = GameInfo and GameInfo.Buildings and GameInfo.Buildings[buildingID];
    if not T2D_IsPrismatic125TierOneGovernmentBuilding(buildingInfo) then return; end
    local pPlayer = Players[playerID];
    if pPlayer then T2D_CheckPrismatic125LegacyPolicies(pPlayer, playerID); end
end

-- 125 无定宪章
function ApplyPrismaticRune125(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("无定宪章缺少有效玩家"); end
    T2D_AttachRequiredModifiers(pPlayer, "无定宪章", {
        "MODIFIER_TURN2_PRISMATIC125_WILDCARD_SLOT_1",
        "MODIFIER_TURN2_PRISMATIC125_WILDCARD_SLOT_2",
    });

    local playerID = pPlayer:GetID();
    Game.SetProperty("Turn2Dedication_Prismatic125_Armed_P" .. tostring(playerID), 1);
    if T2D_Prismatic125PlayerHasTierOneGovernmentBuilding(pPlayer)
        and not T2D_CheckPrismatic125LegacyPolicies(pPlayer, playerID) then
        return "RETRY";
    end
    print("Turn2DedicationTrigger: ✓ 无定宪章");
    return "APPLIED";
end

local T2D_PRISMATIC126_CITY_MODIFIER = "MODIFIER_T2D_PRISMATIC126_GRANT_FREE_BUILDING";
local T2D_PRISMATIC126_KNOWN_CITY_PROPERTY = "Turn2Dedication_Prismatic126_EverSeen";

local function T2D_GetPrismatic126CityProperty(pCity, propertyKey)
    if not pCity or not pCity.GetProperty then return nil; end
    local okValue, value = pcall(function() return pCity:GetProperty(propertyKey); end);
    if not okValue then return nil; end
    return value;
end

local function T2D_SetPrismatic126CityProperty(pCity, propertyKey, value)
    if not pCity or not pCity.SetProperty then return false; end
    local okSet, setError = pcall(function() pCity:SetProperty(propertyKey, value); end);
    if not okSet then
        print("Turn2DedicationTrigger: ⚠ 万城柱石城市属性写入失败 "
            .. tostring(propertyKey) .. ": " .. tostring(setError));
    end
    return okSet;
end

local function T2D_Prismatic126CityKey(prefix, playerID)
    return "Turn2Dedication_Prismatic126_" .. tostring(prefix) .. "_P" .. tostring(playerID);
end

local function T2D_TryPrismatic126CityReward(pCity, playerID)
    local eligibleKey = T2D_Prismatic126CityKey("Eligible", playerID);
    local pendingKey = T2D_Prismatic126CityKey("Pending", playerID);
    local grantedKey = T2D_Prismatic126CityKey("Granted", playerID);
    if T2D_GetPrismatic126CityProperty(pCity, grantedKey) then return true; end
    if not T2D_GetPrismatic126CityProperty(pCity, eligibleKey) then return false; end

    local okOriginal, originalOwner = pcall(function() return pCity:GetOriginalOwner(); end);
    if not okOriginal or originalOwner ~= playerID then return false; end
    if not T2D_SafeAttachCity(
        pCity, T2D_PRISMATIC126_CITY_MODIFIER, "Prismatic126_P" .. tostring(playerID)) then
        T2D_SetPrismatic126CityProperty(pCity, pendingKey, 1);
        return false;
    end

    if not T2D_SetPrismatic126CityProperty(pCity, grantedKey, 1) then
        T2D_SetPrismatic126CityProperty(pCity, pendingKey, 1);
        return false;
    end
    T2D_SetPrismatic126CityProperty(pCity, pendingKey, nil);
    local okCityID, cityID = pcall(function() return pCity:GetID(); end);
    print("Turn2DedicationTrigger: ✓ 万城柱石已为玩家 " .. tostring(playerID)
        .. " 的新城 " .. tostring(okCityID and cityID or "?") .. " 发放最便宜市中心建筑");
    return true;
end

-- 早期 CityAddedToMap 只调用此全局入口。城市 Property 会随实体保存并跟随易主，
-- 因此占领后解放回原拥有者时仍被识别为旧城，不会冒充新建城市领奖。
function T2D_HandlePrismatic126NewCity(pPlayer, playerID, pCity, originalOwner)
    if not T2D_IsAuthoritativeGameplay() or not pCity or playerID == nil then return false; end
    local wasKnown = T2D_GetPrismatic126CityProperty(pCity, T2D_PRISMATIC126_KNOWN_CITY_PROPERTY);
    if not wasKnown
        and not T2D_SetPrismatic126CityProperty(pCity, T2D_PRISMATIC126_KNOWN_CITY_PROPERTY, 1) then
        return false;
    end
    if wasKnown then return false; end

    local armedKey = "Turn2Dedication_Prismatic126_Armed_P" .. tostring(playerID);
    if originalOwner ~= playerID or not Game.GetProperty(armedKey)
        or not PlayerHasDedication(playerID, 126) then
        return false;
    end

    local eligibleKey = T2D_Prismatic126CityKey("Eligible", playerID);
    local pendingKey = T2D_Prismatic126CityKey("Pending", playerID);
    if not T2D_SetPrismatic126CityProperty(pCity, eligibleKey, 1) then return false; end
    T2D_SetPrismatic126CityProperty(pCity, pendingKey, 1);
    return T2D_TryPrismatic126CityReward(pCity, playerID);
end

-- 挂载失败的城市奖励在玩家回合内独立重试；不会扫描并奖励既有城市。
function T2D_CheckPrismatic126PendingCities(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return; end
    if not Game.GetProperty("Turn2Dedication_Prismatic126_Armed_P" .. tostring(playerID))
        or not PlayerHasDedication(playerID, 126) then
        return;
    end
    local pCities = pPlayer.GetCities and pPlayer:GetCities() or nil;
    if not pCities then return; end
    local eligibleKey = T2D_Prismatic126CityKey("Eligible", playerID);
    local grantedKey = T2D_Prismatic126CityKey("Granted", playerID);
    for _, pCity in pCities:Members() do
        if T2D_GetPrismatic126CityProperty(pCity, eligibleKey)
            and not T2D_GetPrismatic126CityProperty(pCity, grantedKey) then
            T2D_TryPrismatic126CityReward(pCity, playerID);
        end
    end
end

-- 126 万城柱石：先挂载玩家持续效果，再把当前城市设为基线，最后开启新城奖励。
function ApplyPrismaticRune126(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID or not pPlayer.GetCities then
        error("万城柱石缺少有效玩家");
    end
    if not GameInfo or not GameInfo.Modifiers or not GameInfo.Modifiers[T2D_PRISMATIC126_CITY_MODIFIER] then
        error("万城柱石新城建筑修改器未加载: " .. T2D_PRISMATIC126_CITY_MODIFIER);
    end

    T2D_AttachRequiredModifierPrefix(
        pPlayer, "万城柱石", "MODIFIER_TURN2_PRISMATIC126_CITY_CENTER_PRODUCTION_");
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "万城柱石", "MODIFIER_TURN2_PRISMATIC126_BASE_");
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "万城柱石", "MODIFIER_TURN2_PRISMATIC126_ENLIGHTENMENT_");

    local playerID = pPlayer:GetID();
    local armedKey = "Turn2Dedication_Prismatic126_Armed_P" .. tostring(playerID);
    if not Game.GetProperty(armedKey) then
        local pCities = pPlayer:GetCities();
        if not pCities then error("万城柱石无法枚举城市基线"); end
        for _, pCity in pCities:Members() do
            if not T2D_SetPrismatic126CityProperty(
                pCity, T2D_PRISMATIC126_KNOWN_CITY_PROPERTY, 1) then
                error("万城柱石既有城市基线写入失败");
            end
        end
        Game.SetProperty(armedKey, 1);
    end

    print("Turn2DedicationTrigger: ✓ 万城柱石");
    return "APPLIED";
end

-- ===========================================================================
-- 第二批棱彩符文（127-141）
-- ===========================================================================

-- 可选动态前缀：没有匹配项是合法状态，但只要存在，所有项都必须成功挂载。
local function T2D_AttachOptionalModifierPrefixStrict(pPlayer, runeName, prefix)
    if not pPlayer or not prefix or not GameInfo or not GameInfo.Modifiers then
        error(tostring(runeName) .. "无法枚举可选修改器前缀: " .. tostring(prefix));
    end
    local found = 0;
    for modifier in GameInfo.Modifiers() do
        local modifierID = modifier and modifier.ModifierId;
        if modifierID and string.sub(modifierID, 1, string.len(prefix)) == prefix then
            found = found + 1;
            if not T2D_SafeAttach(pPlayer, modifierID) then
                error(tostring(runeName) .. "修改器挂载失败: " .. tostring(modifierID));
            end
        end
    end
    return found;
end

-- 127 战略军团制
function ApplyPrismaticRune127(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "战略军团制", {
        "MODIFIER_TURN2_PRISMATIC127_LAND_CORPS_PREREQ",
        "MODIFIER_TURN2_PRISMATIC127_SEA_FLEET_PREREQ",
        "MODIFIER_TURN2_PRISMATIC127_LAND_ARMY_PREREQ",
        "MODIFIER_TURN2_PRISMATIC127_SEA_ARMADA_PREREQ",
        "MODIFIER_TURN2_PRISMATIC127_LAND_CORPS_STRENGTH",
        "MODIFIER_TURN2_PRISMATIC127_SEA_FLEET_STRENGTH",
        "MODIFIER_TURN2_PRISMATIC127_LAND_ARMY_STRENGTH",
        "MODIFIER_TURN2_PRISMATIC127_SEA_ARMADA_STRENGTH",
        "MODIFIER_TURN2_PRISMATIC127_LAND_FORMATION_DISCOUNT",
        "MODIFIER_TURN2_PRISMATIC127_SEA_FORMATION_DISCOUNT",
    });
    print("Turn2DedicationTrigger: ✓ 战略军团制");
end

-- 128 不间断指挥
function ApplyPrismaticRune128(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "不间断指挥", {
        "MODIFIER_TURN2_PRISMATIC128_MOVEMENT",
        "MODIFIER_TURN2_PRISMATIC128_PROMOTION_MOVEMENT",
    });
    print("Turn2DedicationTrigger: ✓ 不间断指挥");
end

-- 129 群星议院
function ApplyPrismaticRune129(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "群星议院", {
        "MODIFIER_TURN2_PRISMATIC129_GOLD_PATRONAGE",
        "MODIFIER_TURN2_PRISMATIC129_FAITH_PATRONAGE",
        "MODIFIER_TURN2_PRISMATIC129_POINT_REFUND",
        "MODIFIER_TURN2_PRISMATIC129_SCIENTIST_ENGINEER_CHARGE",
    });
    print("Turn2DedicationTrigger: ✓ 群星议院");
end

-- 130 信仰即资本
function ApplyPrismaticRune130(pPlayer, stage, rarity)
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "信仰即资本", "MODIFIER_TURN2_PRISMATIC130_FAITH_PURCHASE_");
    print("Turn2DedicationTrigger: ✓ 信仰即资本");
end

local function T2D_GetCurrentGlobalEraType()
    if not Game or not Game.GetEras or not GameInfo or not GameInfo.Eras then return nil; end
    local pEras = Game.GetEras();
    if not pEras or not pEras.GetCurrentEra then return nil; end
    local eraIndex = pEras:GetCurrentEra();
    local eraInfo = eraIndex ~= nil and GameInfo.Eras[eraIndex] or nil;
    return eraInfo and eraInfo.EraType or nil;
end

-- 131 每个全球时代有独立的原生 RunOnce 使者修改器；玩家属性只记录
-- 状态机已经核对过的时代，原生修改器和 SafeAttach 共同提供重复保护。
function T2D_CheckPrismatic131EraEnvoys(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return false; end
    if not PlayerHasDedication(playerID, 131) then return false; end
    local eraType = T2D_GetCurrentGlobalEraType();
    if not eraType then error("城邦联邦无法读取当前全球时代"); end

    local grantedKey = "Turn2Dedication_Prismatic131_EraGranted_P"
        .. tostring(playerID) .. "_" .. tostring(eraType);
    if Game.GetProperty(grantedKey) then return true; end

    local modifierID = "MODIFIER_TURN2_PRISMATIC131_ERA_ENVOYS_" .. eraType;
    if not T2D_SafeAttach(pPlayer, modifierID) then
        error("城邦联邦时代使者修改器挂载失败: " .. modifierID);
    end
    Game.SetProperty(grantedKey, 1);
    print("Turn2DedicationTrigger: ✓ 城邦联邦为玩家 " .. tostring(playerID)
        .. " 发放时代使者: " .. tostring(eraType));
    return true;
end

-- 131 城邦联邦
function ApplyPrismaticRune131(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("城邦联邦缺少有效玩家"); end
    T2D_AttachRequiredModifiers(pPlayer, "城邦联邦", {
        "MODIFIER_TURN2_PRISMATIC131_LEVY_DISCOUNT",
        "MODIFIER_TURN2_PRISMATIC131_LEVY_ENVOY",
        "MODIFIER_TURN2_PRISMATIC131_LEVIED_UPGRADE_DISCOUNT",
        "MODIFIER_TURN2_PRISMATIC131_LEVIED_IGNORE_STRATEGIC_RESOURCE",
        "MODIFIER_TURN2_PRISMATIC131_INFLUENCE",
    });
    if not T2D_CheckPrismatic131EraEnvoys(pPlayer, pPlayer:GetID()) then
        return "RETRY";
    end
    print("Turn2DedicationTrigger: ✓ 城邦联邦");
    return "APPLIED";
end

-- 132 超额区划
function ApplyPrismaticRune132(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "超额区划", {
        "MODIFIER_TURN2_PRISMATIC132_EXTRA_DISTRICT",
        "MODIFIER_TURN2_PRISMATIC132_EXTRA_DISTRICT_POP10",
    });
    print("Turn2DedicationTrigger: ✓ 超额区划");
end

-- 133 帝国动脉
function ApplyPrismaticRune133(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "帝国动脉", {
        "MODIFIER_TURN2_PRISMATIC133_TRADE_GAIN_TILES",
        "MODIFIER_TURN2_PRISMATIC133_IMPROVED_ROADS",
    });
    print("Turn2DedicationTrigger: ✓ 帝国动脉");
end

-- 134 山岳都市
function ApplyPrismaticRune134(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "山岳都市", {
        "MODIFIER_TURN2_PRISMATIC134_WORKABLE_GRASS_MOUNTAIN",
        "MODIFIER_TURN2_PRISMATIC134_WORKABLE_PLAINS_MOUNTAIN",
        "MODIFIER_TURN2_PRISMATIC134_WORKABLE_DESERT_MOUNTAIN",
        "MODIFIER_TURN2_PRISMATIC134_WORKABLE_TUNDRA_MOUNTAIN",
        "MODIFIER_TURN2_PRISMATIC134_WORKABLE_SNOW_MOUNTAIN",
        "MODIFIER_TURN2_PRISMATIC134_MOUNTAIN_PRODUCTION",
        "MODIFIER_TURN2_PRISMATIC134_MOUNTAIN_SCIENCE",
    });
    print("Turn2DedicationTrigger: ✓ 山岳都市");
end

-- 135 万工会典
function ApplyPrismaticRune135(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "万工会典", {
        "MODIFIER_TURN2_PRISMATIC135_BUILDER_CHARGES",
        "MODIFIER_TURN2_PRISMATIC135_DISTRICT_CHARGE",
        "MODIFIER_TURN2_PRISMATIC135_WONDER_CHARGE",
    });
    print("Turn2DedicationTrigger: ✓ 万工会典");
end

-- 136 百家圣约
function ApplyPrismaticRune136(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "百家圣约", {
        "MODIFIER_TURN2_PRISMATIC136_FOLLOWER_BELIEFS",
        "MODIFIER_TURN2_PRISMATIC136_APOSTLE_PROMOTIONS",
        "MODIFIER_TURN2_PRISMATIC136_RELIGIOUS_COMBAT_GRANT",
        "MODIFIER_TURN2_PRISMATIC136_INQUISITOR_EVICT",
    });
    print("Turn2DedicationTrigger: ✓ 百家圣约");
end

-- 137 战略自由
function ApplyPrismaticRune137(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "战略自由", {
        "MODIFIER_TURN2_PRISMATIC137_TRAINING_RESOURCE_FREE",
        "MODIFIER_TURN2_PRISMATIC137_UPGRADE_RESOURCE_FREE",
        "MODIFIER_TURN2_PRISMATIC137_MAINTENANCE_GRANT",
    });
    print("Turn2DedicationTrigger: ✓ 战略自由");
end

local T2D_PRISMATIC138_PLOT_PROPERTY = "T2D_Prismatic138Fortified";

local function T2D_SetPlotPropertySafe(pPlot, key, value)
    if not pPlot or not pPlot.SetProperty then return false; end
    local okSet, setError = pcall(function() pPlot:SetProperty(key, value); end);
    if not okSet then
        print("Turn2DedicationTrigger: ⚠ 地块属性写入失败 " .. tostring(key)
            .. ": " .. tostring(setError));
    end
    return okSet;
end

local function T2D_GetPlotPropertySafe(pPlot, key)
    if not pPlot or not pPlot.GetProperty then return nil; end
    local okGet, value = pcall(function() return pPlot:GetProperty(key); end);
    return okGet and value or nil;
end

-- 138 驻扎状态由房主定期重建为地块条件。属性值保存 playerID+1，清理时
-- 只清理由本玩家写入的地块，避免多人校准互相擦除。
function T2D_ReconcilePrismatic138Fortification(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return; end
    local listKey = "Turn2Dedication_Prismatic138_FortifiedPlots_P" .. tostring(playerID);
    local markerValue = playerID + 1;
    local previous = Game.GetProperty(listKey);
    if previous then
        for plotIndexText in string.gmatch(tostring(previous), "([^,]+)") do
            local pPlot = Map.GetPlotByIndex(tonumber(plotIndexText) or -1);
            if pPlot and T2D_GetPlotPropertySafe(pPlot, T2D_PRISMATIC138_PLOT_PROPERTY) == markerValue then
                T2D_SetPlotPropertySafe(pPlot, T2D_PRISMATIC138_PLOT_PROPERTY, nil);
            end
        end
    end

    if not PlayerHasDedication(playerID, 138) then
        Game.SetProperty(listKey, nil);
        return;
    end

    local pUnits = pPlayer.GetUnits and pPlayer:GetUnits() or nil;
    if not pUnits then error("万军教范无法枚举玩家单位"); end
    local fortifiedPlots = {};
    local seenPlots = {};
    for _, pUnit in pUnits:Members() do
        local okTurns, fortifyTurns = pcall(function() return pUnit:GetFortifyTurns(); end);
        if okTurns and (tonumber(fortifyTurns) or 0) > 0 then
            local pPlot = Map.GetPlot(pUnit:GetX(), pUnit:GetY());
            if pPlot then
                local plotIndex = pPlot:GetIndex();
                if not seenPlots[plotIndex] then
                    if not T2D_SetPlotPropertySafe(
                        pPlot, T2D_PRISMATIC138_PLOT_PROPERTY, markerValue) then
                        error("万军教范无法设置驻扎地块属性");
                    end
                    seenPlots[plotIndex] = true;
                    table.insert(fortifiedPlots, tostring(plotIndex));
                end
            end
        end
    end
    table.sort(fortifiedPlots);
    Game.SetProperty(listKey, #fortifiedPlots > 0 and table.concat(fortifiedPlots, ",") or nil);
end

function T2D_OnPrismatic138UnitStateChanged(playerID)
    if not T2D_IsAuthoritativeGameplay() then return; end
    local pPlayer = playerID ~= nil and Players[playerID] or nil;
    if not pPlayer or not PlayerHasDedication(playerID, 138) then return; end
    local ok138, error138 = pcall(T2D_ReconcilePrismatic138Fortification, pPlayer, playerID);
    if not ok138 then
        print("Turn2DedicationTrigger: ⚠ 万军教范单位事件校准失败: " .. tostring(error138));
    end
end

-- 138 万军教范
function ApplyPrismaticRune138(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("万军教范缺少有效玩家"); end
    T2D_AttachRequiredModifiers(pPlayer, "万军教范", {
        "MODIFIER_TURN2_PRISMATIC138_SIGHT",
        "MODIFIER_TURN2_PRISMATIC138_EXPERIENCE",
        "MODIFIER_TURN2_PRISMATIC138_RECON_PROMOTION",
        "MODIFIER_TURN2_PRISMATIC138_FORTIFIED_COMBAT",
    });
    T2D_ReconcilePrismatic138Fortification(pPlayer, pPlayer:GetID());
    print("Turn2DedicationTrigger: ✓ 万军教范");
end

local function T2D_IsPlotAdjacentToMountain(pPlot)
    if not pPlot then return false; end
    local x, y = pPlot:GetX(), pPlot:GetY();
    for direction = 0, 5 do
        local pAdjacent = Map.GetAdjacentPlot(x, y, direction);
        if pAdjacent then
            local okMountain, isMountain = pcall(function() return pAdjacent:IsMountain(); end);
            if okMountain and isMountain then return true; end
        end
    end
    return false;
end

local function T2D_GetPrismatic139ProductionPlot(pCity, districtInfo, buildingInfo)
    if not pCity then return nil; end
    if districtInfo then
        if districtInfo.DistrictType == "DISTRICT_CITY_CENTER" then
            return Map.GetPlot(pCity:GetX(), pCity:GetY());
        end
        return T2D_GetCityDistrictPlot(pCity, districtInfo.DistrictType);
    end
    if buildingInfo then
        local districtType = buildingInfo.PrereqDistrict;
        if not districtType or districtType == "DISTRICT_CITY_CENTER" then
            return Map.GetPlot(pCity:GetX(), pCity:GetY());
        end
        return T2D_GetCityDistrictPlot(pCity, districtType);
    end
    return nil;
end

-- 139 keeps two mutually exclusive city-center plot properties: one for a
-- district queue item and one for a non-Wonder building queue item.
function T2D_ReconcilePrismatic139City(pPlayer, playerID, pCity)
    if not T2D_IsAuthoritativeGameplay() or not pCity then return; end
    local pCityPlot = Map.GetPlot(pCity:GetX(), pCity:GetY());
    if not pCityPlot then return; end

    local districtEnabled = false;
    local buildingEnabled = false;
    if pPlayer and playerID ~= nil and PlayerHasDedication(playerID, 139) then
        local pQueue = pCity.GetBuildQueue and pCity:GetBuildQueue() or nil;
        local currentHash = pQueue and pQueue.GetCurrentProductionTypeHash
            and pQueue:GetCurrentProductionTypeHash() or nil;
        if currentHash and currentHash ~= 0 then
            local districtInfo = GameInfo and GameInfo.Districts and GameInfo.Districts[currentHash];
            local buildingInfo = GameInfo and GameInfo.Buildings and GameInfo.Buildings[currentHash];
            local pProductionPlot = T2D_GetPrismatic139ProductionPlot(
                pCity, districtInfo, buildingInfo);
            if T2D_IsPlotAdjacentToMountain(pProductionPlot) then
                if districtInfo then
                    districtEnabled = true;
                elseif buildingInfo and not buildingInfo.IsWonder then
                    buildingEnabled = true;
                end
            end
        end
    end

    if not T2D_SetPlotPropertySafe(
        pCityPlot, "T2D_Prismatic139DistrictProduction", districtEnabled and 1 or nil) then
        error("山岳营造法无法写入区域生产条件");
    end
    if not T2D_SetPlotPropertySafe(
        pCityPlot, "T2D_Prismatic139BuildingProduction", buildingEnabled and 1 or nil) then
        error("山岳营造法无法写入建筑生产条件");
    end
end

function T2D_ReconcilePrismatic139Player(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return; end
    local pCities = pPlayer.GetCities and pPlayer:GetCities() or nil;
    if not pCities then return; end
    for _, pCity in pCities:Members() do
        T2D_ReconcilePrismatic139City(pPlayer, playerID, pCity);
    end
end

function T2D_OnPrismatic139ProductionChanged(playerID, cityID)
    if not T2D_IsAuthoritativeGameplay() then return; end
    local pPlayer = playerID ~= nil and Players[playerID] or nil;
    local pCities = pPlayer and pPlayer.GetCities and pPlayer:GetCities() or nil;
    local pCity = pCities and cityID ~= nil and pCities:FindID(cityID) or nil;
    if not pCity then return; end
    local ok139, error139 = pcall(T2D_ReconcilePrismatic139City, pPlayer, playerID, pCity);
    if not ok139 then
        print("Turn2DedicationTrigger: ⚠ 山岳营造法生产事件校准失败: " .. tostring(error139));
    end
end

-- 139 山岳营造法
function ApplyPrismaticRune139(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("山岳营造法缺少有效玩家"); end
    T2D_AttachRequiredModifiers(pPlayer, "山岳营造法", {
        "MODIFIER_TURN2_PRISMATIC139_DISTRICT_PRODUCTION",
        "MODIFIER_TURN2_PRISMATIC139_BUILDING_PRODUCTION",
    });
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "山岳营造法", "MODIFIER_TURN2_PRISMATIC139_FLAT_YIELD_");
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "山岳营造法", "MODIFIER_TURN2_PRISMATIC139_COMMERCIAL_MOUNTAIN_");
    T2D_ReconcilePrismatic139Player(pPlayer, pPlayer:GetID());
    print("Turn2DedicationTrigger: ✓ 山岳营造法");
end

local g_T2DPrismatic140HolyDistrictFamily = nil;

local function T2D_GetPrismatic140HolyDistrictFamily()
    if g_T2DPrismatic140HolyDistrictFamily then return g_T2DPrismatic140HolyDistrictFamily; end
    local family = { DISTRICT_HOLY_SITE = true };
    if GameInfo and GameInfo.DistrictReplaces then
        local changed = true;
        while changed do
            changed = false;
            for replacement in GameInfo.DistrictReplaces() do
                if replacement and family[replacement.ReplacesDistrictType]
                    and not family[replacement.CivUniqueDistrictType] then
                    family[replacement.CivUniqueDistrictType] = true;
                    changed = true;
                end
            end
        end
    end
    g_T2DPrismatic140HolyDistrictFamily = family;
    return family;
end

local function T2D_Prismatic140PlayerHasHolySite(pPlayer)
    local pCities = pPlayer and pPlayer.GetCities and pPlayer:GetCities() or nil;
    if not pCities then return false; end
    local family = T2D_GetPrismatic140HolyDistrictFamily();
    for _, pCity in pCities:Members() do
        for districtType, _ in pairs(family) do
            if T2D_CityHasDistrict(pCity, districtType) then return true; end
        end
    end
    return false;
end

local function T2D_GrantPrismatic140ProphetPoints(pPlayer, playerID)
    local grantedKey = "Turn2Dedication_Prismatic140_ProphetGranted_P" .. tostring(playerID);
    if Game.GetProperty(grantedKey) then return true; end
    if not T2D_SafeAttach(pPlayer, "MODIFIER_TURN2_PRISMATIC140_PROPHET_POINTS") then
        error("圣堂军制发放大预言家点数失败");
    end
    Game.SetProperty(grantedKey, 1);
    print("Turn2DedicationTrigger: ✓ 圣堂军制为玩家 " .. tostring(playerID)
        .. " 发放15点大预言家点数");
    return true;
end

function T2D_CheckPrismatic140ProphetPoints(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return false; end
    if not PlayerHasDedication(playerID, 140) then return false; end
    local armedKey = "Turn2Dedication_Prismatic140_Armed_P" .. tostring(playerID);
    if not Game.GetProperty(armedKey) then return false; end
    if Game.GetProperty("Turn2Dedication_Prismatic140_ProphetGranted_P" .. tostring(playerID)) then
        return true;
    end
    if T2D_Prismatic140PlayerHasHolySite(pPlayer) then
        return T2D_GrantPrismatic140ProphetPoints(pPlayer, playerID);
    end
    return false;
end

function T2D_HandlePrismatic140DistrictCompleted(pPlayer, playerID, districtType, percentComplete)
    if not T2D_IsAuthoritativeGameplay() or (tonumber(percentComplete) or 0) < 100 then return; end
    if not pPlayer or playerID == nil or not PlayerHasDedication(playerID, 140) then return; end
    if not Game.GetProperty("Turn2Dedication_Prismatic140_Armed_P" .. tostring(playerID)) then return; end
    if not T2D_GetPrismatic140HolyDistrictFamily()[districtType] then return; end
    T2D_GrantPrismatic140ProphetPoints(pPlayer, playerID);
end

-- 140 圣堂军制
function ApplyPrismaticRune140(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("圣堂军制缺少有效玩家"); end
    T2D_AttachRequiredModifiers(pPlayer, "圣堂军制", {
        "MODIFIER_TURN2_PRISMATIC140_BASE_HOLY_SITE_PRODUCTION",
        "MODIFIER_TURN2_PRISMATIC140_SHRINE_CITY_ATTACH",
        "MODIFIER_TURN2_PRISMATIC140_TEMPLE_CITY_ATTACH",
        "MODIFIER_TURN2_PRISMATIC140_WORSHIP_CITY_ATTACH",
    });
    T2D_AttachRequiredModifierPrefix(
        pPlayer, "圣堂军制", "MODIFIER_TURN2_PRISMATIC140_BUILDING_PRODUCTION_");
    T2D_AttachOptionalModifierPrefixStrict(
        pPlayer, "圣堂军制", "MODIFIER_TURN2_PRISMATIC140_DISTRICT_MAINTENANCE_");
    T2D_AttachOptionalModifierPrefixStrict(
        pPlayer, "圣堂军制", "MODIFIER_TURN2_PRISMATIC140_BUILDING_MAINTENANCE_");

    local playerID = pPlayer:GetID();
    Game.SetProperty("Turn2Dedication_Prismatic140_Armed_P" .. tostring(playerID), 1);
    if T2D_Prismatic140PlayerHasHolySite(pPlayer)
        and not T2D_CheckPrismatic140ProphetPoints(pPlayer, playerID) then
        return "RETRY";
    end
    print("Turn2DedicationTrigger: ✓ 圣堂军制");
    return "APPLIED";
end

local T2D_PRISMATIC141_MAX_CITY_THRESHOLD = 256;

local function T2D_GetPlayerCityCount(pPlayer)
    local pCities = pPlayer and pPlayer.GetCities and pPlayer:GetCities() or nil;
    if not pCities then return 0; end
    if pCities.GetCount then
        local okCount, count = pcall(function() return pCities:GetCount(); end);
        if okCount then return tonumber(count) or 0; end
    end
    local count = 0;
    for _, _ in pCities:Members() do count = count + 1; end
    return count;
end

local function T2D_GetPrismatic141ModifierIDs(threshold)
    local n = tostring(threshold);
    local ids = {
        "MODIFIER_TURN2_PRISMATIC141_BASE_PRODUCTION_" .. n,
        "MODIFIER_TURN2_PRISMATIC141_BASE_GOLD_" .. n,
        "MODIFIER_TURN2_PRISMATIC141_BASE_FAITH_" .. n,
        "MODIFIER_TURN2_PRISMATIC141_POLITICAL_SCIENCE_" .. n,
        "MODIFIER_TURN2_PRISMATIC141_POLITICAL_CULTURE_" .. n,
        "MODIFIER_TURN2_PRISMATIC141_POLITICAL_HOUSING_" .. n,
        "MODIFIER_TURN2_PRISMATIC141_NATIONALISM_SCIENCE_" .. n,
        "MODIFIER_TURN2_PRISMATIC141_NATIONALISM_CULTURE_" .. n,
    };
    for _, branch in ipairs({ "DIVINE_RIGHT", "REFORMED_CHURCH", "EXPLORATION" }) do
        table.insert(ids, "MODIFIER_TURN2_PRISMATIC141_GOV_" .. branch .. "_PRODUCTION_" .. n);
        table.insert(ids, "MODIFIER_TURN2_PRISMATIC141_GOV_" .. branch .. "_GOLD_" .. n);
        table.insert(ids, "MODIFIER_TURN2_PRISMATIC141_GOV_" .. branch .. "_FAITH_" .. n);
    end
    return ids;
end

-- Attach enough reversible thresholds for the current empire plus headroom.
-- Requirement sets, not Lua arithmetic, turn individual thresholds on/off.
function T2D_EnsurePrismatic141Thresholds(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return; end
    if not PlayerHasDedication(playerID, 141) then return; end
    local maxKey = "Turn2Dedication_Prismatic141_MaxThreshold_P" .. tostring(playerID);
    local rawMax = Game.GetProperty(maxKey);
    local attachedMax = rawMax ~= nil and tonumber(rawMax) or 0;
    local cityCount = T2D_GetPlayerCityCount(pPlayer);
    local target = math.min(
        T2D_PRISMATIC141_MAX_CITY_THRESHOLD,
        math.max(32, cityCount + 16));
    if target <= attachedMax then return; end

    for threshold = attachedMax + 1, target do
        T2D_AttachRequiredModifiers(
            pPlayer, "天下归枢阈值" .. tostring(threshold),
            T2D_GetPrismatic141ModifierIDs(threshold));
        Game.SetProperty(maxKey, threshold);
    end
    print("Turn2DedicationTrigger: ✓ 天下归枢阈值扩展至 " .. tostring(target)
        .. " 城（玩家 " .. tostring(playerID) .. "）");
end

-- 141 天下归枢
function ApplyPrismaticRune141(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("天下归枢缺少有效玩家"); end
    T2D_EnsurePrismatic141Thresholds(pPlayer, pPlayer:GetID());
    print("Turn2DedicationTrigger: ✓ 天下归枢");
end

-- ===========================================================================
-- 随机质变与使者符文（142-145）
-- ===========================================================================

-- Gameplay VM 无法 include UI 注册表，因此在这里镜像所有可作为质变奖励的
-- 黄金/棱彩 ID。质变符文本身不进入奖励池，避免递归抽取。
local T2D_TRANSMUTATION_GOLD_IDS = {
    11,24,30,31,32,34,35,36,37,40,41,42,43,44,45,46,48,50,51,
    70,71,72,73,74,75,76,77,78,79,80,81,82,
    83,84,85,86,87,88,89,90,91,92,
    110,111,112,113,114,115,116,117,145,
};
local T2D_TRANSMUTATION_PRISMATIC_IDS = {
    12,21,22,47,49,
    118,119,120,121,122,123,124,125,126,
    127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,144,
};

local function T2D_GetTransmutationCandidates(playerID, stage, targetRarityCode)
    local source = targetRarityCode == 2
        and T2D_TRANSMUTATION_GOLD_IDS or T2D_TRANSMUTATION_PRISMATIC_IDS;
    local candidates = {};
    for _, runeID in ipairs(source) do
        if T2D_IsRuneEligibleForStage(runeID, stage)
            and not PlayerHasDedication(playerID, runeID)
            and not T2D_GetConflictingRune(playerID, runeID) then
            table.insert(candidates, runeID);
        end
    end
    table.sort(candidates);
    return candidates;
end

local function T2D_ApplyTransmutation(pPlayer, sourceRuneID, stage, targetRarityCode, sourceName)
    if not T2D_IsAuthoritativeGameplay() then return "RETRY"; end
    if not pPlayer or not pPlayer.GetID then error(tostring(sourceName) .. "缺少有效玩家"); end

    local playerID = pPlayer:GetID();
    stage = tonumber(stage) or 1;
    local targetKey = "Turn2Dedication_TransmutationTarget_P" .. playerID .. "_R" .. sourceRuneID;
    local appliedKey = "Turn2Dedication_TransmutationApplied_P" .. playerID .. "_R" .. sourceRuneID;
    local rawTarget = Game.GetProperty(targetKey);
    local targetRuneID = rawTarget ~= nil and tonumber(rawTarget) or nil;

    if Game.GetProperty(appliedKey) and targetRuneID then
        return "APPLIED";
    end

    if not targetRuneID then
        local candidates = T2D_GetTransmutationCandidates(playerID, stage, targetRarityCode);
        if #candidates == 0 then
            print("Turn2DedicationTrigger: ⚠ " .. tostring(sourceName)
                .. "没有符合条件的未拥有奖励，等待后续重试");
            return "RETRY";
        end
        local randomIndex = Game.GetRandNum(#candidates,
            "Turn2Dedication transmutation rune " .. tostring(sourceRuneID)) + 1;
        targetRuneID = candidates[randomIndex];
        Game.SetProperty(targetKey, targetRuneID);
    end

    -- 先写奖励拥有状态，使任务型目标及其内部 PlayerHasDedication 检查可见。
    local bonusKey = "Turn2Dedication_BonusRune_P" .. playerID .. "_R" .. targetRuneID;
    local bonusStageKey = "Turn2Dedication_BonusRuneStage_P" .. playerID .. "_R" .. targetRuneID;
    local bonusRarityKey = "Turn2Dedication_BonusRuneRarity_P" .. playerID .. "_R" .. targetRuneID;
    local bonusSourceKey = "Turn2Dedication_BonusRuneSource_P" .. playerID .. "_R" .. targetRuneID;
    Game.SetProperty(bonusKey, sourceRuneID);
    Game.SetProperty(bonusStageKey, stage);
    Game.SetProperty(bonusRarityKey, targetRarityCode);
    Game.SetProperty(bonusSourceKey, sourceRuneID);

    local okApply, result = pcall(function()
        return ApplyDedicationEffect(pPlayer, targetRuneID, stage, targetRarityCode);
    end);
    if not okApply then
        print("Turn2DedicationTrigger: ⚠ " .. tostring(sourceName) .. "奖励符文 "
            .. tostring(targetRuneID) .. " 应用失败，将固定结果后重试: " .. tostring(result));
        return "RETRY";
    end
    if result == "CONFLICT" or result == "RETRY" then
        print("Turn2DedicationTrigger: ⚠ " .. tostring(sourceName) .. "奖励符文 "
            .. tostring(targetRuneID) .. " 尚未完成: " .. tostring(result));
        return "RETRY";
    end

    Game.SetProperty(appliedKey, 1);
    print("Turn2DedicationTrigger: ✓ " .. tostring(sourceName) .. "随机获得符文 "
        .. tostring(targetRuneID) .. "（" .. tostring(result) .. "）");
    return result == "DEFERRED" and "DEFERRED" or "APPLIED";
end

-- 142 质变：黄金（符文本身为白银）
function ApplySilverRune142(pPlayer, stage, rarity)
    return T2D_ApplyTransmutation(pPlayer, 142, stage, 2, "质变：黄金");
end

-- 143 质变：棱彩（符文本身为黄金）
function ApplyGoldRune143(pPlayer, stage, rarity)
    return T2D_ApplyTransmutation(pPlayer, 143, stage, 3, "质变：棱彩");
end

local function T2D_Prismatic144Property(playerID, suffix)
    return "Turn2Dedication_Prismatic144_" .. suffix .. "_P" .. tostring(playerID);
end

local function T2D_Prismatic144StepModifier(step)
    return "MODIFIER_TURN2_PRISMATIC144_ENVOY_STEP_" .. string.format("%02d", step);
end

-- 每次只发放一个储备使者；UI 桥接确认派到目标城邦后才进入下一步。
-- 这样读档、联机延迟和重复事件都不会一次性留下19名可自由挪用的使者。
function T2D_AdvancePrismatic144(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return false; end
    if not PlayerHasDedication(playerID, 144) then return false; end

    local remainingKey = T2D_Prismatic144Property(playerID, "Remaining");
    local remaining = T2D_GetNumberGameProperty(remainingKey, 0);
    if remaining <= 0 then
        Game.SetProperty(remainingKey, 0);
        Game.SetProperty(T2D_Prismatic144Property(playerID, "AwaitingStep"), 0);
        Game.SetProperty(T2D_Prismatic144Property(playerID, "AuthorizedStep"), 0);
        Game.SetProperty(T2D_Prismatic144Property(playerID, "Complete"), 1);
        return true;
    end
    if T2D_GetNumberGameProperty(T2D_Prismatic144Property(playerID, "AwaitingStep"), 0) > 0 then
        return true;
    end

    local stepKey = T2D_Prismatic144Property(playerID, "NextStep");
    local step = T2D_GetNumberGameProperty(stepKey, 1);
    if step < 1 or step > 19 then
        error("一使定邦补派步骤越界: " .. tostring(step));
    end
    local modifierID = T2D_Prismatic144StepModifier(step);
    if not T2D_SafeAttach(pPlayer, modifierID) then
        error("一使定邦无法发放第" .. tostring(step) .. "名补派使者");
    end

    Game.SetProperty(stepKey, step + 1);
    Game.SetProperty(T2D_Prismatic144Property(playerID, "AwaitingStep"), step);
    Game.SetProperty(T2D_Prismatic144Property(playerID, "AuthorizedStep"), 0);
    print("Turn2DedicationTrigger: ⓘ 一使定邦等待补派步骤 " .. tostring(step)
        .. "，剩余目标 " .. tostring(remaining));
    return true;
end

function T2D_ReconcilePrismatic144(pPlayer, playerID)
    if not T2D_IsAuthoritativeGameplay() or not pPlayer or playerID == nil then return; end
    if not PlayerHasDedication(playerID, 144) then return; end
    if not Game.GetProperty(T2D_Prismatic144Property(playerID, "Triggered")) then return; end
    if Game.GetProperty(T2D_Prismatic144Property(playerID, "Complete")) then return; end
    T2D_AdvancePrismatic144(pPlayer, playerID);
end

function T2D_OnPrismatic144InfluenceToken(majorID, minorID, amount)
    if not T2D_IsAuthoritativeGameplay() or majorID == nil or minorID == nil then return; end
    if not PlayerHasDedication(majorID, 144) then return; end
    local pPlayer = Players[majorID];
    if not pPlayer then return; end

    local triggeredKey = T2D_Prismatic144Property(majorID, "Triggered");
    local targetKey = T2D_Prismatic144Property(majorID, "TargetMinor");
    local remainingKey = T2D_Prismatic144Property(majorID, "Remaining");
    local awaitingKey = T2D_Prismatic144Property(majorID, "AwaitingStep");
    local actualAmount = math.max(1, tonumber(amount) or 1);

    if not Game.GetProperty(triggeredKey) then
        if not Game.GetProperty(T2D_Prismatic144Property(majorID, "Armed")) then return; end
        Game.SetProperty(triggeredKey, 1);
        Game.SetProperty(targetKey, minorID);
        Game.SetProperty(remainingKey, math.max(0, 20 - actualAmount));
        Game.SetProperty(T2D_Prismatic144Property(majorID, "NextStep"), 1);
        Game.SetProperty(awaitingKey, 0);
        print("Turn2DedicationTrigger: ✓ 一使定邦由玩家 " .. tostring(majorID)
            .. " 首次主动派往城邦 " .. tostring(minorID) .. "，首批计 " .. tostring(actualAmount));
        T2D_AdvancePrismatic144(pPlayer, majorID);
        return;
    end

    if Game.GetProperty(T2D_Prismatic144Property(majorID, "Complete")) then return; end
    local targetMinor = T2D_GetNumberGameProperty(targetKey, -1);
    local awaitingStep = T2D_GetNumberGameProperty(awaitingKey, 0);
    local authorizedKey = T2D_Prismatic144Property(majorID, "AuthorizedStep");
    local authorizedStep = T2D_GetNumberGameProperty(authorizedKey, 0);
    -- 仅确认 UI 桥接已向房主授权的后续派遣。这样城邦面板一次确认
    -- 多名手动使者时，第二名及以后不会被误算为19名自动补派的一部分。
    if targetMinor ~= minorID or awaitingStep <= 0 or authorizedStep ~= awaitingStep then return; end

    local remaining = math.max(0,
        T2D_GetNumberGameProperty(remainingKey, 0) - actualAmount);
    Game.SetProperty(remainingKey, remaining);
    Game.SetProperty(awaitingKey, 0);
    Game.SetProperty(authorizedKey, 0);
    if remaining <= 0 then
        Game.SetProperty(T2D_Prismatic144Property(majorID, "Complete"), 1);
        print("Turn2DedicationTrigger: ✓ 一使定邦20名使者结算完成（玩家 "
            .. tostring(majorID) .. "，城邦 " .. tostring(minorID) .. "）");
    else
        T2D_AdvancePrismatic144(pPlayer, majorID);
    end
end

-- 144 一使定邦
function ApplyPrismaticRune144(pPlayer, stage, rarity)
    if not pPlayer or not pPlayer.GetID then error("一使定邦缺少有效玩家"); end
    local playerID = pPlayer:GetID();
    local armedKey = T2D_Prismatic144Property(playerID, "Armed");
    if not Game.GetProperty(armedKey) then Game.SetProperty(armedKey, 1); end
    print("Turn2DedicationTrigger: ✓ 一使定邦已待命，等待首次主动派遣使者");
end

-- 145 使节贡赋
function ApplyGoldRune145(pPlayer, stage, rarity)
    T2D_AttachRequiredModifiers(pPlayer, "使节贡赋", {
        "MODIFIER_TURN2_GOLD145_ENVOY_GOLD",
        "MODIFIER_TURN2_GOLD145_ENVOY_FAITH",
        "MODIFIER_TURN2_GOLD145_INFLUENCE",
    });
    print("Turn2DedicationTrigger: ✓ 使节贡赋");
end

-- UI 请求自动补派前先由房主核对玩家、目标城邦和步骤。端口只承担
-- 操作授权，不直接修改使者或符文状态。
local T2D_PRISMATIC144_AUTH_PORT = 655013;
function OnPrismatic144AuthorizeTopUp(fromPlayer, toPlayer, text, eTargetType)
    if toPlayer ~= T2D_PRISMATIC144_AUTH_PORT or type(text) ~= "string" then return; end
    local playerID, minorID, step = text:match("^%[T2D_ENVOY144%](%d+):(%d+):(%d+)$");
    playerID = tonumber(playerID);
    minorID = tonumber(minorID);
    step = tonumber(step);
    if not T2D_IsAuthoritativeGameplay()
        or playerID == nil or tonumber(fromPlayer) ~= playerID
        or minorID == nil or step == nil or step < 1 or step > 19
        or not PlayerHasDedication(playerID, 144)
        or not Game.GetProperty(T2D_Prismatic144Property(playerID, "Triggered"))
        or Game.GetProperty(T2D_Prismatic144Property(playerID, "Complete")) then
        return;
    end
    local targetMinor = T2D_GetNumberGameProperty(
        T2D_Prismatic144Property(playerID, "TargetMinor"), -1);
    local awaitingStep = T2D_GetNumberGameProperty(
        T2D_Prismatic144Property(playerID, "AwaitingStep"), 0);
    if targetMinor ~= minorID or awaitingStep ~= step then return; end
    Game.SetProperty(T2D_Prismatic144Property(playerID, "AuthorizedStep"), step);
end

-- ===========================================================================
-- 开发者模式：经隐藏端口 655010 立即应用某符文效果（图鉴面板触发）
-- 消息格式：[T2D_DEV]playerID:runeID:stage:rarityCode[:nonce]
-- ===========================================================================
local function T2D_SetDeveloperAck(playerID, nonce, runeID, status)
    local ackKey = "Turn2Dedication_DevAck_P" .. playerID;
    Game.SetProperty(ackKey, tostring(nonce or 0) .. ":" .. tostring(runeID) .. ":" .. tostring(status));
end

function OnDeveloperModeApplyRune(fromPlayer:number, toPlayer:number, text:string, eTargetType:number)
    if toPlayer ~= 655010 then return; end
    if not text or type(text) ~= "string" then return; end
    local isMultiplayer = GameConfiguration and GameConfiguration.IsAnyMultiplayer
        and GameConfiguration.IsAnyMultiplayer();
    if isMultiplayer then
        print("Turn2DedicationTrigger: ❌ 多人游戏禁止开发者符文申请");
        return;
    end

    -- 兼容旧图鉴把超出 32 位范围的 nonce 格式化为负数的故障消息；
    -- 新版 UI 会始终发送安全的正整数，但接收端不再因负号直接拒绝。
    local playerID, runeID, stage, rarityCode, nonce = text:match(
        "^%[T2D_DEV%](%d+):(%d+):(%d+):(%d+):([%-]?%d+)$");
    if not playerID then
        playerID, runeID, stage, rarityCode = text:match("^%[T2D_DEV%](%d+):(%d+):(%d+):(%d+)$");
        nonce = "0";
    end
    if not playerID then
        print("Turn2DedicationTrigger: ❌ 开发者消息格式错误: " .. tostring(text));
        return;
    end
    playerID   = tonumber(playerID);
    runeID     = tonumber(runeID);
    stage      = tonumber(stage);
    rarityCode = tonumber(rarityCode);
    nonce      = tonumber(nonce) or 0;

    -- 只在单人或房主端执行；多人消息不能代替其他玩家申请开发者符文。
    if not T2D_IsAuthoritativeGameplay() then return; end
    if tonumber(fromPlayer) ~= playerID
        or not T2D_IsValidRuneID(runeID)
        or stage == nil or stage ~= math.floor(stage) or stage < 1 or stage > 3
        or rarityCode == nil or rarityCode ~= math.floor(rarityCode)
        or rarityCode < 1 or rarityCode > 3
        or not T2D_IsRuneRarityCodeValid(runeID, rarityCode) then
        print("Turn2DedicationTrigger: ❌ 拒绝无效的开发者符文消息");
        return;
    end

    local pPlayer = Players[playerID];
    if not pPlayer then
        print("Turn2DedicationTrigger: ❌ 开发者应用：无效玩家 " .. tostring(playerID));
        T2D_SetDeveloperAck(playerID, nonce, runeID, "ERROR");
        return;
    end

    print("╔══════════════════════════════════════════════════════════");
    print("║ 开发者模式：立即应用符文 ID=" .. runeID .. " 阶段=" .. stage .. " 稀有度=" .. rarityCode);
    print("╚══════════════════════════════════════════════════════════");

    if PlayerHasDedication(playerID, runeID) then
        print("Turn2DedicationTrigger: ⓘ 开发者模式：符文 " .. runeID .. " 已拥有，跳过重复应用");
        T2D_SetDeveloperAck(playerID, nonce, runeID, "DUPLICATE");
        return;
    end

    local conflictingRuneID = T2D_GetConflictingRune(playerID, runeID);
    if conflictingRuneID then
        T2D_SetDeveloperAck(playerID, nonce, runeID, "CONFLICT");
        print("Turn2DedicationTrigger: ❌ 开发者模式拒绝符文 " .. tostring(runeID)
            .. "：与已拥有符文 " .. tostring(conflictingRuneID) .. " 互斥");
        return;
    end

    local devKey = "Turn2Dedication_DevRune_P" .. playerID .. "_R" .. runeID;
    local rarityKey = "Turn2Dedication_DevRuneRarity_P" .. playerID .. "_R" .. runeID;
    -- 先写临时拥有状态，让任务型检查和 Apply* 内部的 PlayerHasDedication 可见。
    Game.SetProperty(devKey, stage);
    Game.SetProperty(rarityKey, rarityCode);

    local okApply, result = pcall(function()
        return ApplyDedicationEffect(pPlayer, runeID, stage, rarityCode);
    end);
    if not okApply then
        Game.SetProperty(devKey, nil);
        Game.SetProperty(rarityKey, nil);
        T2D_SetDeveloperAck(playerID, nonce, runeID, "ERROR");
        print("Turn2DedicationTrigger: ❌ 开发者模式应用失败，可重试: " .. tostring(result));
        return;
    end

    if result == "CONFLICT" then
        Game.SetProperty(devKey, nil);
        Game.SetProperty(rarityKey, nil);
        T2D_SetDeveloperAck(playerID, nonce, runeID, "CONFLICT");
        print("Turn2DedicationTrigger: ❌ 开发者模式应用阶段检测到互斥，未写入拥有状态");
        return;
    end

    if result == "RETRY" then
        Game.SetProperty(devKey, nil);
        Game.SetProperty(rarityKey, nil);
        T2D_SetDeveloperAck(playerID, nonce, runeID, "RETRY");
        print("Turn2DedicationTrigger: ⓘ 开发者模式应用等待前置条件，未写入拥有状态，可重试");
        return;
    end

    local status = result == "DEFERRED" and "DEFERRED" or "APPLIED";
    T2D_SetDeveloperAck(playerID, nonce, runeID, status);
    print("Turn2DedicationTrigger: ✓ 开发者模式已获得符文 " .. runeID .. "（" .. status .. "）");
end

if Events and Events.MultiplayerChat then
    Events.MultiplayerChat.Add(OnDeveloperModeApplyRune);
    Events.MultiplayerChat.Add(OnPrismatic144AuthorizeTopUp);
    print("Turn2DedicationTrigger: ✓ 已注册开发者模式监听（端口655010）");
    print("Turn2DedicationTrigger: ✓ 已注册一使定邦授权监听（端口655013）");
end

if GameEvents and GameEvents.BuildingConstructed then
    GameEvents.BuildingConstructed.Add(OnWorkshopLecternBuildingConstructed);
    print("Turn2DedicationTrigger: ✓ 已注册工坊讲席建筑完成监听");
end

function OnTurn2DedicationInfluenceToken(majorID, minorID, amount)
    local ok71, error71 = pcall(OnGold71InfluenceToken, majorID, minorID, amount);
    if not ok71 then
        print("Turn2DedicationTrigger: ⚠ 求知使团使者事件失败，其他使者机制继续: "
            .. tostring(error71));
    end
    if T2D_OnPrismatic144InfluenceToken then
        local ok144, error144 = pcall(T2D_OnPrismatic144InfluenceToken, majorID, minorID, amount);
        if not ok144 then
            print("Turn2DedicationTrigger: ⚠ 一使定邦使者事件失败: " .. tostring(error144));
        end
    end
end

if GameEvents and GameEvents.OnPlayerGaveInfluenceToken then
    GameEvents.OnPlayerGaveInfluenceToken.Add(OnTurn2DedicationInfluenceToken);
    print("Turn2DedicationTrigger: ✓ 已注册求知使团/一使定邦使者监听");
end

if GameEvents and GameEvents.PlayerTurnStartComplete then
    GameEvents.PlayerTurnStartComplete.Add(OnGold80PlayerTurnStartComplete);
    print("Turn2DedicationTrigger: ✓ 已注册竭泽而渔玩家回合完成监听");
else
    g_T2DGold80UseTurnStartedFallback = true;
    print("Turn2DedicationTrigger: ⚠ 缺少 PlayerTurnStartComplete，竭泽而渔改用回合开始监听");
end

-- 138/139 use only existing gameplay events; every callback remains
-- authoritative and pcall-isolated inside its wrapper.
if Events and Events.UnitFortificationChanged then
    Events.UnitFortificationChanged.Add(T2D_OnPrismatic138UnitStateChanged);
end
if Events and Events.UnitMoved then
    Events.UnitMoved.Add(T2D_OnPrismatic138UnitStateChanged);
end
if Events and Events.UnitAddedToMap then
    Events.UnitAddedToMap.Add(T2D_OnPrismatic138UnitStateChanged);
end
if Events and Events.UnitRemovedFromMap then
    Events.UnitRemovedFromMap.Add(T2D_OnPrismatic138UnitStateChanged);
end
if Events and Events.CityProductionChanged then
    Events.CityProductionChanged.Add(T2D_OnPrismatic139ProductionChanged);
end
if Events and Events.CityProductionQueueChanged then
    Events.CityProductionQueueChanged.Add(T2D_OnPrismatic139ProductionChanged);
end

