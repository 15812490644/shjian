"""Generate exact-size, antialiased rune frames for the in-game codex UI.

The game renders these textures at their native size.  Drawing at 4x and
downsampling before DXT5 export avoids enlarging Civ VI's 56 px circle rim,
which was the source of the visible stair-stepping around rune icons.
"""

from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "Textures" / "UI"
SCALE = 4


def _ellipse_box(size: int, inset: float) -> tuple[int, int, int, int]:
    value = round(inset * SCALE)
    edge = size * SCALE - 1 - value
    return value, value, edge, edge


def _downsample(image: Image.Image, size: int) -> Image.Image:
    return image.resize((size, size), Image.Resampling.LANCZOS)


def make_ring(size: int = 80) -> Image.Image:
    canvas = Image.new("RGBA", (size * SCALE, size * SCALE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)

    # Dark outer keyline remains neutral when the white frame is rarity-tinted.
    draw.ellipse(
        _ellipse_box(size, 1.6),
        outline=(8, 17, 25, 215),
        width=round(2.0 * SCALE),
    )
    # Main metallic band.
    draw.ellipse(
        _ellipse_box(size, 3.6),
        outline=(255, 255, 255, 245),
        width=round(2.4 * SCALE),
    )
    # Recessed inner edge adds definition without increasing visual thickness.
    draw.ellipse(
        _ellipse_box(size, 6.5),
        outline=(18, 31, 42, 210),
        width=round(1.4 * SCALE),
    )
    draw.ellipse(
        _ellipse_box(size, 7.7),
        outline=(255, 255, 255, 105),
        width=round(0.8 * SCALE),
    )

    # Restrained top-left highlight for a Civ VI-like embossed finish.
    highlight_box = _ellipse_box(size, 4.7)
    draw.arc(
        highlight_box,
        start=205,
        end=330,
        fill=(255, 255, 255, 170),
        width=round(1.0 * SCALE),
    )
    return _downsample(canvas, size)


def make_glow(size: int = 88) -> Image.Image:
    canvas = Image.new("RGBA", (size * SCALE, size * SCALE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    draw.ellipse(
        _ellipse_box(size, 5.5),
        outline=(255, 255, 255, 220),
        width=round(3.0 * SCALE),
    )
    canvas = canvas.filter(ImageFilter.GaussianBlur(radius=2.4 * SCALE))
    return _downsample(canvas, size)


def make_backing(size: int = 82) -> Image.Image:
    """Create a native-size dark inset so the enlarged icon is never cropped."""
    canvas = Image.new("RGBA", (size * SCALE, size * SCALE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    draw.ellipse(
        _ellipse_box(size, 2.0),
        fill=(11, 29, 46, 252),
        outline=(4, 11, 19, 255),
        width=round(1.5 * SCALE),
    )
    draw.arc(
        _ellipse_box(size, 4.0),
        start=205,
        end=330,
        fill=(62, 102, 130, 150),
        width=round(1.2 * SCALE),
    )
    return _downsample(canvas, size)


def save_dds(image: Image.Image, filename: str) -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    image.save(OUTPUT / filename, format="DDS", pixel_format="DXT5")


def main() -> None:
    save_dds(make_ring(), "T2D_RuneRing_80.dds")
    save_dds(make_glow(), "T2D_RuneGlow_88.dds")
    save_dds(make_ring(96), "T2D_RuneRing_96.dds")
    save_dds(make_glow(106), "T2D_RuneGlow_106.dds")
    save_dds(make_backing(82), "T2D_RuneBacking_82.dds")
    print(f"Generated codex frame textures in {OUTPUT}")


if __name__ == "__main__":
    main()
