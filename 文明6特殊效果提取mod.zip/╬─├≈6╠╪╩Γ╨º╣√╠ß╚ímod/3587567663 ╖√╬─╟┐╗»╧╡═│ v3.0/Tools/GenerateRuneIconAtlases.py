"""Build the Civilization VI icon atlases used by Turn2Dedication runes.

Rune N always occupies atlas index N - 1.  Keeping the index stable makes it
easy to audit the registry and deliberately leaves blank cells for retired IDs.
The codex launch icon uses index 145, immediately after rune 145.
"""

from __future__ import annotations

import re
from pathlib import Path
from xml.etree import ElementTree as ET

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIR = ROOT / "Textures" / "RuneIcons" / "Generated" / "ByRune"
CODEX_SOURCE = ROOT / "Textures" / "RuneIcons" / "Generated" / "rune_codex_entrance.png"
OUTPUT_DIR = ROOT / "Textures" / "RuneIcons" / "Atlases"
XML_OUTPUT = ROOT / "Data" / "Turn2Dedication_RuneIcons.xml"

SIZES = (32, 40, 52, 64, 68, 80, 128)
ATLAS_NAME = "ICON_ATLAS_T2D_RUNES"
COLS = 16
ROWS = 10
CODEX_INDEX = 145
RUNE_FILE_RE = re.compile(r"T2D_RUNE_(\d{3})\.png$")


def rune_sources() -> dict[int, Path]:
    sources: dict[int, Path] = {}
    for path in sorted(SOURCE_DIR.glob("T2D_RUNE_*.png")):
        match = RUNE_FILE_RE.fullmatch(path.name)
        if not match:
            continue
        rune_id = int(match.group(1))
        if rune_id in sources:
            raise ValueError(f"Duplicate rune icon ID: {rune_id}")
        if not 1 <= rune_id <= 145:
            raise ValueError(f"Rune icon ID outside supported range: {rune_id}")
        sources[rune_id] = path
    if not sources:
        raise ValueError(f"No rune sources found in {SOURCE_DIR}")
    return sources


def load_rgba(path: Path) -> Image.Image:
    image = Image.open(path).convert("RGBA")
    if image.size != (512, 512):
        raise ValueError(f"Expected a 512x512 source: {path} ({image.size})")
    if image.getbbox() is None:
        raise ValueError(f"Source is fully transparent: {path}")
    return image


def build_atlases(sources: dict[int, Path]) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    loaded = {rune_id: load_rgba(path) for rune_id, path in sources.items()}
    codex = load_rgba(CODEX_SOURCE)

    for size in SIZES:
        atlas = Image.new("RGBA", (COLS * size, ROWS * size), (0, 0, 0, 0))
        for rune_id, source in loaded.items():
            index = rune_id - 1
            x = (index % COLS) * size
            y = (index // COLS) * size
            atlas.alpha_composite(source.resize((size, size), Image.Resampling.LANCZOS), (x, y))

        x = (CODEX_INDEX % COLS) * size
        y = (CODEX_INDEX // COLS) * size
        atlas.alpha_composite(codex.resize((size, size), Image.Resampling.LANCZOS), (x, y))

        # Keep the atlas in uncompressed 32-bit RGBA form.  Civilization VI's
        # UI samples these small icon cells directly, so preserving the source
        # pixels avoids BC3/DXT5 block artifacts around fine transparent edges.
        output = OUTPUT_DIR / f"T2D_RuneAtlas_{size}.dds"
        atlas.save(output, format="DDS")


def indent(element: ET.Element, level: int = 0) -> None:
    whitespace = "\n" + "  " * level
    if len(element):
        if not element.text or not element.text.strip():
            element.text = whitespace + "  "
        for child in element:
            indent(child, level + 1)
        if not child.tail or not child.tail.strip():
            child.tail = whitespace
    if level and (not element.tail or not element.tail.strip()):
        element.tail = whitespace


def build_icon_database(sources: dict[int, Path]) -> None:
    root = ET.Element("GameInfo")
    atlases = ET.SubElement(root, "IconTextureAtlases")
    for size in SIZES:
        ET.SubElement(
            atlases,
            "Row",
            {
                "Name": ATLAS_NAME,
                "IconSize": str(size),
                "IconsPerRow": str(COLS),
                "IconsPerColumn": str(ROWS),
                "Filename": f"T2D_RuneAtlas_{size}.dds",
            },
        )

    definitions = ET.SubElement(root, "IconDefinitions")
    for rune_id in sorted(sources):
        ET.SubElement(
            definitions,
            "Row",
            {
                "Name": f"ICON_T2D_RUNE_{rune_id:03d}",
                "Atlas": ATLAS_NAME,
                "Index": str(rune_id - 1),
            },
        )
    ET.SubElement(
        definitions,
        "Row",
        {
            "Name": "ICON_T2D_RUNE_CODEX",
            "Atlas": ATLAS_NAME,
            "Index": str(CODEX_INDEX),
        },
    )

    indent(root)
    payload = ET.tostring(root, encoding="unicode", short_empty_elements=True)
    XML_OUTPUT.write_text('<?xml version="1.0" encoding="utf-8"?>\n' + payload + "\n", encoding="utf-8")


def main() -> None:
    sources = rune_sources()
    build_atlases(sources)
    build_icon_database(sources)
    print(f"Generated {len(SIZES)} atlases and {len(sources) + 1} icon definitions.")


if __name__ == "__main__":
    main()
