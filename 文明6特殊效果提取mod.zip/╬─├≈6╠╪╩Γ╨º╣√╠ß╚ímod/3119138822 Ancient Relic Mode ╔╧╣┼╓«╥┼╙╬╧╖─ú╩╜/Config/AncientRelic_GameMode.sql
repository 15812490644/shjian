-- GameMode
-- Author: Lazire
-- DateCreated: 12/18/2023 9:39:25 PM
--------------------------------------------------------------
INSERT INTO GameModeItems
(GameModeType,
Name,
Description,
Icon,
Portrait,
Background,
SortIndex)
VALUES
('GAMEMODE_ANCIENT_RELIC',
'LOC_GAMEMODE_ANCIENT_RELIC_NAME',
'LOC_GAMEMODE_ANCIENT_RELIC_DESCRIPTION',
'ICON_GAMEMODE_ANCIENT_RELIC',
'IMG_GAMEMODE_ANCIENT_RELIC_FORE',
'IMG_GAMEMODE_ANCIENT_RELIC_BACK',
233);

INSERT INTO Parameters
(ParameterId,
Name,
Description,
Domain,
DefaultValue,
ConfigurationGroup,
ConfigurationId,
NameArrayConfigurationId,
GroupId,
SortIndex)
VALUES
('GAMEMODE_ANCIENT_RELIC',
'LOC_GAMEMODE_ANCIENT_RELIC_NAME',
'LOC_GAMEMODE_ANCIENT_RELIC_DESCRIPTION',
'bool',
1,
'Game',
'GAMEMODE_ANCIENT_RELIC',
'GAMEMODES_ENABLED_NAMES',
'GameModes',
233);

INSERT INTO ParameterDependencies
(ParameterId,
ConfigurationGroup,
ConfigurationId,
Operator,
ConfigurationValue)
VALUES
('GAMEMODE_ANCIENT_RELIC',
'Game',
'WORLD_BUILDER',
'NotEquals',
1);
