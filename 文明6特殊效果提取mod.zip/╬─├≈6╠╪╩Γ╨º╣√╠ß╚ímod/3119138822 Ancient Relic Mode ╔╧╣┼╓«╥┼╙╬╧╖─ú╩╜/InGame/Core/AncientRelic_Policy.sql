-- AncientRelic_Policy
-- Author: Lazire
-- DateCreated: 12/18/2023 10:53:35 PM
--------------------------------------------------------------
-- �޴������߿����Ը��������������԰�������Ч��
/*INSERT INTO Types
(Type,				Kind)
VALUES
('POLICY_AR_1',		'KIND_POLICY'),
('POLICY_AR_2',		'KIND_POLICY');

INSERT INTO Policies
(PolicyType,		Name,					Description,			PrereqCivic,			GovernmentSlotType)
VALUES
('POLICY_AR_1',		'LOC_POLICY_AR_1_NAME',	'LOC_POLICY_AR_1_DESC',	'CIVIC_CODE_OF_LAWS',	'SLOT_WILDCARD'),
('POLICY_AR_2',		'LOC_POLICY_AR_2_NAME',	'LOC_POLICY_AR_2_DESC',	'CIVIC_CODE_OF_LAWS',	'SLOT_WILDCARD');

INSERT INTO Policies_XP1
(PolicyType,		MinimumGameEra,			MaximumGameEra)
VALUES
('POLICY_AR_1',		'ERA_CLASSICAL',		'ERA_RENAISSANCE'),
('POLICY_AR_2',		'ERA_INDUSTRIAL',		'ERA_FUTURE');

INSERT INTO PolicyModifiers
(PolicyType,		ModifierId)
VALUES
('POLICY_AR_1',		'MODFEAT_POLICY_AR_1'),
('POLICY_AR_2',		'MODFEAT_POLICY_AR_2');

INSERT INTO Modifiers
(ModifierId,			ModifierType)
VALUES
('MODFEAT_POLICY_AR_1',	'MODIFIER_PLAYER_ADJUST_PROPERTY'),
('MODFEAT_POLICY_AR_2',	'MODIFIER_PLAYER_ADJUST_PROPERTY');

INSERT INTO ModifierArguments
(ModifierId,			Name,			Value)
VALUES
('MODFEAT_POLICY_AR_1',	'Key',			'SSSC_ACTIVE_NUM_ALLOWED'),
('MODFEAT_POLICY_AR_1',	'Amount',		1),
('MODFEAT_POLICY_AR_2',	'Key',			'SSSC_ACTIVE_NUM_ALLOWED'),
('MODFEAT_POLICY_AR_2',	'Amount',		2);*/