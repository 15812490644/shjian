-- StellarisCollector_Relic_ActiveModifier_Internal_Building
-- Author: Lazire
-- DateCreated: 12/3/2023 11:26:59 PM
--------------------------------------------------------------
-- ����ļ�Ӧ����������ȷ����ȡ����Ч��

INSERT INTO Types
(Type,								Kind)
SELECT DISTINCT
'BUILDING_SSSC_'||RelicType,		'KIND_BUILDING'
FROM SSSC_Relic;

INSERT INTO Buildings
(BuildingType,				
Name,																							
Cost,		
InternalOnly,
PrereqDistrict)
SELECT DISTINCT
'BUILDING_SSSC_'||RelicType,
Name,
1,
1,
'DISTRICT_CITY_CENTER'
FROM SSSC_Relic;

INSERT INTO BuildingModifiers
(BuildingType,							ModifierId)
SELECT 
'BUILDING_SSSC_'||RelicType,			ModifierId
FROM SSSC_Relic_ActiveModifier;