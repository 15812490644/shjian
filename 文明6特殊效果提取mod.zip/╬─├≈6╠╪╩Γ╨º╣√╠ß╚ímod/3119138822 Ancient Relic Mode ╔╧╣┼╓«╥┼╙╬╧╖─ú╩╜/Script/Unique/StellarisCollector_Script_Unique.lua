-- StellarisCollector_Script_Unique
-- Author: Lazire
-- DateCreated: 12/26/2023 2:56:20 PM
--------------------------------------------------------------
print('SC_Unique loaded');

-- ===========================================================================
--  Unique Relic
-- ===========================================================================
function Pen_Kjerag_ReligionFounded(playerID)
	local pPlayer = Players[playerID]
	local ePro = pPlayer:GetProperty('PROPERTY_UR_PEN_KJERAG') or 0;
	if ePro > 0 then
		print('Kjerag add belief')
		pPlayer:GetReligion():ChangeNumBeliefsEarned(2);
	end
end







-- ===========================================================================
function Initialize_XP1()
	Events.ReligionFounded.Add( Pen_Kjerag_ReligionFounded )
end

Events.LoadGameViewStateDone.Add(Initialize_XP1);