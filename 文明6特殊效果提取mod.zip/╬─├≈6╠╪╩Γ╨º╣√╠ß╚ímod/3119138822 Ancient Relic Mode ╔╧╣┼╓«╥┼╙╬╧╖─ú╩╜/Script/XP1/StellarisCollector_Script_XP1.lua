-- StellarisCollector_Script_XP1
-- Author: Lazire
-- DateCreated: 12/19/2023 4:33:42 PM
--------------------------------------------------------------
print('SC_XP1 loaded')


-- ===========================================================================
--  For UI
-- ===========================================================================
function TidyupTraits()
	local tmpTraits = {}
	for row in GameInfo.CivilizationTraits() do
		if GameInfo.Civilizations[row.CivilizationType].StartingCivilizationLevelType == 'CIVILIZATION_LEVEL_FULL_CIV' then
			table.insert(tmpTraits, row.TraitType)
		end
	end
	for row in GameInfo.LeaderTraits() do
		if GameInfo.Leaders[row.LeaderType].InheritFrom == 'LEADER_DEFAULT' then
			table.insert(tmpTraits, row.TraitType)
		end
	end
	local sTraits = Game:GetProperty('SC_EA_Traits') or {};
	if #sTraits ~= 0 then return; end
	for i, sTrait in ipairs(tmpTraits) do
		local b = true;
		if b then 
			for row in GameInfo.Improvements() do
				if row.TraitType == sTrait then
					b = false
					break
				end
			end
		end
		if b then 
			for row in GameInfo.Units() do
				if row.TraitType == sTrait then
					b = false
					break
				end
			end
		end
		if b then 
			for row in GameInfo.Buildings() do
				if row.TraitType == sTrait then
					b = false
					break
				end
			end
		end
		if b then 
			for row in GameInfo.Districts() do
				if row.TraitType == sTrait then
					b = false
					break
				end
			end
		end
		if b then 
			for i, PlayerID in ipairs(PlayerManager.GetAliveMajorIDs()) do
				if HasTrait(sTrait, PlayerID) then
					b = false
					break
				end
			end
		end
		if b then
			if GameInfo.Traits[sTrait].Name and GameInfo.Traits[sTrait].Description then
				Item = {}
				Item.Trait = sTrait
				Item.RandNum = Game.GetRandNum(#tmpTraits)
				table.insert(sTraits, Item)
			end
		end
	end
	table.sort(sTraits, function(a, b) return a.RandNum > b.RandNum; end);
	Game:SetProperty('SC_EA_Traits', sTraits);
end

function SC_ExtraAbility_Confirm(playerID, param)
	pPlayer = Players[playerID]
	row_Trait = param.row_Trait
	for row in GameInfo.TraitModifiers() do
		if row.TraitType == row_Trait.TraitType then
			pPlayer:AttachModifierByID(row.ModifierId)
		end
	end
	local ePro = pPlayer:GetProperty('PROPERTY_SC_EXTRA_ABILITY') or 0;
	pPlayer:SetProperty('PROPERTY_SC_EXTRA_ABILITY', ePro-1)
	local tPro = pPlayer:GetProperty('PROPERTY_SC_EXTRA_ABILITY_ATTACHED') or {}
	table.insert(tPro, row_Trait.TraitType)
	pPlayer:SetProperty('PROPERTY_SC_EXTRA_ABILITY_ATTACHED', tPro)
	
	local sTraits = Game:GetProperty('SC_EA_Traits')
	for i, Item in ipairs(sTraits) do
		if Item.Trait == row_Trait.TraitType then	
			print('remove',Item.Trait)
			table.remove(sTraits, i)
			Game:SetProperty('SC_EA_Traits', EA_Shuffle(sTraits));
			return
		end
	end
end

function EA_Shuffle(sTraits:table)
	for i, Item in ipairs(sTraits) do
		Item.RandNum = Game.GetRandNum(#sTraits)
	end
	table.sort(sTraits, function(a, b) return a.RandNum > b.RandNum; end);
	return sTraits
end
-- ===========================================================================
--  Relic Ability 
-- ===========================================================================
function CelestialTear_BuildingConstructed(playerID, cityID, buildingID, plotID, bOriginalConstruction)
	if GameInfo.Buildings[buildingID].BuildingType ~= 'BUILDING_SSSC_RELIC_CELESTIAL_TEAR' then return; end
	local ActivationsAllowed:number = Players[playerID]:GetProperty('SSSC_ACTIVE_NUM_ALLOWED') or 0;
	if ActivationsAllowed > 0 then
		SSSC_PlayerGrantRandomRelic(playerID)
	end
end

function Whiteflower_BuildingConstructed(playerID, cityID, buildingID, plotID, bOriginalConstruction)
	if GameInfo.Buildings[buildingID].BuildingType ~= 'BUILDING_SSSC_RELIC_AKN_WHITEFLOWER' then return; end
	local tPlot			= Map.GetPlotByIndex(plotID)
	local iEra			= Game.GetEras():GetCurrentEra()
	local pPlayer 		= Players[playerID];
	local Units 		= DB.Query("SELECT * FROM Units")
	local WF_Val		= 5
	local i 			= 0
	repeat
		local RandNum = Game.GetRandNum(#Units) + 1
		if Units[RandNum].Domain == 'DOMAIN_LAND' 
		and Units[RandNum].ReligiousStrength == 0 
		and not Units[RandNum].MakeTradeRoute 
		and not Units[RandNum].Spy 
		and CheckIsGreatPerson(Units[RandNum].UnitType)
		then
			if (Units[RandNum].PrereqTech and GameInfo.Eras[GameInfo.Technologies[Units[RandNum].PrereqTech].EraType].Index <= iEra + 1) 
			or (Units[RandNum].PrereqCivic and GameInfo.Eras[GameInfo.Civics[Units[RandNum].PrereqCivic].EraType].Index <= iEra + 1) 
			or (not Units[RandNum].PrereqTech and not Units[RandNum].PrereqCivic) then
				--print(Units[RandNum].UnitType)
				UnitManager.InitUnit(playerID, Units[RandNum].UnitType, tPlot:GetX(), tPlot:GetY())
				i = i + 1
			end
		end
	until( i == WF_Val )
end
function CheckIsGreatPerson(UnitType)
	for row in GameInfo.GreatPersonClasses() do
		if row.UnitType == UnitType then
			return false
		end
	end
	return true
end

-- ===========================================================================
function Initialize_XP1()
	Events.LoadGameViewStateDone.Add( TidyupTraits );
	-- Relic Ability
	GameEvents.BuildingConstructed.Add( CelestialTear_BuildingConstructed );
	GameEvents.BuildingConstructed.Add( Whiteflower_BuildingConstructed );
	
	-- Extra Ability
	GameEvents.SC_ExtraAbility_Confirm.Add( SC_ExtraAbility_Confirm );
end

Initialize_XP1();