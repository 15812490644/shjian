-- StellarisCollector_CivilopediaPage
-- Author: Lazire
-- DateCreated: 12/11/2023 11:59:07 PM
--------------------------------------------------------------
print('StellarisCollector_CivilopediaPage Load')

PageLayouts["RELICInfo" ] = function(page)
	local sectionId = page.SectionId;
	local pageId = page.PageId;
	--print(sectionId)
	--print(pageId)
	
	SetPageHeader(page.Title);
	SetPageSubHeader(page.Subtitle);
	--print('ICON_'..pageId..'_100')
	AddPortrait('ICON_'..pageId);
	
	local chapters = GetPageChapters(page.PageLayoutId);
	for i, chapter in ipairs(chapters) do
		local chapterId = chapter.ChapterId;
		local chapter_header = 'LOC_CIVILOPEDIA_RELIC_'..chapterId
		local chapter_body = 'LOC_'..pageId..'_'..chapterId
		-- Do not show chapter header for the first chapter if it matches the page's title or subtitle.
		if(chapter_header == nil or i == 1 and (Locale.Lookup(chapter_header) == page.Title) or (Locale.Lookup(chapter_header) == page.Subtitle)) then
			AddParagraphs(chapter_body);
		else
			AddChapter(chapter_header, chapter_body);
		end
	end
end