-- StellarisCollector_Panel
-- Author: Lazire
-- DateCreated: 12/4/2023 11:51:22 PM
--------------------------------------------------------------
-- ����дUI����ȥ��
-- �����Ż���û��Ҫ�����ܾ���
include("GameCapabilities");
include("InstanceManager");
include("ModalScreen_PlayerYieldsHelper");
GameEvents = ExposedMembers.GameEvents;

local debug						=	false;

local m_SpeedMul 				= 	GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;
local m_IsXP1Active:boolean 	=	Modding.IsModActive("1B28771A-C749-434B-9053-D1380C553DE9");
local m_IsXP2Active:boolean 	= 	Modding.IsModActive("4873eb62-8ccc-4574-b784-dda455e74e68");
local m_LocalPlayer				= 	Game.GetLocalPlayer();
local m_SelectedRelic			=	{};
local m_numSelected				=	0;
local m_RelicActivedIM:table 	=	InstanceManager:new("SSSCRelicInstance", "SSSCRelicContainer", Controls.SSSCRelicActivedStack);
local m_RelicIM:table 			= 	InstanceManager:new("SSSCRelicInstance", "SSSCRelicContainer", Controls.SSSCRelicStack);
-- ===========================================================================
function RefreshRelics()	
	Controls.ConfirmSelected:SetDisabled(true)
	m_RelicActivedIM:DestroyInstances()
	m_RelicIM:DestroyInstances()
	m_numSelected				=	0;
	m_SelectedRelic				=	{}
	local LocalRelics			= 	Players[m_LocalPlayer]:GetProperty('SSSC_Relic') or {};
	local ActivedRelics			= 	Players[m_LocalPlayer]:GetProperty('SSSC_ActivedRelics') or {};
	local ActivationsAllowed	= 	Players[m_LocalPlayer]:GetProperty('SSSC_ACTIVE_NUM_ALLOWED') or 1;
	Controls.SSSCAllowedActived:SetText(#ActivedRelics.."/"..ActivationsAllowed)
	for i, RelicActived in ipairs(ActivedRelics) do
		row = GameInfo.SSSC_Relic[RelicActived]
		AddRelicActivedInst(row)
		--AddRelicInst(row , 'Actived')
	end
	for i, RelicAcquired in ipairs(LocalRelics) do
		local b = true
		for j, RelicActived in ipairs(ActivedRelics) do
			if RelicAcquired == RelicActived then
				b = false
			end
		end
		if b then
			row = GameInfo.SSSC_Relic[RelicAcquired]
			AddRelicInst(row , 'Acquired')
		end
	end
	for row in GameInfo.SSSC_Relic() do
		m_SelectedRelic[row.Index] = false
		local b = true
		for i, RelicActived in ipairs(ActivedRelics) do
			if RelicActived == row.RelicType then
				b = false
				break
			end
		end
		for i, RelicAcquired in ipairs(LocalRelics) do
			if RelicAcquired == row.RelicType then
				b = false
				break
			end
		end
		if b then
			AddRelicInst(row, 'Unknown')
		end
	end
	local ePro = Players[m_LocalPlayer]:GetProperty('PROPERTY_SC_EXTRA_ABILITY') or 0;
	local tPro = Players[m_LocalPlayer]:GetProperty('PROPERTY_SC_EXTRA_ABILITY_ATTACHED') or {};
	if ePro > 0 or #tPro > 0 then
		Controls.SC_ExtraAbility_Launch:SetHide(false)
		Controls.SC_ExtraAbility_Launch:RegisterCallback(Mouse.eLClick,
		function()
			LuaEvents.SC_ExtraAb_Button_Toggle()
		end)
	end
end

function AddRelicActivedInst(row)	
	local new = m_RelicActivedIM:GetInstance()
	new.RelicHightlightIcon:SetTexture(IconManager:FindIconAtlas('ICON_'..row.RelicType, 100))
	new.RelicName:SetText(Locale.Lookup(row.Name))
	local RelicAbilityText = ""
	RelicAbilityText = Locale.Lookup(row.Description)
	RelicAbilityText = RelicAbilityText..'[NEWLINE]'..Locale.Lookup('LOC_SSSC_PASSIVE')..'[NEWLINE]'..Locale.Lookup(row.PassiveDesc)
	RelicAbilityText = RelicAbilityText..'[NEWLINE]'..Locale.Lookup('LOC_SSSC_ACTIVE')..'[NEWLINE]'..Locale.Lookup(row.ActiveDesc)
	new.RelicHightlightIcon:SetToolTipString(RelicAbilityText)
	local turneft:number = Game:GetProperty('SSSC_RELIC_TURN_LEFT'..row.RelicType) or 0
	new.TurnLeftIcon:SetText('[ICON_TURN]')
	new.TurnLeft:SetText(turneft)
end

function AddRelicInst(row, state)	
	local b_IsActive = false
	local new = m_RelicIM:GetInstance()
	local ActivedRelics	=	Players[m_LocalPlayer]:GetProperty('SSSC_ActivedRelics') or {};
	local ActivationsAllowed:number = Players[m_LocalPlayer]:GetProperty('SSSC_ACTIVE_NUM_ALLOWED') or 1;
	if state == 'Acquired' then
		new.RelicHightlightIcon:SetTexture(IconManager:FindIconAtlas('ICON_'..row.RelicType, 100))
		new.RelicName:SetText(Locale.Lookup(row.Name))
		local RelicAbilityText = ""
		RelicAbilityText = Locale.Lookup(row.Description)
		RelicAbilityText = RelicAbilityText..'[NEWLINE]'..Locale.Lookup('LOC_SSSC_PASSIVE')..'[NEWLINE]'..Locale.Lookup(row.PassiveDesc)
		RelicAbilityText = RelicAbilityText..'[NEWLINE]'..Locale.Lookup('LOC_SSSC_ACTIVE')..'[NEWLINE]'..Locale.Lookup(row.ActiveDesc)
		RelicAbilityText = RelicAbilityText..'[NEWLINE]'..'[ICON_TURN]'..math.ceil(row.Last * m_SpeedMul)
		new.RelicHightlightIcon:SetToolTipString(RelicAbilityText)
	else
		new.RelicIcon:SetTexture(IconManager:FindIconAtlas('ICON_'..row.RelicType, 100))
		new.RelicHightlightIcon:SetToolTipString(Locale.Lookup('LOC_NOT_FOUNDED'))
	end
	if state == 'Acquired' then 
		for i, relic in ipairs(ActivedRelics) do
			if relic == row.RelicType then
				b_IsActive = true
				break
			end
		end
		if not b_IsActive and ActivationsAllowed > #ActivedRelics then	
			new.RelicSelect:SetSelected(false);
			new.DefaultBG:SetAlpha(1)
			new.RelicSelect:RegisterCallback(Mouse.eLClick,
			function()
				OnRelicToActiveSelected(row, new)
			end)
		else
			new.RelicSelect:SetSelected(true);
		end
	end
end

function OnRelicToActiveSelected(row, inst)
	local ActivationsAllowed:number = Players[m_LocalPlayer]:GetProperty('SSSC_ACTIVE_NUM_ALLOWED') or 1;
	local ActivedRelics:table	=	Players[m_LocalPlayer]:GetProperty('SSSC_ActivedRelics') or {};
	local ActiveAllowedLeft:number = ActivationsAllowed - #ActivedRelics
	
	if not inst.RelicSelect:IsSelected() then
		m_SelectedRelic[row.Index] = true
		inst.RelicSelect:SetSelected(true)
		inst.DefaultBG:SetAlpha(3)
		m_numSelected = m_numSelected + 1
	else
		m_SelectedRelic[row.Index] = false
		inst.RelicSelect:SetSelected(false)
		inst.DefaultBG:SetAlpha(1)
		m_numSelected = m_numSelected - 1
	end
	
	if m_numSelected > ActiveAllowedLeft or m_numSelected == 0 then
		Controls.ConfirmSelected:SetDisabled(true)
	else
		Controls.ConfirmSelected:SetDisabled(false)
	end
end

function OnConfirmSelected()	
	local ActivedRelicNum = 0;
	local LocalRelics = Players[m_LocalPlayer]:GetProperty('SSSC_Relic') or {};
	for i, Relic in ipairs(LocalRelics) do
		RelicInfo = GameInfo.SSSC_Relic[Relic]
		if m_SelectedRelic[RelicInfo.Index] == true then
			local kParameters = {}
			kParameters.OnStart = "SSSC_RelicActive";
			kParameters.RelicIndex = RelicInfo.Index;
			UI.RequestPlayerOperation(m_LocalPlayer, PlayerOperations.EXECUTE_SCRIPT, kParameters)
			Network.BroadcastPlayerInfo();
			ActivedRelicNum = ActivedRelicNum + 1;
		end
	end
	print('Confirmed')
	UI.PlaySound("UI_GREAT_WORKS_BONUS_ACHIEVED");
	Close()
	LuaEvents.SSSC_Confirmed(m_LocalPlayer, ActivedRelicNum)
end

-- ===========================================================================
function OnInit( isReload:boolean )
	if isReload then
        Open()
    end
end

function OnInputHandler(pInputStruct:table)
	local uiMsg = pInputStruct:GetMessageType();
	if uiMsg == KeyEvents.KeyUp and pInputStruct:GetKey() == Keys.VK_ESCAPE then
		if not ContextPtr:IsHidden() then
			Close();
		end
		return true;
	end
	return false;
end

-- ===========================================================================
function OnTogglePanel()
	if ContextPtr:IsHidden() then
		Open()
	else
		Close()
	end
end

function Open()
	if (Game.GetLocalPlayer() == -1) then
		return
	end
	RefreshRelics();
	ContextPtr:SetHide(false);
	
	if not UIManager:IsInPopupQueue(ContextPtr) then
        local kParameters = {};
        kParameters.RenderAtCurrentParent = true;
        kParameters.InputAtCurrentParent = true;
        kParameters.AlwaysVisibleInQueue = true;
        UIManager:QueuePopup(ContextPtr, PopupPriority.Low, kParameters);
        -- Change our parent to be 'Screens' so the navigational hooks draw on top of it.
        ContextPtr:ChangeParent(ContextPtr:LookUpControl("/InGame/Screens"));
        UI.PlaySound("UI_Screen_Open");
        --LuaEvents.QDDealPopup_Opened();
    end
	Controls.ScreenAnimIn:SetToBeginning();
	Controls.ScreenAnimIn:Play();
	LuaEvents.SSSC_OpenRelicPanel();
	--LuaEvents.TradeRouteChooser_CloseIfPopups();
	--LuaEvents.LaunchBar_CloseChoosers();
end

function Close()
	RefreshRelics();
	UIManager:DequeuePopup(ContextPtr);
	ContextPtr:SetHide(true);
	LuaEvents.SSSC_CloseRelicPanel()
end

function CloseOtherPanels()
    LuaEvents.LaunchBar_CloseTechTree()
    LuaEvents.LaunchBar_CloseCivicsTree()
    LuaEvents.LaunchBar_CloseGovernmentPanel()
    LuaEvents.LaunchBar_CloseReligionPanel()
    LuaEvents.LaunchBar_CloseGreatPeoplePopup()
    LuaEvents.LaunchBar_CloseGreatWorksOverview()
    if m_IsXP1Active then
        LuaEvents.GovernorPanel_Close()
        LuaEvents.HistoricMoments_Close()
    end
    if m_IsXP2Active then
        LuaEvents.Launchbar_Expansion2_ClimateScreen_Close()
    end
end

-- ===========================================================================

function OnSSSC_Debug()
	local Relics = Game:GetProperty("SSSC_RelicsAvailabe") or 0
	for i = 1, #Relics, 1 do
		ExposedMembers.StellarisCollector.SSSC_Debug_GrantRelic(m_LocalPlayer)
	end
	ExposedMembers.StellarisCollector.SSSC_Debug_RelicAcLimitMax(m_LocalPlayer)
	Close();
end
-- ===========================================================================
function Initialize()

	ContextPtr:SetHide(true);
	ContextPtr:SetInitHandler( OnInit );
	ContextPtr:SetInputHandler( OnInputHandler, true );

	Controls.SSSC_CloseButton:RegisterCallback(Mouse.eLClick, Close)
	Controls.ConfirmSelected:RegisterCallback(Mouse.eLClick, OnConfirmSelected)
	if debug then
		Controls.SSSC_Debug:RegisterCallback(Mouse.eLClick, OnSSSC_Debug)
	else
		Controls.SSSC_Debug:SetHide(true)
	end
	
	Events.TurnBegin.Add(Close)
	LuaEvents.SSSC_RelicsButton_TogglePopup.Add(OnTogglePanel);
	LuaEvents.SSSC_OpenRelicPanel.Add(CloseOtherPanels);
	
	LuaEvents.DiplomacyActionView_HideIngameUI.Add(Close)
    LuaEvents.EndGameMenu_Shown.Add(Close)
    LuaEvents.FullscreenMap_Shown.Add(Close)
    LuaEvents.NaturalWonderPopup_Shown.Add(Close)
    LuaEvents.ProjectBuiltPopup_Shown.Add(Close)
    LuaEvents.Tutorial_ToggleInGameOptionsMenu.Add(Close)
    LuaEvents.WonderBuiltPopup_Shown.Add(Close)
    LuaEvents.NaturalDisasterPopup_Shown.Add(Close)  
    LuaEvents.RockBandMoviePopup_Shown.Add(Close)
	LuaEvents.CivicsTree_OpenCivicsTree.Add(Close);	
	LuaEvents.Government_OpenGovernment.Add(Close);
	LuaEvents.GovernorPanel_Opened.Add(Close);	
	LuaEvents.GreatPeople_OpenGreatPeople.Add(Close);
	LuaEvents.GreatWorks_OpenGreatWorks.Add(Close);
	LuaEvents.HistoricMoments_Opened.Add(Close);
	LuaEvents.Religion_OpenReligion.Add(Close);	
	LuaEvents.PantheonChooser_OpenReligion.Add(Close);	
	LuaEvents.TechTree_OpenTechTree.Add(Close);
	LuaEvents.ClimateScreen_Opened.Add(Close);
end

Initialize();