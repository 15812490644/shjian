-- StellarisCollector_Button
-- Author: Lazire
-- DateCreated: 12/4/2023 11:36:15 PM
--------------------------------------------------------------
local m_LaunchButtonInstance = {};
local m_LaunchButtonLocked = false;

function ToggleSSSCPopup()
	LuaEvents.SSSC_RelicsButton_TogglePopup()
end

function AttachLaunchButton()
    local buttonStack = ContextPtr:LookUpControl("/InGame/LaunchBar/ButtonStack");

    ContextPtr:BuildInstanceForControl("StellarisCollectorRelicsItem", m_LaunchButtonInstance, buttonStack);
    m_LaunchButtonInstance.SSSC_ItemButton:RegisterCallback(Mouse.eLClick, ToggleSSSCPopup);
    ContextPtr:BuildInstanceForControl("StellarisCollectorRelicsPinInstance", {}, buttonStack);

    -- Resize.
    buttonStack:CalculateSize();

    local backing = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBacking");
    backing:SetSizeX(buttonStack:GetSizeX() + 116);

    local backingTile = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBackingTile");
    backingTile:SetSizeX(buttonStack:GetSizeX() - 20);

    LuaEvents.LaunchBar_Resize(buttonStack:GetSizeX());
end

function OnSSSCLauchButtonSetup()
	if Players[Game.GetLocalPlayer()]:IsHuman() then
		if not m_LaunchButtonLocked  then
			AttachLaunchButton();
			m_LaunchButtonLocked = true
		end
	end
end

function OnPlayerTurnActivated(playerID:number, isFirstTimeThisTurn:boolean)
	if Game.GetLocalPlayer() == playerID and isFirstTimeThisTurn then
		CheckActivationAllowed();
    end
end

function SSSC_Confirmed(playerID, num)
	if Game.GetLocalPlayer() == playerID then
		print('LuaEvent: Confirm')
		CheckActivationAllowed(num);
	end
end

--[[function SSSC_RelicCreated(playerID)
	if Game.GetLocalPlayer() == playerID then
		print('LuaEvent: Relic Created')
		CheckActivationAllowed();
	end
end]]--

function CheckActivationAllowed(num)
	local ePro = Players[Game.GetLocalPlayer()]:GetProperty('SSSC_PROMOTION_1_PROPERTY') or 0;
	if ePro > 0 then
		local pPlayer = Players[Game.GetLocalPlayer()]
		local ActivationsAllowed:number = pPlayer:GetProperty('SSSC_ACTIVE_NUM_ALLOWED') or 1;
		local ActivedRelics:table = pPlayer:GetProperty('SSSC_ActivedRelics') or {};
		local ActiveAllowedLeft:number = ActivationsAllowed - #ActivedRelics
		print('Check Allowed',ActiveAllowedLeft)
		if num then
			if ActiveAllowedLeft > 0 and num < ActiveAllowedLeft then
				m_LaunchButtonInstance.AlertIndicator:SetHide(false);
			else
				m_LaunchButtonInstance.AlertIndicator:SetHide(true);
			end
		else
			if ActiveAllowedLeft > 0 then
				m_LaunchButtonInstance.AlertIndicator:SetHide(false);
			else
				m_LaunchButtonInstance.AlertIndicator:SetHide(true);
			end
		end
	end
end



function Initialize()
    Events.LoadGameViewStateDone.Add(OnSSSCLauchButtonSetup);
	--Events.GovernorPromoted.Add( OnSSSCLauchButtonSetup );
	LuaEvents.SSSC_Confirmed.Add( SSSC_Confirmed );
	--LuaEvents.SSSC_RelicCreated.Add( SSSC_RelicCreated );
	Events.PlayerTurnActivated.Add(OnPlayerTurnActivated);
end

Initialize();