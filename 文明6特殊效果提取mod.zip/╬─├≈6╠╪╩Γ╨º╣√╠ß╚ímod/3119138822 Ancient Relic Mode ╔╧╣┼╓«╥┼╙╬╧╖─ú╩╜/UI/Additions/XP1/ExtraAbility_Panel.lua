-- ExtraAbility_Panel
-- Author: Lazire
-- DateCreated: 12/19/2023 4:48:54 PM
--------------------------------------------------------------
include("AnimSidePanelSupport");
include("InstanceManager");
include("SupportFunctions");
include("GameCapabilities");
include("TeamSupport");

local m_kScreenSlideAnim:table;	
local m_ChooserTraitIM	= InstanceManager:new("TraitInstance", "Top", Controls.ChooserTraitItem);
local m_ReviewTraitIM	= InstanceManager:new("TraitInstance", "Top", Controls.ReviewTraitItem);
local m_RandChoiceNum	= 10;
local m_SelectedInst;

function Refresh()
	m_ChooserTraitIM:DestroyInstances();
	m_ReviewTraitIM:DestroyInstances();
	Controls.ChooserStatusMessage:SetText(Locale.Lookup('LOC_EA_CHOOSER'));
	Controls.ConfirmButton:SetDisabled(true)
	
	-- Populate Chooser
	local ePro_EA = Players[Game.GetLocalPlayer()]:GetProperty('PROPERTY_SC_EXTRA_ABILITY') or 0;
	if ePro_EA > 0 then
		Controls.ChooserStatusMessage:LocalizeAndSetText('LOC_EA_CHOOSER_TIP',ePro_EA)
		local Traits	= Game:GetProperty('SC_EA_Traits') or {};
		m_SelectedInst = nil;
		for i = 1, m_RandChoiceNum do
			AddChooserInstance(Traits[i].Trait)
		end
	end
	
	-- Populate Review
	local tPro = Players[Game.GetLocalPlayer()]:GetProperty('PROPERTY_SC_EXTRA_ABILITY_ATTACHED') or {}
	if #tPro > 0 then
		for i, TraitType in ipairs(tPro) do
			AddReviewInstance(TraitType)
		end	
	end
end

function AddChooserInstance(sTrait)
	local new = m_ChooserTraitIM:GetInstance()
	--new.Button:SetVoids(sTrait, -1)
	new.Name:SetText(Locale.Lookup(GameInfo.Traits[sTrait].Name)) 
	new.Info:SetText(Locale.Lookup(GameInfo.Traits[sTrait].Description)) 
	
	local backColor:number, frontColor:number  = UI.GetPlayerColors( Game.GetLocalPlayer() );
	new.BannerBase:SetColor(backColor)
	new.Name:SetColor(frontColor)
	new.SelectorBrace:SetColor(UI.GetColorValue(1,1,1,0));
	new.Button:SetVoid1(GameInfo.Traits[sTrait].Index)
	new.Button:SetSelected(false);
	new.Button:RegisterCallback(Mouse.eLClick, function() 
		SelectCheck(new)
	end)
end

function AddReviewInstance(sTrait)
	local new = m_ReviewTraitIM:GetInstance()
	new.Name:SetText(Locale.Lookup(GameInfo.Traits[sTrait].Name)) 
	new.Info:SetText(Locale.Lookup(GameInfo.Traits[sTrait].Description)) 
	local backColor:number, frontColor:number  = UI.GetPlayerColors( Game.GetLocalPlayer() );
	new.BannerBase:SetColor(backColor)
	new.Name:SetColor(frontColor)
	new.SelectorBrace:SetColor(UI.GetColorValue(1,1,1,0));
end

function SelectCheck(new)
	if new ~= m_SelectedInst then
		if m_SelectedInst ~= nil then
			m_SelectedInst.Button:SetSelected(false)
			m_SelectedInst.SelectorBrace:SetColor(UI.GetColorValue(1,1,1,0));
		end
		new.SelectorBrace:SetColor(UI.GetColorValue(1,1,1,1));
		new.Button:SetSelected(true);
		m_SelectedInst = new
		Controls.ConfirmButton:SetDisabled(false)
	else
		new.SelectorBrace:SetColor(UI.GetColorValue(1,1,1,0));
		new.Button:SetSelected(false);
		m_SelectedInst = nil;
		Controls.ConfirmButton:SetDisabled(true)
	end
end

function OnSCEA_Confirm()
	UI.PlaySound("UI_GREAT_WORKS_BONUS_ACHIEVED");
	local kParameters = {}
	kParameters.OnStart = "SC_ExtraAbility_Confirm"
	kParameters.row_Trait	= GameInfo.Traits[m_SelectedInst.Button:GetVoid1()]
	UI.RequestPlayerOperation(Game.GetLocalPlayer(), PlayerOperations.EXECUTE_SCRIPT, kParameters)
	Network.BroadcastPlayerInfo();
	Close()
end

function OnToggle_EAPanel()
	if ContextPtr:IsHidden() then
		Open()
	else
		Close()
	end
end

function Open()
	if (Game.GetLocalPlayer() == -1) then
		return
	end
	Refresh()
	UI.PlaySound("CityStates_Panel_Open");
	m_kScreenSlideAnim.Show();
end

function Close()
	UI.PlaySound("CityStates_Panel_Close");
	m_kScreenSlideAnim.Hide();
end


function Initialize()
	m_kScreenSlideAnim = CreateScreenAnimation( Controls.EASlideAnim );
	
	Controls.ConfirmButton:RegisterCallback(Mouse.eLClick, OnSCEA_Confirm)
	LuaEvents.SSSC_CloseRelicPanel.Add(Close)
	LuaEvents.SC_ExtraAb_Button_Toggle.Add(OnToggle_EAPanel)
end

Initialize();