-- StellarisCollector_UI
-- Author: Lazire
-- DateCreated: 12/6/2023 9:51:43 PM
--------------------------------------------------------------
include("GameCapabilities");
GameEvents = ExposedMembers.GameEvents;

function SSSC_GreatWorkCreated( playerID, unitID, iCityPlotX, iCityPlotY, buildingID, greatWorkID )
	local cityPlotIndex = Map.GetPlotIndex(iCityPlotX, iCityPlotY);
	local city = Cities.GetCityInPlot(cityPlotIndex);
	local pPlayer = Players[playerID];
	local pCityBldgs = city:GetBuildings();
	local greatWorkType = pCityBldgs:GetGreatWorkTypeFromIndex(greatWorkID);
	if GameInfo.GreatWorks[greatWorkType].GreatWorkObjectType ~= 'GREATWORKOBJECT_ARTIFACT' then
		local ePro = pPlayer:GetProperty('SSSC_PROMOTION_2_PROPERTY') or 0
		if ePro > 0 then
			ExposedMembers.StellarisCollector.SSSCGreatWorkCreated_2(playerID)
		end
	elseif GameInfo.GreatWorks[greatWorkType].GreatWorkObjectType == 'GREATWORKOBJECT_ARTIFACT' then
		local ePro = pPlayer:GetProperty('SSSC_PROMOTION_3_PROPERTY') or 0
		if ePro > 0 then
			ExposedMembers.StellarisCollector.SSSCGreatWorkCreated_3(playerID)
		end
	end
end

-- ===========================================================================
--  Relic Ability 
-- ===========================================================================
--	如果遗珍的主动效果无法通过modifier简单呈现，请建立函数来实现它的效果
--	注意建筑生成事件Events.BuildingAddedToMap在加载游戏时会重新触发，可能需要使用property判定或其他方式避免

function Dreambind_Castle_BuildingAddedToMap( iX, iY, buildingID, playerID)
	local pPlayer = Players[playerID];
	if buildingID == GameInfo.Buildings['BUILDING_SSSC_RELIC_AKN_DREAMBIND_CASTLE'].Index then
		local GoldenAgeGurantee_Diff = Game.GetEras():GetPlayerGoldenAgeThreshold(playerID)-Game.GetEras():GetPlayerCurrentScore(playerID);
		ExposedMembers.StellarisCollector.Dreambind_Castle_Active(playerID,	GoldenAgeGurantee_Diff);
	end
end


function Initialize()
	Events.GreatWorkCreated.Add( SSSC_GreatWorkCreated );
	
	Events.BuildingAddedToMap.Add( Dreambind_Castle_BuildingAddedToMap );
	
end



Initialize();