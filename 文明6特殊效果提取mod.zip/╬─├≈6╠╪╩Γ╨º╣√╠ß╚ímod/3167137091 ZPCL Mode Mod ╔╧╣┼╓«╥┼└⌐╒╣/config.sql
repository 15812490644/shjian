-- GameMode
-- Author: Lazire
-- DateCreated: 12/18/2023 9:39:25 PM
--------------------------------------------------------------



INSERT INTO GameModeItems
(GameModeType,
Name,
Description,
Icon,
Portrait,
Background,
SortIndex)
VALUES
('GAMEMODE_ANCIENT_RELIC2',
'LOC_GAMEMODE_ANCIENT_RELIC2_NAME',
'LOC_GAMEMODE_ANCIENT_RELIC2_DESCRIPTION',
'ICON_GAMEMODE_ANCIENT_RELIC',
'IMG_GAMEMODE_ANCIENT_RELIC_FORE',
'IMG_GAMEMODE_ANCIENT_RELIC_BACK',
234);

INSERT INTO Parameters
(ParameterId,
Name,
Description,
Domain,
DefaultValue,
ConfigurationGroup,
ConfigurationId,
NameArrayConfigurationId,
GroupId,
SortIndex)
VALUES
('GAMEMODE_ANCIENT_RELIC2',
'LOC_GAMEMODE_ANCIENT_RELIC2_NAME',
'LOC_GAMEMODE_ANCIENT_RELIC2_DESCRIPTION',
'bool',
0,
'Game',
'GAMEMODE_ANCIENT_RELIC2',
'GAMEMODES_ENABLED_NAMES1',
'GameModes',
234);

INSERT INTO ParameterDependencies
(ParameterId,
ConfigurationGroup,
ConfigurationId,
Operator,
ConfigurationValue)
VALUES
('GAMEMODE_ANCIENT_RELIC2',
'Game',
'WORLD_BUILDER',
'NotEquals',
1);
