-- StellarisCollector_Script_ZPCL
-- Author: Lazire
-- DateCreated: 12/5/2023 3:51:43 PM
--------------------------------------------------------------
--include("StellarisCollector_Script");
print('StellarisCollector_Script_ZPCL loaded')
GameEvents.PlayerTurnStarted.Remove( AR_PlayerTurnStarted );
Events.GameEraChanged.Remove( AR_GameEraChanged );
Events.GameEraChanged.Remove( AR_GameEraChanged );
--[[ExposedMembers.GameEvents = GameEvents;

-- ===========================================================================
--	Misc
-- ===========================================================================
local SpeedMul 			= GameInfo.GameSpeeds[GameConfiguration.GetGameSpeedType()].CostMultiplier / 100;
local SSSC_Pro_1_GH		= 12;
local SSSC_Pro_1_BC		= 12;
local SSSC_Pro_2		= 15;
local SSSC_Pro_3		= 33;

-- ===========================================================================
--	To Grant Relic
-- ===========================================================================
function CalculateRsum()
	local Relics = Game:GetProperty('SSSC_RelicsAvailabe') or DB.Query("SELECT * FROM SSSC_Relic")
	local SSSC_Rsum = 0
	
	for i, row in ipairs(Relics) do
		if not row.TraitType then
			SSSC_Rsum = SSSC_Rsum + row.Chance
		end
	end
	--print(#Relics)
	Game:SetProperty('SSSC_Rsum',SSSC_Rsum)
end

function SSSC_PlayerGrantRandomRelic(playerID)
	if not Players[playerID]:IsHuman() then return; end
	CalculateRsum()
	local Relics = Game:GetProperty('SSSC_RelicsAvailabe') or DB.Query("SELECT * FROM SSSC_Relic")
	local SSSC_Rsum = Game:GetProperty("SSSC_Rsum") or 0
	local pPlayer = Players[playerID]
	local RelicList = pPlayer:GetProperty('SSSC_Relic') or {}
	local tmp = Game.GetRandNum(SSSC_Rsum)+1
	local b, UniqueRelic = HaveUniqueRelic(playerID)
	if b then
		for i, row in ipairs(Relics) do
			if row.RelicType == UniqueRelic then
				table.insert(RelicList, row.RelicType)
				pPlayer:SetProperty('SSSC_Relic', RelicList) 
				if pPlayer:IsHuman() then
					NotificationManager.SendNotification(playerID, "NOTIFICATION_RELIC_CREATED", Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT'),Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT_DESC'));
				end
				table.remove(Relics,i)
				Game:SetProperty('SSSC_RelicsAvailabe', Relics)
				for s_row in GameInfo.SSSC_Relic_PassiveModifier() do	-- Permanent
					if s_row.RelicType == row.RelicType then
						--print('Attach Relic Ability',s_row.ModifierId)
						pPlayer:AttachModifierByID(s_row.ModifierId)
					end
				end
				--LuaEvents.SSSC_RelicCreated(playerID, row.RelicType)
				return
			end
		end
	end
	for i, row in ipairs(Relics) do
		if not row.TraitType then
			tmp = tmp - row.Chance
			if tmp <= 0 then
				table.insert(RelicList, row.RelicType)
				--print('player '..playerID..' grant a random Relic '..row.RelicType)
				pPlayer:SetProperty('SSSC_Relic', RelicList) 
				if pPlayer:IsHuman() then
					NotificationManager.SendNotification(playerID, "NOTIFICATION_RELIC_CREATED", Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT'),Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT_DESC'));
				end
				table.remove(Relics,i)
				Game:SetProperty('SSSC_RelicsAvailabe', Relics)
				for s_row in GameInfo.SSSC_Relic_PassiveModifier() do	-- Permanent
					if s_row.RelicType == row.RelicType then
						--print('Attach Relic Ability',s_row.ModifierId)
						pPlayer:AttachModifierByID(s_row.ModifierId)
					end
				end
				--LuaEvents.SSSC_RelicCreated(playerID, row.RelicType)
				return
			end
		end
	end
end

function HaveUniqueRelic(playerID)
	local Relics = Game:GetProperty('SSSC_RelicsAvailabe') or DB.Query("SELECT * FROM SSSC_Relic")
	for i, row in ipairs(Relics) do
		if row.TraitType and HasTrait(row.TraitType, playerID) then
			return true, row.RelicType
		end
	end
	return false, nil
end

-- Newly added on 2024/1/11
function GrantSpecificRelic(playerID, SpecificRelicType)
	local pPlayer = Players[playerID]
	local Relics = Game:GetProperty('SSSC_RelicsAvailabe') or DB.Query("SELECT * FROM SSSC_Relic")
	local playerRelics = pPlayer:GetProperty('SSSC_Relic') or {}
	for i, row in ipairs(Relics) do
		if row.RelicType == SpecificRelicType then
			table.insert(playerRelics, SpecificRelicType)
			pPlayer:SetProperty('SSSC_Relic', playerRelics) 
			if pPlayer:IsHuman() then
				NotificationManager.SendNotification(playerID, "NOTIFICATION_RELIC_CREATED", Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT'),Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT_DESC'));
			end
			table.remove(Relics,i)
			Game:SetProperty('SSSC_RelicsAvailabe', Relics)
			for s_row in GameInfo.SSSC_Relic_PassiveModifier() do	
				if s_row.RelicType == row.RelicType then
					pPlayer:AttachModifierByID(s_row.ModifierId)
				end
			end
			return
		end
	end
	print("ERROR: Can't find available specific relic",SpecificRelicType)
end]]--

-- ����setproperty���ӳٿ��ܵ�������ģʽ�²�ͬ���������˻�ȡ��ʽ
function AR_GameEraChanged_ZPCL(previousEra, newEra)
	CalculateRsum()
	local Relics = Game:GetProperty('SSSC_RelicsAvailabe') or DB.Query("SELECT * FROM SSSC_Relic")
	if GameInfo.Eras[newEra].Hash == GameConfiguration.GetStartEra() then return; end
	if GameInfo.Eras[newEra].EraType ~= 'ERA_RENAISSANCE' then return; end
	for i, playerID in ipairs(PlayerManager.GetAliveMajorIDs()) do
		local pPlayer = Players[playerID];
		if pPlayer:IsHuman() then
			local row = {}
			local Sum = 0
			for r, row in ipairs(Relics) do
				if not row.TraitType then
					Sum = Sum + row.Chance
				end
			end
			local tmp = Game.GetRandNum(Sum) + 1
			row.playerID = playerID
			local b, UniqueRelic = HaveUniqueRelic(playerID)
			if b then 	
				row.RelicType = UniqueRelic
				for j, RelicInfo in ipairs(Relics) do
					if UniqueRelic == RelicInfo.RelicType then
						table.remove(Relics, j)
						break
					end
				end
			else
				for j, RelicInfo in ipairs(Relics) do
					if not RelicInfo.TraitType then
						tmp = tmp - RelicInfo.Chance
						if tmp <= 0 then
							row.RelicType = RelicInfo.RelicType
							table.remove(Relics, j)
							break
						end
					end
				end
			end
			GrantSpecificRelic(row.playerID, row.RelicType)
		end
	end
end

function AR_PlayerTurnStarted_ZPCL(playerID)
	local pPlayer = Players[playerID];
	if pPlayer:IsHuman() then
		local ePro = pPlayer:GetProperty('AR_CEREMONIAL') or false;
		if not ePro then
			SSSC_PlayerGrantRandomRelic(playerID)		
			for i = 0, GameInfo.Eras[GameConfiguration.GetStartEra()].Index, 1 do
				SSSC_PlayerGrantRandomRelic(playerID)
				SSSC_PlayerGrantRandomRelic(playerID)				
			end
			pPlayer:SetProperty('AR_CEREMONIAL', true)
		end
	end
end

--[[function SSSC_GoodyHutReward(playerID, unitID, iUnknown1, iUnknown2)
	--print('Goody Hut Reward',playerID)
	local ActivationsAllowed:number = Players[playerID]:GetProperty('SSSC_ACTIVE_NUM_ALLOWED') or 0;
	if ActivationsAllowed > 0 then
		local RandomNum = Game.GetRandNum(100)
		print(RandomNum)
		if RandomNum < SSSC_Pro_1_GH then
			SSSC_PlayerGrantRandomRelic(playerID)
		end
	end
end

function SSSC_ImprovementRemovedFromMap(plotX, plotY, playerID)
	local pPlayer = Players[playerID]
    if (pPlayer ~= nil) and pPlayer:IsBarbarian() then

		local pPlot = Map.GetPlot(plotX, plotY)
		for i, Unit in ipairs(Units.GetUnitsInPlot(pPlot)) do
			if(Unit ~= nil) then
				--print('Barbarian Camp Removed',playerID)
				if GameInfo.Units[Unit:GetType()].Combat ~= 0 then

					local UnitOwnerID = Unit:GetOwner()
					local ActivationsAllowed:number = Players[UnitOwnerID]:GetProperty('SSSC_ACTIVE_NUM_ALLOWED') or 0;
					if ActivationsAllowed > 0 then
						local pPlayer = Players[UnitOwnerID];
						local temp = Game.GetRandNum(100)
						local RandomNum = Game.GetRandNum(100)
						print(RandomNum)
						if RandomNum < SSSC_Pro_1_BC then
							SSSC_PlayerGrantRandomRelic(UnitOwnerID)
						end
					end
				end
			end
		end
	end
end]]--

--[[function SSSC_GreatWorkCreated( playerID, unitID, iCityPlotX, iCityPlotY, buildingID, greatWorkID )
	local cityPlotIndex = Map.GetPlotIndex(iCityPlotX, iCityPlotY);
	local city = Cities.GetCityInPlot(cityPlotIndex);
	local pPlayer = Players[playerID]
	local pCityBldgs = city:GetBuildings();
	local greatWorkType = pCityBldgs:GetGreatWorkTypeFromIndex(greatWorkID);
	if GameInfo.GreatWorks[greatWorkType].GreatWorkObjectType ~= 'GREATWORKOBJECT_ARTIFACT' then
		local ePro = pPlayer:GetProperty('SSSC_PROMOTION_2_PROPERTY') or 0
		if ePro > 0 then
			local RandomNum = Game.GetRandNum(100)
			if RandomNum < SSSC_Pro_2 then
				SSSC_PlayerGrantRandomRelic(playerID)
			end
		end
	elseif GameInfo.GreatWorks[greatWorkType].GreatWorkObjectType == 'GREATWORKOBJECT_ARTIFACT' then
		local ePro = pPlayer:GetProperty('SSSC_PROMOTION_3_PROPERTY') or 0
		if ePro > 0 then
			local RandomNum = Game.GetRandNum(100)
			if RandomNum < SSSC_Pro_3 then
				SSSC_PlayerGrantRandomRelic(playerID)
			end
		end
	end
end]]--
-- ===========================================================================
--  Relic Activation
-- ===========================================================================
--[[function SSSC_PlayerTurnStarted(playerID)
	for row in GameInfo.SSSC_Relic() do
		local ActivedRelics = Players[playerID]:GetProperty('SSSC_ActivedRelics') or {};
		for i, ActivedRelic in ipairs(ActivedRelics) do 
			if row.RelicType == ActivedRelic then
				local turnleft = Game:GetProperty('SSSC_RELIC_TURN_LEFT'..row.RelicType) or DefaultCooldown;
				local new_turnleft = turnleft-1
				if new_turnleft <= 0 then	
					table.remove(ActivedRelics, i)
					Players[playerID]:SetProperty('SSSC_ActivedRelics', ActivedRelics)
					local iPlot = Game:GetProperty('SSSC_RELIC_POSITION'..row.RelicType) or -1;
					local iX, iY = Map.GetPlotByIndex(iPlot):GetX(),Map.GetPlotByIndex(iPlot):GetY()
					local pCity = CityManager.GetCityAt(iX,iY)
					pCity:GetBuildings():RemoveBuilding(GameInfo.Buildings['BUILDING_SSSC_'..row.RelicType].Index)
				end
				Game:SetProperty('SSSC_RELIC_TURN_LEFT'..row.RelicType, new_turnleft)
			end
		end
	end
end

function SSSCGreatWorkCreated_2(playerID)
	local RandomNum = Game.GetRandNum(100)
	if RandomNum < SSSC_Pro_2 then
		SSSC_PlayerGrantRandomRelic(playerID)
	end
end
function SSSCGreatWorkCreated_3(playerID)
	local RandomNum = Game.GetRandNum(100)
	if RandomNum < SSSC_Pro_3 then
		SSSC_PlayerGrantRandomRelic(playerID)
	end
end

function SSSC_Debug_RelicAcLimitMax(playerID)
	Players[playerID]:SetProperty('SSSC_ACTIVE_NUM_ALLOWED', 99)
end

function SSSC_Debug_GrantRelic(playerID)
	SSSC_PlayerGrantRandomRelic(playerID)
end

function SSSC_RelicActive(playerID, param)
	pPlayer = Players[playerID]
	RelicInfo = GameInfo.SSSC_Relic[param.RelicIndex]
	local ActivedRelics = pPlayer:GetProperty('SSSC_ActivedRelics') or {};
	table.insert(ActivedRelics,RelicInfo.RelicType)
	--print('Relic Activate',RelicInfo.RelicType)
	pPlayer:GetCities():GetCapitalCity():GetBuildQueue():CreateBuilding(GameInfo.Buildings['BUILDING_SSSC_'..RelicInfo.RelicType].Index)
	pPlayer:SetProperty('SSSC_ActivedRelics',ActivedRelics)
	Game:SetProperty('SSSC_RELIC_TURN_LEFT'..RelicInfo.RelicType,math.ceil(RelicInfo.Last * SpeedMul));
	local iPlot = pPlayer:GetCities():GetCapitalCity():GetPlot():GetIndex();
	Game:SetProperty('SSSC_RELIC_POSITION'..RelicInfo.RelicType,iPlot);
end]]--

-- ===========================================================================
--  Relic Ability 
-- ===========================================================================
--	������������Ч���޷�ͨ��modifier�򵥳��֣��뽨��������ʵ������Ч��
--	ע�⽨�������¼�Events.BuildingAddedToMap�ڼ�����Ϸʱ�����´�����������Ҫʹ��property�ж���������ʽ����
--	����GameEvents.BuildingConstructed�ǽϺõĽ����ʽ

--[[local Damaru_RelicChance = 2;

function Damaru_PlayerTurnStarted(playerID)	
	local pPlayer = Players[playerID]
	local ePro = pPlayer:GetProperty('PROPERTY_DAMARU') or 0
	if ePro > 0 then 
		local RandomNum = Game.GetRandNum(100)
		--print('Damaru Relic Rand Num',RandomNum,playerID)
		if RandomNum < Damaru_RelicChance then
			SSSC_PlayerGrantRandomRelic(playerID)
		end
	end
end

function Damaru_BuildingConstructed(playerID, cityID, buildingID, plotID, bOriginalConstruction)
	if GameInfo.Buildings[buildingID].BuildingType ~= 'BUILDING_SSSC_RELIC_SS_DAMARU' then return; end
	local ActivationsAllowed:number = Players[playerID]:GetProperty('SSSC_ACTIVE_NUM_ALLOWED') or 0;
	if ActivationsAllowed > 0 then
		SSSC_PlayerGrantRandomRelic(playerID)
	end
end

function Dreambind_Castle_Active(playerID, GoldenAgeGurantee_Diff)
	Game.GetEras():ChangePlayerEraScore(playerID, GoldenAgeGurantee_Diff)
end

function AKN_Diamond_GreatWorkCreated(playerID, unitID, iCityPlotX, iCityPlotY, buildingID, greatWorkID)
	local pPlayer = Players[playerID];
	local ePro = pPlayer:GetProperty('PROPERTY_AKN_DIAMOND') or 0;
	if ePro > 0 then
		pPlayer:AttachModifierByID('GOODY_CULTURE_GRANT_TWO_CIVIC_BOOSTS')
	end
end]]--

-- ===========================================================================
function SSSC_PlayerGrantRandomRelic(playerID)
	if not Players[playerID]:IsHuman() then return; end
	CalculateRsum()
	local Relics = Game:GetProperty('SSSC_RelicsAvailabe') or DB.Query("SELECT * FROM SSSC_Relic")
	local SSSC_Rsum = Game:GetProperty("SSSC_Rsum") or 0
	local pPlayer = Players[playerID]
	local RelicList = pPlayer:GetProperty('SSSC_Relic') or {}
	local tmp = Game.GetRandNum(SSSC_Rsum)+1
	local b, UniqueRelic = HaveUniqueRelic(playerID)
	if b then
		for i, row in ipairs(Relics) do
			if row.RelicType == UniqueRelic then
				table.insert(RelicList, row.RelicType)
				pPlayer:SetProperty('SSSC_Relic', RelicList) 
				if pPlayer:IsHuman() then
					NotificationManager.SendNotification(playerID, "NOTIFICATION_RELIC_CREATED", Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT'),Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT_DESC'));
				end
				table.remove(Relics,i)
				Game:SetProperty('SSSC_RelicsAvailabe', Relics)
				--LuaEvents.SSSC_RelicCreated(playerID, row.RelicType)
				return
			end
		end
	end
	for i, row in ipairs(Relics) do
		if not row.TraitType then
			tmp = tmp - row.Chance
			if tmp <= 0 then
				table.insert(RelicList, row.RelicType)
				--print('player '..playerID..' grant a random Relic '..row.RelicType)
				pPlayer:SetProperty('SSSC_Relic', RelicList) 
				if pPlayer:IsHuman() then
					NotificationManager.SendNotification(playerID, "NOTIFICATION_RELIC_CREATED", Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT'),Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT_DESC'));
				end
				table.remove(Relics,i)
				Game:SetProperty('SSSC_RelicsAvailabe', Relics)
				--LuaEvents.SSSC_RelicCreated(playerID, row.RelicType)
				return
			end
		end
	end
end

function GrantSpecificRelic(playerID, SpecificRelicType)
	local pPlayer = Players[playerID]
	local Relics = Game:GetProperty('SSSC_RelicsAvailabe') or DB.Query("SELECT * FROM SSSC_Relic")
	local playerRelics = pPlayer:GetProperty('SSSC_Relic') or {}
	for i, row in ipairs(Relics) do
		if row.RelicType == SpecificRelicType then
			table.insert(playerRelics, SpecificRelicType)
			pPlayer:SetProperty('SSSC_Relic', playerRelics) 
			if pPlayer:IsHuman() then
				NotificationManager.SendNotification(playerID, "NOTIFICATION_RELIC_CREATED", Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT'),Locale.Lookup('LOC_NOTIFICATION_SSSC_RELIC_GRANT_DESC'));
			end
			table.remove(Relics,i)
			Game:SetProperty('SSSC_RelicsAvailabe', Relics)
			return
		end
	end
	print("ERROR: Can't find available specific relic",SpecificRelicType)
end

Events.GoodyHutReward.Remove( SSSC_GoodyHutReward );
Events.ImprovementRemovedFromMap.Remove( SSSC_ImprovementRemovedFromMap );
Events.CityProjectCompleted.Remove( SSSC_CityProjectCompleted );
GameEvents.SSSCGreatWorkCreated_2.Remove( SSSCGreatWorkCreated_2 );
GameEvents.SSSCGreatWorkCreated_3.Remove( SSSCGreatWorkCreated_3 );
GameEvents.PlayerTurnStarted.Add( AR_PlayerTurnStarted_ZPCL );
GameEvents.BuildingConstructed.Remove( Damaru_BuildingConstructed );
GameEvents.BuildingConstructed.Remove( CelestialTear_BuildingConstructed );	
--[[function Initialize()
	CalculateRsum()
	ExposedMembers.StellarisCollector = ExposedMembers.StellarisCollector or {};
	ExposedMembers.StellarisCollector.SSSCGreatWorkCreated_2 = SSSCGreatWorkCreated_2;
	ExposedMembers.StellarisCollector.SSSCGreatWorkCreated_3 = SSSCGreatWorkCreated_3;
	ExposedMembers.StellarisCollector.SSSC_Debug_RelicAcLimitMax = SSSC_Debug_RelicAcLimitMax;
	ExposedMembers.StellarisCollector.SSSC_Debug_GrantRelic = SSSC_Debug_GrantRelic;
	-- get relic
	--Events.GovernorPromoted.Add( SSSC_GovernorPromoted );
	GameEvents.PlayerTurnStarted.Add( AR_PlayerTurnStarted );
	Events.GameEraChanged.Add( AR_GameEraChanged );
	GameEvents.SSSC_Debug_RelicAcLimitMax.Add( SSSC_Debug_RelicAcLimitMax );
	GameEvents.Dreambind_Castle_Active.Add( Dreambind_Castle_Active );
	GameEvents.SSSC_Debug_GrantRelic.Add( SSSC_Debug_GrantRelic );
	
	GameEvents.PlayerTurnStarted.Add( SSSC_PlayerTurnStarted );

	-- Relic Ability
	ExposedMembers.StellarisCollector.Dreambind_Castle_Active = Dreambind_Castle_Active;
	GameEvents.PlayerTurnStarted.Add( Damaru_PlayerTurnStarted );
	GameEvents.BuildingConstructed.Add( Damaru_BuildingConstructed );

	GameEvents.SSSC_RelicActive.Add( SSSC_RelicActive );
	Events.GreatWorkCreated.Add( AKN_Diamond_GreatWorkCreated );
end]]--

--Initialize();

--include('StellarisCollector_',true);

GameEvents.BuildingConstructed.Remove( Whiteflower_BuildingConstructed );