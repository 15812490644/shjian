-- Relic
-- Author: Administrator
-- DateCreated: 2024/2/23 14:28:37
--------------------------------------------------------------
--��������ӥ��
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_UR_OPH_CALRADIA';
--Ү���Ե�֮ʯ
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_UR_PEN_KJERAG';
--Ш
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_WORMHOLE_KEY_5';
--����������
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_AKN_CIVILIGHT_ETERNA';
--������
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_AKN_B_N_U';
--���
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_PRETHORYN_QUEEN';
--���������
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_AKN_OCEAN_PULSE';


--��������Ϣ
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_AKN_TIDE_BREATH';
--����ҩƬ
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_AKN_BRAINTET';
--���
DELETE FROM SSSC_Relic WHERE RelicType='RELIC_AKN_BLACKTEA';
DELETE FROM Types WHERE Type='POLICY_SSSC_BLANK_1';
DELETE FROM Types WHERE Type='POLICY_SSSC_BLANK_4';
DELETE FROM Types WHERE Type='POLICY_SSSC_BLANK_7';













--��ˮ��
UPDATE SSSC_Relic SET Last = '80' WHERE RelicType = 'RELIC_AKN_WATER_BOILER';

--�µ���˹����ˮ��
UPDATE SSSC_Relic SET Last = '60' WHERE RelicType = 'RELIC_ODRYSKAN_CRISTAL';
--��������ͷ­
UPDATE SSSC_Relic SET Last = '60' WHERE RelicType = 'RELIC_SEVERED_HEAD';
--`
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_CONSOLE';


--����RELIC_AKN_LAST_REFRAIN
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_AKN_LAST_REFRAIN_5_CIVIC_BOOST' AND Name='Amount';
-- ��̫����ս��Ʒ--RELIC_DRAGON_TROPHY
UPDATE ModifierArguments SET Value='6' WHERE ModifierId='MODFEAT_SSSC_DRAGON_TROPHY_PASSIVE_FAITH_BONUS' AND Name='Amount';
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_SSSC_DRAGON_TROPHY_ACTIVE_AMENITY' AND Name='Amount';
UPDATE ModifierArguments SET Value='10' WHERE ModifierId='MODFEAT_SSSC_DRAGON_TROPHY_ACTIVE_LOYALTY' AND Name='Amount';
UPDATE SSSC_Relic SET Last = '20' WHERE RelicType = 'RELIC_DRAGON_TROPHY';

-- Logos�ĹǱ�
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_BONE_PEN';
UPDATE ModifierArguments SET Value='-1' WHERE ModifierId='MODFEAT_ABILITY_AKN_BONE_PEN_DEBUFF' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_ABILITY_AKN_BONE_PEN_BUFF' AND Name='Amount';
-- ��Ѫ
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_AKN_DEMON_BLOOD_YIELD_SCIENCE' AND Name='Amount';
UPDATE ModifierArguments SET Value='-30' WHERE ModifierId='MODFEAT_AKN_DEMON_BLOOD_HEAL_ALL' AND Name='Amount';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_ABILITY_AKN_DEMON_BLOOD' AND Name='Amount';
UPDATE SSSC_Relic SET Last = '60' WHERE RelicType = 'RELIC_AKN_DEMON_BLOOD';
-- �ʼ����ھ�
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_ROYAL_LIQUEUR';
-- Ѽ����ש
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_GOLDEN_BRICK';
UPDATE ModifierArguments SET Value='7' WHERE ModifierId='MODFEAT_AKN_GOLDEN_BRICK_FREE_UPGRADE' AND Name='Amount';
-- ����
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_BEDROCK';
UPDATE Modifiers SET ModifierType='MODIFIER_PLAYER_UNITS_GRANT_ABILITY' WHERE ModifierId='MODFEAT_AKN_BEDROCK_MILITARY_STRENGTH';


UPDATE ModifierArguments SET Value='-10' WHERE ModifierId='MODFEAT_AKN_BEDROCK_MILITARY_PRODUCTION_REDUCE' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_ABILITY_AKN_BEDROCK' AND Name='Amount';
-- ��������
UPDATE SSSC_Relic SET Last = '100' WHERE RelicType = 'RELIC_AKN_TWISHORN';
UPDATE Modifiers SET SubjectRequirementSetId='MODFEAT_AKN_O_IRIS_Z' WHERE ModifierId='MODFEAT_AKN_TWISHORN_GRANT_RELIC';
--��������Ȩ��
UPDATE ModifierArguments SET Value='100' WHERE ModifierId='MODFEAT_AKN_SCEPTRE_HOLY_SITE_BONUS' AND Name='Amount';
--��ˮ��
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_AKN_WATER_BOILER_GRANT_SETTLER' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_AKN_WATER_BOILER_GRANT_BUILDER' AND Name='Amount';
UPDATE Modifiers SET SubjectRequirementSetId='MODFEAT_AKN_O_IRIS_Z' WHERE ModifierId='MODFEAT_AKN_WATER_BOILER_GRANT_BUILDER';



-- ����֮��
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_GALATRON_FAVOR' AND Name='Amount';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_SSSC_GALATRON_GOLD_INTEREST' AND Name='Percent';
-- Ů����֮��
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_ANCIENT_SWORD';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_ABILITY_SSSC_ANCIENT_SWORD_STRENGTH' AND Name='Amount';
INSERT INTO UnitAbilityModifiers
(UnitAbilityType,						ModifierId)
VALUES
('ABILITY_SSSC_ANCIENT_SWORD_STRENGTH',	'MODFEAT_ABILITY_SSSC_ANCIENT_SWORD_STRENGTH_1');
INSERT INTO Modifiers
(ModifierId,										ModifierType)
VALUES
('MODFEAT_ABILITY_SSSC_ANCIENT_SWORD_STRENGTH_1',					'MODIFIER_PLAYER_UNIT_ADJUST_HEAL_PER_TURN');
INSERT INTO ModifierArguments
(ModifierId,											Name,				Value)
VALUES
('MODFEAT_ABILITY_SSSC_ANCIENT_SWORD_STRENGTH_1',						'Amount',			5);
INSERT INTO ModifierArguments
(ModifierId,											Name,				Value)
VALUES
('MODFEAT_ABILITY_SSSC_ANCIENT_SWORD_STRENGTH_1',						'Type',			'ALL');
--��¬
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_MANTLE';

-- ��������������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_CONTINGENCY_CORE';

UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_SSSC_CONTINGENCY_CORE_UNIT_PRODUCTION' AND Name='Amount';
UPDATE ModifierArguments SET Value='15' WHERE ModifierId='MODFEAT_SSSC_CONTINGENCY_CORE_WONDER_PRODUCTION' AND Name='Amount';
-- �����䶳����
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_CRYO_CORE';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_CRYO_CORE_NEW_CITY_POP' AND Name='Amount';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_SSSC_CRYO_CORE_UNIT_MAINTENANCE' AND Name='Amount';
-- ΢���Ǻ�-CD����
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_GALAXY';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_SSSC_GALAXY_SCIENCE_BONUS' AND Name='Amount';
UPDATE ModifierArguments SET Value='YIELD_CULTURE' WHERE ModifierId='MODFEAT_SSSC_GALAXY_SCIENCE_BONUS' AND Name='YieldType';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_SSSC_GALAXY_2_RANDOM_TECH' AND Name='Amount';

-- �ɺ�����
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_KHANS_THRONE';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_SSSC_KHANS_THRONE_GOLD_BONUS' AND Name='Amount';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_SSSC_KHANS_THRONE_FAITH_BONUS' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_KHANS_THRONE_INFLUENCE' AND Name='Amount';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_ABILITY_SSSC_KHANS_THRONE_PROMOTION' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_ABILITY_SSSC_KHANS_THRONE_STRENGTH' AND Name='Amount';

-- �µ���˹����ˮ��-CD����
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_ODRYSKAN_CRISTAL_PLOT_YIELD' AND Name='Amount';
UPDATE ModifierArguments SET Value='50' WHERE ModifierId='MODFEAT_SSSC_ODRYSKAN_CRISTAL_1000_GOLD' AND Name='Amount';
-- �л�ȫ��
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_OMNICODEX';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_SSSC_OMNICODEX_GRANT_POP' AND Name='Amount';
UPDATE ModifierArguments SET Value='10' WHERE ModifierId='MODFEAT_SSSC_OMNICODEX_GROWTH_RATE' AND Name='Amount';
-- ����������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_POX_SAMPLE';
UPDATE ModifierArguments SET Value='5' WHERE ModifierId='MODFEAT_ABILITY_SSSC_PX_SAMPLE' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_POX_SAMPLE_2_RANDOM_CIVIC' AND Name='Amount';


--����ԭ����
UPDATE SSSC_Relic SET Last = '80' WHERE RelicType = 'RELIC_PRETHORYN_QUEEN';
UPDATE ModifierArguments SET Value='PROMOTION_CLASS_RECON' WHERE ModifierId='MODFEAT_SSSC_PRETHORYN_QUEEN_GRANT_1_LC' AND Name='UnitPromotionClassType';

UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_SSSC_PRETHORYN_QUEEN_CULTURE' AND Name='Amount';
--����ķ��ʵ͸����
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_REALITY_PERFORATOR';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_PERFORATOR_AMENITIES' AND Name='Amount';
UPDATE ModifierArguments SET Value='5' WHERE ModifierId='MODFEAT_ABILITY_SSSC_PERFORATOR' AND Name='PercentDefeatedStrength';
--��¼��
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_ABILITY_SSSC_RUBRICATOR' AND Name='Amount';
UPDATE TypeTags SET Tag='CLASS_ALL_COMBAT_UNITS' WHERE Type='ABILITY_SSSC_RUBRICATOR' AND Tag='CLASS_RELIGIOUS';
UPDATE Modifiers SET SubjectRequirementSetId='REQUIREMENTS_OPPONENT_IS_OTHER_RELIGION' WHERE ModifierId='MODFEAT_ABILITY_SSSC_RUBRICATOR';
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_RUBRICATOR';

--��������ͷ­
UPDATE ModifierArguments SET Value='200' WHERE ModifierId='MODFEAT_SSSC_SEVERED_HEAD_RELIGIOUS_PRESSURE' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_SEVERED_HEAD_HOLY_GUARDIANS' AND Name='Amount';
UPDATE Units SET BaseMoves='1' WHERE UnitType='UNIT_SSSC_HOLY_GUARDIAN';
UPDATE Units SET Combat='10' WHERE UnitType='UNIT_SSSC_HOLY_GUARDIAN';
UPDATE Units SET UseMaxMeleeTrainedStrength=0 WHERE UnitType='UNIT_SSSC_HOLY_GUARDIAN';

--��̽��
UPDATE ModifierArguments SET Value='40' WHERE ModifierId='MODFEAT_SSSC_SURVEYOR_GRANT_RESOURCE' AND Name='Amount';
--��Ƭ��������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_THE_DEFRAGMENTOR';

UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_SSSC_DEFRAGMENTOR_MAINTENANCE' AND Name='Amount';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_SSSC_DEFRAGMENTOR_AMENITIES' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_DEFRAGMENTOR_HOUSING' AND Name='Amount';
UPDATE ModifierArguments SET Value='5' WHERE ModifierId='MODFEAT_SSSC_DEFRAGMENTOR_GOLD_YIELD' AND Name='Amount';

--���İͰ�
UPDATE ModifierArguments SET Value='15' WHERE ModifierId='MODFEAT_SSSC_LAST_BAOL_GROWTH_RATE' AND Name='Amount';
--��ջ���
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_THE_RADIANCE';
UPDATE ModifierArguments SET Value='4' WHERE ModifierId='MODFEAT_SSSC_RADIANCE_GOLD_YIELD' AND Name='Amount';
UPDATE ModifierArguments SET Value='5' WHERE ModifierId='MODFEAT_SSSC_RADIANCE_10_POP_YIELD_FOOD' AND Name='Amount';
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_SSSC_RADIANCE_10_POP_YIELD_PRODUCTION' AND Name='Amount';
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_SSSC_RADIANCE_10_POP_YIELD_CULTURE' AND Name='Amount';
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_SSSC_RADIANCE_10_POP_YIELD_SCIENCE' AND Name='Amount';
UPDATE ModifierArguments SET Value='10' WHERE ModifierId='MODFEAT_SSSC_RADIANCE_10_POP_YIELD_GOLD' AND Name='Amount';
UPDATE ModifierArguments SET Value='5' WHERE ModifierId='MODFEAT_SSSC_RADIANCE_10_POP_YIELD_FAITH' AND Name='Amount';
--������o֮��
UPDATE SSSC_Relic SET Last = '60' WHERE RelicType = 'RELIC_TOXIC_GOD';
UPDATE ModifierArguments SET Value='5' WHERE ModifierId='MODFEAT_ABILITY_TOXIC_GOD' AND Name='Amount';
--�����տ�˹������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_WAR_FORGE';
UPDATE ModifierArguments SET Value='4' WHERE ModifierId='MODFEAT_SSSC_WAR_FORGE_PRODUCTION_PASSIVE' AND Name='Amount';
UPDATE ModifierArguments SET Value='6' WHERE ModifierId='MODFEAT_SSSC_WAR_FORGE_PRODUCTION_ACTIVE' AND Name='Amount';
--ʱ�J֮��
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_WORM_SCALES';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_WORM_SCALES_SCIENCE_YIELD_PASSIVE' AND Name='Amount';
UPDATE ModifierArguments SET Value='-10' WHERE ModifierId='MODFEAT_SSSC_WORM_SCALES_SCIENCE_YIELD_ACTIVE' AND Name='Amount';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_SSSC_WORM_SCALES_AMENITIES' AND Name='Amount';
--���ܵ���
UPDATE ModifierArguments SET Value='50' WHERE ModifierId='MODFEAT_ABILITY_ZRO_CRYSTAL' AND Name='Amount';
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_ZRO_CRYSTAL';

--СѪƿ
UPDATE SSSC_Relic SET Last = '20' WHERE RelicType = 'RELIC_SS_BLOOD_VIAL';
UPDATE ModifierArguments SET Value='-15' WHERE ModifierId='MODFEAT_SSSC_BLOOD_VIAL_HEAL_ALL' AND Name='Amount';
--��Ա��
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_SS_MEMBERSHIP_CARD';
UPDATE ModifierArguments SET Value='10' WHERE ModifierId='MODFEAT_SSSC_MEMBERSHIP_CARD_PURCHASE_DISCOUNT' AND Name='Amount';
--ȼ��֮Ѫ
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_SS_BURNING_BLOOD';

--�������צ
UPDATE SSSC_Relic SET Last = '80' WHERE RelicType = 'RELIC_AKN_FROZEN_CLAW';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_ABILITY_AKN_FROZEN_CLAW' AND Name='Amount';
--��������Ϣ
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_AKN_FROZEN_CLAW_YIELD_FAITH' AND Name='Amount';
DELETE FROM SSSC_Relic_ActiveModifier WHERE ModifierId='MODFEAT_AKN_TIDE_BREATH_GRANT_TIDE_HUNT_KNIGHT';
--���
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_HAND_GUN';
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_AKN_HAND_GUN_MILITARY_PRODUCTION' AND Name='Amount';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_ABILITY_AKN_HAND_GUN_STRENGTH' AND Name='Amount';
UPDATE ModifierArguments SET Value='50' WHERE ModifierId='MODFEAT_ABILITY_AKN_HAND_GUN_COMBAT_YIELD' AND Name='PercentDefeatedStrength';
--����˹�䵶
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_AKN_CHACHECK_GRANT_ENVOY' AND Name='Amount';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_AKN_CHACHECK_GRANT_TITLE' AND Name='Delta';
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_ABILITY_AKN_CHACHECK_STRENGTH' AND Name='Amount';
UPDATE SSSC_Relic SET Last = '80' WHERE RelicType = 'RELIC_AKN_CHACHECK';
--һ�����
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_BLACKTEA';
--ǳ���ᳪ
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_AKN_SHALLOW_WHISPER_YIELD_CULTURE' AND Name='Amount';
UPDATE ModifierArguments SET Value='-1' WHERE ModifierId='MODFEAT_ABILITY_AKN_SHALLOW_WHISPER_ATTACHED' AND Name='Amount';
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_SHALLOW_WHISPER';
--����ָ��
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_AKN_SUPREME_RING_YIELD_GOLD' AND Name='Amount';
--���ιű�ģ��
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_AKN_DREAMBIND_CASTLE_YIELD_CULTURE' AND Name='Amount';
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_DREAMBIND_CASTLE';

--����֮��
UPDATE ModifierArguments SET Value='10' WHERE ModifierId='MODFEAT_CELESTIAL_TEAR_CAPITAL_FAITH' AND Name='Amount';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_CELESTIAL_TEAR_CAPITAL_6_TILE_FAITH' AND Name='Amount';
--������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_CONTINUUM';
UPDATE ModifierArguments SET Value='8' WHERE ModifierId='MODFEAT_CONTINUUM_DISTRICT_PRODUCTION' AND Name='Amount';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_CONTINUUM_YIELD_SCIENCE' AND Name='Amount';

--������˹��ӡ
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_DAEDALUS';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_DAEDALUS_SPY_BONUS' AND Name='Amount';
--��������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_E_S_TOP';

UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_E_S_TOP_YIELD_GOLD' AND Name='Amount';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_E_S_TOP_YIELD_SCIENCE' AND Name='Amount';
--����֮��
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_INFINITY_ROOT';
UPDATE ModifierArguments SET Value='4' WHERE ModifierId='MODFEAT_INFINITY_ROOT_GROWTH' AND Name='Amount';
UPDATE ModifierArguments SET Value='20' WHERE ModifierId='MODFEAT_INFINITY_ROOT_EXPANSION' AND Name='Amount';
UPDATE ModifierArguments SET Value='0' WHERE ModifierId='MODFEAT_INFINITY_ROOT_2_GPSCIENTIST' AND Name='Amount';
--ʱ��ˮ��
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_TIME_CRYSTAL';
UPDATE ModifierArguments SET Value='10' WHERE ModifierId='MODFEAT_PLASMIC_CORE_GROWTH' AND Name='Amount';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_TIME_CRYSTAL_PRODUCTION' AND Name='Amount';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_TIME_CRYSTAL_SCIENCE' AND Name='Amount';
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_TIME_CRYSTAL_CULTURE' AND Name='Amount';
--��������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_ETERNAL_THRONE';
UPDATE ModifierArguments SET Value='10' WHERE ModifierId='MODFEAT_ETERNAL_THRONE_YIELD_GOLD' AND Name='Amount';
--Ѫ������

--���������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_OCEAN_PULSE';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_AKN_OCEAN_PULSE_EMBARK_MOVEMENT' AND Name='Amount';
--�����Ĵ���
UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_AKN_CIVILIGHT_ETERNA_ALLOW_ACTIVATION' AND Name='Amount';
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_CIVILIGHT_ETERNA';
--Դʯ�β��
UPDATE SSSC_Relic SET Last = '90' WHERE RelicType = 'RELIC_AKN_O_IRIS';
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_AKN_O_IRIS_UNLOCK_CIVICS' AND Name='Amount';


--����С��

--��Ӣ��
UPDATE ModifierArguments SET Value='1' WHERE ModifierId='MODFEAT_AKN_WHITEFLOWER_ALLIANCE_POINT' AND Name='Amount';

--����������
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_B_N_U';
UPDATE ModifierArguments SET Value='3' WHERE ModifierId='MODFEAT_AKN_B_N_U_AUTO_THEME' AND Name='Amount';
--�������ȵĴ���

UPDATE ModifierArguments SET Value='2' WHERE ModifierId='MODFEAT_AKN_A_INSPIRATION_EUREKA_BONUS' AND Name='Amount';
UPDATE SSSC_Relic SET Last = '500' WHERE RelicType = 'RELIC_AKN_A_INSPIRATION';













