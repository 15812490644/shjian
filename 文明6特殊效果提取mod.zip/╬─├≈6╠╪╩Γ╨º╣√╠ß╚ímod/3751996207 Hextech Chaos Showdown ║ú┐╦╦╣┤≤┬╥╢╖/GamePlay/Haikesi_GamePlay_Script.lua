﻿-- Haikesi_GamePlay_Script
-- Author: 千川白浪
-- DateCreated: 2025-7-14 16:00:00
--------------------------------------------------------------
-- 海克斯大乱斗 — 服务端 GamePlay 脚本
-- 负责处理海克斯遴选效果：持久化、Modifier 挂载、Lua 效果层
--------------------------------------------------------------

--||======================= Debug ========================||--

-- 内存 Map：RelicType → ModifierId[]（在 Initialize 中构建）
local g_RelicModifierMap = nil

--||======================= Key ========================||--
local RelicsPropertyKey = 'PROP_NW_HAIKESI_RELICS'
local RelicsCountPropertyKey = 'PROP_NW_HAIKESI_RELIC_COUNT'
local RelicsSlotPropertyPrefix = 'PROP_NW_HAIKESI_RELIC_'
-- 仿生模仿 (MIMICRUNE) 能力选择相关：仅记录玩家最终选定的 Trait（tooltip 用）
local MimicTraitKey = 'PROP_NW_HAIKESI_MIMIC_TRAIT'
local HAIKESI_DEBUG_PREREQS = false
local g_PrereqDebugPrinted = {}

local function DebugPrereqOnce(key, message)
    if not HAIKESI_DEBUG_PREREQS or g_PrereqDebugPrinted[key] then return end
    g_PrereqDebugPrinted[key] = true
    print(message)
end

local function GetPlayerConfigTypes(playerID)
    local pConfig = PlayerConfigurations[playerID]
    if not pConfig then return nil, nil end
    return pConfig:GetCivilizationTypeName(), pConfig:GetLeaderTypeName()
end

-- 将标准速度回合数缩放为当前游戏速度下的等效回合数
-- 基于 GameSpeeds.CostMultiplier（标准=100, 快速≈67, 史诗=150, 马拉松=300）
local function ScaleTurnForGameSpeed(standardTurn)
    if standardTurn == nil then return nil end
    local gameSpeedType = GameConfiguration.GetGameSpeedType()
    local speedInfo = GameInfo.GameSpeeds[gameSpeedType]
    local multiplier = (speedInfo and speedInfo.CostMultiplier or 100)
    return math.floor(standardTurn * multiplier / 100 + 0.5)
end

local function IsRelicSelectionOnly(relicType)
    local relicDef = GameInfo.Haikesi_Relics[relicType]
    return relicDef ~= nil and relicDef.SelectionOnly == 1
end

local function GetRelicTypeFromIndex(index)
    for row in GameInfo.Haikesi_Relics() do
        if row.Index == index then
            return row.RelicType
        end
    end
    return nil
end

local function GetSelectedRelicTypeListForPlayer(pPlayer)
    local relicTypes = {}
    local count = tonumber(pPlayer:GetProperty(RelicsCountPropertyKey) or 0) or 0
    if count > 0 then
        for i = 1, count do
            local relicType = pPlayer:GetProperty(RelicsSlotPropertyPrefix .. i)
            if relicType ~= nil and GameInfo.Haikesi_Relics[relicType] ~= nil then
                table.insert(relicTypes, relicType)
            end
        end
    end
    if #relicTypes > 0 then
        return relicTypes
    end

    local prop = pPlayer:GetProperty(RelicsPropertyKey) or ""
    if prop ~= "" then
        for idxStr in string.gmatch(prop, "[^|]+") do
            local idx = tonumber(idxStr)
            if idx ~= nil then
                local relicType = GetRelicTypeFromIndex(idx)
                if relicType ~= nil then
                    table.insert(relicTypes, relicType)
                end
            end
        end
    end
    return relicTypes
end

local function GetSelectedRelicTypesForPlayer(pPlayer)
    local selected = {}
    for _, relicType in ipairs(GetSelectedRelicTypeListForPlayer(pPlayer)) do
        selected[relicType] = true
    end
    return selected
end

local function IsTechnologyPrerequisiteMet(pPlayer, techType, allowInProgress)
    local tech = GameInfo.Technologies[techType]
    if tech == nil then return false end

    local pTechs = pPlayer:GetTechs()
    if pTechs == nil then return false end
    if pTechs:HasTech(tech.Index) then return true end

    return allowInProgress == 1
        and (pTechs:GetResearchingTech() == tech.Index or pTechs:IsResearchingTech(tech.Index))
end

-- 检查玩家是否拥有指定 Trait：通过 ModCore 绑定的 PROPERTY_<TraitType> 判断（O(1)）
-- ModCore 给每个文明/领袖 Trait set PROPERTY_<TraitType>=1；替代遍历 CivilizationTraits/LeaderTraits 的 O(n) 旧逻辑
local function PlayerHasTrait(playerID, traitType)
    if playerID == nil or playerID == PlayerTypes.NONE then return false end
    if traitType == nil then return false end
    local pPlayer = Players[playerID]
    if pPlayer == nil then return false end
    return (pPlayer:GetProperty('PROPERTY_' .. traitType) or 0) > 0
end

local function AreRelicPrerequisitesMet(pPlayer, relicType, selectedTypes)
    local tableAvailable = GameInfo.Haikesi_Relic_Prerequisites ~= nil
    local matchedRows = 0

    if tableAvailable then
        for req in GameInfo.Haikesi_Relic_Prerequisites() do
            if req.RelicType == relicType then
                matchedRows = matchedRows + 1
                if req.PrerequisiteKind == 'RELIC' then
                    if not selectedTypes[req.PrerequisiteType] then
                        return false
                    end
                elseif req.PrerequisiteKind == 'TECHNOLOGY' then
                    if not IsTechnologyPrerequisiteMet(pPlayer, req.PrerequisiteType, req.AllowInProgress) then
                        return false
                    end
                elseif req.PrerequisiteKind == 'TRAIT' then
                    local playerID = pPlayer:GetID()
                    local hasTrait = PlayerHasTrait(playerID, req.PrerequisiteType)
                    local civType, leaderType = GetPlayerConfigTypes(playerID)
                    DebugPrereqOnce('trait:' .. relicType .. ':' .. req.PrerequisiteType,
                        '[Haikesi GamePlay DEBUG] Trait prereq check relic=' .. tostring(relicType)
                        .. ' required=' .. tostring(req.PrerequisiteType)
                        .. ' player=' .. tostring(playerID)
                        .. ' civ=' .. tostring(civType)
                        .. ' leader=' .. tostring(leaderType)
                        .. ' result=' .. tostring(hasTrait))
                    if not hasTrait then
                        return false
                    end
                elseif req.PrerequisiteKind == 'EXCLUDE_TRAIT' then
                    local playerID = pPlayer:GetID()
                    local hasTrait = PlayerHasTrait(playerID, req.PrerequisiteType)
                    DebugPrereqOnce('exclude_trait:' .. relicType .. ':' .. req.PrerequisiteType,
                        '[Haikesi GamePlay DEBUG] ExcludeTrait check relic=' .. tostring(relicType)
                        .. ' trait=' .. tostring(req.PrerequisiteType)
                        .. ' player=' .. tostring(playerID)
                        .. ' hasTrait=' .. tostring(hasTrait))
                    if hasTrait then
                        return false  -- 拥有该 Trait → 排除出刷新池
                    end
                else
                    return false
                end
            end
        end
    end

    DebugPrereqOnce('rows:' .. relicType,
        '[Haikesi GamePlay DEBUG] Prereq rows for relic=' .. tostring(relicType)
        .. ' tableAvailable=' .. tostring(tableAvailable)
        .. ' matchedRows=' .. tostring(matchedRows))
    return true
end
local function CanGrantRelicFromBonus(pPlayer, relicType, selectedTypes)
    local relicDef = GameInfo.Haikesi_Relics[relicType]
    if relicDef == nil or relicDef.IsActive ~= 1 then return false end
    if relicDef.SelectionOnly == 1 then return false end
    if selectedTypes[relicType] and relicDef.IsRepeatable ~= 1 then return false end
    if pPlayer:GetProperty('PROP_NW_HAIKESI_LOCKED_' .. relicType) == 1 then return false end

    -- 回合限制检查（以标准速度为准）
    if relicDef.MinTurn ~= nil or relicDef.MaxTurn ~= nil then
        local currentTurn = Game.GetCurrentGameTurn()
        local scaledMin = ScaleTurnForGameSpeed(relicDef.MinTurn)
        local scaledMax = ScaleTurnForGameSpeed(relicDef.MaxTurn)
        if scaledMin ~= nil and currentTurn < scaledMin then return false end
        if scaledMax ~= nil and currentTurn > scaledMax then return false end
    end

    return AreRelicPrerequisitesMet(pPlayer, relicType, selectedTypes)
end

--||======================= Core: apply one relic to one player ========================||--
function ApplyRelicToPlayer(iPlayer, relicType, isSelection)
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then
        print("[Haikesi GamePlay] invalid player id: " .. tostring(iPlayer))
        return false
    end

    local relicDef = GameInfo.Haikesi_Relics[relicType]
    if relicDef == nil then
        print("[Haikesi GamePlay] unknown relic type: " .. tostring(relicType))
        return false
    end
    if (not isSelection) and IsRelicSelectionOnly(relicType) then
        print("[Haikesi GamePlay] skipped selection-only bonus relic: " .. tostring(relicType))
        return false
    end

    local relicIndex = relicDef.Index
    local relicTypes = GetSelectedRelicTypeListForPlayer(pPlayer)
    table.insert(relicTypes, relicType)

    local relicIndexes = {}
    for _, selectedRelicType in ipairs(relicTypes) do
        local selectedRelicDef = GameInfo.Haikesi_Relics[selectedRelicType]
        if selectedRelicDef ~= nil then
            table.insert(relicIndexes, tostring(selectedRelicDef.Index))
        end
    end
    pPlayer:SetProperty(RelicsPropertyKey, table.concat(relicIndexes, "|"))
    pPlayer:SetProperty(RelicsCountPropertyKey, #relicTypes)
    pPlayer:SetProperty(RelicsSlotPropertyPrefix .. #relicTypes, relicType)

    local modifierIds = g_RelicModifierMap[relicType]
    if modifierIds then
        for _, modId in ipairs(modifierIds) do
            pPlayer:AttachModifierByID(modId)
            print("[Haikesi GamePlay] attached Modifier: " .. modId .. " -> Player" .. iPlayer)
        end
    end

    Haikesi_ApplyLuaEffect(iPlayer, relicType)

    print("[Haikesi GamePlay] Player" .. iPlayer .. " gained relic " .. relicType .. " (Index=" .. relicIndex .. ")")
    return true
end

--||======================= Main Event Handler ========================||--
-- AI 专属海克斯池（仅 NW_HAIKESI_AI_RELIC 开关开启时，AI 随玩家同步触发选其一）
-- 服务端仅做校验：relicType 必须属于 AI 池且 AI 未选过；随机选择由房主 UI 端决定（经 EXECUTE_SCRIPT 下发）
local AI_RELIC_TYPES = {
    'NW_AI_STATS_1', 'NW_AI_STATS_2', 'NW_AI_STATS_3', 'NW_AI_STATS_4', 'NW_AI_STATS_5', 'NW_AI_STATS_6',
    'NW_AI_ECHO_SETTLER', 'NW_AI_ECHO_BUILDER', 'NW_AI_ECHO_MELEE', 'NW_AI_ECHO_RANGED',
    'NW_AI_ECHO_LIGHT_CAVALRY', 'NW_AI_ECHO_HEAVY_CAVALRY', 'NW_AI_ECHO_ANTI_CAVALRY', 'NW_AI_ECHO_SIEGE',
}
local AI_RELIC_TYPE_SET = {}
for _, t in ipairs(AI_RELIC_TYPES) do AI_RELIC_TYPE_SET[t] = true end

function HaikesiSelectRelic(iPlayer, param)
    if param == nil or param.RelicType == nil then
        print("[Haikesi GamePlay] invalid HaikesiSelectRelic param")
        return
    end
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then
        print("[Haikesi GamePlay] invalid player id: " .. tostring(iPlayer))
        return
    end
    local relicType = param.RelicType

    if not ApplyRelicToPlayer(iPlayer, relicType, true) then
        return
    end

    if param.ExtraRelicTypes ~= nil then
        for _, extraType in ipairs(param.ExtraRelicTypes) do
            local selectedTypes = GetSelectedRelicTypesForPlayer(pPlayer)
            if CanGrantRelicFromBonus(pPlayer, extraType, selectedTypes)
                and ApplyRelicToPlayer(iPlayer, extraType, false) then
                print("[Haikesi GamePlay] Player" .. iPlayer .. " bonus relic " .. extraType)
            else
                print("[Haikesi GamePlay] rejected invalid bonus relic " .. tostring(extraType) .. " for Player" .. iPlayer)
            end
        end
    end

    -- PVE + AI 海克斯开关开：仅房主(Player0)请求时，处理其下发的 AI 海克斯选择
    -- 房主 UI 端为每个 AI 随机选一个未选过的 AI 专属海克斯，经 param.AIChoices = { [aiID] = relicType } 下发
    -- 服务端仅做校验：relicType 必须属于 AI 池 + 该 AI 未选过，拒绝非法/重复
    if iPlayer == 0 and pPlayer:IsHuman()
        and (GameConfiguration.GetValue('NW_HAIKESI_AI_RELIC') or false)
        and param.AIChoices ~= nil then
        for aiIDStr, aiRelic in pairs(param.AIChoices) do
            local aiID = tonumber(aiIDStr)
            if aiID == nil then
                print("[Haikesi GamePlay] AIChoices 非法 aiID: " .. tostring(aiIDStr))
            elseif not AI_RELIC_TYPE_SET[aiRelic] then
                print("[Haikesi GamePlay] AIChoices 非法 relicType: " .. tostring(aiRelic))
            else
                local pAI = Players[aiID]
                if pAI ~= nil and not pAI:IsHuman() and not pAI:IsBarbarian() then
                    local selectedTypes = GetSelectedRelicTypesForPlayer(pAI)
                    if not selectedTypes[aiRelic] then
                        if ApplyRelicToPlayer(aiID, aiRelic, true) then
                            print("[Haikesi GamePlay] AI Player" .. aiID .. " gained AI relic " .. aiRelic)
                        end
                    else
                        print("[Haikesi GamePlay] AI Player" .. aiID .. " 已选过 " .. aiRelic .. "，跳过")
                    end
                end
            end
        end
    end
end

--||======================= MIMIC 能力选择确认 ========================||--
-- 玩家在能力选择 UI 点选某 Trait 后，UI 经 EXECUTE_SCRIPT(OnStart='HaikesiSelectAbility') 下发
-- 遍历该 Trait 的 TraitModifiers，逐个 AttachModifierByID 永久挂到玩家（含 ModCore 派生的
-- PROPERTY_<Trait> 标记 Modifier，使 PlayerHasTrait 对该 Trait 返回 true）
function HaikesiSelectAbility(iPlayer, param)
    if param == nil or param.TraitType == nil then
        print("[Haikesi GamePlay] invalid HaikesiSelectAbility param")
        return
    end
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then return end
    local traitType = param.TraitType

    -- 遍历 TraitModifiers，Attach 该 Trait 的所有 Modifier
    local attached = 0
    for row in GameInfo.TraitModifiers() do
        if row.TraitType == traitType then
            pPlayer:AttachModifierByID(row.ModifierId)
            attached = attached + 1
        end
    end
    print("[Haikesi GamePlay] MIMIC 玩家" .. iPlayer .. " 获得能力 " .. traitType .. " (attached " .. attached .. " modifiers)")

    -- 记录选中的 Trait（已选海克斯 tooltip 追加用）
    pPlayer:SetProperty(MimicTraitKey, traitType)

    -- UI 关闭由本地能力窗自行处理（Gameplay 不通知 UI）
end
--||======================= Lua Effect ========================||--
-- 混合层：部分海克斯效果必须 Lua 实现（无原生 Modifier 对应）
-- 占位检测仅对残存占位项生效（目前已无残留）
local PLACEHOLDER_MODIFIER_ID = 'MODIFIER_NW_HAIKESI_PLACEHOLDER_UNIT'

-- 判断某海克斯是否仍为占位（即其 Modifier 列表里只有占位 Modifier）
local function IsRelicPlaceholder(relicType)
    local modifierIds = g_RelicModifierMap[relicType]
    if not modifierIds or #modifierIds == 0 then
        return true  -- 无任何 Modifier 映射，按占位处理
    end
    for _, modId in ipairs(modifierIds) do
        if modId ~= PLACEHOLDER_MODIFIER_ID then
            return false  -- 存在非占位 Modifier，视为已迁移
        end
    end
    return true
end

-- DICEMANIAC 持久化 Key：记录该玩家是否拥有额外刷新
local DICEMANIAC_PROP_KEY = 'PROP_NW_HAIKESI_DICEMANIAC'

-- DOUBLEEXISTENCERUNE 持久化 Key：记录该玩家是否被禁止刷新海克斯
local NO_REROLL_PROP_KEY = 'PROP_NW_HAIKESI_NO_REROLL'

function Haikesi_ApplyLuaEffect(iPlayer, relicType)
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then
        print("[Haikesi GamePlay] 错误: Haikesi_ApplyLuaEffect — 无效玩家ID: " .. tostring(iPlayer))
        return
    end

    -- ==============================
    -- CIRCLEOFDEATH 死亡之环
    -- 删除首都7环内全部非己方单位；删除首都9环外全部己方单位
    -- ==============================
    if relicType == 'CIRCLEOFDEATHRUNE' then
        local pCapital = pPlayer:GetCities():GetCapitalCity()
        if pCapital == nil then
            print("[Haikesi GamePlay] CIRCLEOFDEATH 跳过 — 无首都")
            return
        end
        local capX, capY = pCapital:GetX(), pCapital:GetY()
        local unitsToKill = {}

        -- 非己方单位（含蛮族、城邦、其他文明）：首都 7 环以内
        for iOtherID = 0, 63 do
            if iOtherID ~= iPlayer then
                local pOther = Players[iOtherID]
                if pOther ~= nil then
                    local units = pOther:GetUnits()
                    if units ~= nil then
                        for _, unit in units:Members() do
                            if unit and Map.GetPlotDistance(capX, capY, unit:GetX(), unit:GetY()) <= 7 then
                                table.insert(unitsToKill, unit)
                            end
                        end
                    end
                end
            end
        end

        -- 己方单位：首都 9 环以外
        local myUnits = pPlayer:GetUnits()
        if myUnits ~= nil then
            for _, unit in myUnits:Members() do
                if unit and Map.GetPlotDistance(capX, capY, unit:GetX(), unit:GetY()) > 9 then
                    table.insert(unitsToKill, unit)
                end
            end
        end

        local killCount = 0
        for _, unit in ipairs(unitsToKill) do
            UnitManager.Kill(unit, true)
            killCount = killCount + 1
        end
        print("[Haikesi GamePlay] CIRCLEOFDEATH 删除 " .. killCount .. " 个单位")
        return
    end

    -- ==============================
    -- DICEMANIAC 掷骰狂人
    -- 后续选择海克斯时，所有海克斯可额外刷新一次（UI 读取 PROP 实现）
    -- ==============================
    if relicType == 'DICEMANIACRUNE' then
        pPlayer:SetProperty(DICEMANIAC_PROP_KEY, 1)
        -- The same-turn bonus relic is selected once in UI and passed through
        -- ExtraRelicTypes. Do not roll again here, or MP peers can persist a
        -- different relic list than the player confirmed.
        print("[Haikesi GamePlay] DICEMANIAC bonus reroll enabled (Player" .. iPlayer .. ")")
        return
    end

    -- ==============================
    -- DOUBLEEXISTENCERUNE 手快全拿
    -- "另外两个海克斯"由 UI 侧通过 ExtraRelicTypes 一并下发，服务端循环 ApplyRelicToPlayer 处理。
    -- 本分支只负责副作用：之后无法再刷新海克斯（UI 读取 NO_REROLL_PROP_KEY 锁定 RerollCard）。
    -- ==============================
    if relicType == 'DOUBLEEXISTENCERUNE' then
        pPlayer:SetProperty(NO_REROLL_PROP_KEY, 1)
        -- 全队锁定：同队所有人类玩家不再能刷出手快全选
        local myTeam = pPlayer:GetTeam()
        for i = 0, 63 do
            local pOther = Players[i]
            if pOther and pOther:IsHuman() and pOther:GetTeam() == myTeam then
                pOther:SetProperty('PROP_NW_HAIKESI_LOCKED_DOUBLEEXISTENCERUNE', 1)
            end
        end
        print("[Haikesi GamePlay] DOUBLEEXISTENCE — 刷新已锁定 (Player" .. iPlayer .. ")")
        return
    end

    -- ==============================
    -- HASTYSCRIBBLERUNE 潦草急就：清空当前所有金币（送大将军由 SQL GRANT 实现）
    -- 无原生"清零金币"Modifier，必须 Lua。GetTreasury():SetGoldBalance(0) 置零。
    -- ==============================
    if relicType == 'HASTYSCRIBBLERUNE' then
        local pTreasury = pPlayer:GetTreasury()
        if pTreasury and pTreasury.SetGoldBalance then
            pTreasury:SetGoldBalance(0)
            print("[Haikesi GamePlay] HASTYSCRIBBLE — 清空玩家" .. iPlayer .. " 金币")
        else
            print("[Haikesi GamePlay] 警告: GetTreasury().SetGoldBalance 不可用（HASTYSCRIBBLE）")
        end
        return
    end

    -- ==============================
    -- MIMICRUNE 仿生模仿：空 Marker 已在 ApplyRelicToPlayer 标记非占位
    -- 抽 10 项 + 弹能力窗 全在 UI 端（math.random），Gameplay 不参与
    -- 玩家在能力窗选定的 Trait 由 HaikesiSelectAbility 挂 Modifier
    -- ==============================
    if relicType == 'MIMICRUNE' then
        print("[Haikesi GamePlay] MIMIC 玩家" .. iPlayer .. " 触发能力选择（UI 端处理）")
        return
    end

    -- ==============================
    -- 占位补偿：无真实效果的海克斯补 100 金币过渡（目前已无残留占位）
    -- ==============================
    if not IsRelicPlaceholder(relicType) then
        return
    end
    pPlayer:GetTreasury():ChangeGoldBalance(100)
    print("[Haikesi GamePlay] Lua 占位补偿：玩家" .. iPlayer .. " 获得 100 金币 → " .. relicType)
end

--||======================= INIT ========================||--
function Initialize()
    -- 构建 RelicType → ModifierId[] 内存 Map（一次性，替代运行时全表遍历）
    g_RelicModifierMap = {}
    local rowCount = 0
    for row in GameInfo.Haikesi_Relic_Modifiers() do
        if not g_RelicModifierMap[row.RelicType] then
            g_RelicModifierMap[row.RelicType] = {}
        end
        table.insert(g_RelicModifierMap[row.RelicType], row.ModifierId)
        rowCount = rowCount + 1
    end
    print("[Haikesi GamePlay] RelicModifierMap 构建完成，行数 = " .. rowCount)

    GameEvents.HaikesiSelectRelic.Add(HaikesiSelectRelic)
    GameEvents.HaikesiSelectAbility.Add(HaikesiSelectAbility)

    print("[Haikesi GamePlay] Script 初始化完成")
end

Events.LoadScreenClose.Add(Initialize)
