-- Haikesi_GamePlay_Script
-- Author: 千川白浪
-- DateCreated: 2025-7-14 16:00:00
--------------------------------------------------------------
-- 海克斯大乱斗 — 服务端 GamePlay 脚本
-- 负责处理海克斯遴选效果：持久化、Modifier 挂载、Lua 效果层
--------------------------------------------------------------

--||======================= Debug ========================||--

-- 内存 Map：RelicType → ModifierId[]（在 Initialize 中构建）
local g_RelicModifierMap = nil

--||======================= Key ========================||--
local RelicsPropertyKey = 'PROP_NW_HAIKESI_RELICS'
local RelicsCountPropertyKey = 'PROP_NW_HAIKESI_RELIC_COUNT'
local RelicsSlotPropertyPrefix = 'PROP_NW_HAIKESI_RELIC_'
local FANTHEHAMMER_MOVE_AFTER_ATTACK_KEY = 'PROP_NW_HAIKESI_FANTHEHAMMER_MOVE_AFTER_ATTACK'
local FANTHEHAMMER_ATTACK_STACKS_KEY = 'PROP_NW_HAIKESI_FANTHEHAMMER_ATTACK_STACKS'
local HEARTSTEEL_STACKS_KEY = 'PROP_NW_HAIKESI_HEARTSTEEL_STACKS'
-- 仿生模仿 (MIMICRUNE) 能力选择相关：仅记录玩家最终选定的 Trait（tooltip 用）
local MimicTraitKey = 'PROP_NW_HAIKESI_MIMIC_TRAIT'
local HAIKESI_DEBUG_PREREQS = false
local g_PrereqDebugPrinted = {}

local function DebugPrereqOnce(key, message)
    if not HAIKESI_DEBUG_PREREQS or g_PrereqDebugPrinted[key] then return end
    g_PrereqDebugPrinted[key] = true
    print(message)
end

local function GetPlayerConfigTypes(playerID)
    local pConfig = PlayerConfigurations[playerID]
    if not pConfig then return nil, nil end
    return pConfig:GetCivilizationTypeName(), pConfig:GetLeaderTypeName()
end

-- 将标准速度回合数缩放为当前游戏速度下的等效回合数
-- 基于 GameSpeeds.CostMultiplier（标准=100, 快速≈67, 史诗=150, 马拉松=300）
local function ScaleTurnForGameSpeed(standardTurn)
    if standardTurn == nil then return nil end
    local gameSpeedType = GameConfiguration.GetGameSpeedType()
    local speedInfo = GameInfo.GameSpeeds[gameSpeedType]
    local multiplier = (speedInfo and speedInfo.CostMultiplier or 100)
    return math.floor(standardTurn * multiplier / 100 + 0.5)
end

local function IsRelicSelectionOnly(relicType)
    local relicDef = GameInfo.Haikesi_Relics[relicType]
    return relicDef ~= nil and relicDef.SelectionOnly == 1
end

local function GetRelicTypeFromIndex(index)
    for row in GameInfo.Haikesi_Relics() do
        if row.Index == index then
            return row.RelicType
        end
    end
    return nil
end

local function GetSelectedRelicTypeListForPlayer(pPlayer)
    local relicTypes = {}
    local count = tonumber(pPlayer:GetProperty(RelicsCountPropertyKey) or 0) or 0
    if count > 0 then
        for i = 1, count do
            local relicType = pPlayer:GetProperty(RelicsSlotPropertyPrefix .. i)
            if relicType ~= nil and GameInfo.Haikesi_Relics[relicType] ~= nil then
                table.insert(relicTypes, relicType)
            end
        end
    end
    if #relicTypes > 0 then
        return relicTypes
    end

    local prop = pPlayer:GetProperty(RelicsPropertyKey) or ""
    if prop ~= "" then
        for idxStr in string.gmatch(prop, "[^|]+") do
            local idx = tonumber(idxStr)
            if idx ~= nil then
                local relicType = GetRelicTypeFromIndex(idx)
                if relicType ~= nil then
                    table.insert(relicTypes, relicType)
                end
            end
        end
    end
    return relicTypes
end

local function GetSelectedRelicTypesForPlayer(pPlayer)
    local selected = {}
    for _, relicType in ipairs(GetSelectedRelicTypeListForPlayer(pPlayer)) do
        selected[relicType] = true
    end
    return selected
end

local function GetSelectedRelicCountsForPlayer(pPlayer)
    local counts = {}
    for _, relicType in ipairs(GetSelectedRelicTypeListForPlayer(pPlayer)) do
        counts[relicType] = (counts[relicType] or 0) + 1
    end
    return counts
end

local function HasReachedSelectionLimit(relicDef, selectedTypes, selectedCounts)
    local selectedCount = selectedCounts[relicDef.RelicType] or 0
    local maxSelections = tonumber(relicDef.MaxSelections)
    if maxSelections ~= nil and selectedCount >= maxSelections then
        return true
    end
    return selectedTypes[relicDef.RelicType] and relicDef.IsRepeatable ~= 1
end

local function IsTechnologyPrerequisiteMet(pPlayer, techType, allowInProgress)
    local tech = GameInfo.Technologies[techType]
    if tech == nil then return false end

    local pTechs = pPlayer:GetTechs()
    if pTechs == nil then return false end
    if pTechs:HasTech(tech.Index) then return true end

    return allowInProgress == 1
        and (pTechs:GetResearchingTech() == tech.Index or pTechs:IsResearchingTech(tech.Index))
end

-- 检查玩家是否拥有指定 Trait：通过 ModCore 绑定的 PROPERTY_<TraitType> 判断（O(1)）
-- ModCore 给每个文明/领袖 Trait set PROPERTY_<TraitType>=1；替代遍历 CivilizationTraits/LeaderTraits 的 O(n) 旧逻辑
local function PlayerHasTrait(playerID, traitType)
    if playerID == nil or playerID == PlayerTypes.NONE then return false end
    if traitType == nil then return false end
    local pPlayer = Players[playerID]
    if pPlayer == nil then return false end
    return (pPlayer:GetProperty('PROPERTY_' .. traitType) or 0) > 0
end

local function AreRelicPrerequisitesMet(pPlayer, relicType, selectedTypes)
    local tableAvailable = GameInfo.Haikesi_Relic_Prerequisites ~= nil
    local matchedRows = 0

    if tableAvailable then
        for req in GameInfo.Haikesi_Relic_Prerequisites() do
            if req.RelicType == relicType then
                matchedRows = matchedRows + 1
                if req.PrerequisiteKind == 'RELIC' then
                    if not selectedTypes[req.PrerequisiteType] then
                        return false
                    end
                elseif req.PrerequisiteKind == 'TECHNOLOGY' then
                    if not IsTechnologyPrerequisiteMet(pPlayer, req.PrerequisiteType, req.AllowInProgress) then
                        return false
                    end
                elseif req.PrerequisiteKind == 'TRAIT' then
                    local playerID = pPlayer:GetID()
                    local hasTrait = PlayerHasTrait(playerID, req.PrerequisiteType)
                    local civType, leaderType = GetPlayerConfigTypes(playerID)
                    DebugPrereqOnce('trait:' .. relicType .. ':' .. req.PrerequisiteType,
                        '[Haikesi GamePlay DEBUG] Trait prereq check relic=' .. tostring(relicType)
                        .. ' required=' .. tostring(req.PrerequisiteType)
                        .. ' player=' .. tostring(playerID)
                        .. ' civ=' .. tostring(civType)
                        .. ' leader=' .. tostring(leaderType)
                        .. ' result=' .. tostring(hasTrait))
                    if not hasTrait then
                        return false
                    end
                elseif req.PrerequisiteKind == 'EXCLUDE_TRAIT' then
                    local playerID = pPlayer:GetID()
                    local hasTrait = PlayerHasTrait(playerID, req.PrerequisiteType)
                    DebugPrereqOnce('exclude_trait:' .. relicType .. ':' .. req.PrerequisiteType,
                        '[Haikesi GamePlay DEBUG] ExcludeTrait check relic=' .. tostring(relicType)
                        .. ' trait=' .. tostring(req.PrerequisiteType)
                        .. ' player=' .. tostring(playerID)
                        .. ' hasTrait=' .. tostring(hasTrait))
                    if hasTrait then
                        return false  -- 拥有该 Trait → 排除出刷新池
                    end
                else
                    return false
                end
            end
        end
    end

    DebugPrereqOnce('rows:' .. relicType,
        '[Haikesi GamePlay DEBUG] Prereq rows for relic=' .. tostring(relicType)
        .. ' tableAvailable=' .. tostring(tableAvailable)
        .. ' matchedRows=' .. tostring(matchedRows))
    return true
end
local function CanGrantRelicFromBonus(pPlayer, relicType, selectedTypes)
    local relicDef = GameInfo.Haikesi_Relics[relicType]
    if relicDef == nil or relicDef.IsActive ~= 1 then return false end
    if relicDef.SelectionOnly == 1 then return false end
    if HasReachedSelectionLimit(relicDef, selectedTypes, GetSelectedRelicCountsForPlayer(pPlayer)) then return false end
    if pPlayer:GetProperty('PROP_NW_HAIKESI_LOCKED_' .. relicType) == 1 then return false end

    -- 回合限制检查（以标准速度为准）
    if relicDef.MinTurn ~= nil or relicDef.MaxTurn ~= nil then
        local currentTurn = Game.GetCurrentGameTurn()
        local scaledMin = ScaleTurnForGameSpeed(relicDef.MinTurn)
        local scaledMax = ScaleTurnForGameSpeed(relicDef.MaxTurn)
        if scaledMin ~= nil and currentTurn < scaledMin then return false end
        if scaledMax ~= nil and currentTurn > scaledMax then return false end
    end

    return AreRelicPrerequisitesMet(pPlayer, relicType, selectedTypes)
end

--||======================= Core: apply one relic to one player ========================||--
function ApplyRelicToPlayer(iPlayer, relicType, isSelection)
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then
        print("[Haikesi GamePlay] invalid player id: " .. tostring(iPlayer))
        return false
    end

    local relicDef = GameInfo.Haikesi_Relics[relicType]
    if relicDef == nil then
        print("[Haikesi GamePlay] unknown relic type: " .. tostring(relicType))
        return false
    end
    if (not isSelection) and IsRelicSelectionOnly(relicType) then
        print("[Haikesi GamePlay] skipped selection-only bonus relic: " .. tostring(relicType))
        return false
    end

    local relicIndex = relicDef.Index
    local relicTypes = GetSelectedRelicTypeListForPlayer(pPlayer)
    table.insert(relicTypes, relicType)

    local relicIndexes = {}
    for _, selectedRelicType in ipairs(relicTypes) do
        local selectedRelicDef = GameInfo.Haikesi_Relics[selectedRelicType]
        if selectedRelicDef ~= nil then
            table.insert(relicIndexes, tostring(selectedRelicDef.Index))
        end
    end
    pPlayer:SetProperty(RelicsPropertyKey, table.concat(relicIndexes, "|"))
    pPlayer:SetProperty(RelicsCountPropertyKey, #relicTypes)
    pPlayer:SetProperty(RelicsSlotPropertyPrefix .. #relicTypes, relicType)

    if relicType == 'MOREFOODRUNE' then
        local selectedCount = GetSelectedRelicCountsForPlayer(pPlayer)[relicType] or 0
        local stackModifierId = 'MODIFIER_NW_MOREFOOD_MINE_FOOD_STACK_' .. tostring(selectedCount)
        pPlayer:AttachModifierByID(stackModifierId)
        print("[Haikesi GamePlay] attached Modifier: " .. stackModifierId .. " -> Player" .. iPlayer)
    else
        local modifierIds = g_RelicModifierMap[relicType]
        if modifierIds then
            for _, modId in ipairs(modifierIds) do
                pPlayer:AttachModifierByID(modId)
                print("[Haikesi GamePlay] attached Modifier: " .. modId .. " -> Player" .. iPlayer)
            end
        end
    end

    Haikesi_ApplyLuaEffect(iPlayer, relicType)

    print("[Haikesi GamePlay] Player" .. iPlayer .. " gained relic " .. relicType .. " (Index=" .. relicIndex .. ")")
    return true
end

--||======================= Main Event Handler ========================||--
-- AI 专属海克斯池（仅 NW_HAIKESI_AI_RELIC 开关开启时，AI 随玩家同步触发选其一）
-- 服务端仅做校验：relicType 必须属于 AI 池且未违反重复/次数上限；随机选择由房主 UI 端决定（经 EXECUTE_SCRIPT 下发）
local AI_RELIC_TYPES = {
    'NW_AI_STATS_1', 'NW_AI_STATS_2', 'NW_AI_STATS_3', 'NW_AI_STATS_4', 'NW_AI_STATS_5', 'NW_AI_STATS_6',
    'NW_AI_ECHO_SETTLER', 'NW_AI_ECHO_BUILDER', 'NW_AI_ECHO_MELEE', 'NW_AI_ECHO_RANGED',
    'NW_AI_ECHO_LIGHT_CAVALRY', 'NW_AI_ECHO_HEAVY_CAVALRY', 'NW_AI_ECHO_ANTI_CAVALRY', 'NW_AI_ECHO_SIEGE',
}
local AI_RELIC_TYPE_SET = {}
for _, t in ipairs(AI_RELIC_TYPES) do AI_RELIC_TYPE_SET[t] = true end
local function CanGrantAIRelicToPlayer(pAI, relicType)
    if not AI_RELIC_TYPE_SET[relicType] then return false end

    local relicDef = GameInfo.Haikesi_Relics[relicType]
    if relicDef == nil then return false end

    local selectedCounts = GetSelectedRelicCountsForPlayer(pAI)
    local selectedCount = selectedCounts[relicType] or 0
    local maxSelections = tonumber(relicDef.MaxSelections)
    if maxSelections ~= nil and selectedCount >= maxSelections then
        return false
    end
    return selectedCount == 0 or relicDef.IsRepeatable == 1
end

function HaikesiSelectRelic(iPlayer, param)
    if param == nil or param.RelicType == nil then
        print("[Haikesi GamePlay] invalid HaikesiSelectRelic param")
        return
    end
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then
        print("[Haikesi GamePlay] invalid player id: " .. tostring(iPlayer))
        return
    end
    local relicType = param.RelicType

    if not ApplyRelicToPlayer(iPlayer, relicType, true) then
        return
    end

    if param.ExtraRelicTypes ~= nil then
        for _, extraType in ipairs(param.ExtraRelicTypes) do
            local selectedTypes = GetSelectedRelicTypesForPlayer(pPlayer)
            if CanGrantRelicFromBonus(pPlayer, extraType, selectedTypes)
                and ApplyRelicToPlayer(iPlayer, extraType, false) then
                print("[Haikesi GamePlay] Player" .. iPlayer .. " bonus relic " .. extraType)
            else
                print("[Haikesi GamePlay] rejected invalid bonus relic " .. tostring(extraType) .. " for Player" .. iPlayer)
            end
        end
    end

    -- PVE + AI 海克斯开关开：仅房主(Player0)请求时，处理其下发的 AI 海克斯选择
    -- 房主 UI 端为每个 AI 随机选一个未达到上限的 AI 专属海克斯，经 param.AIChoices = { [aiID] = relicType } 下发
    -- 服务端仅做校验：relicType 必须属于 AI 池 + 符合重复/次数上限，拒绝非法或超限选择
    if iPlayer == 0 and pPlayer:IsHuman()
        and (GameConfiguration.GetValue('NW_HAIKESI_AI_RELIC') or false)
        and param.AIChoices ~= nil then
        for aiIDStr, aiRelic in pairs(param.AIChoices) do
            local aiID = tonumber(aiIDStr)
            if aiID == nil then
                print("[Haikesi GamePlay] AIChoices 非法 aiID: " .. tostring(aiIDStr))
            elseif not AI_RELIC_TYPE_SET[aiRelic] then
                print("[Haikesi GamePlay] AIChoices 非法 relicType: " .. tostring(aiRelic))
            else
                local pAI = Players[aiID]
                if pAI ~= nil and not pAI:IsHuman() and not pAI:IsBarbarian() then
                    if CanGrantAIRelicToPlayer(pAI, aiRelic) then
                        if ApplyRelicToPlayer(aiID, aiRelic, true) then
                            print("[Haikesi GamePlay] AI Player" .. aiID .. " gained AI relic " .. aiRelic)
                        end
                    else
                        print("[Haikesi GamePlay] AI Player" .. aiID .. " 的 " .. aiRelic .. " 不可重复或已达上限，跳过")
                    end
                end
            end
        end
    end
end

--||======================= MIMIC 能力选择确认 ========================||--
-- 玩家在能力选择 UI 点选某 Trait 后，UI 经 EXECUTE_SCRIPT(OnStart='HaikesiSelectAbility') 下发
-- 遍历该 Trait 的 TraitModifiers，逐个 AttachModifierByID 永久挂到玩家（含 ModCore 派生的
-- PROPERTY_<Trait> 标记 Modifier，使 PlayerHasTrait 对该 Trait 返回 true）
function HaikesiSelectAbility(iPlayer, param)
    if param == nil or param.TraitType == nil then
        print("[Haikesi GamePlay] invalid HaikesiSelectAbility param")
        return
    end
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then return end
    local traitType = param.TraitType

    -- 遍历 TraitModifiers，Attach 该 Trait 的所有 Modifier
    local attached = 0
    for row in GameInfo.TraitModifiers() do
        if row.TraitType == traitType then
            pPlayer:AttachModifierByID(row.ModifierId)
            attached = attached + 1
        end
    end
    print("[Haikesi GamePlay] MIMIC 玩家" .. iPlayer .. " 获得能力 " .. traitType .. " (attached " .. attached .. " modifiers)")

    -- 记录选中的 Trait（已选海克斯 tooltip 追加用）
    pPlayer:SetProperty(MimicTraitKey, traitType)

    -- UI 关闭由本地能力窗自行处理（Gameplay 不通知 UI）
end
--||======================= Lua Effect ========================||--
-- 混合层：部分海克斯效果必须 Lua 实现（无原生 Modifier 对应）
-- 占位检测仅对残存占位项生效（目前已无残留）
local PLACEHOLDER_MODIFIER_ID = 'MODIFIER_NW_HAIKESI_PLACEHOLDER_UNIT'

-- 判断某海克斯是否仍为占位（即其 Modifier 列表里只有占位 Modifier）
local function IsRelicPlaceholder(relicType)
    local modifierIds = g_RelicModifierMap[relicType]
    if not modifierIds or #modifierIds == 0 then
        return true  -- 无任何 Modifier 映射，按占位处理
    end
    for _, modId in ipairs(modifierIds) do
        if modId ~= PLACEHOLDER_MODIFIER_ID then
            return false  -- 存在非占位 Modifier，视为已迁移
        end
    end
    return true
end

-- DICEMANIAC 持久化 Key：记录该玩家是否拥有额外刷新
local DICEMANIAC_PROP_KEY = 'PROP_NW_HAIKESI_DICEMANIAC'

-- DOUBLEEXISTENCERUNE legacy Key：旧存档曾用它记录禁刷；UI 现在按 -1 刷新修正兼容
local NO_REROLL_PROP_KEY = 'PROP_NW_HAIKESI_NO_REROLL'
local REROLL_DELTA_PROP_KEY = 'PROP_NW_HAIKESI_REROLL_DELTA'

local COMPENSATION_GOLD_PER_CITY = 1000
local COMPENSATION_PAYMENT_TURNS = 30
local COMPENSATION_REMAINING_GOLD_KEY = 'PROP_NW_HAIKESI_COMPENSATION_REMAINING_GOLD'
local COMPENSATION_REMAINING_TURNS_KEY = 'PROP_NW_HAIKESI_COMPENSATION_REMAINING_TURNS'

local function GetRelicSelectionCountForPlayer(pPlayer, relicType)
    return GetSelectedRelicCountsForPlayer(pPlayer)[relicType] or 0
end

local function AddPlayerRerollDelta(pPlayer, amount)
    local current = pPlayer:GetProperty(REROLL_DELTA_PROP_KEY) or 0
    pPlayer:SetProperty(REROLL_DELTA_PROP_KEY, current + amount)
end

local function CountPlayerCities(pPlayer)
    if pPlayer == nil or pPlayer:GetCities() == nil then return 0 end
    local count = 0
    for _, city in pPlayer:GetCities():Members() do
        count = count + 1
    end
    return count
end

local function IsCompensationRecipient(iPlayer, iOtherPlayer)
    if iOtherPlayer == iPlayer then return false end
    local pOther = Players[iOtherPlayer]
    if pOther == nil then return false end
    if pOther.IsAlive ~= nil and not pOther:IsAlive() then return false end
    if pOther.IsHuman ~= nil and pOther:IsHuman() then return false end
    if pOther.IsBarbarian ~= nil and pOther:IsBarbarian() then return false end
    if pOther.IsFreeCities ~= nil and pOther:IsFreeCities() then return false end
    if pOther.IsMajor ~= nil and not pOther:IsMajor() then return false end
    return pOther:GetTreasury() ~= nil
end

local function GetCompensationRecipients(iPlayer)
    local recipients = {}
    for iOtherPlayer = 0, 63 do
        if IsCompensationRecipient(iPlayer, iOtherPlayer) then
            table.insert(recipients, iOtherPlayer)
        end
    end
    return recipients
end

local function StartCompensationSchedule(iPlayer, pPlayer)
    local cityCount = CountPlayerCities(pPlayer)
    local grantGold = cityCount * COMPENSATION_GOLD_PER_CITY
    if grantGold > 0 then
        pPlayer:GetTreasury():ChangeGoldBalance(grantGold)
    end

    local paymentGold = math.floor(grantGold / 2)
    local existingGold = tonumber(pPlayer:GetProperty(COMPENSATION_REMAINING_GOLD_KEY) or 0) or 0
    pPlayer:SetProperty(COMPENSATION_REMAINING_GOLD_KEY, existingGold + paymentGold)
    pPlayer:SetProperty(COMPENSATION_REMAINING_TURNS_KEY, COMPENSATION_PAYMENT_TURNS)

    print('[Haikesi GamePlay] COMPENSATION player=' .. tostring(iPlayer)
        .. ' cities=' .. tostring(cityCount)
        .. ' grantGold=' .. tostring(grantGold)
        .. ' paymentGold=' .. tostring(paymentGold)
        .. ' turns=' .. tostring(COMPENSATION_PAYMENT_TURNS))
end

local function OnCompensationPlayerTurnStarted(iPlayer)
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then return end

    local remainingGold = tonumber(pPlayer:GetProperty(COMPENSATION_REMAINING_GOLD_KEY) or 0) or 0
    local remainingTurns = tonumber(pPlayer:GetProperty(COMPENSATION_REMAINING_TURNS_KEY) or 0) or 0
    if remainingGold <= 0 or remainingTurns <= 0 then return end

    local recipients = GetCompensationRecipients(iPlayer)
    if #recipients <= 0 then
        pPlayer:SetProperty(COMPENSATION_REMAINING_GOLD_KEY, 0)
        pPlayer:SetProperty(COMPENSATION_REMAINING_TURNS_KEY, 0)
        print('[Haikesi GamePlay] COMPENSATION cleared: no AI recipients for player=' .. tostring(iPlayer))
        return
    end

    local turnGold = math.ceil(remainingGold / remainingTurns)
    if turnGold > remainingGold then
        turnGold = remainingGold
    end

    local baseShare = math.floor(turnGold / #recipients)
    local remainder = turnGold - (baseShare * #recipients)
    pPlayer:GetTreasury():ChangeGoldBalance(-turnGold)

    for index, iRecipient in ipairs(recipients) do
        local amount = baseShare
        if index <= remainder then
            amount = amount + 1
        end
        if amount > 0 then
            Players[iRecipient]:GetTreasury():ChangeGoldBalance(amount)
        end
    end

    pPlayer:SetProperty(COMPENSATION_REMAINING_GOLD_KEY, remainingGold - turnGold)
    pPlayer:SetProperty(COMPENSATION_REMAINING_TURNS_KEY, remainingTurns - 1)

    print('[Haikesi GamePlay] COMPENSATION payment player=' .. tostring(iPlayer)
        .. ' total=' .. tostring(turnGold)
        .. ' recipients=' .. tostring(#recipients)
        .. ' remainingGold=' .. tostring(remainingGold - turnGold)
        .. ' remainingTurns=' .. tostring(remainingTurns - 1))
end

local function ApplyMadScientistSelection(iPlayer, pPlayer)
    local selectedCount = GetRelicSelectionCountForPlayer(pPlayer, 'MADSCIENTISTRUNE')
    local gpModifier = 'MODIFIER_NW_MADSCIENTIST_GP_4'
    if selectedCount <= 1 then
        gpModifier = 'MODIFIER_NW_MADSCIENTIST_GP_2'
    end

    pPlayer:AttachModifierByID(gpModifier)
    if selectedCount == 1 then
        pPlayer:AttachModifierByID('MODIFIER_NW_MADSCIENTIST_BOOST')
    end

    print('[Haikesi GamePlay] MADSCIENTIST player=' .. tostring(iPlayer)
        .. ' count=' .. tostring(selectedCount)
        .. ' gpModifier=' .. tostring(gpModifier)
        .. ' unlock=' .. tostring(selectedCount == 1))
end

local function ApplyMadIndustrialistSelection(iPlayer, pPlayer)
    local selectedCount = GetRelicSelectionCountForPlayer(pPlayer, 'MADINDUSTRIALISTRUNE')
    local engineerModifier = 'MODIFIER_NW_MADINDUSTRIALIST_ENGINEER_GP_2'
    local merchantModifier = 'MODIFIER_NW_MADINDUSTRIALIST_MERCHANT_GP_2'
    if selectedCount <= 1 then
        engineerModifier = 'MODIFIER_NW_MADINDUSTRIALIST_ENGINEER_GP_1'
        merchantModifier = 'MODIFIER_NW_MADINDUSTRIALIST_MERCHANT_GP_1'
    end

    pPlayer:AttachModifierByID(engineerModifier)
    pPlayer:AttachModifierByID(merchantModifier)
    if selectedCount == 1 then
        pPlayer:AttachModifierByID('MODIFIER_NW_MADINDUSTRIALIST_CIVIC')
    end

    print('[Haikesi GamePlay] MADINDUSTRIALIST player=' .. tostring(iPlayer)
        .. ' count=' .. tostring(selectedCount)
        .. ' engineerModifier=' .. tostring(engineerModifier)
        .. ' merchantModifier=' .. tostring(merchantModifier)
        .. ' unlock=' .. tostring(selectedCount == 1))
end

function Haikesi_ApplyLuaEffect(iPlayer, relicType)
    local pPlayer = Players[iPlayer]
    if pPlayer == nil then
        print("[Haikesi GamePlay] 错误: Haikesi_ApplyLuaEffect — 无效玩家ID: " .. tostring(iPlayer))
        return
    end

    -- The SQL stack was attached in ApplyRelicToPlayer. Keep this branch free
    -- of initialization, load-screen, and per-player synchronization logic.
    if relicType == 'MOREFOODRUNE' then
        return
    end

    -- ==============================
    -- CIRCLEOFDEATH 死亡之环
    -- 删除首都7环内全部非己方单位；删除首都9环外全部己方单位
    -- ==============================
    if relicType == 'CIRCLEOFDEATHRUNE' then
        local pCapital = pPlayer:GetCities():GetCapitalCity()
        if pCapital == nil then
            print("[Haikesi GamePlay] CIRCLEOFDEATH 跳过 — 无首都")
            return
        end
        local capX, capY = pCapital:GetX(), pCapital:GetY()
        local unitsToKill = {}

        -- 非己方单位（含蛮族、城邦、其他文明）：首都 7 环以内
        for iOtherID = 0, 63 do
            if iOtherID ~= iPlayer then
                local pOther = Players[iOtherID]
                if pOther ~= nil then
                    local units = pOther:GetUnits()
                    if units ~= nil then
                        for _, unit in units:Members() do
                            if unit and Map.GetPlotDistance(capX, capY, unit:GetX(), unit:GetY()) <= 7 then
                                table.insert(unitsToKill, unit)
                            end
                        end
                    end
                end
            end
        end

        -- 己方单位：首都 9 环以外
        local myUnits = pPlayer:GetUnits()
        if myUnits ~= nil then
            for _, unit in myUnits:Members() do
                if unit and Map.GetPlotDistance(capX, capY, unit:GetX(), unit:GetY()) > 9 then
                    table.insert(unitsToKill, unit)
                end
            end
        end

        local killCount = 0
        for _, unit in ipairs(unitsToKill) do
            UnitManager.Kill(unit, true)
            killCount = killCount + 1
        end
        print("[Haikesi GamePlay] CIRCLEOFDEATH 删除 " .. killCount .. " 个单位")
        return
    end

    -- ==============================
    -- CERBERUSRUNE: before turn 60, create three scouts in randomized cities.
    -- From turn 60 onward, sacrifice every scout and grant two envoys per scout.
    -- ==============================
    if relicType == 'CERBERUSRUNE' then
        local currentTurn = Game.GetCurrentGameTurn()
        if currentTurn < 60 then
            local cities = {}
            for _, city in pPlayer:GetCities():Members() do
                table.insert(cities, city)
            end
            for index = #cities, 2, -1 do
                local swapIndex = TerrainBuilder.GetRandomNumber(index, 'Cerberus scout city') + 1
                cities[index], cities[swapIndex] = cities[swapIndex], cities[index]
            end
            local created = 0
            for index = 1, 3 do
                local city = cities[((index - 1) % #cities) + 1]
                if UnitManager.InitUnit(iPlayer, 'UNIT_SCOUT', city:GetX(), city:GetY()) then
                    created = created + 1
                end
            end
            print('[Haikesi GamePlay] CERBERUS scouts player=' .. tostring(iPlayer)
                .. ' turn=' .. tostring(currentTurn) .. ' created=' .. tostring(created))
        else
            local scouts = {}
            for _, unit in pPlayer:GetUnits():Members() do
                -- Civ6 Unit instances expose GetType(), not GetUnitType().
                local unitInfo = unit and GameInfo.Units[unit:GetType()]
                if unitInfo and unitInfo.UnitType == 'UNIT_SCOUT' then
                    table.insert(scouts, unit)
                end
            end
            for _, scout in ipairs(scouts) do
                UnitManager.Kill(scout, true)
            end
            local rewardStacks = math.max(1, #scouts)
            for _ = 1, rewardStacks do
                pPlayer:AttachModifierByID('MODIFIER_NW_CERBERUS_GRANT_ENVOYS')
            end
            print('[Haikesi GamePlay] CERBERUS sacrifice player=' .. tostring(iPlayer)
                .. ' turn=' .. tostring(currentTurn) .. ' scouts=' .. tostring(#scouts)
                .. ' envoys=' .. tostring(rewardStacks * 2))
        end
        return
    end

    -- ==============================
    -- COMPENSATIONRUNE 代偿
    -- 当前每城 +1000 金币；随后 30 回合将总额一半分期转给其他主要 AI。
    -- ==============================
    if relicType == 'COMPENSATIONRUNE' then
        StartCompensationSchedule(iPlayer, pPlayer)
        return
    end

    -- 羊刀：攻击次数仍由 SQL 能力在每次选择时叠加；仅前三次选择额外挂 -5 攻击战斗力。
    if relicType == 'FANTHEHAMMERRUNE' then
        local selectedCount = GetRelicSelectionCountForPlayer(pPlayer, 'FANTHEHAMMERRUNE')
        local appliedStacks = tonumber(pPlayer:GetProperty(FANTHEHAMMER_ATTACK_STACKS_KEY) or 1) or 1
        for stack = appliedStacks + 1, selectedCount do
            pPlayer:AttachModifierByID('MODIFIER_NW_FANTHEHAMMER_GRANT_STACK_' .. tostring(stack))
        end
        if selectedCount > appliedStacks then
            pPlayer:SetProperty(FANTHEHAMMER_ATTACK_STACKS_KEY, selectedCount)
        end
        if selectedCount <= 3 then
            pPlayer:AttachModifierByID('MODIFIER_NW_FANTHEHAMMER_ATTACK_PENALTY')
        end
        if selectedCount >= 5 and pPlayer:GetProperty(FANTHEHAMMER_MOVE_AFTER_ATTACK_KEY) ~= 1 then
            pPlayer:AttachModifierByID('MODIFIER_NW_FANTHEHAMMER_GRANT_MOVE_AFTER_ATTACK')
            pPlayer:SetProperty(FANTHEHAMMER_MOVE_AFTER_ATTACK_KEY, 1)
        end
        print('[Haikesi GamePlay] FANTHEHAMMER player=' .. tostring(iPlayer)
            .. ' count=' .. tostring(selectedCount)
            .. ' attackStacks=' .. tostring(math.max(selectedCount, appliedStacks))
            .. ' penaltyApplied=' .. tostring(selectedCount <= 3)
            .. ' moveAfterAttackGranted=' .. tostring(pPlayer:GetProperty(FANTHEHAMMER_MOVE_AFTER_ATTACK_KEY) == 1))
        return
    end

    -- ==============================
    -- MADSCIENTISTRUNE 科学狂人
    -- 首次解锁招募大科学家随机科技；重复选择改为双倍大科学家点数补偿。
    -- ==============================
    if relicType == 'MADSCIENTISTRUNE' then
        ApplyMadScientistSelection(iPlayer, pPlayer)
        return
    end

    -- ==============================
    -- MADINDUSTRIALISTRUNE 工贸狂人
    -- 首次解锁招募大工程师/大商人随机市政；重复选择改为双倍伟人点数补偿。
    -- ==============================
    if relicType == 'MADINDUSTRIALISTRUNE' then
        ApplyMadIndustrialistSelection(iPlayer, pPlayer)
        return
    end

    -- ==============================
    -- DICEMANIAC 掷骰狂人
    -- 后续选择海克斯时，所有海克斯可额外刷新一次（UI 读取刷新修正实现）
    -- ==============================
    if relicType == 'DICEMANIACRUNE' then
        pPlayer:SetProperty(DICEMANIAC_PROP_KEY, 1)
        AddPlayerRerollDelta(pPlayer, 1)
        -- The same-turn bonus relic is selected once in UI and passed through
        -- ExtraRelicTypes. Do not roll again here, or MP peers can persist a
        -- different relic list than the player confirmed.
        print("[Haikesi GamePlay] DICEMANIAC bonus reroll enabled (Player" .. iPlayer .. ")")
        return
    end

    -- ==============================
    -- DOUBLEEXISTENCERUNE 手快全拿
    -- "另外两个海克斯"由 UI 侧通过 ExtraRelicTypes 一并下发，服务端循环 ApplyRelicToPlayer 处理。
    -- 本分支只负责副作用：之后每次海克斯选择的刷新次数 -1（UI 读取刷新修正实现）。
    -- ==============================
    if relicType == 'DOUBLEEXISTENCERUNE' then
        AddPlayerRerollDelta(pPlayer, -1)
        pPlayer:SetProperty(NO_REROLL_PROP_KEY, 0)
        print("[Haikesi GamePlay] DOUBLEEXISTENCE — 刷新次数 -1 (Player" .. iPlayer .. ")")
        return
    end

    -- SPYMASTERRUNE 王牌间谍
    -- 每选 5 次在首都生成一个满级间谍
    -- ==============================
    if relicType == 'SPYMASTERRUNE' then
        local selectedCount = GetRelicSelectionCountForPlayer(pPlayer, 'SPYMASTERRUNE')
        -- Create the spy unit in the capital
        local pCapital = pPlayer:GetCities():GetCapitalCity()
        if pCapital then
            local capX, capY = pCapital:GetX(), pCapital:GetY()
            local pUnit = UnitManager.InitUnit(iPlayer, "UNIT_SPY", capX, capY)
            if pUnit then
                local xpOk, _ = pcall(function() pUnit:GetExperience():ChangeExperience(500) end)
                print("[Haikesi GamePlay] SPYMASTER spy spawned player=" .. tostring(iPlayer)
                    .. " count=" .. tostring(selectedCount)
                    .. " xpOk=" .. tostring(xpOk))
            end
        end
        return
    end

    -- ==============================
    -- MIMICRUNE 仿生模仿：空 Marker 已在 ApplyRelicToPlayer 标记非占位
    -- 抽 10 项 + 弹能力窗 全在 UI 端（math.random），Gameplay 不参与
    -- 玩家在能力窗选定的 Trait 由 HaikesiSelectAbility 挂 Modifier
    -- ==============================
    if relicType == 'MIMICRUNE' then
        print("[Haikesi GamePlay] MIMIC 玩家" .. iPlayer .. " 触发能力选择（UI 端处理）")
        return
    end

    -- ==============================
    -- 占位补偿：无真实效果的海克斯补 100 金币过渡（目前已无残留占位）
    -- ==============================
    if not IsRelicPlaceholder(relicType) then
        return
    end
    pPlayer:GetTreasury():ChangeGoldBalance(100)
    print("[Haikesi GamePlay] Lua 占位补偿：玩家" .. iPlayer .. " 获得 100 金币 → " .. relicType)
end

local function PlayerHasRelic(pPlayer, relicType)
    if pPlayer == nil or relicType == nil then return false end
    for _, selectedRelicType in ipairs(GetSelectedRelicTypeListForPlayer(pPlayer)) do
        if selectedRelicType == relicType then
            return true
        end
    end
    return false
end

local function RestoreUnitMoves(pUnit)
    if pUnit == nil or pUnit.GetMaxMoves == nil or pUnit.GetMovesRemaining == nil then
        return false, 'missing unit movement API'
    end

    local maxMoves = pUnit:GetMaxMoves()
    local currentMoves = pUnit:GetMovesRemaining()
    if maxMoves == nil or currentMoves == nil then
        return false, 'nil moves'
    end

    local delta = maxMoves - currentMoves
    if delta <= 0 then
        return true, 'already full'
    end

    if pUnit.ChangeMovesRemaining ~= nil then
        pUnit:ChangeMovesRemaining(delta)
        return true, 'unit ChangeMovesRemaining +' .. tostring(delta)
    end
    if UnitManager ~= nil and UnitManager.ChangeMovesRemaining ~= nil then
        UnitManager.ChangeMovesRemaining(pUnit, delta)
        return true, 'UnitManager ChangeMovesRemaining +' .. tostring(delta)
    end

    return false, 'no ChangeMovesRemaining API'
end

local function GetBestUnlockedMeleeUnitType(iPlayer, pPlayer)
    if pPlayer == nil or pPlayer:GetTechs() == nil or pPlayer:GetCulture() == nil then return nil end

    local playerTechs = pPlayer:GetTechs()
    local playerCulture = pPlayer:GetCulture()
    local bestUnitType = nil
    local bestCombat = -1
    local bestCost = math.huge
    for unitInfo in GameInfo.Units() do
        if unitInfo.Domain == 'DOMAIN_LAND' and unitInfo.PromotionClass == 'PROMOTION_CLASS_MELEE' then
            local isUnlocked = true
            if unitInfo.PrereqTech ~= nil then
                local techInfo = GameInfo.Technologies[unitInfo.PrereqTech]
                isUnlocked = techInfo ~= nil and playerTechs:HasTech(techInfo.Index)
            end
            if isUnlocked and unitInfo.PrereqCivic ~= nil then
                local civicInfo = GameInfo.Civics[unitInfo.PrereqCivic]
                isUnlocked = civicInfo ~= nil and playerCulture:HasCivic(civicInfo.Index)
            end
            if isUnlocked and unitInfo.TraitType ~= nil then
                isUnlocked = PlayerHasTrait(iPlayer, unitInfo.TraitType)
            end
            if isUnlocked then
                local combat = tonumber(unitInfo.Combat) or 0
                local cost = tonumber(unitInfo.Cost) or math.huge
                if combat > bestCombat or (combat == bestCombat and cost < bestCost) then
                    bestUnitType = unitInfo.UnitType
                    bestCombat = combat
                    bestCost = cost
                end
            end
        end
    end
    return bestUnitType
end

local function OnNewCityRelicRewards(iPlayer, cityID, cityX, cityY)
    local ok, err = pcall(function()
        local pPlayer = Players[iPlayer]
        if pPlayer == nil or pPlayer:GetCities() == nil then return end

        local builderCount = GetRelicSelectionCountForPlayer(pPlayer, 'OTTERANDFRIENDSRUNE')
        local meleeCount = GetRelicSelectionCountForPlayer(pPlayer, 'ONELANEBRIDGERUNE')
        if builderCount <= 0 and meleeCount <= 0 then return end

        local pCity = pPlayer:GetCities():FindID(cityID)
        if pCity == nil then return end
        local x = cityX or pCity:GetX()
        local y = cityY or pCity:GetY()

        for _ = 1, builderCount do
            UnitManager.InitUnit(iPlayer, 'UNIT_BUILDER', x, y)
        end

        local meleeUnitType = nil
        if meleeCount > 0 then
            meleeUnitType = GetBestUnlockedMeleeUnitType(iPlayer, pPlayer)
            if meleeUnitType ~= nil then
                for _ = 1, meleeCount do
                    UnitManager.InitUnit(iPlayer, meleeUnitType, x, y)
                end
            end
        end

        print('[Haikesi GamePlay] NEW_CITY_RELIC_REWARDS player=' .. tostring(iPlayer)
            .. ' city=' .. tostring(cityID)
            .. ' builders=' .. tostring(builderCount)
            .. ' melee=' .. tostring(meleeCount)
            .. ' meleeType=' .. tostring(meleeUnitType))
    end)
    if not ok then
        print('[Haikesi GamePlay] NEW_CITY_RELIC_REWARDS handler error: ' .. tostring(err))
    end
end

local function AddHeartsteelStack(iPlayer, pUnit)
    local pPlayer = Players[iPlayer]
    if pPlayer == nil or pUnit == nil or not PlayerHasRelic(pPlayer, 'HANDOFBARONRUNE') then return end
    if pUnit:IsDead() or pUnit:IsDelayedDeath() then return end

    local unitInfo = GameInfo.Units[pUnit:GetType()]
    if unitInfo == nil or ((tonumber(unitInfo.Combat) or 0) <= 0 and (tonumber(unitInfo.RangedCombat) or 0) <= 0) then
        return
    end

    local unitAbility = pUnit:GetAbility()
    if unitAbility == nil then return end

    local selectedLayers = math.min(10, GetSelectedRelicCountsForPlayer(pPlayer)['HANDOFBARONRUNE'] or 0)
    if selectedLayers <= 0 then return end

    local currentStacks = tonumber(pUnit:GetProperty(HEARTSTEEL_STACKS_KEY) or 0) or 0
    if currentStacks >= 1000 then return end
    local nextStack = math.min(1000, currentStacks + selectedLayers)

    -- 清理此前所有心之钢 Ability，再只挂载新的累计层级。
    -- 前 10 级逐个清理用于兼容旧测试存档；新方案只需额外移除当前累计层级。
    for stack = 1, 10 do
        local oldAbilityType = 'ABILITY_NW_HEARTSTEEL_STACK_' .. tostring(stack)
        local oldCount = unitAbility:GetAbilityCount(oldAbilityType)
        if oldCount ~= nil and oldCount > 0 then
            unitAbility:ChangeAbilityCount(oldAbilityType, -oldCount)
        end
    end
    if currentStacks > 10 then
        local currentAbilityType = 'ABILITY_NW_HEARTSTEEL_STACK_' .. tostring(currentStacks)
        local currentCount = unitAbility:GetAbilityCount(currentAbilityType)
        if currentCount ~= nil and currentCount > 0 then
            unitAbility:ChangeAbilityCount(currentAbilityType, -currentCount)
        end
    end
    unitAbility:ChangeAbilityCount('ABILITY_NW_HEARTSTEEL_STACK_' .. tostring(nextStack), 1)
    pUnit:SetProperty(HEARTSTEEL_STACKS_KEY, nextStack)
    print('[Haikesi GamePlay] HEARTSTEEL player=' .. tostring(iPlayer)
        .. ' unit=' .. tostring(pUnit:GetID())
        .. ' selectedLayers=' .. tostring(selectedLayers)
        .. ' stacks=' .. tostring(nextStack))
end

local function OnCombatOccurred(attackerPlayerID, attackerUnitID, defenderPlayerID, defenderUnitID)
    local ok, err = pcall(function()
        if attackerPlayerID == nil or attackerUnitID == nil or defenderPlayerID == nil or defenderUnitID == nil then
            return
        end

        local pAttackerPlayer = Players[attackerPlayerID]
        local pDefenderPlayer = Players[defenderPlayerID]
        if pAttackerPlayer == nil or pDefenderPlayer == nil then return end

        local pAttackerUnit = pAttackerPlayer:GetUnits():FindID(attackerUnitID)
        local pDefenderUnit = pDefenderPlayer:GetUnits():FindID(defenderUnitID)

        -- 官方 Gameplay 事件在战斗结算后触发；仅给仍然存活的军事单位立即增加一层。
        AddHeartsteelStack(attackerPlayerID, pAttackerUnit)
        AddHeartsteelStack(defenderPlayerID, pDefenderUnit)

        if pAttackerUnit == nil then return end

        if not PlayerHasRelic(pAttackerPlayer, 'ARCANEPUNCHRUNE') then return end

        local monkInfo = GameInfo.Units['UNIT_WARRIOR_MONK']
        if monkInfo == nil or pAttackerUnit:GetType() ~= monkInfo.Index then return end

        if pDefenderUnit ~= nil and not pDefenderUnit:IsDead() and not pDefenderUnit:IsDelayedDeath() then return end

        local restored, path = RestoreUnitMoves(pAttackerUnit)
        print('[Haikesi GamePlay] ARCANEPUNCH kill restore player=' .. tostring(attackerPlayerID)
            .. ' unit=' .. tostring(attackerUnitID)
            .. ' restored=' .. tostring(restored)
            .. ' path=' .. tostring(path))
    end)
    if not ok then
        print('[Haikesi GamePlay] COMBAT handler error: ' .. tostring(err))
    end
end

--||======================= INIT ========================||--
function Initialize()
    -- 构建 RelicType → ModifierId[] 内存 Map（一次性，替代运行时全表遍历）
    g_RelicModifierMap = {}
    local rowCount = 0
    for row in GameInfo.Haikesi_Relic_Modifiers() do
        if not g_RelicModifierMap[row.RelicType] then
            g_RelicModifierMap[row.RelicType] = {}
        end
        table.insert(g_RelicModifierMap[row.RelicType], row.ModifierId)
        rowCount = rowCount + 1
    end
    print("[Haikesi GamePlay] RelicModifierMap 构建完成，行数 = " .. rowCount)

    GameEvents.HaikesiSelectRelic.Add(HaikesiSelectRelic)
    GameEvents.HaikesiSelectAbility.Add(HaikesiSelectAbility)
    if GameEvents.PlayerTurnStarted ~= nil then
        GameEvents.PlayerTurnStarted.Add(OnCompensationPlayerTurnStarted)
    elseif Events.PlayerTurnActivated ~= nil then
        Events.PlayerTurnActivated.Add(OnCompensationPlayerTurnStarted)
    else
        print("[Haikesi GamePlay] COMPENSATION warning: no player turn event available")
    end
    if GameEvents.OnCombatOccurred ~= nil then
        GameEvents.OnCombatOccurred.Add(OnCombatOccurred)
    else
        print("[Haikesi GamePlay] COMBAT warning: GameEvents.OnCombatOccurred unavailable")
    end
    if GameEvents.CityBuilt ~= nil then
        GameEvents.CityBuilt.Add(OnNewCityRelicRewards)
    else
        print("[Haikesi GamePlay] NEW_CITY_RELIC_REWARDS warning: GameEvents.CityBuilt unavailable")
    end

    print("[Haikesi GamePlay] Script 初始化完成")
end

 Events.LoadScreenClose.Add(Initialize)
