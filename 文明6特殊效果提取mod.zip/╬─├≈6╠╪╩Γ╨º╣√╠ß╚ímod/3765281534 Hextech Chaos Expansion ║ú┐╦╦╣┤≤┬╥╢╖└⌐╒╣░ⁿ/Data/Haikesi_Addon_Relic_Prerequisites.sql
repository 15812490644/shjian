-- ===========================================================================
-- 海克斯大乱斗扩展包：恢复海克斯刷新池前置条件。
--
-- Haikesi_Addon_Relics.sql 会清空并重建 Haikesi_Relics；原版前置条件表
-- 通过外键 ON DELETE CASCADE 关联该表，因此必须在重建完成后重新创建并填充。
-- ===========================================================================

DROP TABLE IF EXISTS Haikesi_Relic_Prerequisites;
CREATE TABLE Haikesi_Relic_Prerequisites (
    RelicType        TEXT NOT NULL,
    PrerequisiteKind TEXT NOT NULL,
    PrerequisiteType TEXT NOT NULL,
    AllowInProgress INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (RelicType, PrerequisiteKind, PrerequisiteType),
    FOREIGN KEY (RelicType) REFERENCES Haikesi_Relics(RelicType) ON DELETE CASCADE ON UPDATE CASCADE,
    CHECK (PrerequisiteKind IN ('RELIC', 'TECHNOLOGY', 'TRAIT', 'EXCLUDE_TRAIT')),
    CHECK (AllowInProgress IN (0, 1))
);

-- 信仰值 / 圣地相关海克斯：已研究占星术，或当前正在研究占星术，才进入刷新池。
INSERT INTO Haikesi_Relic_Prerequisites
    (RelicType, PrerequisiteKind, PrerequisiteType, AllowInProgress) VALUES
    ('MIKAELSBLESSINGRUNE',   'TECHNOLOGY', 'TECH_ASTROLOGY', 1);

-- 特色区域升级：只有拥有对应文明 Trait 的玩家才能刷到。
INSERT INTO Haikesi_Relic_Prerequisites
    (RelicType, PrerequisiteKind, PrerequisiteType, AllowInProgress) VALUES
    ('DRAWYOURSWORDRUNE',     'TRAIT', 'TRAIT_CIVILIZATION_ROYAL_NAVY_DOCKYARD', 0),
    ('DUALWIELDRUNE',         'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_COTHON', 0),
    ('EXPLOSIONARTRUNE',      'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_HANSA', 0),
    ('FEELTHEBURNRUNE',       'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_SUGUBA', 0),
    ('FEYMAGICRUNE',          'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_ACROPOLIS', 0),
    ('FLYINGKICKRUNE',        'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_SEOWON', 0),
    ('CANTTOUCHTHISRUNE',     'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_BATH', 0),
    ('FORBIDDENGRIMOIRERUNE', 'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_MBANZA', 0),
    ('GHOSTFORMRUNE',         'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_STREET_CARNIVAL', 0),
    ('GIANTSLAYERRUNE',       'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_IKANDA', 0),
    ('GOLIATHRUNE',           'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_HIPPODROME', 0),
    ('JEWELEDGAUNTLETRUNE',   'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_OPPIDUM', 0),
    ('MASTEROFDUALITYRUNE',   'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_THANH', 0),
    ('LAVRAUPGRADERUNE',      'TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_LAVRA', 0);

-- 德国和高卢已有各自的工业区升级，排除通用“超负荷”。
INSERT INTO Haikesi_Relic_Prerequisites
    (RelicType, PrerequisiteKind, PrerequisiteType, AllowInProgress) VALUES
    ('COREOVERLOADRUNE', 'EXCLUDE_TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_HANSA', 0),
    ('COREOVERLOADRUNE', 'EXCLUDE_TRAIT', 'TRAIT_CIVILIZATION_DISTRICT_OPPIDUM', 0);
