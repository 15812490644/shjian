-- AI 重复规则；原版 AI 海克斯行由依赖项先创建。
UPDATE Haikesi_Relics SET IsRepeatable = 1, MaxSelections = NULL WHERE RelicType IN (
    'NW_AI_STATS_1', 'NW_AI_STATS_2', 'NW_AI_STATS_3',
    'NW_AI_STATS_4', 'NW_AI_STATS_5', 'NW_AI_STATS_6'
);

UPDATE Haikesi_Relics SET IsRepeatable = 1, MaxSelections = 3
WHERE RelicType = 'NW_AI_ECHO_SETTLER';
UPDATE Haikesi_Relics SET IsRepeatable = 1, MaxSelections = 6
WHERE RelicType = 'NW_AI_ECHO_BUILDER';
UPDATE Haikesi_Relics SET IsRepeatable = 1, MaxSelections = 8 WHERE RelicType IN (
    'NW_AI_ECHO_MELEE', 'NW_AI_ECHO_RANGED', 'NW_AI_ECHO_LIGHT_CAVALRY',
    'NW_AI_ECHO_HEAVY_CAVALRY', 'NW_AI_ECHO_ANTI_CAVALRY'
);
UPDATE Haikesi_Relics SET IsRepeatable = 1, MaxSelections = 5
WHERE RelicType = 'NW_AI_ECHO_SIEGE';
