-- 原版已经建立 NwHaikesiMode；扩展包只追加“渐进模式”。
INSERT OR REPLACE INTO DomainValues
    (Domain, Value, Name, Description, SortIndex)
VALUES
    ('NwHaikesiMode', 5,
     'LOC_NW_HAIKESI_MODE_PROGRESSIVE_NAME',
     'LOC_NW_HAIKESI_MODE_PROGRESSIVE_DESC',
     60);
