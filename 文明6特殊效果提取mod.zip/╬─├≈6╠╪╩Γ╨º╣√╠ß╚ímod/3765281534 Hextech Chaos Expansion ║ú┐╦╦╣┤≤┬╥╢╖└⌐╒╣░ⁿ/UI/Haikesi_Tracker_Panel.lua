-- Haikesi_Tracker_Panel.lua
include("InstanceManager")
include("TabSupport")
include("Civ6Common")

local m_tabButtonIM = InstanceManager:new("TabButtonInstance", "Button", Controls.TabContainer)
local m_PlayerRowIM = InstanceManager:new("HaikesiPlayerRow", "Content", Controls.PlayerStack)
local m_EncyclopediaIM = InstanceManager:new("HaikesiEncyclopediaEntry", "Content", Controls.EncyclopediaStack)
local m_tabs = nil
local m_HomeTabInstance = nil

local IndexToRelic = {}
local RelicTypeToRelic = {}
local HAIKESI_RELICS_PROP_KEY = "PROP_NW_HAIKESI_RELICS"
local HAIKESI_RELIC_COUNT_KEY = "PROP_NW_HAIKESI_RELIC_COUNT"
local HAIKESI_RELIC_SLOT_PREFIX = "PROP_NW_HAIKESI_RELIC_"
local HEARTSTEEL_SOUND_EVENT = "HAIKESI_HEARTSTEEL_STACK"

local FALLBACK_MAX_SELECTIONS = {
    EARTHAWAKENSRUNE = 50,
    MOREFOODRUNE = 50,
    SLOWCOOKRUNE = 3,
    BACKTOBASICSRUNE = 10,
    CLOWNCOLLEGERUNE = 10,
    CLOWNTHEATERRUNE = 10,
    SPYMASTERRUNE = 6,
    SURPLUSGRAINRUNE = 10,
}

local function BuildIndexMap()
    IndexToRelic = {}
    RelicTypeToRelic = {}
    for row in GameInfo.Haikesi_Relics() do
        IndexToRelic[row.Index] = row
        RelicTypeToRelic[row.RelicType] = row
    end
end

local function GetRelicCardsForPlayer(pPlayer)
    local relicCards = {}
    local count = tonumber(pPlayer:GetProperty(HAIKESI_RELIC_COUNT_KEY) or 0) or 0
    local hasSlotData = false

    if count > 0 then
        for i = 1, count do
            local relicType = pPlayer:GetProperty(HAIKESI_RELIC_SLOT_PREFIX .. i)
            local relicRow = RelicTypeToRelic[relicType]
            if relicRow ~= nil then
                table.insert(relicCards, relicRow)
                hasSlotData = true
            end
        end
    end
    if hasSlotData then
        return relicCards
    end

    local prop = pPlayer:GetProperty(HAIKESI_RELICS_PROP_KEY) or ""
    if prop ~= "" then
        for idxStr in string.gmatch(prop, "[^|]+") do
            local idx = tonumber(idxStr)
            local relicRow = IndexToRelic[idx]
            if relicRow ~= nil then
                table.insert(relicCards, relicRow)
            end
        end
    end
    return relicCards
end

local function GetAggregatedRelicCardsForPlayer(pPlayer)
    local groupedCards = {}
    local groupedByType = {}

    for _, relicRow in ipairs(GetRelicCardsForPlayer(pPlayer)) do
        local relicType = relicRow.RelicType
        local entry = groupedByType[relicType]
        if entry == nil then
            entry = { Row = relicRow, Count = 0 }
            groupedByType[relicType] = entry
            table.insert(groupedCards, entry)
        end
        entry.Count = entry.Count + 1
    end

    return groupedCards
end

local function PlayerHasHeartsteel(pPlayer)
    for _, relicRow in ipairs(GetRelicCardsForPlayer(pPlayer)) do
        if relicRow.RelicType == "HANDOFBARONRUNE" then
            return true
        end
    end
    return false
end

local function OnHeartsteelCombatVisEnd(combatVisData)
    local localPlayerID = Game.GetLocalPlayer()
    local pLocalPlayer = Players[localPlayerID]
    if pLocalPlayer == nil or combatVisData == nil or not PlayerHasHeartsteel(pLocalPlayer) then return end

    local localSurvivingUnit = nil
    local hasEnemyUnit = false

    for _, participant in ipairs(combatVisData) do
        if participant.componentType == ComponentType.UNIT then
            if participant.playerID == localPlayerID then
                local pUnit = pLocalPlayer:GetUnits():FindID(participant.componentID)
                if pUnit ~= nil and not pUnit:IsDead() and not pUnit:IsDelayedDeath() then
                    localSurvivingUnit = pUnit
                end
            else
                hasEnemyUnit = true
            end
        end
    end

    if localSurvivingUnit ~= nil and hasEnemyUnit then
        UI.PlaySound(HEARTSTEEL_SOUND_EVENT)
        print("[Haikesi Tracker] HEARTSTEEL_SOUND unit=" .. tostring(localSurvivingUnit:GetID()))
    end
end

local function GetMaxSelectionsText(relicRow)
    local maxSelections = tonumber(relicRow.MaxSelections) or FALLBACK_MAX_SELECTIONS[relicRow.RelicType]
    if maxSelections ~= nil then
        return tostring(maxSelections)
    end
    local repeatable = (relicRow.IsRepeatable == 1 or relicRow.IsRepeatable == "1" or relicRow.IsRepeatable == true)
    if repeatable then
        return "∞"
    end
    return "1"
end

local function GetCurrentEffectText(relicType, selectedCount)
    if selectedCount <= 0 then return nil end

    if relicType == "EARTHAWAKENSRUNE" then
        return string.format("当前效果：矿山 +%d [ICON_Production] 生产力。", selectedCount)
    elseif relicType == "MOREFOODRUNE" then
        return string.format("当前效果：矿山 +%d [ICON_Food] 食物。", selectedCount)
    elseif relicType == "SLOWCOOKRUNE" then
        return string.format("当前效果：农场 +%d [ICON_Food] 食物。", selectedCount * 3)
    elseif relicType == "BACKTOBASICSRUNE" then
        return string.format("当前效果：所有城市全部产出 +%d%%。", selectedCount * 10)
    elseif relicType == "CLOWNCOLLEGERUNE" then
        return string.format("当前效果：学院 +%d [ICON_Science] 科技值；图书馆 +%d [ICON_Science] 科技值；大学 +%d [ICON_Science] 科技值；研究实验室 +%d [ICON_Science] 科技值。",
            selectedCount, selectedCount * 2, selectedCount * 3, selectedCount * 4)
    elseif relicType == "CLOWNTHEATERRUNE" then
        return string.format("当前效果：剧院广场 +%d [ICON_Culture] 文化值；圆形剧场 +%d [ICON_Culture] 文化值；博物馆 +%d [ICON_Culture] 文化值；广播中心 +%d [ICON_Culture] 文化值。",
            selectedCount, selectedCount * 2, selectedCount * 3, selectedCount * 4)
    elseif relicType == "SURPLUSGRAINRUNE" then
        return string.format("当前效果：所有城市 +%d [ICON_Amenities] 宜居度。", selectedCount * 1)
    elseif relicType == "BREADSANDWICHRUNE" then
        return string.format("当前效果：所有城市 +%d [ICON_Amenities] 宜居度。", selectedCount)
    end

    return nil
end

local function BuildTooltip(pPlayer, relicRow, selectedCount)
    local tooltip = Locale.Lookup(relicRow.Description) or ""
    local currentEffect = GetCurrentEffectText(relicRow.RelicType, selectedCount)
    if currentEffect ~= nil then
        tooltip = tooltip .. "[NEWLINE][NEWLINE]" .. currentEffect
    end

    if relicRow.RelicType == "MIMICRUNE" then
        local trait = pPlayer:GetProperty("PROP_NW_HAIKESI_MIMIC_TRAIT")
        local tInfo = trait and GameInfo.Traits[trait] or nil
        if tInfo and tInfo.Name and tInfo.Description then
            tooltip = tooltip
                .. "[NEWLINE][NEWLINE]"
                .. "[COLOR:ResScienceLabelCS]" .. Locale.Lookup(tInfo.Name) .. "[ENDCOLOR]"
                .. "[NEWLINE]"
                .. Locale.Lookup(tInfo.Description)
        end
    end

    return tooltip
end

local function ResetAreas()
    Controls.TrackerArea:SetHide(true)
    Controls.EncyclopediaArea:SetHide(true)
end

local function Refresh()
    m_PlayerRowIM:ResetInstances()
    BuildIndexMap()

    for _, pPlayer in ipairs(PlayerManager.GetAliveMajors()) do
        local groupedCards = GetAggregatedRelicCardsForPlayer(pPlayer)
        if #groupedCards > 0 then
            local playerID = pPlayer:GetID()
            local rowInstance = m_PlayerRowIM:GetInstance()
            local pConfig = PlayerConfigurations[playerID]

            rowInstance.PlayerName:SetText(Locale.Lookup(pConfig:GetPlayerName()))
            rowInstance.CivIcon:SetIcon("ICON_" .. pConfig:GetLeaderTypeName())

            local relicGrid = rowInstance.RelicGrid
            relicGrid:DestroyAllChildren()

            local rowIM = InstanceManager:new("HaikesiRelicRow", "Content", relicGrid)
            local cardIM = nil
            for i, entry in ipairs(groupedCards) do
                if (i - 1) % 6 == 0 then
                    local rowInst = rowIM:GetInstance()
                    cardIM = InstanceManager:new("HaikesiRelicCard", "Content", rowInst.Content)
                end

                local relicRow = entry.Row
                local selectedCount = entry.Count
                local card = cardIM:GetInstance()
                card.CardIcon:SetIcon(relicRow.Icon)
                card.CardIcon:SetToolTipString(BuildTooltip(pPlayer, relicRow, selectedCount))
                local localizedName = Locale.Lookup(relicRow.Name)
                local countText = string.format("%d/%s", selectedCount, GetMaxSelectionsText(relicRow))
                if card.CardCount ~= nil then
                    card.CardName:SetText(localizedName)
                    card.CardCount:SetText(countText)
                    card.CardCount:SetToolTipString(localizedName)
                else
                    -- 兼容原版 XML：即使 CardCount 控件未被 VFS 覆盖，也显示次数。
                    card.CardName:SetText(localizedName .. "[NEWLINE]" .. countText)
                end
            end

            relicGrid:CalculateSize()
            if rowInstance.Content.ReprocessAnchoring ~= nil then
                rowInstance.Content:ReprocessAnchoring()
            end
        end
    end

    Controls.PlayerStack:CalculateSize()
    Controls.PlayerScroller:CalculateSize()
end

local function InitEncyclopediaData()
    m_EncyclopediaIM:ResetInstances()
    BuildIndexMap()

    local rows = {}
    local mode = GameConfiguration.GetValue("NW_HAIKESI_MODE") or 0
    local isDevMode = (mode == 3)

    for row in GameInfo.Haikesi_Relics() do
        local isActive = (row.IsActive == 1 or row.IsActive == "1" or row.IsActive == true)
        local desc = Locale.Lookup(row.Description) or ""
        if isDevMode or (isActive and desc ~= "" and desc ~= "效果待填充") then
            table.insert(rows, row)
        end
    end

    table.sort(rows, function(a, b)
        return (a.Index or 0) < (b.Index or 0)
    end)

    for _, row in ipairs(rows) do
        local instance = m_EncyclopediaIM:GetInstance()
        instance.RelicIcon:SetIcon(row.Icon)
        instance.RelicName:SetText(Locale.ToUpper(Locale.Lookup(row.Name)))
        local desc = Locale.Lookup(row.Description) or ""
        if desc == "" or desc == "效果待填充" then
            desc = "（暂无描述 - " .. tostring(row.RelicType) .. "）"
        end
        instance.RelicDesc:SetText(desc)
        instance.RelicFlavor:SetText(Locale.Lookup(row.Flavor) or "")
    end

    Controls.EncyclopediaStack:CalculateSize()
    Controls.EncyclopediaScroller:CalculateSize()
end

local function ViewTracker()
    ResetAreas()
    Controls.TrackerArea:SetHide(false)
    Refresh()
end

local function ViewEncyclopedia()
    ResetAreas()
    Controls.EncyclopediaArea:SetHide(false)
    InitEncyclopediaData()
end

local function SetTabButtonsSelected(selectedButton)
    if m_HomeTabInstance and m_HomeTabInstance.Button then
        m_HomeTabInstance.Button:SetSelected(m_HomeTabInstance.Button == selectedButton)
    end
end

local function OnTrackerTabClick()
    SetTabButtonsSelected(m_HomeTabInstance.Button)
    ViewTracker()
end

local function OnEncyclopediaTabClick()
    ViewEncyclopedia()
end

local function Close()
    if UIManager:DequeuePopup(ContextPtr) then
        UI.PlaySound("UI_Screen_Close")
    end
end

local function Open()
    if UIManager:IsInPopupQueue(ContextPtr) then
        return
    end

    local parameters = {}
    parameters.RenderAtCurrentParent = true
    parameters.InputAtCurrentParent = true
    parameters.AlwaysVisibleInQueue = true
    UIManager:QueuePopup(ContextPtr, PopupPriority.Low, parameters)
    UI.PlaySound("UI_Screen_Open")
end

local function OnToggle()
    if UIManager:IsInPopupQueue(ContextPtr) then
        Close()
    else
        Open()
    end
end

local function OnShow()
    if m_HomeTabInstance ~= nil then
        SetTabButtonsSelected(m_HomeTabInstance.Button)
    end
    ViewTracker()
end

local function OnInputHandler(input)
    if input:GetMessageType() == KeyEvents.KeyUp and input:GetKey() == Keys.VK_ESCAPE then
        Close()
        return true
    end
    return false
end

local function AddTabInstance(buttonText, callbackFunc)
    local instance = m_tabButtonIM:GetInstance()
    instance.Button:SetText(Locale.Lookup(buttonText))
    instance.Button:RegisterCallback(Mouse.eMouseEnter, function()
        UI.PlaySound("Main_Menu_Mouse_Over")
    end)
    m_tabs.AddTab(instance.Button, callbackFunc)
    return instance
end

local function Initialize()
    BuildIndexMap()
    ContextPtr:SetHide(true)
    ContextPtr:SetInputHandler(OnInputHandler, true)
    ContextPtr:SetShowHandler(OnShow)

    Controls.ModalScreenClose:RegisterCallback(Mouse.eLClick, Close)
    Controls.ModalBG:SetHide(true)
    Controls.ModalScreenTitle:SetText(Locale.Lookup("LOC_HAIKESI_TRACKER_TITLE"))

    m_tabs = CreateTabs(Controls.TabContainer, 42, 34, UI.GetColorValueFromHexLiteral(0xFF331D05))
    m_HomeTabInstance = AddTabInstance("LOC_HAIKESI_TRACKER_TAB_SELECTED", OnTrackerTabClick)
    AddTabInstance("LOC_HAIKESI_TRACKER_TAB_ENCYCLOPEDIA", OnEncyclopediaTabClick)

    Controls.TabContainer:SetSizeX(350)
    m_tabs.CenterAlignTabs(-10)

    LuaEvents.Haikesi_ToggleTracker.Add(OnToggle)
    Events.CombatVisEnd.Add(OnHeartsteelCombatVisEnd)
end

function OnInit(isReload)
    if isReload then
        LuaEvents.Haikesi_ToggleTracker.Remove(OnToggle)
        Events.CombatVisEnd.Remove(OnHeartsteelCombatVisEnd)
    end
    Initialize()
end

ContextPtr:SetInitHandler(OnInit)
