-- Haikesi_Tracker_EntryButton.lua
local m_LaunchButtonInstance = {}
local m_HasPendingSelection = false

local function HasPendingMimicChoice()
    local localPlayerID = Game.GetLocalPlayer()
    if localPlayerID == nil or localPlayerID == PlayerTypes.NONE then return false end
    local pPlayer = Players[localPlayerID]
    if pPlayer == nil then return false end

    local hasMimic = (pPlayer:GetProperty("PROPERTY_NW_HAIKESI_MIMIC") or 0) > 0
    local hasChosenTrait = pPlayer:GetProperty("PROP_NW_HAIKESI_MIMIC_TRAIT") ~= nil
    return hasMimic and not hasChosenTrait
end

function Toggle_HaikesiTracker_Popup()
    if HasPendingMimicChoice() then
        LuaEvents.Haikesi_OpenAbilityPanel()
        return
    end

    if not m_HasPendingSelection then
        LuaEvents.Haikesi_ToggleTracker()
        return
    end

    -- 仅在玩家隐藏了待选面板时唤回选卡；确认选择后按钮只打开追踪面板。
    LuaEvents.Haikesi_TogglePanel()
    Timer.After(0.03, function()
        local panel = ContextPtr:LookUpControl('/InGame/HaikesiPanel')
        if panel == nil or panel:IsHidden() then
            -- 无待选海克斯，打开追踪面板
            LuaEvents.Haikesi_ToggleTracker()
        end
    end)
end

local function OnPendingSelection()
    m_HasPendingSelection = true
end

local function OnClearPendingSelection()
    m_HasPendingSelection = false
end

local function InjectLaunchButton()
    local buttonStack = ContextPtr:LookUpControl("/InGame/LaunchBar/ButtonStack")
    if buttonStack == nil then
        return false
    end

    ContextPtr:BuildInstanceForControl("HaikesiTracker_Info", m_LaunchButtonInstance, buttonStack)
    m_LaunchButtonInstance.HaikesiTracker_InfoIcon:SetIcon("ICON_HAIKESI_RELIC_ARCANEPUNCHRUNE")
    m_LaunchButtonInstance.HaikesiTracker_InfoButton:RegisterCallback(Mouse.eLClick, Toggle_HaikesiTracker_Popup)
    ContextPtr:BuildInstanceForControl("HaikesiTracker_PinInstance", {}, buttonStack)

    buttonStack:CalculateSize()
    local backing = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBacking")
    if backing ~= nil then
        backing:SetSizeX(buttonStack:GetSizeX() + 116)
    end
    local backingTile = ContextPtr:LookUpControl("/InGame/LaunchBar/LaunchBackingTile")
    if backingTile ~= nil then
        backingTile:SetSizeX(buttonStack:GetSizeX() - 20)
    end
    LuaEvents.LaunchBar_Resize(buttonStack:GetSizeX())
    return true
end

local function OnLoadScreenClose()
    if InjectLaunchButton() then
        Events.LoadScreenClose.Remove(OnLoadScreenClose)
    end
end

function Initialize()
    local localPlayerID = Game.GetLocalPlayer()
    if localPlayerID ~= nil and localPlayerID ~= PlayerTypes.NONE and Players[localPlayerID] ~= nil and Players[localPlayerID]:IsHuman() then
        LuaEvents.Haikesi_PendingSelection.Add(OnPendingSelection)
        LuaEvents.Haikesi_ClearPendingSelection.Add(OnClearPendingSelection)
        if not InjectLaunchButton() then
            Events.LoadScreenClose.Add(OnLoadScreenClose)
        end
    end
end

function OnInit(isReload)
    if isReload then
        Events.LoadScreenClose.Remove(OnLoadScreenClose)
        LuaEvents.Haikesi_PendingSelection.Remove(OnPendingSelection)
        LuaEvents.Haikesi_ClearPendingSelection.Remove(OnClearPendingSelection)
    end
    Initialize()
end

ContextPtr:SetInitHandler(OnInit)
